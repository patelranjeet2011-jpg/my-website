<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Talk Show - KMFSL | Expert Insights & Financial Discussions</title>
    <meta name="description" content="Watch KMFSL's Digital Talk Show featuring expert interviews, asset recovery insights, investment tips, and success stories from financial recovery specialists.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>

    
    <!-- Search and Filter Section -->
    <!-- Digital Talk Show Hero Section -->
    <section class="section-padding bg-gradient-to-br from-red-50 via-white to-pink-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <div class="inline-flex items-center bg-red-100 text-red-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 352 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M176 352c53.02 0 96-42.98 96-96V96c0-53.02-42.98-96-96-96S80 42.98 80 96v160c0 53.02 42.98 96 96 96zm160-160h-16c-8.84 0-16 7.16-16 16v48c0 74.8-64.49 134.82-140.79 127.38C96.71 376.89 48 317.11 48 250.3V208c0-8.84-7.16-16-16-16H16c-8.84 0-16 7.16-16 16v40.16c0 89.64 63.97 169.55 152 181.69V464H96c-8.84 0-16 7.16-16 16v16c0 8.84 7.16 16 16 16h160c8.84 0 16-7.16 16-16v-16c0-8.84-7.16-16-16-16h-56v-33.77C285.71 418.47 352 344.9 352 256v-48c0-8.84-7.16-16-16-16z"></path>
                    </svg>
                    KMFSL Digital Talk Show
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">Digital <span class="text-gradient">Talk Show</span></h1>
                <p class="text-xl text-secondary-600 max-w-4xl mx-auto leading-relaxed mb-8">Join our experts for insightful discussions on asset recovery, investment strategies, market trends, and success stories. Get expert advice and stay updated with the latest developments in the financial services industry.</p>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-6 h-6 text-red-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">50+</div>
                        <div class="text-sm text-secondary-600">Episodes</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-6 h-6 text-blue-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">500K+</div>
                        <div class="text-sm text-secondary-600">Total Views</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-green-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M256 32C114.52 32 0 146.496 0 288v48a32 32 0 0 0 17.689 28.622l14.383 7.191C34.083 431.903 83.421 480 144 480h24c13.255 0 24-10.745 24-24V280c0-13.255-10.745-24-24-24h-24c-31.342 0-59.671 12.879-80 33.627V288c0-105.869 86.131-192 192-192s192 86.131 192 192v1.627C427.671 268.879 399.342 256 368 256h-24c-13.255 0-24 10.745-24 24v176c0 13.255 10.745 24 24 24h24c60.579 0 109.917-48.098 111.928-108.187l14.382-7.191A32 32 0 0 0 512 336v-48c0-141.479-114.496-256-256-256z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">25K+</div>
                        <div class="text-sm text-secondary-600">Subscribers</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-purple-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">35 min</div>
                        <div class="text-sm text-secondary-600">Avg Duration</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Featured Episodes Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Featured <span class="text-gradient">Episodes</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Don't miss these popular episodes featuring expert insights and valuable discussions.</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <article class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div class="p-6">
                        <div class="relative mb-4">
                            <div class="w-full h-48 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-6xl">🎙️</div>
                            <div class="absolute top-4 right-4 flex gap-2">
                                <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M336.2 64H47.8C21.4 64 0 85.4 0 111.8v288.4C0 426.6 21.4 448 47.8 448h288.4c26.4 0 47.8-21.4 47.8-47.8V111.8c0-26.4-21.4-47.8-47.8-47.8zm189.4 37.7L416 177.3v157.4l109.6 75.5c21.2 14.6 50.4-.3 50.4-25.8V127.5c0-25.4-29.1-40.4-50.4-25.8z"></path>
                                    </svg>
                                    Video
                                </span>
                                <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                            </div>
                            <button class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="flex items-center gap-2 mb-3">
                            <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Expert Interviews</span>
                            <span class="text-xs text-secondary-500">45 min</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">The Future of Asset Recovery in India</h3>
                        <p class="text-secondary-600 mb-4 line-clamp-3 text-sm">Join our CEO as he discusses the evolving landscape of asset recovery, emerging technologies, and future opportunities in the Indian financial sector.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <div class="flex items-center gap-4">
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <span>Rajesh Kumar</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                    </svg>
                                    <span>1/15/2024</span>
                                </div>
                            </div>
                            <div class="flex items-center gap-1">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                </svg>
                                <span>15,000</span>
                            </div>
                        </div>
                        <div class="flex flex-wrap gap-2 mb-4">
                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Digital Transformation</span>
                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Market Trends</span>
                        </div>
                        <button class="w-full bg-primary-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center group">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                            </svg>
                            Watch Episode
                        </button>
                    </div>
                </article>
                
                <article class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div class="p-6">
                        <div class="relative mb-4">
                            <div class="w-full h-48 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-6xl">💰</div>
                            <div class="absolute top-4 right-4 flex gap-2">
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M256 32C114.52 32 0 146.496 0 288v48a32 32 0 0 0 17.689 28.622l14.383 7.191C34.083 431.903 83.421 480 144 480h24c13.255 0 24-10.745 24-24V280c0-13.255-10.745-24-24-24h-24c-31.342 0-59.671 12.879-80 33.627V288c0-105.869 86.131-192 192-192s192 86.131 192 192v1.627C427.671 268.879 399.342 256 368 256h-24c-13.255 0-24 10.745-24 24v176c0 13.255 10.745 24 24 24h24c60.579 0 109.917-48.098 111.928-108.187l14.382-7.191A32 32 0 0 0 512 336v-48c0-141.479-114.496-256-256-256z"></path>
                                    </svg>
                                    Audio
                                </span>
                                <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                            </div>
                            <button class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="flex items-center gap-2 mb-3">
                            <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Asset Recovery</span>
                            <span class="text-xs text-secondary-500">38 min</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">IEPF Claims: A Complete Guide for Investors</h3>
                        <p class="text-secondary-600 mb-4 line-clamp-3 text-sm">Comprehensive discussion on IEPF claims process, recent regulatory changes, and step-by-step guidance for investors.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <div class="flex items-center gap-4">
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <span>Priya Sharma</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                    </svg>
                                    <span>1/12/2024</span>
                                </div>
                            </div>
                            <div class="flex items-center gap-1">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                </svg>
                                <span>12,500</span>
                            </div>
                        </div>
                        <div class="flex flex-wrap gap-2 mb-4">
                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#IEPF Process</span>
                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Documentation</span>
                        </div>
                        <button class="w-full bg-primary-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center group">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                            </svg>
                            Watch Episode
                        </button>
                    </div>
                </article>
                
                <article class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div class="p-6">
                        <div class="relative mb-4">
                            <div class="w-full h-48 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-6xl">🎉</div>
                            <div class="absolute top-4 right-4 flex gap-2">
                                <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M336.2 64H47.8C21.4 64 0 85.4 0 111.8v288.4C0 426.6 21.4 448 47.8 448h288.4c26.4 0 47.8-21.4 47.8-47.8V111.8c0-26.4-21.4-47.8-47.8-47.8zm189.4 37.7L416 177.3v157.4l109.6 75.5c21.2 14.6 50.4-.3 50.4-25.8V127.5c0-25.4-29.1-40.4-50.4-25.8z"></path>
                                    </svg>
                                    Video
                                </span>
                                <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                            </div>
                            <button class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="flex items-center gap-2 mb-3">
                            <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Success Stories</span>
                            <span class="text-xs text-secondary-500">32 min</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">Success Story: From ₹50K to ₹50L Recovery</h3>
                        <p class="text-secondary-600 mb-4 line-clamp-3 text-sm">Inspiring success story of a client who recovered ₹50 lakhs in unclaimed assets with detailed case study and lessons learned.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <div class="flex items-center gap-4">
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <span>Amit Singh</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                    </svg>
                                    <span>1/10/2024</span>
                                </div>
                            </div>
                            <div class="flex items-center gap-1">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                </svg>
                                <span>18,000</span>
                            </div>
                        </div>
                        <div class="flex flex-wrap gap-2 mb-4">
                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Case Study</span>
                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Recovery Process</span>
                        </div>
                        <button class="w-full bg-primary-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center group">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                            </svg>
                            Watch Episode
                        </button>
                    </div>
                </article>
                
                <article class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div class="p-6">
                        <div class="relative mb-4">
                            <div class="w-full h-48 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-6xl">📊</div>
                            <div class="absolute top-4 right-4 flex gap-2">
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M256 32C114.52 32 0 146.496 0 288v48a32 32 0 0 0 17.689 28.622l14.383 7.191C34.083 431.903 83.421 480 144 480h24c13.255 0 24-10.745 24-24V280c0-13.255-10.745-24-24-24h-24c-31.342 0-59.671 12.879-80 33.627V288c0-105.869 86.131-192 192-192s192 86.131 192 192v1.627C427.671 268.879 399.342 256 368 256h-24c-13.255 0-24 10.745-24 24v176c0 13.255 10.745 24 24 24h24c60.579 0 109.917-48.098 111.928-108.187l14.382-7.191A32 32 0 0 0 512 336v-48c0-141.479-114.496-256-256-256z"></path>
                                    </svg>
                                    Audio
                                </span>
                                <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                            </div>
                            <button class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="flex items-center gap-2 mb-3">
                            <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Market Analysis</span>
                            <span class="text-xs text-secondary-500">48 min</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">Market Outlook 2024: Opportunities and Risks</h3>
                        <p class="text-secondary-600 mb-4 line-clamp-3 text-sm">Comprehensive market analysis for 2024 with insights on investment opportunities and potential risks.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <div class="flex items-center gap-4">
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <span>Market Analyst</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                    </svg>
                                    <span>1/1/2024</span>
                                </div>
                            </div>
                            <div class="flex items-center gap-1">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                </svg>
                                <span>16,000</span>
                            </div>
                        </div>
                        <div class="flex flex-wrap gap-2 mb-4">
                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Market Forecast</span>
                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Economic Trends</span>
                        </div>
                        <button class="w-full bg-primary-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center group">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                            </svg>
                            Watch Episode
                        </button>
                    </div>
                </article>
            </div>
        </div>
    </section>
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">All <span class="text-gradient">Episodes</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Browse through all episodes and filter by category or search for specific topics.</p>
            </div>
            
            <div class="max-w-4xl mx-auto mb-12">
                <div class="flex flex-col md:flex-row gap-4">
                    <div class="flex-1 relative">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-5 h-5" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                        </svg>
                        <input type="text" placeholder="Search episodes, topics, or hosts..." class="w-full pl-12 pr-4 py-3 border border-secondary-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent" value="">
                    </div>
                    <select class="px-4 py-3 border border-secondary-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                        <option value="All">All</option>
                        <option value="Asset Recovery">Asset Recovery</option>
                        <option value="Investment Tips">Investment Tips</option>
                        <option value="Legal Updates">Legal Updates</option>
                        <option value="Success Stories">Success Stories</option>
                        <option value="Expert Interviews">Expert Interviews</option>
                        <option value="Market Analysis">Market Analysis</option>
                    </select>
                </div>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
                <div class="lg:col-span-2">
                    <div class="space-y-8">
                        <article class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border">
                            <div class="flex flex-col md:flex-row gap-6">
                                <div class="md:w-1/3">
                                    <div class="relative">
                                        <div class="w-full h-32 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-4xl">🎙️</div>
                                        <button class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-300 rounded-lg">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-8 h-8 text-white opacity-0 hover:opacity-100 transition-opacity duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                                <div class="md:w-2/3">
                                    <div class="flex items-center gap-2 mb-3">
                                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Expert Interviews</span>
                                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M336.2 64H47.8C21.4 64 0 85.4 0 111.8v288.4C0 426.6 21.4 448 47.8 448h288.4c26.4 0 47.8-21.4 47.8-47.8V111.8c0-26.4-21.4-47.8-47.8-47.8zm189.4 37.7L416 177.3v157.4l109.6 75.5c21.2 14.6 50.4-.3 50.4-25.8V127.5c0-25.4-29.1-40.4-50.4-25.8z"></path>
                                            </svg>
                                            Video
                                        </span>
                                        <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                                    </div>
                                    <h3 class="text-xl font-semibold text-secondary-800 mb-2 hover:text-primary-600 transition-colors">The Future of Asset Recovery in India</h3>
                                    <p class="text-secondary-600 mb-4 line-clamp-2">Join our CEO as he discusses the evolving landscape of asset recovery, emerging technologies, and future opportunities in the Indian financial sector.</p>
                                    <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                                        <div class="flex items-center gap-4">
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                                </svg>
                                                <span>Rajesh Kumar</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                                                </svg>
                                                <span>45 min</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                                </svg>
                                                <span>1/15/2024</span>
                                            </div>
                                        </div>
                                        <div class="flex items-center gap-1">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                            </svg>
                                            <span>15,000</span>
                                        </div>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <div class="flex flex-wrap gap-2">
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Digital Transformation</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Market Trends</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Future Outlook</span>
                                        </div>
                                        <button class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                            </svg>
                                            Watch Now
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </article>
                        
                        <article class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border">
                            <div class="flex flex-col md:flex-row gap-6">
                                <div class="md:w-1/3">
                                    <div class="relative">
                                        <div class="w-full h-32 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-4xl">💰</div>
                                        <button class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-300 rounded-lg">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-8 h-8 text-white opacity-0 hover:opacity-100 transition-opacity duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                                <div class="md:w-2/3">
                                    <div class="flex items-center gap-2 mb-3">
                                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Asset Recovery</span>
                                        <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M256 32C114.52 32 0 146.496 0 288v48a32 32 0 0 0 17.689 28.622l14.383 7.191C34.083 431.903 83.421 480 144 480h24c13.255 0 24-10.745 24-24V280c0-13.255-10.745-24-24-24h-24c-31.342 0-59.671 12.879-80 33.627V288c0-105.869 86.131-192 192-192s192 86.131 192 192v1.627C427.671 268.879 399.342 256 368 256h-24c-13.255 0-24 10.745-24 24v176c0 13.255 10.745 24 24 24h24c60.579 0 109.917-48.098 111.928-108.187l14.382-7.191A32 32 0 0 0 512 336v-48c0-141.479-114.496-256-256-256z"></path>
                                            </svg>
                                            Audio
                                        </span>
                                        <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                                    </div>
                                    <h3 class="text-xl font-semibold text-secondary-800 mb-2 hover:text-primary-600 transition-colors">IEPF Claims: A Complete Guide for Investors</h3>
                                    <p class="text-secondary-600 mb-4 line-clamp-2">Comprehensive discussion on IEPF claims process, recent regulatory changes, and step-by-step guidance for investors.</p>
                                    <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                                        <div class="flex items-center gap-4">
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                                </svg>
                                                <span>Priya Sharma</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                                                </svg>
                                                <span>38 min</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                                </svg>
                                                <span>1/12/2024</span>
                                            </div>
                                        </div>
                                        <div class="flex items-center gap-1">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                            </svg>
                                            <span>12,500</span>
                                        </div>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <div class="flex flex-wrap gap-2">
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#IEPF Process</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Documentation</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Success Tips</span>
                                        </div>
                                        <button class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                            </svg>
                                            Watch Now
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </article>
                        
                        <article class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border">
                            <div class="flex flex-col md:flex-row gap-6">
                                <div class="md:w-1/3">
                                    <div class="relative">
                                        <div class="w-full h-32 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-4xl">🎉</div>
                                        <button class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-300 rounded-lg">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-8 h-8 text-white opacity-0 hover:opacity-100 transition-opacity duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M424.4 214.7L72.4 6.6C43-8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                                <div class="md:w-2/3">
                                    <div class="flex items-center gap-2 mb-3">
                                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Success Stories</span>
                                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M336.2 64H47.8C21.4 64 0 85.4 0 111.8v288.4C0 426.6 21.4 448 47.8 448h288.4c26.4 0 47.8-21.4 47.8-47.8V111.8c0-26.4-21.4-47.8-47.8-47.8zm189.4 37.7L416 177.3v157.4l109.6 75.5c21.2 14.6 50.4-.3 50.4-25.8V127.5c0-25.4-29.1-40.4-50.4-25.8z"></path>
                                            </svg>
                                            Video
                                        </span>
                                        <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                                    </div>
                                    <h3 class="text-xl font-semibold text-secondary-800 mb-2 hover:text-primary-600 transition-colors">Success Story: From ₹50K to ₹50L Recovery</h3>
                                    <p class="text-secondary-600 mb-4 line-clamp-2">Inspiring success story of a client who recovered ₹50 lakhs in unclaimed assets with detailed case study and lessons learned.</p>
                                    <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                                        <div class="flex items-center gap-4">
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                                </svg>
                                                <span>Amit Singh</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                                                </svg>
                                                <span>32 min</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                                </svg>
                                                <span>1/10/2024</span>
                                            </div>
                                        </div>
                                        <div class="flex items-center gap-1">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                            </svg>
                                            <span>18,000</span>
                                        </div>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <div class="flex flex-wrap gap-2">
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Case Study</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Recovery Process</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Client Experience</span>
                                        </div>
                                        <button class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                            </svg>
                                            Watch Now
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </article>
                        
                        <article class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border">
                            <div class="flex flex-col md:flex-row gap-6">
                                <div class="md:w-1/3">
                                    <div class="relative">
                                        <div class="w-full h-32 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-4xl">📈</div>
                                        <button class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-300 rounded-lg">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-8 h-8 text-white opacity-0 hover:opacity-100 transition-opacity duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                                <div class="md:w-2/3">
                                    <div class="flex items-center gap-2 mb-3">
                                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Investment Tips</span>
                                        <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M256 32C114.52 32 0 146.496 0 288v48a32 32 0 0 0 17.689 28.622l14.383 7.191C34.083 431.903 83.421 480 144 480h24c13.255 0 24-10.745 24-24V280c0-13.255-10.745-24-24-24h-24c-31.342 0-59.671 12.879-80 33.627V288c0-105.869 86.131-192 192-192s192 86.131 192 192v1.627C427.671 268.879 399.342 256 368 256h-24c-13.255 0-24 10.745-24 24v176c0 13.255 10.745 24 24 24h24c60.579 0 109.917-48.098 111.928-108.187l14.382-7.191A32 32 0 0 0 512 336v-48c0-141.479-114.496-256-256-256z"></path>
                                            </svg>
                                            Audio
                                        </span>
                                    </div>
                                    <h3 class="text-xl font-semibold text-secondary-800 mb-2 hover:text-primary-600 transition-colors">Investment Mistakes to Avoid in 2024</h3>
                                    <p class="text-secondary-600 mb-4 line-clamp-2">Expert analysis of common investment mistakes and practical tips to avoid them in the current market scenario.</p>
                                    <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                                        <div class="flex items-center gap-4">
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                                </svg>
                                                <span>Dr. Meera Jain</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                                                </svg>
                                                <span>29 min</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                                </svg>
                                                <span>1/8/2024</span>
                                            </div>
                                        </div>
                                        <div class="flex items-center gap-1">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                            </svg>
                                            <span>9,800</span>
                                        </div>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <div class="flex flex-wrap gap-2">
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Investment Strategy</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Risk Management</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Market Analysis</span>
                                        </div>
                                        <button class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                                            </svg>
                                            Listen Now
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
                
                <!-- Sidebar -->
                <div class="lg:col-span-1">
                    <div class="space-y-8">
                        <!-- Recent Episodes -->
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h3 class="text-lg font-semibold text-secondary-800 mb-4">Recent Episodes</h3>
                            <div class="space-y-4">
                                <div class="flex gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-lg flex-shrink-0">🎙️</div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-semibold text-secondary-800 mb-1 line-clamp-2 hover:text-primary-600 transition-colors cursor-pointer">The Future of Asset Recovery in India</h4>
                                        <div class="flex items-center gap-2 text-xs text-secondary-500">
                                            <span>Rajesh Kumar</span>
                                            <span>•</span>
                                            <span>45 min</span>
                                            <span>•</span>
                                            <span>15,000 views</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-lg flex-shrink-0">💰</div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-semibold text-secondary-800 mb-1 line-clamp-2 hover:text-primary-600 transition-colors cursor-pointer">IEPF Claims: A Complete Guide for Investors</h4>
                                        <div class="flex items-center gap-2 text-xs text-secondary-500">
                                            <span>Priya Sharma</span>
                                            <span>•</span>
                                            <span>38 min</span>
                                            <span>•</span>
                                            <span>12,500 views</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-lg flex-shrink-0">🎉</div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-semibold text-secondary-800 mb-1 line-clamp-2 hover:text-primary-600 transition-colors cursor-pointer">Success Story: From ₹50K to ₹50L Recovery</h4>
                                        <div class="flex items-center gap-2 text-xs text-secondary-500">
                                            <span>Amit Singh</span>
                                            <span>•</span>
                                            <span>32 min</span>
                                            <span>•</span>
                                            <span>18,000 views</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-red-100 to-pink-100 rounded-lg flex items-center justify-center text-lg flex-shrink-0">📈</div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-semibold text-secondary-800 mb-1 line-clamp-2 hover:text-primary-600 transition-colors cursor-pointer">Investment Mistakes to Avoid in 2024</h4>
                                        <div class="flex items-center gap-2 text-xs text-secondary-500">
                                            <span>Dr. Suresh Patel</span>
                                            <span>•</span>
                                            <span>28 min</span>
                                            <span>•</span>
                                            <span>9,500 views</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Our Hosts -->
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h3 class="text-lg font-semibold text-secondary-800 mb-4">Our Hosts</h3>
                            <div class="space-y-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-red-100 to-pink-100 rounded-full flex items-center justify-center text-2xl">👨‍💼</div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-semibold text-secondary-800">Rajesh Kumar</h4>
                                        <p class="text-xs text-secondary-600">CEO & Host</p>
                                        <p class="text-xs text-secondary-500">15 episodes</p>
                                    </div>
                                </div>
                                <div class="flex items-center gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-red-100 to-pink-100 rounded-full flex items-center justify-center text-2xl">👩‍💼</div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-semibold text-secondary-800">Priya Sharma</h4>
                                        <p class="text-xs text-secondary-600">Senior Analyst</p>
                                        <p class="text-xs text-secondary-500">12 episodes</p>
                                    </div>
                                </div>
                                <div class="flex items-center gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-red-100 to-pink-100 rounded-full flex items-center justify-center text-2xl">👨‍⚕️</div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-semibold text-secondary-800">Dr. Suresh Patel</h4>
                                        <p class="text-xs text-secondary-600">Investment Advisor</p>
                                        <p class="text-xs text-secondary-500">10 episodes</p>
                                    </div>
                                </div>
                                <div class="flex items-center gap-3">
                                    <div class="w-12 h-12 bg-gradient-to-br from-red-100 to-pink-100 rounded-full flex items-center justify-center text-2xl">👨‍💻</div>
                                    <div class="flex-1">
                                        <h4 class="text-sm font-semibold text-secondary-800">Amit Singh</h4>
                                        <p class="text-xs text-secondary-600">Client Relations Head</p>
                                        <p class="text-xs text-secondary-500">8 episodes</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Subscribe to Our Show -->
                        <div class="bg-gradient-to-br from-red-600 to-pink-600 rounded-xl p-6 text-white">
                            <h3 class="text-lg font-semibold mb-3">Subscribe to Our Show</h3>
                            <p class="text-sm mb-4 opacity-90">Get notified about new episodes and exclusive content from our digital talk show.</p>
                            <button class="w-full bg-white text-red-600 py-2 rounded-lg font-semibold text-sm hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M256 32C114.52 32 0 146.496 0 288v48a32 32 0 0 0 17.689 28.622l14.383 7.191C34.083 431.903 83.421 480 144 480h24c13.255 0 24-10.745 24-24V280c0-13.255-10.745-24-24-24h-24c-31.342 0-59.671 12.879-80 33.627V288c0-105.869 86.131-192 192-192s192 86.131 192 192v1.627C427.671 268.879 399.342 256 368 256h-24c-13.255 0-24 10.745-24 24v176c0 13.255 10.745 24 24 24h24c60.579 0 109.917-48.098 111.928-108.187l14.382-7.191A32 32 0 0 0 512 336v-48c0-141.479-114.496-256-256-256z"></path>
                                </svg>
                                Subscribe Now
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    
    <!-- Join Our Digital Community Section -->
    <section class="section-padding bg-gradient-to-r from-red-600 to-pink-600">
        <div class="container-custom text-center text-white">
            <h2 class="text-3xl font-bold mb-4">Join Our Digital Community</h2>
            <p class="text-xl mb-8 max-w-2xl mx-auto">Subscribe to our digital talk show and join thousands of viewers who stay updated with expert insights on asset recovery and financial services.</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <button class="bg-white text-red-600 py-3 px-6 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path>
                    </svg>
                    Watch Latest Episode
                </button>
                <button class="border-2 border-white text-white py-3 px-6 rounded-lg font-semibold hover:bg-white hover:text-red-600 transition-colors flex items-center justify-center gap-2">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M256 32C114.52 32 0 146.496 0 288v48a32 32 0 0 0 17.689 28.622l14.383 7.191C34.083 431.903 83.421 480 144 480h24c13.255 0 24-10.745 24-24V280c0-13.255-10.745-24-24-24h-24c-31.342 0-59.671 12.879-80 33.627V288c0-105.869 86.131-192 192-192s192 86.131 192 192v1.627C427.671 268.879 399.342 256 368 256h-24c-13.255 0-24 10.745-24 24v176c0 13.255 10.745 24 24 24h24c60.579 0 109.917-48.098 111.928-108.187l14.382-7.191A32 32 0 0 0 512 336v-48c0-141.479-114.496-256-256-256z"></path>
                    </svg>
                    Subscribe to Podcast
                </button>
            </div>
        </div>
    </section>
    
    <!-- Contact Form Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="max-w-4xl mx-auto">
                <div class="text-center mb-12">
                    <h2 class="text-4xl font-bold text-secondary-800 mb-4">Get Your <span class="text-gradient">Free Consultation</span></h2>
                    <p class="text-xl text-secondary-600">Fill out the form below and our experts will contact you within 24 hours to discuss your case.</p>
                </div>
                <div class="card max-w-4xl mx-auto">
                    <div class="text-center mb-8">
                        <div class="flex justify-center mb-6">
                            <img src="../kmfsl logo svg.svg" alt="KMFSL - Kaimur Financial Services" class="h-24 w-auto">
                        </div>
                        <h3 class="text-2xl font-bold text-secondary-800 mb-2">Send us your enquiry</h3>
                        <p class="text-secondary-600">We'll get back to you within 24 hours</p>
                    </div>
                    <form class="space-y-6" action="../subscribe.php" method="POST">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Full Name *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <input type="text" name="name" class="input-field pl-10" placeholder="Enter your full name" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                    </svg>
                                    <input type="email" name="email" class="input-field pl-10" placeholder="Enter your email address" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                    </svg>
                                    <input type="tel" name="phone" class="input-field pl-10" placeholder="Enter your phone number" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Service Required *</label>
                                <select name="service" class="input-field" required>
                                    <option value="">Select a service</option>
                                    <option value="IEPF Claim">IEPF Claim</option>
                                    <option value="Transmission of Shares">Transmission of Shares</option>
                                    <option value="Demat of Physical Shares">Demat of Physical Shares</option>
                                    <option value="Unclaimed Dividends">Unclaimed Dividends</option>
                                    <option value="Conversion of Shares/Debentures">Conversion of Shares/Debentures</option>
                                    <option value="Property Claim Samadhan">Property Claim Samadhan</option>
                                    <option value="Debtor Recovery">Debtor Recovery</option>
                                    <option value="Recovery of Unclaimed Mutual Funds">Recovery of Unclaimed Mutual Funds</option>
                                    <option value="Recovery of Inoperative Bank Accounts">Recovery of Inoperative Bank Accounts</option>
                                    <option value="Provident Funds Claim">Provident Funds Claim</option>
                                    <option value="Recovery of Unclaimed Matured Insurance">Recovery of Unclaimed Matured Insurance</option>
                                    <option value="Wealth Samadhan">Wealth Samadhan</option>
                                    <option value="NRI Samadhan">NRI Samadhan</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Preferred Contact Method</label>
                            <div class="flex space-x-4">
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="email" checked>
                                    Email
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="phone">
                                    Phone
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="whatsapp">
                                    WhatsApp
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Message *</label>
                            <textarea name="message" rows="4" class="input-field resize-none" placeholder="Please describe your requirements or any specific questions you have..." required></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn-primary inline-flex items-center justify-center min-w-[200px]">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                                </svg>
                                Send Enquiry
                            </button>
                        </div>
                        <div class="text-center text-sm text-secondary-500">
                            <p>By submitting this form, you agree to our <a href="../privacy-policy.php" class="text-primary-600 hover:underline">Privacy Policy</a> and <a href="../terms-conditions.php" class="text-primary-600 hover:underline">Terms & Conditions</a>.</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Digital Talk Show JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Slider Functionality
            let currentSlide = 0;
            const totalSlides = 2;
            let slideInterval;
            
            function showSlide(index) {
                const slides = document.querySelectorAll('.slide');
                const dots = document.querySelectorAll('.slider-dot');
                
                if (slides.length === 0) return;
                
                slides.forEach(slide => {
                    slide.classList.remove('active');
                });
                
                dots.forEach(dot => {
                    dot.classList.remove('active');
                });
                
                if (slides[index]) {
                    slides[index].classList.add('active');
                }
                
                if (dots[index]) {
                    dots[index].classList.add('active');
                }
            }
            
            window.showSlide = showSlide;
            
            function nextSlide() {
                currentSlide = (currentSlide + 1) % totalSlides;
                showSlide(currentSlide);
            }
            
            function prevSlide() {
                currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
                showSlide(currentSlide);
            }
            
            function goToSlide(index) {
                currentSlide = index;
                showSlide(currentSlide);
            }
            
            window.nextSlide = nextSlide;
            window.prevSlide = prevSlide;
            window.goToSlide = goToSlide;
            
            // Auto-play slider
            function startSlideshow() {
                slideInterval = setInterval(nextSlide, 5000);
            }
            
            function stopSlideshow() {
                clearInterval(slideInterval);
            }
            
            // Start auto-play
            startSlideshow();
            
            // Pause on hover
            const slider = document.querySelector('.hero-slider');
            if (slider) {
                slider.addEventListener('mouseenter', stopSlideshow);
                slider.addEventListener('mouseleave', startSlideshow);
            }
            
            const categoryBtns = document.querySelectorAll('.category-btn');
            const episodeCards = document.querySelectorAll('.episode-card');
            const searchInput = document.querySelector('input[placeholder*="Search"]');
            
            // Category Filter
            if (categoryBtns.length > 0) {
                categoryBtns.forEach(btn => {
                    btn.addEventListener('click', function() {
                        const category = this.dataset.category;
                        
                        // Update active button
                        categoryBtns.forEach(b => b.classList.remove('active'));
                        this.classList.add('active');
                        
                        // Filter episodes
                        if (searchInput) {
                            filterEpisodes(category, searchInput.value);
                        }
                    });
                });
            }
            
            // Search Functionality
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    const activeBtn = document.querySelector('.category-btn.active');
                    const activeCategory = activeBtn ? activeBtn.dataset.category : 'all';
                    filterEpisodes(activeCategory, this.value);
                });
            }
            
            function filterEpisodes(category, searchTerm) {
                episodeCards.forEach(card => {
                    const cardCategory = card.dataset.category;
                    const cardTitle = card.querySelector('h3').textContent.toLowerCase();
                    const cardDescription = card.querySelector('p').textContent.toLowerCase();
                    
                    const matchesCategory = category === 'all' || cardCategory === category;
                    const matchesSearch = searchTerm === '' || 
                                        cardTitle.includes(searchTerm.toLowerCase()) || 
                                        cardDescription.includes(searchTerm.toLowerCase());
                    
                    if (matchesCategory && matchesSearch) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            }
        });
        
        function loadMoreEpisodes() {
            // In a real implementation, this would load more episodes via AJAX
            alert('More episodes would be loaded here in the actual implementation.');
        }
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                const href = this.getAttribute('href');
                if (href && href !== '#' && href.length > 1) {
                    e.preventDefault();
                    const target = document.querySelector(href);
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    </script>
    
    <style>
        .category-btn {
            @apply px-6 py-3 rounded-full border-2 border-primary-600 text-primary-600 font-semibold transition-all duration-300 hover:bg-primary-600 hover:text-white;
        }
        
        .category-btn.active {
            @apply bg-primary-600 text-white;
        }
        
        .episode-card:not(.featured) {
            transition: transform 0.3s ease;
        }
        
        .episode-card:not(.featured):hover {
            transform: translateY(-5px);
        }
        
        /* Hero Slider Styles */
        .hero-slider {
            position: relative;
            height: 100%;
        }
        
        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.8s ease-in-out;
        }
        
        .slide.active {
            opacity: 1;
        }
        
        .slider-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.5);
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .slider-dot.active {
            background-color: white;
            transform: scale(1.2);
        }
    </style>
    

    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
</body>
</html>