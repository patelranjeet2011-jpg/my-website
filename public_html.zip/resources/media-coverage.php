<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Coverage - KMFSL in News | KMFSL</title>
    <meta name="description" content="Discover how leading media outlets cover KMFSL's innovations, achievements, and contributions to the financial services industry.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Hero Section -->
    <section class="section-padding bg-gradient-to-br from-purple-50 via-white to-blue-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <div class="inline-flex items-center bg-purple-100 text-purple-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M464 32H48C21.49 32 0 53.49 0 80v352c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V80c0-26.51-21.49-48-48-48zM224 416H64V160h160v256zm224 0H288V160h160v256z"></path>
                    </svg>
                    Media Coverage & Press
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                    Media <span class="text-gradient">Coverage</span>
                </h1>
                <p class="text-xl text-secondary-600 max-w-4xl mx-auto leading-relaxed mb-8">
                    Discover how leading media outlets are covering KMFSL's innovations, achievements, and contributions to the financial services industry. Stay updated with our latest news and press coverage.
                </p>
                
                <!-- Stats Grid -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="text-2xl font-bold text-purple-600 mb-1">150+</div>
                        <div class="text-sm text-secondary-600">Total Coverage</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="text-2xl font-bold text-purple-600 mb-1">50+</div>
                        <div class="text-sm text-secondary-600">Media Outlets</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="text-2xl font-bold text-purple-600 mb-1">10M+</div>
                        <div class="text-sm text-secondary-600">Total Reach</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="text-2xl font-bold text-purple-600 mb-1">25K+</div>
                        <div class="text-sm text-secondary-600">Average Views</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Search and Filter Section -->
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="max-w-4xl mx-auto">
                <!-- Search Bar -->
                <div class="mb-8">
                    <div class="relative">
                        <input type="text" id="searchInput" placeholder="Search media coverage..." class="w-full pl-12 pr-4 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent text-lg">
                        <svg class="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </div>
                </div>
                
                <!-- Media Type Filter -->
                <div class="mb-12">
                    <div class="flex flex-wrap gap-3 justify-center">
                        <button class="media-btn active" data-media="All">All</button>
                        <button class="media-btn" data-media="Newspaper">Newspaper</button>
                        <button class="media-btn" data-media="Television">Television</button>
                        <button class="media-btn" data-media="Online">Online</button>
                        <button class="media-btn" data-media="Radio">Radio</button>
                        <button class="media-btn" data-media="Magazine">Magazine</button>
                        <button class="media-btn" data-media="Press Release">Press Release</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Featured Coverage Section -->
    <section class="section-padding bg-gradient-to-br from-purple-50 to-blue-50">
        <div class="container-custom">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Featured <span class="text-gradient">Coverage</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Highlighted media coverage and press mentions</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="featuredCoverage">
                <!-- Featured Coverage Item 1 -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="text-4xl">📰</div>
                            <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">Newspaper</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-purple-600 transition-colors">KMFSL Revolutionizes Asset Recovery with Digital Solutions</h3>
                        <p class="text-secondary-600 mb-4 text-sm">Economic Times</p>
                        <p class="text-secondary-600 mb-4 line-clamp-3">Leading financial daily covers KMFSL's innovative digital approach to asset recovery, highlighting the company's success in recovering ₹500+ crores for clients.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <span>📅 Jan 15, 2024</span>
                            <span>👁️ 25,000 views</span>
                        </div>
                        <a href="#" class="inline-flex items-center text-purple-600 hover:text-purple-700 font-semibold">
                            Read Article
                            <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                        </a>
                    </div>
                </div>
                
                <!-- Featured Coverage Item 2 -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="text-4xl">📺</div>
                            <span class="bg-red-100 text-red-600 text-xs font-semibold px-3 py-1 rounded-full">Television</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-purple-600 transition-colors">CEO Interview: Future of Financial Asset Recovery</h3>
                        <p class="text-secondary-600 mb-4 text-sm">CNBC TV18</p>
                        <p class="text-secondary-600 mb-4 line-clamp-3">Exclusive interview with KMFSL CEO discussing market trends, regulatory changes, and the company's expansion plans.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <span>📅 Jan 12, 2024</span>
                            <span>👁️ 45,000 views</span>
                        </div>
                        <a href="#" class="inline-flex items-center text-purple-600 hover:text-purple-700 font-semibold">
                            Watch Interview
                            <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h8m-9-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </a>
                    </div>
                </div>
                
                <!-- Featured Coverage Item 3 -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="text-4xl">🏆</div>
                            <span class="bg-purple-100 text-purple-600 text-xs font-semibold px-3 py-1 rounded-full">Online</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-purple-600 transition-colors">KMFSL Wins Best Financial Services Award 2024</h3>
                        <p class="text-secondary-600 mb-4 text-sm">Business Standard</p>
                        <p class="text-secondary-600 mb-4 line-clamp-3">Coverage of KMFSL receiving the prestigious "Best Financial Recovery Service" award at the Financial Services Excellence Awards.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <span>📅 Jan 10, 2024</span>
                            <span>👁️ 18,000 views</span>
                        </div>
                        <a href="#" class="inline-flex items-center text-purple-600 hover:text-purple-700 font-semibold">
                            Read More
                            <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- All Coverage Section -->
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">All Media <span class="text-gradient">Coverage</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Complete list of media mentions and press coverage</p>
            </div>
            
            <div class="max-w-6xl mx-auto" id="allCoverage">
                <!-- All coverage items will be populated by JavaScript -->
            </div>
        </div>
    </section>
    
    <!-- Press Kit Section -->
    <section class="section-padding bg-gradient-to-r from-purple-600 to-blue-600">
        <div class="container-custom text-center text-white">
            <h2 class="text-3xl font-bold mb-4">Press Kit & Media Resources</h2>
            <p class="text-xl mb-8 max-w-2xl mx-auto">Download our press kit for high-resolution images, company information, and media resources.</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="#" class="bg-white text-purple-600 py-3 px-6 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center justify-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    Download Press Kit
                </a>
                <a href="mailto:media@kmfsl.com" class="border-2 border-white text-white py-3 px-6 rounded-lg font-semibold hover:bg-white hover:text-purple-600 transition-colors flex items-center justify-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                        <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                    </svg>
                    Media Inquiries
                </a>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
    
    <!-- Media Coverage JavaScript -->
    <script>
        // Media coverage data
        const mediaCoverage = [
            {
                id: 1,
                title: 'KMFSL Revolutionizes Asset Recovery with Digital Solutions',
                outlet: 'Economic Times',
                type: 'Newspaper',
                date: '2024-01-15',
                description: 'Leading financial daily covers KMFSL\'s innovative digital approach to asset recovery, highlighting the company\'s success in recovering ₹500+ crores for clients.',
                image: '📰',
                link: '#',
                views: 25000,
                featured: true,
                excerpt: 'KMFSL has emerged as a pioneer in the asset recovery sector, leveraging technology to simplify complex financial processes...'
            },
            {
                id: 2,
                title: 'CEO Interview: Future of Financial Asset Recovery',
                outlet: 'CNBC TV18',
                type: 'Television',
                date: '2024-01-12',
                description: 'Exclusive interview with KMFSL CEO discussing market trends, regulatory changes, and the company\'s expansion plans.',
                image: '📺',
                link: '#',
                views: 45000,
                featured: true,
                excerpt: 'In an exclusive conversation, the CEO shares insights on how KMFSL is transforming the asset recovery landscape...'
            },
            {
                id: 3,
                title: 'KMFSL Wins Best Financial Services Award 2024',
                outlet: 'Business Standard',
                type: 'Online',
                date: '2024-01-10',
                description: 'Coverage of KMFSL receiving the prestigious "Best Financial Recovery Service" award at the Financial Services Excellence Awards.',
                image: '🏆',
                link: '#',
                views: 18000,
                featured: true,
                excerpt: 'KMFSL\'s commitment to excellence and client satisfaction has been recognized with a prestigious industry award...'
            },
            {
                id: 4,
                title: 'Digital Transformation in Asset Recovery Sector',
                outlet: 'Hindu Business Line',
                type: 'Newspaper',
                date: '2024-01-08',
                description: 'Analysis of how digital transformation is reshaping the asset recovery industry, featuring KMFSL as a case study.',
                image: '💻',
                link: '#',
                views: 22000,
                featured: false,
                excerpt: 'The asset recovery sector is undergoing a digital revolution, with companies like KMFSL leading the charge...'
            },
            {
                id: 5,
                title: 'KMFSL Expands NRI Services Globally',
                outlet: 'Times of India',
                type: 'Newspaper',
                date: '2024-01-05',
                description: 'Coverage of KMFSL\'s expansion of NRI asset recovery services to serve clients in 50+ countries.',
                image: '🌍',
                link: '#',
                views: 31000,
                featured: false,
                excerpt: 'KMFSL\'s global expansion brings specialized asset recovery services to NRIs worldwide...'
            },
            {
                id: 6,
                title: 'Radio Interview: Unclaimed Assets in India',
                outlet: 'All India Radio',
                type: 'Radio',
                date: '2024-01-03',
                description: 'KMFSL expert discusses the scale of unclaimed assets in India and how citizens can recover their investments.',
                image: '📻',
                link: '#',
                views: 15000,
                featured: false,
                excerpt: 'An informative discussion on the massive scale of unclaimed assets and the recovery process...'
            },
            {
                id: 7,
                title: 'Market Analysis: Asset Recovery Trends 2024',
                outlet: 'Mint',
                type: 'Online',
                date: '2024-01-01',
                description: 'Comprehensive market analysis covering trends in asset recovery sector with insights from KMFSL leadership.',
                image: '📊',
                link: '#',
                views: 28000,
                featured: false,
                excerpt: 'An in-depth analysis of the asset recovery market with insights from industry leaders including KMFSL...'
            },
            {
                id: 8,
                title: 'KMFSL Partnership with Leading Banks',
                outlet: 'Financial Express',
                type: 'Newspaper',
                date: '2023-12-28',
                description: 'Coverage of strategic partnerships between KMFSL and major banks to enhance asset recovery services.',
                image: '🤝',
                link: '#',
                views: 19000,
                featured: false,
                excerpt: 'Strategic alliances with leading banks position KMFSL for accelerated growth and enhanced service delivery...'
            },
            {
                id: 9,
                title: 'TV Panel: Regulatory Changes in Financial Services',
                outlet: 'Zee Business',
                type: 'Television',
                date: '2023-12-25',
                description: 'KMFSL representative participates in expert panel discussing recent regulatory changes affecting financial services.',
                image: '⚖️',
                link: '#',
                views: 32000,
                featured: false,
                excerpt: 'Expert panel discussion on how regulatory changes are shaping the future of financial services...'
            },
            {
                id: 10,
                title: 'Success Story: ₹50 Lakh Recovery Case Study',
                outlet: 'Money Control',
                type: 'Online',
                date: '2023-12-22',
                description: 'Detailed case study of KMFSL\'s successful recovery of ₹50 lakhs for a client, showcasing the company\'s expertise.',
                image: '💰',
                link: '#',
                views: 41000,
                featured: true,
                excerpt: 'A remarkable success story demonstrating KMFSL\'s expertise in complex asset recovery cases...'
            }
        ];
        
        let currentMedia = 'All';
        let searchTerm = '';
        
        // Initialize media coverage functionality
        document.addEventListener('DOMContentLoaded', function() {
            renderAllCoverage();
            setupEventListeners();
        });
        
        function setupEventListeners() {
            // Search functionality
            document.getElementById('searchInput').addEventListener('input', function(e) {
                searchTerm = e.target.value.toLowerCase();
                renderAllCoverage();
            });
            
            // Media type filter
            document.querySelectorAll('.media-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.media-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    currentMedia = this.dataset.media;
                    renderAllCoverage();
                });
            });
        }
        
        function getMediaColor(type) {
            switch (type) {
                case 'Newspaper': return 'bg-blue-100 text-blue-600';
                case 'Television': return 'bg-red-100 text-red-600';
                case 'Radio': return 'bg-green-100 text-green-600';
                case 'Online': return 'bg-purple-100 text-purple-600';
                case 'Magazine': return 'bg-yellow-100 text-yellow-600';
                case 'Press Release': return 'bg-gray-100 text-gray-600';
                default: return 'bg-blue-100 text-blue-600';
            }
        }
        
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });
        }
        
        function formatViews(views) {
            if (views >= 1000) {
                return (views / 1000).toFixed(0) + 'K';
            }
            return views.toString();
        }
        
        function renderAllCoverage() {
            const container = document.getElementById('allCoverage');
            const filteredCoverage = mediaCoverage.filter(item => {
                const matchesSearch = item.title.toLowerCase().includes(searchTerm) || 
                                    item.outlet.toLowerCase().includes(searchTerm) ||
                                    item.description.toLowerCase().includes(searchTerm);
                const matchesMedia = currentMedia === 'All' || item.type === currentMedia;
                return matchesSearch && matchesMedia;
            });
            
            container.innerHTML = `
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    ${filteredCoverage.map(item => `
                        <div class="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                            <div class="p-6">
                                <div class="flex items-center justify-between mb-4">
                                    <div class="text-4xl">${item.image}</div>
                                    <span class="${getMediaColor(item.type)} text-xs font-semibold px-3 py-1 rounded-full">${item.type}</span>
                                </div>
                                <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-purple-600 transition-colors line-clamp-2">${item.title}</h3>
                                <p class="text-secondary-600 mb-4 text-sm font-medium">${item.outlet}</p>
                                <p class="text-secondary-600 mb-4 line-clamp-3 text-sm">${item.description}</p>
                                <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                                    <span>📅 ${formatDate(item.date)}</span>
                                    <span>👁️ ${formatViews(item.views)} views</span>
                                </div>
                                <a href="${item.link}" class="inline-flex items-center text-purple-600 hover:text-purple-700 font-semibold">
                                    Read More
                                    <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }
    </script>
    
    <style>
        .media-btn {
            @apply px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 border border-gray-300 text-gray-700 hover:border-purple-300 hover:text-purple-600;
        }
        
        .media-btn.active {
            @apply bg-purple-600 text-white border-purple-600 shadow-lg;
        }
        
        .text-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .line-clamp-3 {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
    </style>
</body>
</html>