<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - KMFSL | Frequently Asked Questions</title>
    <meta name="description" content="Find answers to frequently asked questions about KMFSL's financial recovery services, IEPF claims, and asset recovery processes.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
                                
                                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8">
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">100+</div>
                                        <div class="text-sm text-white/70">Questions</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">5</div>
                                        <div class="text-sm text-white/70">Categories</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">24/7</div>
                                        <div class="text-sm text-white/70">Support</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Instant</div>
                                        <div class="text-sm text-white/70">Answers</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="hidden lg:block">
                                <div class="relative">
                                    <div class="w-96 h-96 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                        <div class="w-80 h-80 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                            <div class="w-64 h-64 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                                <div class="text-6xl text-white/80">❓</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="absolute -top-4 -right-4 w-16 h-16 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 flex items-center justify-center animate-bounce">
                                        <i class="fas fa-lightbulb text-white text-xl"></i>
                                    </div>
                                    <div class="absolute -bottom-4 -left-4 w-12 h-12 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 flex items-center justify-center animate-bounce" style="animation-delay: 0.5s;">
                                        <i class="fas fa-search text-white"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Slide 2: Expert Support -->
            <div class="slide" data-slide="2">
                <div class="min-h-[80vh] bg-gradient-to-r from-blue-600 to-purple-600 flex items-center">
                    <div class="absolute inset-0 bg-black/30"></div>
                    
                    <div class="absolute inset-0 opacity-10">
                        <div class="absolute inset-0" style="background-image: url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'0.1\'%3E%3Ccircle cx=\'30\' cy=\'30\' r=\'2\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')"></div>
                    </div>
                    
                    <div class="container-custom relative z-10">
                        <div class="grid lg:grid-cols-2 gap-12 items-center px-4">
                            <div class="text-white space-y-6">
                                <div class="space-y-4">
                                    <h1 class="text-4xl lg:text-6xl font-bold leading-tight">Expert Support</h1>
                                    <h2 class="text-xl lg:text-2xl font-medium text-white/90">Professional Guidance</h2>
                                    <p class="text-lg text-white/80 max-w-2xl leading-relaxed">Can't find your answer? Our expert team is ready to provide personalized assistance and detailed guidance for your specific situation.</p>
                                </div>
                                
                                <div class="flex flex-col sm:flex-row gap-4 pt-4">
                                    <a href="tel:+917070972333" class="inline-flex items-center justify-center px-8 py-4 bg-white text-gray-900 font-semibold rounded-lg hover:bg-gray-100 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                                        Call Now
                                        <i class="fas fa-phone ml-2 w-4 h-4"></i>
                                    </a>
                                    <a href="../contact.php" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-gray-900 transition-all duration-300">
                                        <i class="fas fa-envelope mr-2 w-4 h-4"></i>
                                        Email Us
                                    </a>
                                </div>
                                
                                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8">
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Expert</div>
                                        <div class="text-sm text-white/70">Team</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Quick</div>
                                        <div class="text-sm text-white/70">Response</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Free</div>
                                        <div class="text-sm text-white/70">Consultation</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">24/7</div>
                                        <div class="text-sm text-white/70">Available</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="hidden lg:block">
                                <div class="relative">
                                    <div class="w-96 h-96 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                        <div class="w-80 h-80 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                            <div class="w-64 h-64 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                                <div class="text-6xl text-white/80">🎯</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="absolute -top-4 -right-4 w-16 h-16 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 flex items-center justify-center animate-bounce">
                                        <i class="fas fa-headset text-white text-xl"></i>
                                    </div>
                                    <div class="absolute -bottom-4 -left-4 w-12 h-12 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 flex items-center justify-center animate-bounce" style="animation-delay: 0.5s;">
                                        <i class="fas fa-user-tie text-white"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Slider Controls -->
        <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center space-x-4">
            <div class="flex space-x-2">
                <button class="slider-dot active" data-slide="0" onclick="goToSlide(0)"></button>
                <button class="slider-dot" data-slide="1" onclick="goToSlide(1)"></button>
            </div>
        </div>
        
        <button class="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white p-2 rounded-full backdrop-blur-sm transition-all duration-300 opacity-70 hover:opacity-100" onclick="prevSlide()">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </button>
        <button class="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white p-2 rounded-full backdrop-blur-sm transition-all duration-300 opacity-70 hover:opacity-100" onclick="nextSlide()">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
        </button>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- FAQ Section -->
    <section id="faq-section" class="section-padding bg-white">
        <div class="container-custom px-4">
            <div class="max-w-4xl mx-auto">
                <!-- FAQ Categories -->
                <div class="flex flex-wrap justify-center gap-4 mb-12">
                    <button class="faq-category-btn active" data-category="all">All Questions</button>
                    <button class="faq-category-btn" data-category="iepf">IEPF Claims</button>
                    <button class="faq-category-btn" data-category="services">Services</button>
                    <button class="faq-category-btn" data-category="process">Process</button>
                    <button class="faq-category-btn" data-category="fees">Fees & Charges</button>
                </div>
                
                <!-- FAQ Items -->
                <div class="space-y-4">
                    <!-- IEPF Questions -->
                    <div class="faq-item" data-category="iepf">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">What is IEPF and how does it work?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed">
                                IEPF (Investor Education and Protection Fund) is a fund established by the Government of India under the Ministry of Corporate Affairs. When dividends remain unclaimed for 7 consecutive years, or shares are not claimed for 7 years, they are transferred to IEPF. We help you reclaim these transferred assets through proper legal procedures.
                            </p>
                        </div>
                    </div>
                    
                    <div class="faq-item" data-category="iepf">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">How long does the IEPF claim process take?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed">
                                The IEPF claim process typically takes 15-30 working days from the date of complete document submission. However, the timeline may vary depending on the complexity of the case and the response time from the concerned authorities.
                            </p>
                        </div>
                    </div>
                    
                    <div class="faq-item" data-category="iepf">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">What documents are required for IEPF claims?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed mb-4">
                                The required documents typically include:
                            </p>
                            <ul class="list-disc list-inside text-secondary-600 space-y-2">
                                <li>Original share certificates or demat statement</li>
                                <li>PAN Card copy</li>
                                <li>Aadhaar Card copy</li>
                                <li>Bank account details</li>
                                <li>Indemnity bond</li>
                                <li>Transmission documents (if applicable)</li>
                            </ul>
                        </div>
                    </div>
                    
                    <!-- Services Questions -->
                    <div class="faq-item" data-category="services">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">What services does KMFSL offer?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed mb-4">
                                KMFSL offers comprehensive financial recovery services including:
                            </p>
                            <ul class="list-disc list-inside text-secondary-600 space-y-2">
                                <li>IEPF Claims Recovery</li>
                                <li>Transmission of Shares</li>
                                <li>Demat of Physical Shares</li>
                                <li>Unclaimed Dividends Recovery</li>
                                <li>Wealth Samadhan Services</li>
                                <li>NRI Financial Services</li>
                                <li>Insurance Recovery</li>
                                <li>Property Claims</li>
                                <li>Bank Account Recovery</li>
                                <li>Mutual Funds Recovery</li>
                                <li>Provident Fund Claims</li>
                                <li>Debt Recovery Services</li>
                                <li>Share Conversion Services</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="faq-item" data-category="services">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">Do you provide services for NRI clients?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed">
                                Yes, we provide specialized NRI Samadhan services for Non-Resident Indians. Our NRI services include asset recovery, property claims, financial documentation, and comprehensive support for managing Indian assets from abroad. We understand the unique challenges faced by NRIs and provide tailored solutions.
                            </p>
                        </div>
                    </div>
                    
                    <!-- Process Questions -->
                    <div class="faq-item" data-category="process">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">How do I start the recovery process?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed mb-4">
                                Starting the recovery process is simple:
                            </p>
                            <ol class="list-decimal list-inside text-secondary-600 space-y-2">
                                <li>Contact us for a free consultation</li>
                                <li>Provide basic information about your assets</li>
                                <li>Our experts will assess your case</li>
                                <li>We'll provide a detailed action plan</li>
                                <li>Submit required documents</li>
                                <li>We handle the entire process</li>
                                <li>Receive your recovered assets</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="faq-item" data-category="process">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">What is your success rate?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed">
                                We maintain a success rate of over 98% in asset recovery cases. Our experienced team, thorough documentation process, and strong relationships with regulatory authorities contribute to our high success rate. We have successfully recovered over ₹500 crores for more than 10,000 satisfied clients.
                            </p>
                        </div>
                    </div>
                    
                    <!-- Fees Questions -->
                    <div class="faq-item" data-category="fees">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">What are your service charges?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed">
                                Our service charges are competitive and transparent. We offer different pricing models including percentage-based fees and fixed charges depending on the service type and complexity. The consultation is completely free, and we provide detailed cost breakdown before starting any work. No hidden charges guaranteed.
                            </p>
                        </div>
                    </div>
                    
                    <div class="faq-item" data-category="fees">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">Do you charge upfront fees?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed">
                                We offer flexible payment options. For most services, we work on a success-based model where major fees are charged only after successful recovery. Some services may require minimal processing fees upfront to cover documentation and filing costs. All fee structures are clearly explained during consultation.
                            </p>
                        </div>
                    </div>
                    
                    <!-- General Questions -->
                    <div class="faq-item" data-category="all">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">Is KMFSL a registered company?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed">
                                Yes, Kaimur Financial Services Pvt. Ltd. (KMFSL) is a legally registered private limited company with all necessary licenses and certifications. We operate under strict regulatory compliance and maintain the highest standards of professional service delivery.
                            </p>
                        </div>
                    </div>
                    
                    <div class="faq-item" data-category="all">
                        <div class="faq-question bg-gray-50 p-6 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors duration-300">
                            <div class="flex justify-between items-center">
                                <h3 class="text-lg font-semibold text-secondary-800">How can I contact KMFSL for support?</h3>
                                <i class="fas fa-chevron-down faq-icon text-primary-600 transition-transform duration-300"></i>
                            </div>
                        </div>
                        <div class="faq-answer hidden p-6 bg-white border-l-4 border-primary-600">
                            <p class="text-secondary-600 leading-relaxed mb-4">
                                You can contact us through multiple channels:
                            </p>
                            <ul class="list-disc list-inside text-secondary-600 space-y-2">
                                <li>Phone: +91 7070972333</li>
                                <li>Email: info@kmfsl.com</li>
                                <li>Website contact form</li>
                                <li>Live chat support</li>
                                <li>WhatsApp support</li>
                                <li>Office visit (by appointment)</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- CTA Section -->
    <section class="section-padding bg-gradient-to-r from-primary-600 to-accent-500">
        <div class="container-custom">
            <div class="text-center text-white">
                <h2 class="text-3xl lg:text-4xl font-bold mb-4">
                    Still Have Questions?
                </h2>
                <p class="text-xl mb-8 opacity-90">
                    Can't find the answer you're looking for? Our expert team is ready to help you with personalized assistance.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="../contact.php" class="bg-white text-primary-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
                        Contact Us
                    </a>
                    <a href="tel:+917070972333" class="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-primary-600 transition-colors duration-300">
                        Call: +91 7070972333
                    </a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- FAQ JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Slider Functionality
            let currentSlide = 0;
            const totalSlides = 2;
            let slideInterval;
            
            function showSlide(index) {
                const slides = document.querySelectorAll('.slide');
                const dots = document.querySelectorAll('.slider-dot');
                
                if (slides.length === 0) return;
                
                slides.forEach(slide => {
                    slide.classList.remove('active');
                });
                
                dots.forEach(dot => {
                    dot.classList.remove('active');
                });
                
                if (slides[index]) {
                    slides[index].classList.add('active');
                }
                
                if (dots[index]) {
                    dots[index].classList.add('active');
                }
            }
            
            window.showSlide = showSlide;
            
            function nextSlide() {
                currentSlide = (currentSlide + 1) % totalSlides;
                showSlide(currentSlide);
            }
            
            function prevSlide() {
                currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
                showSlide(currentSlide);
            }
            
            function goToSlide(index) {
                currentSlide = index;
                showSlide(currentSlide);
            }
            
            window.nextSlide = nextSlide;
            window.prevSlide = prevSlide;
            window.goToSlide = goToSlide;
            
            // Auto-play slider
            function startSlideshow() {
                slideInterval = setInterval(nextSlide, 5000);
            }
            
            function stopSlideshow() {
                clearInterval(slideInterval);
            }
            
            // Start auto-play
            startSlideshow();
            
            // Pause on hover
            const slider = document.querySelector('.hero-slider');
            if (slider) {
                slider.addEventListener('mouseenter', stopSlideshow);
                slider.addEventListener('mouseleave', startSlideshow);
            }
            
            // FAQ Toggle Functionality
            const faqQuestions = document.querySelectorAll('.faq-question');
            const categoryBtns = document.querySelectorAll('.faq-category-btn');
            const faqItems = document.querySelectorAll('.faq-item');
            
            // FAQ Question Toggle
            faqQuestions.forEach(question => {
                question.addEventListener('click', function() {
                    const faqItem = this.parentElement;
                    const answer = faqItem.querySelector('.faq-answer');
                    const icon = this.querySelector('.faq-icon');
                    
                    // Close other open FAQs
                    faqQuestions.forEach(otherQuestion => {
                        if (otherQuestion !== this) {
                            const otherFaqItem = otherQuestion.parentElement;
                            const otherAnswer = otherFaqItem.querySelector('.faq-answer');
                            const otherIcon = otherQuestion.querySelector('.faq-icon');
                            
                            otherAnswer.classList.add('hidden');
                            otherIcon.classList.remove('rotate-180');
                            otherQuestion.classList.remove('bg-primary-50');
                        }
                    });
                    
                    // Toggle current FAQ
                    answer.classList.toggle('hidden');
                    icon.classList.toggle('rotate-180');
                    this.classList.toggle('bg-primary-50');
                });
            });
            
            // Category Filter
            categoryBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const category = this.dataset.category;
                    
                    // Update active button
                    categoryBtns.forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Filter FAQ items
                    faqItems.forEach(item => {
                        if (category === 'all' || item.dataset.category === category) {
                            item.style.display = 'block';
                        } else {
                            item.style.display = 'none';
                            // Close any open answers in hidden items
                            const answer = item.querySelector('.faq-answer');
                            const icon = item.querySelector('.faq-icon');
                            const question = item.querySelector('.faq-question');
                            
                            answer.classList.add('hidden');
                            icon.classList.remove('rotate-180');
                            question.classList.remove('bg-primary-50');
                        }
                    });
                });
            });
            
            // Open first FAQ by default
            const firstFAQ = document.querySelector('.faq-question');
            if (firstFAQ) {
                firstFAQ.click();
            }
            
            // Smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    const href = this.getAttribute('href');
                    if (href && href !== '#' && href.length > 1) {
                        e.preventDefault();
                        const target = document.querySelector(href);
                        if (target) {
                            target.scrollIntoView({
                                behavior: 'smooth'
                            });
                        }
                    }
                });
            });
        });
    </script>
    
    <style>
        .faq-category-btn {
            @apply px-6 py-3 rounded-full border-2 border-primary-600 text-primary-600 font-semibold transition-all duration-300 hover:bg-primary-600 hover:text-white;
        }
        
        .faq-category-btn.active {
            @apply bg-primary-600 text-white;
        }
        
        .faq-icon {
            transition: transform 0.3s ease;
        }
        
        .faq-icon.rotate-180 {
            transform: rotate(180deg);
        }
    </style>
    
    <!-- Contact Form Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="max-w-4xl mx-auto">
                <div class="text-center mb-12">
                    <h2 class="text-4xl font-bold text-secondary-800 mb-4">Get Your <span class="text-gradient">Free Consultation</span></h2>
                    <p class="text-xl text-secondary-600">Fill out the form below and our experts will contact you within 24 hours to discuss your case.</p>
                </div>
                <div class="card max-w-4xl mx-auto">
                    <div class="text-center mb-8">
                        <div class="flex justify-center mb-6">
                            <img src="../kmfsl logo svg.svg" alt="KMFSL - Kaimur Financial Services" class="h-24 w-auto">
                        </div>
                        <h3 class="text-2xl font-bold text-secondary-800 mb-2">Send us your enquiry</h3>
                        <p class="text-secondary-600">We'll get back to you within 24 hours</p>
                    </div>
                    <form class="space-y-6" action="../subscribe.php" method="POST">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Full Name *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <input type="text" name="name" class="input-field pl-10" placeholder="Enter your full name" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                    </svg>
                                    <input type="email" name="email" class="input-field pl-10" placeholder="Enter your email address" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                    </svg>
                                    <input type="tel" name="phone" class="input-field pl-10" placeholder="Enter your phone number" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Service Required *</label>
                                <select name="service" class="input-field" required>
                                    <option value="">Select a service</option>
                                    <option value="IEPF Claim">IEPF Claim</option>
                                    <option value="Transmission of Shares">Transmission of Shares</option>
                                    <option value="Demat of Physical Shares">Demat of Physical Shares</option>
                                    <option value="Unclaimed Dividends">Unclaimed Dividends</option>
                                    <option value="Conversion of Shares/Debentures">Conversion of Shares/Debentures</option>
                                    <option value="Property Claim Samadhan">Property Claim Samadhan</option>
                                    <option value="Debtor Recovery">Debtor Recovery</option>
                                    <option value="Recovery of Unclaimed Mutual Funds">Recovery of Unclaimed Mutual Funds</option>
                                    <option value="Recovery of Inoperative Bank Accounts">Recovery of Inoperative Bank Accounts</option>
                                    <option value="Provident Funds Claim">Provident Funds Claim</option>
                                    <option value="Recovery of Unclaimed Matured Insurance">Recovery of Unclaimed Matured Insurance</option>
                                    <option value="Wealth Samadhan">Wealth Samadhan</option>
                                    <option value="NRI Samadhan">NRI Samadhan</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Preferred Contact Method</label>
                            <div class="flex space-x-4">
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="email" checked>
                                    Email
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="phone">
                                    Phone
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="whatsapp">
                                    WhatsApp
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Message *</label>
                            <textarea name="message" rows="4" class="input-field resize-none" placeholder="Please describe your requirements or any specific questions you have..." required></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn-primary inline-flex items-center justify-center min-w-[200px]">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                                </svg>
                                Send Enquiry
                            </button>
                        </div>
                        <div class="text-center text-sm text-secondary-500">
                            <p>By submitting this form, you agree to our <a href="../privacy-policy.php" class="text-primary-600 hover:underline">Privacy Policy</a> and <a href="../terms-conditions.php" class="text-primary-600 hover:underline">Terms & Conditions</a>.</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
</body>
</html>