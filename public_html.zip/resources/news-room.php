<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Room - KMFSL | Latest News & Company Updates</title>
    <meta name="description" content="Stay updated with the latest news, announcements, and industry updates from KMFSL. Read about our achievements, new services, and company milestones.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
                    
                    <div class="container-custom relative z-10">
                        <div class="grid lg:grid-cols-2 gap-12 items-center px-4">
                            <div class="text-white space-y-6">
                                <div class="space-y-4">
                                    <h1 class="text-4xl lg:text-6xl font-bold leading-tight">News Room</h1>
                                    <h2 class="text-xl lg:text-2xl font-medium text-white/90">Latest Updates & Announcements</h2>
                                    <p class="text-lg text-white/80 max-w-2xl leading-relaxed">Stay informed with the latest news, company updates, industry announcements, and important notices from KMFSL and the financial recovery sector.</p>
                                </div>
                                
                                <div class="flex flex-col sm:flex-row gap-4 pt-4">
                                    <a href="#news-section" class="inline-flex items-center justify-center px-8 py-4 bg-white text-gray-900 font-semibold rounded-lg hover:bg-gray-100 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                                        Latest News
                                        <i class="fas fa-arrow-down ml-2 w-4 h-4"></i>
                                    </a>
                                    <a href="#press-releases" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-gray-900 transition-all duration-300">
                                        <i class="fas fa-newspaper mr-2 w-4 h-4"></i>
                                        Press Releases
                                    </a>
                                </div>
                                
                                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8">
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Latest</div>
                                        <div class="text-sm text-white/70">Updates</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Company</div>
                                        <div class="text-sm text-white/70">News</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Industry</div>
                                        <div class="text-sm text-white/70">Insights</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Press</div>
                                        <div class="text-sm text-white/70">Releases</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="hidden lg:block">
                                <div class="relative">
                                    <div class="w-96 h-96 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                        <div class="w-80 h-80 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                            <div class="w-64 h-64 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                                <div class="text-6xl text-white/80">📰</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="absolute -top-4 -right-4 w-16 h-16 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 flex items-center justify-center animate-bounce">
                                        <i class="fas fa-bullhorn text-white text-xl"></i>
                                    </div>
                                    <div class="absolute -bottom-4 -left-4 w-12 h-12 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 flex items-center justify-center animate-bounce" style="animation-delay: 0.5s;">
                                        <i class="fas fa-rss text-white"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Slide 2: Media Coverage -->
            <div class="slide" data-slide="2">
                <div class="min-h-[80vh] bg-gradient-to-r from-red-600 to-orange-600 flex items-center">
                    <div class="absolute inset-0 bg-black/30"></div>
                    
                    <div class="absolute inset-0 opacity-10">
                        <div class="absolute inset-0" style="background-image: url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'0.1\'%3E%3Ccircle cx=\'30\' cy=\'30\' r=\'2\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')"></div>
                    </div>
                    
                    <div class="container-custom relative z-10">
                        <div class="grid lg:grid-cols-2 gap-12 items-center px-4">
                            <div class="text-white space-y-6">
                                <div class="space-y-4">
                                    <h1 class="text-4xl lg:text-6xl font-bold leading-tight">Media Coverage</h1>
                                    <h2 class="text-xl lg:text-2xl font-medium text-white/90">Industry Recognition</h2>
                                    <p class="text-lg text-white/80 max-w-2xl leading-relaxed">Discover how KMFSL is making headlines in the financial recovery industry with our innovative services, client success stories, and expert insights.</p>
                                </div>
                                
                                <div class="flex flex-col sm:flex-row gap-4 pt-4">
                                    <a href="#media-contact" class="inline-flex items-center justify-center px-8 py-4 bg-white text-gray-900 font-semibold rounded-lg hover:bg-gray-100 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                                        Media Contact
                                        <i class="fas fa-phone ml-2 w-4 h-4"></i>
                                    </a>
                                    <a href="../contact.php" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-gray-900 transition-all duration-300">
                                        <i class="fas fa-envelope mr-2 w-4 h-4"></i>
                                        Press Inquiry
                                    </a>
                                </div>
                                
                                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8">
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Media</div>
                                        <div class="text-sm text-white/70">Coverage</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Expert</div>
                                        <div class="text-sm text-white/70">Opinions</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Industry</div>
                                        <div class="text-sm text-white/70">Awards</div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-2xl font-bold text-white">Press</div>
                                        <div class="text-sm text-white/70">Features</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="hidden lg:block">
                                <div class="relative">
                                    <div class="w-96 h-96 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                        <div class="w-80 h-80 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                            <div class="w-64 h-64 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 flex items-center justify-center">
                                                <div class="text-6xl text-white/80">📺</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="absolute -top-4 -right-4 w-16 h-16 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 flex items-center justify-center animate-bounce">
                                        <i class="fas fa-microphone text-white text-xl"></i>
                                    </div>
                                    <div class="absolute -bottom-4 -left-4 w-12 h-12 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 flex items-center justify-center animate-bounce" style="animation-delay: 0.5s;">
                                        <i class="fas fa-camera text-white"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Slider Controls -->
        <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center space-x-4">
            <div class="flex space-x-2">
                <button class="slider-dot active" data-slide="0" onclick="goToSlide(0)"></button>
                <button class="slider-dot" data-slide="1" onclick="goToSlide(1)"></button>
            </div>
        </div>
        
        <button class="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white p-2 rounded-full backdrop-blur-sm transition-all duration-300 opacity-70 hover:opacity-100" onclick="prevSlide()">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </button>
        <button class="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white p-2 rounded-full backdrop-blur-sm transition-all duration-300 opacity-70 hover:opacity-100" onclick="nextSlide()">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
        </button>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- News Section -->
    <section id="news-section" class="section-padding bg-white">
        <div class="container-custom px-4">
            <!-- News Categories -->
            <div class="flex flex-wrap justify-center gap-4 mb-12">
                <button class="news-category-btn active" data-category="all">All News</button>
                <button class="news-category-btn" data-category="company">Company News</button>
                <button class="news-category-btn" data-category="industry">Industry Updates</button>
                <button class="news-category-btn" data-category="achievements">Achievements</button>
                <button class="news-category-btn" data-category="announcements">Announcements</button>
            </div>
            
            <!-- Featured News -->
            <div class="mb-16">
                <div class="bg-gradient-to-r from-primary-600 to-accent-500 rounded-2xl overflow-hidden shadow-2xl">
                    <div class="grid lg:grid-cols-2 gap-0">
                        <div class="p-8 lg:p-12 text-white">
                            <div class="mb-4">
                                <span class="bg-white/20 text-white px-3 py-1 rounded-full text-sm font-semibold">Breaking News</span>
                            </div>
                            <h2 class="text-3xl lg:text-4xl font-bold mb-4 leading-tight">
                                KMFSL Crosses ₹500 Crore Recovery Milestone
                            </h2>
                            <p class="text-white/90 text-lg mb-6 leading-relaxed">
                                We are proud to announce that KMFSL has successfully recovered over ₹500 crores in unclaimed assets for our clients, marking a significant milestone in our journey of financial recovery excellence.
                            </p>
                            <div class="flex items-center mb-6">
                                <div class="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mr-3">
                                    <i class="fas fa-calendar text-white"></i>
                                </div>
                                <div>
                                    <div class="font-semibold">January 15, 2024</div>
                                    <div class="text-white/70 text-sm">Company Achievement</div>
                                </div>
                            </div>
                            <a href="#" class="inline-flex items-center bg-white text-primary-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
                                Read Full Story <i class="fas fa-arrow-right ml-2"></i>
                            </a>
                        </div>
                        <div class="hidden lg:block">
                            <div class="w-full h-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                            <div class="text-center text-white">
                                <svg class="w-16 h-16 mx-auto mb-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M12 2l3.09 6.26L22 9l-5 4.87L18.18 21 12 17.77 5.82 21 7 13.87 2 9l6.91-.74L12 2z"></path>
                                </svg>
                                <h3 class="text-xl font-bold">₹500 Crore Milestone</h3>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- News Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- News Item 1 -->
                <article class="news-item card" data-category="company">
                    <div class="mb-6">
                        <div class="w-full h-48 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
                                <div class="text-center text-white">
                                    <svg class="w-12 h-12 mx-auto mb-2" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                    </svg>
                                    <h4 class="font-bold">New Office Opening</h4>
                                </div>
                            </div>
                    </div>
                    <div class="mb-4">
                        <span class="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-semibold">Company News</span>
                    </div>
                    <h3 class="text-xl font-bold text-secondary-800 mb-3 hover:text-primary-600 transition-colors duration-300">
                        <a href="#">KMFSL Opens New Branch Office in Mumbai</a>
                    </h3>
                    <p class="text-secondary-600 mb-4 leading-relaxed">
                        Expanding our reach to serve more clients, KMFSL inaugurates a new branch office in Mumbai to provide better accessibility to financial recovery services.
                    </p>
                    <div class="flex items-center justify-between text-sm text-secondary-500">
                        <div class="flex items-center">
                            <i class="fas fa-calendar mr-2"></i>
                            <span>Jan 12, 2024</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-map-marker-alt mr-2"></i>
                            <span>Mumbai</span>
                        </div>
                    </div>
                </article>
                
                <!-- News Item 2 -->
                <article class="news-item card" data-category="industry">
                    <div class="mb-6">
                        <div class="w-full h-48 bg-gradient-to-br from-red-500 to-pink-600 rounded-lg flex items-center justify-center">
                                <div class="text-center text-white">
                                    <svg class="w-12 h-12 mx-auto mb-2" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path>
                                    </svg>
                                    <h4 class="font-bold">IEPF Updates</h4>
                                </div>
                            </div>
                    </div>
                    <div class="mb-4">
                        <span class="bg-green-100 text-green-600 px-3 py-1 rounded-full text-sm font-semibold">Industry Updates</span>
                    </div>
                    <h3 class="text-xl font-bold text-secondary-800 mb-3 hover:text-primary-600 transition-colors duration-300">
                        <a href="#">New IEPF Guidelines Released by MCA</a>
                    </h3>
                    <p class="text-secondary-600 mb-4 leading-relaxed">
                        Ministry of Corporate Affairs releases updated guidelines for IEPF claims, making the process more streamlined and user-friendly for investors.
                    </p>
                    <div class="flex items-center justify-between text-sm text-secondary-500">
                        <div class="flex items-center">
                            <i class="fas fa-calendar mr-2"></i>
                            <span>Jan 10, 2024</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-building mr-2"></i>
                            <span>MCA</span>
                        </div>
                    </div>
                </article>
                
                <!-- News Item 3 -->
                <article class="news-item card" data-category="achievements">
                    <div class="mb-6">
                        <div class="w-full h-48 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-lg flex items-center justify-center">
                                <div class="text-center text-white">
                                    <svg class="w-12 h-12 mx-auto mb-2" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                                    </svg>
                                    <h4 class="font-bold">Award Recognition</h4>
                                </div>
                            </div>
                    </div>
                    <div class="mb-4">
                        <span class="bg-purple-100 text-purple-600 px-3 py-1 rounded-full text-sm font-semibold">Achievements</span>
                    </div>
                    <h3 class="text-xl font-bold text-secondary-800 mb-3 hover:text-primary-600 transition-colors duration-300">
                        <a href="#">KMFSL Wins 'Best Financial Recovery Service' Award</a>
                    </h3>
                    <p class="text-secondary-600 mb-4 leading-relaxed">
                        Recognized for excellence in financial recovery services, KMFSL receives the prestigious industry award for outstanding client service and success rates.
                    </p>
                    <div class="flex items-center justify-between text-sm text-secondary-500">
                        <div class="flex items-center">
                            <i class="fas fa-calendar mr-2"></i>
                            <span>Jan 8, 2024</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-trophy mr-2"></i>
                            <span>Industry Award</span>
                        </div>
                    </div>
                </article>
                
                <!-- News Item 4 -->
                <article class="news-item card" data-category="announcements">
                    <div class="mb-6">
                        <div class="w-full h-48 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-lg flex items-center justify-center">
                                <div class="text-center text-white">
                                    <svg class="w-12 h-12 mx-auto mb-2" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path>
                                    </svg>
                                    <h4 class="font-bold">New Services</h4>
                                </div>
                            </div>
                    </div>
                    <div class="mb-4">
                        <span class="bg-yellow-100 text-yellow-600 px-3 py-1 rounded-full text-sm font-semibold">Announcements</span>
                    </div>
                    <h3 class="text-xl font-bold text-secondary-800 mb-3 hover:text-primary-600 transition-colors duration-300">
                        <a href="#">Launch of Digital Asset Recovery Platform</a>
                    </h3>
                    <p class="text-secondary-600 mb-4 leading-relaxed">
                        KMFSL announces the launch of its new digital platform for asset recovery, making it easier for clients to track and manage their recovery processes online.
                    </p>
                    <div class="flex items-center justify-between text-sm text-secondary-500">
                        <div class="flex items-center">
                            <i class="fas fa-calendar mr-2"></i>
                            <span>Jan 5, 2024</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-laptop mr-2"></i>
                            <span>Digital Platform</span>
                        </div>
                    </div>
                </article>
                
                <!-- News Item 5 -->
                <article class="news-item card" data-category="company">
                    <div class="mb-6">
                        <div class="w-full h-48 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg flex items-center justify-center">
                                <div class="text-center text-white">
                                    <svg class="w-12 h-12 mx-auto mb-2" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z"></path>
                                    </svg>
                                    <h4 class="font-bold">Team Expansion</h4>
                                </div>
                            </div>
                    </div>
                    <div class="mb-4">
                        <span class="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-semibold">Company News</span>
                    </div>
                    <h3 class="text-xl font-bold text-secondary-800 mb-3 hover:text-primary-600 transition-colors duration-300">
                        <a href="#">KMFSL Expands Expert Team with 50 New Professionals</a>
                    </h3>
                    <p class="text-secondary-600 mb-4 leading-relaxed">
                        To meet growing demand, KMFSL adds 50 new financial recovery experts and legal professionals to strengthen our service capabilities.
                    </p>
                    <div class="flex items-center justify-between text-sm text-secondary-500">
                        <div class="flex items-center">
                            <i class="fas fa-calendar mr-2"></i>
                            <span>Jan 3, 2024</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-users mr-2"></i>
                            <span>Team Growth</span>
                        </div>
                    </div>
                </article>
                
                <!-- News Item 6 -->
                <article class="news-item card" data-category="industry">
                    <div class="mb-6">
                        <div class="w-full h-48 bg-gradient-to-br from-red-500 to-rose-600 rounded-lg flex items-center justify-center">
                                <div class="text-center text-white">
                                    <svg class="w-12 h-12 mx-auto mb-2" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z"></path>
                                    </svg>
                                    <h4 class="font-bold">Market Report</h4>
                                </div>
                            </div>
                    </div>
                    <div class="mb-4">
                        <span class="bg-green-100 text-green-600 px-3 py-1 rounded-full text-sm font-semibold">Industry Updates</span>
                    </div>
                    <h3 class="text-xl font-bold text-secondary-800 mb-3 hover:text-primary-600 transition-colors duration-300">
                        <a href="#">Unclaimed Assets in India Reach ₹50,000 Crores</a>
                    </h3>
                    <p class="text-secondary-600 mb-4 leading-relaxed">
                        Latest industry report reveals that unclaimed financial assets in India have reached a staggering ₹50,000 crores, highlighting the need for professional recovery services.
                    </p>
                    <div class="flex items-center justify-between text-sm text-secondary-500">
                        <div class="flex items-center">
                            <i class="fas fa-calendar mr-2"></i>
                            <span>Dec 28, 2023</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-chart-bar mr-2"></i>
                            <span>Market Report</span>
                        </div>
                    </div>
                </article>
            </div>
            
            <!-- Load More Button -->
            <div class="text-center mt-12">
                <button class="btn-primary" onclick="loadMoreNews()">
                    Load More News <i class="fas fa-arrow-down ml-2"></i>
                </button>
            </div>
        </div>
    </section>
    
    <!-- Press Releases -->
    <section id="press-releases" class="section-padding bg-gray-50">
        <div class="container-custom px-4">
            <div class="text-center mb-12">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Press <span class="text-gradient">Releases</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Official press releases and media announcements from KMFSL.
                </p>
            </div>
            
            <div class="space-y-6">
                <!-- Press Release 1 -->
                <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                    <div class="flex items-start justify-between">
                        <div class="flex-1">
                            <div class="flex items-center mb-3">
                                <span class="bg-red-100 text-red-600 px-3 py-1 rounded-full text-sm font-semibold mr-4">Press Release</span>
                                <span class="text-secondary-500 text-sm">January 15, 2024</span>
                            </div>
                            <h3 class="text-xl font-bold text-secondary-800 mb-3">
                                KMFSL Achieves Historic ₹500 Crore Recovery Milestone, Announces Expansion Plans
                            </h3>
                            <p class="text-secondary-600 leading-relaxed mb-4">
                                Kaimur Financial Services Pvt. Ltd. today announced that it has successfully recovered over ₹500 crores in unclaimed assets for its clients, marking a significant milestone in the company's growth trajectory...
                            </p>
                            <a href="#" class="text-primary-600 font-semibold hover:underline">
                                Read Full Press Release <i class="fas fa-external-link-alt ml-1"></i>
                            </a>
                        </div>
                        <div class="ml-6">
                            <button class="bg-primary-100 text-primary-600 p-3 rounded-lg hover:bg-primary-200 transition-colors duration-300">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Press Release 2 -->
                <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                    <div class="flex items-start justify-between">
                        <div class="flex-1">
                            <div class="flex items-center mb-3">
                                <span class="bg-red-100 text-red-600 px-3 py-1 rounded-full text-sm font-semibold mr-4">Press Release</span>
                                <span class="text-secondary-500 text-sm">January 8, 2024</span>
                            </div>
                            <h3 class="text-xl font-bold text-secondary-800 mb-3">
                                KMFSL Receives 'Best Financial Recovery Service' Award at National Finance Summit
                            </h3>
                            <p class="text-secondary-600 leading-relaxed mb-4">
                                The company was recognized for its outstanding contribution to financial asset recovery and exceptional client service standards...
                            </p>
                            <a href="#" class="text-primary-600 font-semibold hover:underline">
                                Read Full Press Release <i class="fas fa-external-link-alt ml-1"></i>
                            </a>
                        </div>
                        <div class="ml-6">
                            <button class="bg-primary-100 text-primary-600 p-3 rounded-lg hover:bg-primary-200 transition-colors duration-300">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Media Contact -->
    <section id="media-contact" class="section-padding bg-gradient-to-r from-primary-600 to-accent-500">
        <div class="container-custom">
            <div class="text-center text-white">
                <h2 class="text-3xl lg:text-4xl font-bold mb-4">
                    Media Inquiries
                </h2>
                <p class="text-xl mb-8 opacity-90">
                    For press inquiries, interviews, or media-related questions, please contact our media relations team.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="mailto:media@kmfsl.com" class="bg-white text-primary-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
                        <i class="fas fa-envelope mr-2"></i>media@kmfsl.com
                    </a>
                    <a href="tel:+917070972333" class="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-primary-600 transition-colors duration-300">
                        <i class="fas fa-phone mr-2"></i>+91 7070972333
                    </a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- News JavaScript -->
    <script>
        // Hero Slider Functionality
        let currentSlide = 0;
        const slides = document.querySelectorAll('.slide');
        const dots = document.querySelectorAll('.slider-dot');
        const totalSlides = slides.length;
        
        function showSlide(index) {
            slides.forEach((slide, i) => {
                slide.classList.toggle('active', i === index);
            });
            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === index);
            });
        }
        
        function nextSlide() {
            currentSlide = (currentSlide + 1) % totalSlides;
            showSlide(currentSlide);
        }
        
        function prevSlide() {
            currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
            showSlide(currentSlide);
        }
        
        function goToSlide(index) {
            currentSlide = index;
            showSlide(currentSlide);
        }
        
        // Auto-advance slides
        setInterval(nextSlide, 8000);
        
        document.addEventListener('DOMContentLoaded', function() {
            const categoryBtns = document.querySelectorAll('.news-category-btn');
            const newsItems = document.querySelectorAll('.news-item');
            
            // Category Filter
            categoryBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const category = this.dataset.category;
                    
                    // Update active button
                    categoryBtns.forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Filter news items
                    newsItems.forEach(item => {
                        if (category === 'all' || item.dataset.category === category) {
                            item.style.display = 'block';
                        } else {
                            item.style.display = 'none';
                        }
                    });
                });
            });
        });
        
        function loadMoreNews() {
            // In a real implementation, this would load more news via AJAX
            alert('More news articles would be loaded here in the actual implementation.');
        }
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                const href = this.getAttribute('href');
                if (href && href !== '#' && href.length > 1) {
                    e.preventDefault();
                    const target = document.querySelector(href);
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    </script>
    
    <style>
        .news-category-btn {
            @apply px-6 py-3 rounded-full border-2 border-primary-600 text-primary-600 font-semibold transition-all duration-300 hover:bg-primary-600 hover:text-white;
        }
        
        .news-category-btn.active {
            @apply bg-primary-600 text-white;
        }
        
        /* Hero Slider Styles */
        .hero-slider {
            position: relative;
            height: 100%;
        }
        
        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.8s ease-in-out;
        }
        
        .slide.active {
            opacity: 1;
        }
        
        .slider-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.5);
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .slider-dot.active {
            background-color: white;
            transform: scale(1.2);
        }
    </style>
    
    <!-- Contact Form Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="max-w-4xl mx-auto">
                <div class="text-center mb-12">
                    <h2 class="text-4xl font-bold text-secondary-800 mb-4">Get Your <span class="text-gradient">Free Consultation</span></h2>
                    <p class="text-xl text-secondary-600">Fill out the form below and our experts will contact you within 24 hours to discuss your case.</p>
                </div>
                <div class="card max-w-4xl mx-auto">
                    <div class="text-center mb-8">
                        <div class="flex justify-center mb-6">
                            <img src="../kmfsl logo svg.svg" alt="KMFSL - Kaimur Financial Services" class="h-24 w-auto">
                        </div>
                        <h3 class="text-2xl font-bold text-secondary-800 mb-2">Send us your enquiry</h3>
                        <p class="text-secondary-600">We'll get back to you within 24 hours</p>
                    </div>
                    <form class="space-y-6" action="../subscribe.php" method="POST">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Full Name *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <input type="text" name="name" class="input-field pl-10" placeholder="Enter your full name" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                    </svg>
                                    <input type="email" name="email" class="input-field pl-10" placeholder="Enter your email address" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                    </svg>
                                    <input type="tel" name="phone" class="input-field pl-10" placeholder="Enter your phone number" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Service Required *</label>
                                <select name="service" class="input-field" required>
                                    <option value="">Select a service</option>
                                    <option value="IEPF Claim">IEPF Claim</option>
                                    <option value="Transmission of Shares">Transmission of Shares</option>
                                    <option value="Demat of Physical Shares">Demat of Physical Shares</option>
                                    <option value="Unclaimed Dividends">Unclaimed Dividends</option>
                                    <option value="Conversion of Shares/Debentures">Conversion of Shares/Debentures</option>
                                    <option value="Property Claim Samadhan">Property Claim Samadhan</option>
                                    <option value="Debtor Recovery">Debtor Recovery</option>
                                    <option value="Recovery of Unclaimed Mutual Funds">Recovery of Unclaimed Mutual Funds</option>
                                    <option value="Recovery of Inoperative Bank Accounts">Recovery of Inoperative Bank Accounts</option>
                                    <option value="Provident Funds Claim">Provident Funds Claim</option>
                                    <option value="Recovery of Unclaimed Matured Insurance">Recovery of Unclaimed Matured Insurance</option>
                                    <option value="Wealth Samadhan">Wealth Samadhan</option>
                                    <option value="NRI Samadhan">NRI Samadhan</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Preferred Contact Method</label>
                            <div class="flex space-x-4">
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="email" checked>
                                    Email
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="phone">
                                    Phone
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="whatsapp">
                                    WhatsApp
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Message *</label>
                            <textarea name="message" rows="4" class="input-field resize-none" placeholder="Please describe your requirements or any specific questions you have..." required></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn-primary inline-flex items-center justify-center min-w-[200px]">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                                </svg>
                                Send Enquiry
                            </button>
                        </div>
                        <div class="text-center text-sm text-secondary-500">
                            <p>By submitting this form, you agree to our <a href="../privacy-policy.php" class="text-primary-600 hover:underline">Privacy Policy</a> and <a href="../terms-conditions.php" class="text-primary-600 hover:underline">Terms & Conditions</a>.</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
</body>
</html>