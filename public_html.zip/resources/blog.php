<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - KMFSL | Financial Recovery Insights & Expert Articles</title>
    <meta name="description" content="Stay updated with latest insights, expert articles, and industry news on financial recovery, IEPF claims, and asset management from KMFSL experts.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>

    <!-- News Room Hero Section -->
    <section class="section-padding bg-gradient-to-br from-green-50 via-white to-blue-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <div class="inline-flex items-center bg-green-100 text-green-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M552 64H88c-13.255 0-24 10.745-24 24v8H24c-13.255 0-24 10.745-24 24v272c0 30.928 25.072 56 56 56h472c26.51 0 48-21.49 48-48V88c0-13.255-10.745-24-24-24zM56 400a8 8 0 0 1-8-8V144h16v248a8 8 0 0 1-8 8zm236-16H140c-6.627 0-12-5.373-12-12v-8c0-6.627 5.373-12 12-12h152c6.627 0 12 5.373 12 12v8c0 6.627-5.373 12-12 12zm208 0H348c-6.627 0-12-5.373-12-12v-8c0-6.627 5.373-12 12-12h152c6.627 0 12 5.373 12 12v8c0 6.627-5.373 12-12 12zm-208-96H140c-6.627 0-12-5.373-12-12v-8c0-6.627 5.373-12 12-12h152c6.627 0 12 5.373 12 12v8c0 6.627-5.373 12-12 12zm208 0H348c-6.627 0-12-5.373-12-12v-8c0-6.627 5.373-12 12-12h152c6.627 0 12 5.373 12 12v8c0 6.627-5.373 12-12 12zm0-96H140c-6.627 0-12-5.373-12-12v-40c0-6.627 5.373-12 12-12h360c6.627 0 12 5.373 12 12v40c0 6.627-5.373 12-12 12z"></path>
                    </svg>
                    Latest News & Updates
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">KMFSL <span class="text-gradient">News Room</span></h1>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto leading-relaxed">Stay informed with the latest news, regulatory updates, company announcements, and industry insights from Kaimur Financial Services and the financial sector.</p>
            </div>
            
            <div class="max-w-4xl mx-auto mb-12">
                <div class="flex flex-col md:flex-row gap-4">
                    <div class="flex-1 relative">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-5 h-5" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                        </svg>
                        <input type="text" placeholder="Search news, updates, or topics..." class="w-full pl-12 pr-4 py-3 border border-secondary-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                    </div>
                    <select class="px-4 py-3 border border-secondary-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                        <option value="All">All</option>
                        <option value="Company News">Company News</option>
                        <option value="Industry Updates">Industry Updates</option>
                        <option value="Regulatory Changes">Regulatory Changes</option>
                        <option value="Awards & Recognition">Awards & Recognition</option>
                        <option value="Press Releases">Press Releases</option>
                        <option value="Market Insights">Market Insights</option>
                    </select>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured News Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Featured <span class="text-gradient">News</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Breaking news and important updates from KMFSL and the financial services industry.</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <article class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div class="p-6">
                        <div class="text-4xl mb-4">🎉</div>
                        <div class="flex items-center justify-between mb-3">
                            <span class="bg-green-100 text-green-600 text-xs font-semibold px-2 py-1 rounded-full">Company News</span>
                            <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Breaking</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">KMFSL Achieves Milestone: ₹500 Crores in Asset Recovery</h3>
                        <p class="text-secondary-600 mb-4 line-clamp-3">Kaimur Financial Services Pvt. Ltd. celebrates a significant milestone, successfully recovering over ₹500 crores in unclaimed assets for clients across India.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <div class="flex items-center gap-4">
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <span>KMFSL Media Team</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                    </svg>
                                    <span>1/15/2024</span>
                                </div>
                            </div>
                            <div class="flex items-center gap-1">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                </svg>
                                <span>3500</span>
                            </div>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-xs text-secondary-500">KMFSL Press Release</span>
                            <button class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group">
                                Read More
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3 group-hover:translate-x-1 transition-transform" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </article>
                
                <article class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div class="p-6">
                        <div class="text-4xl mb-4">📋</div>
                        <div class="flex items-center justify-between mb-3">
                            <span class="bg-green-100 text-green-600 text-xs font-semibold px-2 py-1 rounded-full">Regulatory Changes</span>
                            <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Breaking</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">New SEBI Guidelines Simplify IEPF Claim Process</h3>
                        <p class="text-secondary-600 mb-4 line-clamp-3">Securities and Exchange Board of India introduces new guidelines to streamline the IEPF claim process, benefiting millions of investors.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <div class="flex items-center gap-4">
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <span>Regulatory Team</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                    </svg>
                                    <span>1/12/2024</span>
                                </div>
                            </div>
                            <div class="flex items-center gap-1">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                </svg>
                                <span>2800</span>
                            </div>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-xs text-secondary-500">SEBI Official Notification</span>
                            <button class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group">
                                Read More
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3 group-hover:translate-x-1 transition-transform" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </article>
                
                <article class="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div class="p-6">
                        <div class="text-4xl mb-4">🏆</div>
                        <div class="flex items-center justify-between mb-3">
                            <span class="bg-green-100 text-green-600 text-xs font-semibold px-2 py-1 rounded-full">Awards & Recognition</span>
                            <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Breaking</span>
                        </div>
                        <h3 class="text-xl font-semibold text-secondary-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">KMFSL Wins "Best Financial Recovery Service" Award 2024</h3>
                        <p class="text-secondary-600 mb-4 line-clamp-3">Recognized for excellence in financial asset recovery services, KMFSL receives prestigious industry award at the Financial Services Excellence Awards.</p>
                        <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                            <div class="flex items-center gap-4">
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <span>Awards Committee</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                    </svg>
                                    <span>1/10/2024</span>
                                </div>
                            </div>
                            <div class="flex items-center gap-1">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                </svg>
                                <span>2200</span>
                            </div>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-xs text-secondary-500">Financial Services Excellence Awards</span>
                            <button class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group">
                                Read More
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3 group-hover:translate-x-1 transition-transform" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <!-- All News Section -->
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
                <div class="lg:col-span-2">
                    <div class="flex items-center justify-between mb-8">
                        <h2 class="text-2xl font-bold text-secondary-800">All News (10)</h2>
                    </div>
                    
                    <div class="space-y-8">
                        <article class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border">
                            <div class="flex flex-col md:flex-row gap-6">
                                <div class="md:w-1/4">
                                    <div class="w-full h-32 bg-gradient-to-br from-green-100 to-blue-100 rounded-lg flex items-center justify-center text-4xl">🎉</div>
                                </div>
                                <div class="md:w-3/4">
                                    <div class="flex items-center gap-2 mb-3">
                                        <span class="bg-green-100 text-green-600 text-xs font-semibold px-2 py-1 rounded-full">Company News</span>
                                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                                    </div>
                                    <h3 class="text-xl font-semibold text-secondary-800 mb-3 hover:text-primary-600 transition-colors">KMFSL Achieves Milestone: ₹500 Crores in Asset Recovery</h3>
                                    <p class="text-secondary-600 mb-4 line-clamp-2">Kaimur Financial Services Pvt. Ltd. celebrates a significant milestone, successfully recovering over ₹500 crores in unclaimed assets for clients across India.</p>
                                    <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                                        <div class="flex items-center gap-4">
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                                </svg>
                                                <span>KMFSL Media Team</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                                </svg>
                                                <span>1/15/2024</span>
                                            </div>
                                        </div>
                                        <div class="flex items-center gap-1">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                            </svg>
                                            <span>3500</span>
                                        </div>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <div class="flex flex-wrap gap-2">
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Milestone</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Asset Recovery</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Company Achievement</span>
                                        </div>
                                        <div class="flex items-center gap-3">
                                            <span class="text-xs text-secondary-500">KMFSL Press Release</span>
                                            <button class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group">
                                                Read Full Article
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 group-hover:translate-x-1 transition-transform" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M432,320H400a16,16,0,0,0-16,16V448H64V128H208a16,16,0,0,0,16-16V80a16,16,0,0,0-16-16H48A48,48,0,0,0,0,112V464a48,48,0,0,0,48,48H400a48,48,0,0,0,48-48V336A16,16,0,0,0,432,320ZM488,0h-128c-21.37,0-32.05,25.91-17,41l35.73,35.73L135,320.37a24,24,0,0,0,0,34L157.67,377a24,24,0,0,0,34,0L435.28,133.32,471,169c15,15,41,4.5,41-17V24A24,24,0,0,0,488,0Z"></path>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </article>
                        
                        <!-- Article 2 -->
                        <article class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
                            <div class="flex flex-col md:flex-row gap-6">
                                <div class="md:w-1/4">
                                    <div class="w-full h-32 bg-gradient-to-br from-primary-100 to-accent-100 rounded-lg flex items-center justify-center text-4xl">💡</div>
                                </div>
                                <div class="md:w-3/4">
                                    <div class="flex items-center gap-2 mb-3">
                                        <span class="bg-primary-100 text-primary-600 text-xs font-semibold px-2 py-1 rounded-full">Investment Tips</span>
                                        <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                                    </div>
                                    <h3 class="text-xl font-semibold text-secondary-800 mb-3 hover:text-primary-600 transition-colors">
                                        <a href="/resources/blog/2">Top 10 Investment Mistakes to Avoid in 2024</a>
                                    </h3>
                                    <p class="text-secondary-600 mb-4 line-clamp-2">Discover the most common investment mistakes that can cost you money and learn how to avoid them.</p>
                                    <div class="flex items-center justify-between text-sm text-secondary-500 mb-4">
                                        <div class="flex items-center gap-4">
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                                </svg>
                                                <span>Priya Sharma</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                                                </svg>
                                                <span>1/12/2024</span>
                                            </div>
                                            <span>6 min read</span>
                                        </div>
                                        <div class="flex items-center gap-4">
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                                </svg>
                                                <span>1890</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M462.3 62.6C407.5 15.9 326 24.3 275.7 76.2L256 96.5l-19.7-20.3C186.1 24.3 104.5 15.9 49.7 62.6c-62.8 53.6-66.1 149.8-9.9 207.9l193.5 199.8c12.5 12.9 32.8 12.9 45.3 0l193.5-199.8c56.3-58.1 53-154.3-9.8-207.9z"></path>
                                                </svg>
                                                <span>67</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <div class="flex flex-wrap gap-2">
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Investment</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Tips</span>
                                            <span class="bg-gray-100 text-secondary-600 text-xs px-2 py-1 rounded">#Financial Planning</span>
                                        </div>
                                        <a class="text-primary-600 hover:text-primary-700 font-semibold text-sm flex items-center gap-1 group" href="/resources/blog/2">
                                            Read Full Article
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3 group-hover:translate-x-1 transition-transform" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
                
                <!-- Sidebar -->
                <div class="lg:col-span-1">
                    <div class="space-y-8">
                        <!-- Popular Posts -->
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h3 class="text-xl font-bold text-secondary-800 mb-6">Popular Posts</h3>
                            <div class="space-y-4">
                                <div class="flex gap-4">
                                    <div class="w-16 h-16 bg-gradient-to-br from-primary-100 to-accent-100 rounded-lg flex items-center justify-center text-2xl flex-shrink-0">📊</div>
                                    <div>
                                        <h4 class="font-semibold text-secondary-800 text-sm mb-1 line-clamp-2">IEPF Claims Made Simple</h4>
                                        <p class="text-xs text-secondary-500">Jan 15, 2024</p>
                                    </div>
                                </div>
                                <div class="flex gap-4">
                                    <div class="w-16 h-16 bg-gradient-to-br from-green-100 to-emerald-100 rounded-lg flex items-center justify-center text-2xl flex-shrink-0">💰</div>
                                    <div>
                                        <h4 class="font-semibold text-secondary-800 text-sm mb-1 line-clamp-2">Asset Recovery Tips</h4>
                                        <p class="text-xs text-secondary-500">Jan 12, 2024</p>
                                    </div>
                                </div>
                                <div class="flex gap-4">
                                    <div class="w-16 h-16 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-lg flex items-center justify-center text-2xl flex-shrink-0">🌍</div>
                                    <div>
                                        <h4 class="font-semibold text-secondary-800 text-sm mb-1 line-clamp-2">NRI Investment Guide</h4>
                                        <p class="text-xs text-secondary-500">Jan 10, 2024</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Categories -->
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h3 class="text-xl font-bold text-secondary-800 mb-6">Categories</h3>
                            <div class="space-y-3">
                                <div class="flex items-center justify-between">
                                    <span class="text-secondary-600">IEPF Claims</span>
                                    <span class="bg-primary-100 text-primary-600 text-xs px-2 py-1 rounded-full">12</span>
                                </div>
                                <div class="flex items-center justify-between">
                                    <span class="text-secondary-600">Investment Tips</span>
                                    <span class="bg-primary-100 text-primary-600 text-xs px-2 py-1 rounded-full">8</span>
                                </div>
                                <div class="flex items-center justify-between">
                                    <span class="text-secondary-600">Asset Recovery</span>
                                    <span class="bg-primary-100 text-primary-600 text-xs px-2 py-1 rounded-full">15</span>
                                </div>
                                <div class="flex items-center justify-between">
                                    <span class="text-secondary-600">NRI Services</span>
                                    <span class="bg-primary-100 text-primary-600 text-xs px-2 py-1 rounded-full">6</span>
                                </div>
                                <div class="flex items-center justify-between">
                                    <span class="text-secondary-600">Legal Updates</span>
                                    <span class="bg-primary-100 text-primary-600 text-xs px-2 py-1 rounded-full">9</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Newsletter Signup -->
                        <div class="bg-gradient-to-br from-primary-600 to-accent-600 rounded-xl p-6 text-white">
                            <h3 class="text-xl font-bold mb-4">Stay Updated</h3>
                            <p class="text-white/90 mb-4 text-sm">Get the latest insights delivered to your inbox.</p>
                            <form class="space-y-3">
                                <input type="email" placeholder="Your email" class="w-full px-3 py-2 rounded-lg text-secondary-800 text-sm">
                                <button type="submit" class="w-full bg-white text-primary-600 py-2 rounded-lg font-semibold text-sm hover:bg-gray-100 transition-colors">
                                    Subscribe
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Stay Connected Section -->
    <section class="section-padding bg-gradient-to-r from-green-600 to-blue-600">
        <div class="container-custom text-center text-white">
            <h2 class="text-3xl font-bold mb-4">Stay Connected with KMFSL</h2>
            <p class="text-xl mb-8 max-w-2xl mx-auto">Subscribe to our newsletter and follow us on social media for the latest news, updates, and insights from the financial services industry.</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <button class="bg-white text-green-600 py-3 px-6 rounded-lg font-semibold hover:bg-gray-100 transition-colors">Subscribe to Newsletter</button>
                <a href="/contact" class="border-2 border-white text-white py-3 px-6 rounded-lg font-semibold hover:bg-white hover:text-green-600 transition-colors">Contact Media Team</a>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
</body>
</html>