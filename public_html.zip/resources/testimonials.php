<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testimonials - KMFSL | Client Success Stories</title>
    <meta name="description" content="Read genuine testimonials and success stories from KMFSL clients who have successfully recovered their financial assets through our expert services.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Hero Section with Statistics -->
    <section class="section-padding bg-gradient-to-br from-yellow-50 via-white to-orange-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <div class="inline-flex items-center bg-yellow-100 text-yellow-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                    </svg>
                    Client Success Stories
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">Client <span class="text-gradient">Testimonials</span></h1>
                <p class="text-xl text-secondary-600 max-w-4xl mx-auto leading-relaxed mb-8">Read genuine experiences from our satisfied clients who have successfully recovered their unclaimed assets with our expert assistance. Their success stories speak for our commitment.</p>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-yellow-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M0 405.3V448c0 35.3 86 64 192 64s192-28.7 192-64v-42.7C342.7 434.4 267.2 448 192 448S41.3 434.4 0 405.3zM320 128c106 0 192-28.7 192-64S426 0 320 0 128 28.7 128 64s86 64 192 64zM0 300.4V352c0 35.3 86 64 192 64s192-28.7 192-64v-51.6c-41.3 34-116.9 51.6-192 51.6S41.3 334.4 0 300.4zm416 11c57.3-11.1 96-31.7 96-55.4v-42.7c-23.2 16.4-57.3 27.6-96 34.5v63.6zM192 160C86 160 0 195.8 0 240s86 80 192 80 192-35.8 192-80-86-80-192-80zm219.3 56.3c60-10.8 100.7-32 100.7-56.3v-42.7c-35.5 25.1-96.5 38.6-160.7 41.8 29.5 14.3 51.2 33.5 60 57.2z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">₹45+ Crores</div>
                        <div class="text-sm text-secondary-600">Total Recovered</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-6 h-6 text-green-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">12,000+</div>
                        <div class="text-sm text-secondary-600">Happy Clients</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-6 h-6 text-blue-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">4.9/5</div>
                        <div class="text-sm text-secondary-600">Average Rating</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-purple-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M487.976 0H24.028C2.71 0-8.047 25.866 7.058 40.971L192 225.941V432c0 7.831 3.821 15.17 10.237 19.662l80 55.98C298.02 518.69 320 507.493 320 487.98V225.941l184.947-184.97C520.021 25.896 509.338 0 487.976 0z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">96.8%</div>
                        <div class="text-sm text-secondary-600">Success Rate</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Success Stories Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Featured <span class="text-gradient">Success Stories</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Highlighted testimonials from clients who achieved remarkable recoveries with our services.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 relative">
                    <div class="absolute top-4 right-4">
                        <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                    </div>
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 bg-gradient-to-br from-primary-100 to-accent-100 rounded-full flex items-center justify-center text-2xl mr-4">👨‍💼</div>
                        <div>
                            <h3 class="font-semibold text-secondary-800">Rajesh Kumar Sharma</h3>
                            <div class="flex items-center text-sm text-secondary-600">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"></path>
                                </svg>
                                <span>Mumbai, Maharashtra</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                            </svg>
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                            </svg>
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                            </svg>
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                            </svg>
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                            </svg>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold text-green-600">₹4,85,000</div>
                            <div class="text-xs text-secondary-500">Recovered</div>
                        </div>
                    </div>
                    <div class="mb-4">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-primary-300 mb-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M464 256h-80v-64c0-35.3 28.7-64 64-64h8c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24h-8c-88.4 0-160 71.6-160 160v240c0 26.5 21.5 48 48 48h128c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48zm-288 0H96v-64c0-35.3 28.7-64 64-64h8c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24h-8C71.6 32 0 103.6 0 192v240c0 26.5 21.5 48 48 48h128c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48z"></path>
                        </svg>
                        <p class="text-secondary-700 text-sm italic line-clamp-4">"I had completely forgotten about my old investments from the 1990s. KMFSL team not only found my unclaimed dividends worth ₹4.85 lakhs but also helped me recover them within just 3 weeks. Their professional approach and regular updates made the entire process stress-free. Highly recommended!"</p>
                    </div>
                    <div class="flex items-center justify-between text-xs text-secondary-500">
                        <span class="bg-primary-100 text-primary-600 px-2 py-1 rounded-full">IEPF Claims</span>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                            </svg>
                            <span>1/15/2024</span>
                        </div>
                    </div>
                </div>
            
            <!-- More Featured Stories -->
                 <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 relative">
                     <div class="absolute top-4 right-4">
                         <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                     </div>
                     <div class="flex items-center mb-4">
                         <div class="w-12 h-12 bg-gradient-to-br from-primary-100 to-accent-100 rounded-full flex items-center justify-center text-2xl mr-4">👩‍⚕️</div>
                         <div>
                             <h3 class="font-semibold text-secondary-800">Dr. Priya Mehta</h3>
                             <div class="flex items-center text-sm text-secondary-600">
                                 <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                     <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"></path>
                                 </svg>
                                 <span>Delhi, NCR</span>
                             </div>
                         </div>
                     </div>
                     <div class="flex items-center justify-between mb-4">
                         <div class="flex items-center">
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                         </div>
                         <div class="text-right">
                             <div class="text-lg font-bold text-green-600">₹2,35,000</div>
                             <div class="text-xs text-secondary-500">Recovered</div>
                         </div>
                     </div>
                     <div class="mb-4">
                         <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-primary-300 mb-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                             <path d="M464 256h-80v-64c0-35.3 28.7-64 64-64h8c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24h-8c-88.4 0-160 71.6-160 160v240c0 26.5 21.5 48 48 48h128c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48zm-288 0H96v-64c0-35.3 28.7-64 64-64h8c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24h-8C71.6 32 0 103.6 0 192v240c0 26.5 21.5 48 48 48h128c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48z"></path>
                         </svg>
                         <p class="text-secondary-700 text-sm italic line-clamp-4">"After my father passed away, I was struggling with the complex process of share transmission. KMFSL handled everything professionally - from documentation to final transfer. They recovered shares worth ₹2.35 lakhs that I thought were lost forever. Excellent service and genuine people."</p>
                     </div>
                     <div class="flex items-center justify-between text-xs text-secondary-500">
                         <span class="bg-primary-100 text-primary-600 px-2 py-1 rounded-full">Share Transmission</span>
                         <div class="flex items-center">
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                             </svg>
                             <span>1/12/2024</span>
                         </div>
                     </div>
                 </div>
                 
                 <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 relative">
                     <div class="absolute top-4 right-4">
                         <span class="bg-yellow-100 text-yellow-600 text-xs font-semibold px-2 py-1 rounded-full">Featured</span>
                     </div>
                     <div class="flex items-center mb-4">
                         <div class="w-12 h-12 bg-gradient-to-br from-primary-100 to-accent-100 rounded-full flex items-center justify-center text-2xl mr-4">👨‍🏭</div>
                         <div>
                             <h3 class="font-semibold text-secondary-800">Suresh Agarwal</h3>
                             <div class="flex items-center text-sm text-secondary-600">
                                 <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                     <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"></path>
                                 </svg>
                                 <span>Ahmedabad, Gujarat</span>
                             </div>
                         </div>
                     </div>
                     <div class="flex items-center justify-between mb-4">
                         <div class="flex items-center">
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 text-yellow-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"></path>
                             </svg>
                         </div>
                         <div class="text-right">
                             <div class="text-lg font-bold text-green-600">₹1,75,000</div>
                             <div class="text-xs text-secondary-500">Recovered</div>
                         </div>
                     </div>
                     <div class="mb-4">
                         <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-primary-300 mb-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                             <path d="M464 256h-80v-64c0-35.3 28.7-64 64-64h8c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24h-8c-88.4 0-160 71.6-160 160v240c0 26.5 21.5 48 48 48h128c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48zm-288 0H96v-64c0-35.3 28.7-64 64-64h8c13.3 0 24-10.7 24-24V56c0-13.3-10.7-24-24-24h-8C71.6 32 0 103.6 0 192v240c0 26.5 21.5 48 48 48h128c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48z"></path>
                         </svg>
                         <p class="text-secondary-700 text-sm italic line-clamp-4">"I had physical share certificates lying in my locker for years. KMFSL helped me convert them to demat form and also discovered additional unclaimed dividends. The entire process was smooth and transparent. They truly care about their clients."</p>
                     </div>
                     <div class="flex items-center justify-between text-xs text-secondary-500">
                         <span class="bg-primary-100 text-primary-600 px-2 py-1 rounded-full">Demat Services</span>
                         <div class="flex items-center">
                             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3 mr-1" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M12 192h424c6.6 0 12 5.4 12 12v260c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V204c0-6.6 5.4-12 12-12zm436-44v-36c0-26.5-21.5-48-48-48h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v36c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12z"></path>
                             </svg>
                             <span>1/10/2024</span>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </section>


    

    
    <!-- Call to Action Section -->
     <section class="section-padding bg-gradient-to-r from-yellow-500 to-orange-500">
         <div class="container-custom text-center text-white">
             <h2 class="text-3xl font-bold mb-4">Ready to Join Our Success Stories?</h2>
             <p class="text-xl mb-8 max-w-2xl mx-auto">Join 12,000+ satisfied clients who have recovered ₹45+ Crores with our expert assistance. Your success story could be next!</p>
             <div class="flex flex-col sm:flex-row gap-4 justify-center">
                 <a href="../contact.php" class="bg-white text-yellow-600 py-3 px-6 rounded-lg font-semibold hover:bg-gray-100 transition-colors">Start Your Recovery Journey</a>
                 <a href="tel:+919876543210" class="border-2 border-white text-white py-3 px-6 rounded-lg font-semibold hover:bg-white hover:text-yellow-600 transition-colors">Call Expert: +91 98765 43210</a>
             </div>
         </div>
     </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Testimonials JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Slider Functionality
            let currentSlide = 0;
            const totalSlides = 8;
            let slideInterval;
            
            function showSlide(index) {
                const slides = document.querySelectorAll('.slide');
                const dots = document.querySelectorAll('.slider-dot');
                
                if (slides.length === 0) return;
                
                slides.forEach(slide => {
                    slide.classList.remove('active');
                });
                
                dots.forEach(dot => {
                    dot.classList.remove('active');
                });
                
                if (slides[index]) {
                    slides[index].classList.add('active');
                }
                
                if (dots[index]) {
                    dots[index].classList.add('active');
                }
            }
            
            window.showSlide = showSlide;
            
            function nextSlide() {
                currentSlide = (currentSlide + 1) % totalSlides;
                showSlide(currentSlide);
            }
            
            function prevSlide() {
                currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
                showSlide(currentSlide);
            }
            
            function goToSlide(index) {
                currentSlide = index;
                showSlide(currentSlide);
            }
            
            window.nextSlide = nextSlide;
            window.prevSlide = prevSlide;
            window.goToSlide = goToSlide;
            
            // Auto-play slider
            function startSlideshow() {
                slideInterval = setInterval(nextSlide, 5000);
            }
            
            function stopSlideshow() {
                clearInterval(slideInterval);
            }
            
            // Start auto-play
            startSlideshow();
            
            // Pause on hover
            const slider = document.querySelector('.hero-slider');
            if (slider) {
                slider.addEventListener('mouseenter', stopSlideshow);
                slider.addEventListener('mouseleave', startSlideshow);
            }
        });
        
        function loadMoreTestimonials() {
            // In a real implementation, this would load more testimonials via AJAX
            alert('More testimonials would be loaded here in the actual implementation.');
        }
        
        function playVideo(videoId) {
            // In a real implementation, this would open a video modal or redirect to video
            alert('Video player would open here for: ' + videoId);
        }
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                const href = this.getAttribute('href');
                if (href && href !== '#' && href.length > 1) {
                    e.preventDefault();
                    const target = document.querySelector(href);
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    </script>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
</body>
</html>