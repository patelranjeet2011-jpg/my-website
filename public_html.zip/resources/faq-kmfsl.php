<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ KMFSL - Frequently Asked Questions | KMFSL</title>
    <meta name="description" content="Find answers to frequently asked questions about KMFSL services, processes, documentation, and support. Get instant help for your queries.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Hero Section -->
    <section class="section-padding bg-gradient-to-br from-indigo-50 via-white to-purple-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <div class="inline-flex items-center bg-indigo-100 text-indigo-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zM262.655 90c-54.497 0-89.255 22.957-116.549 63.758-3.536 5.286-2.353 12.415 2.715 16.258l34.699 26.31c5.205 3.947 12.621 3.008 16.665-2.122 17.864-22.658 30.113-35.797 57.303-35.797 20.429 0 45.698 13.148 45.698 32.958 0 14.976-12.363 22.667-32.534 33.976C247.128 238.528 216 254.941 216 296v4c0 6.627 5.373 12 12 12h56c6.627 0 12-5.373 12-12v-1.333c0-28.462 83.186-29.647 83.186-106.667 0-58.002-60.165-102-116.531-102zM256 338c-25.365 0-46 20.635-46 46 0 25.364 20.635 46 46 46s46-20.636 46-46c0-25.365-20.635-46-46-46z"></path>
                    </svg>
                    KMFSL Support Center
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                    FAQ <span class="text-gradient">KMFSL</span>
                </h1>
                <p class="text-xl text-secondary-600 max-w-4xl mx-auto leading-relaxed mb-8">
                    Find answers to frequently asked questions about KMFSL services, processes, billing, documentation, and more. Our comprehensive FAQ section is designed to provide quick and accurate information.
                </p>
                
                <!-- Stats Grid -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-indigo-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zM262.655 90c-54.497 0-89.255 22.957-116.549 63.758-3.536 5.286-2.353 12.415 2.715 16.258l34.699 26.31c5.205 3.947 12.621 3.008 16.665-2.122 17.864-22.658 30.113-35.797 57.303-35.797 20.429 0 45.698 13.148 45.698 32.958 0 14.976-12.363 22.667-32.534 33.976C247.128 238.528 216 254.941 216 296v4c0 6.627 5.373 12 12 12h56c6.627 0 12-5.373 12-12v-1.333c0-28.462 83.186-29.647 83.186-106.667 0-58.002-60.165-102-116.531-102zM256 338c-25.365 0-46 20.635-46 46 0 25.364 20.635 46 46 46s46-20.636 46-46c0-25.365-20.635-46-46-46z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">100+</div>
                        <div class="text-sm text-secondary-600">Total FAQs</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-purple-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 110c23.196 0 42 18.804 42 42s-18.804 42-42 42-42-18.804-42-42 18.804-42 42-42zm56 254c0 6.627-5.373 12-12 12h-88c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h12v-64h-12c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h64c6.627 0 12 5.373 12 12v100h12c6.627 0 12 5.373 12 12v24z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">15+</div>
                        <div class="text-sm text-secondary-600">Categories</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-green-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">< 2 hrs</div>
                        <div class="text-sm text-secondary-600">Avg Response</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 text-yellow-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">98%</div>
                        <div class="text-sm text-secondary-600">Satisfaction</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Search and Filter Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="max-w-4xl mx-auto mb-12">
                <div class="bg-white rounded-xl shadow-lg p-8">
                    <h2 class="text-2xl font-bold text-secondary-800 mb-6 text-center">Search FAQs</h2>
                    <div class="flex flex-col md:flex-row gap-4">
                        <div class="flex-1 relative">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-5 h-5" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                            </svg>
                            <input type="text" id="searchInput" placeholder="Search questions, topics, or keywords..." class="w-full pl-12 pr-4 py-3 border border-secondary-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                        </div>
                        <select id="categoryFilter" class="px-4 py-3 border border-secondary-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                            <option value="All">All</option>
                            <option value="KMFSL Services">KMFSL Services</option>
                            <option value="Account & Billing">Account & Billing</option>
                            <option value="Process & Timeline">Process & Timeline</option>
                            <option value="Documentation">Documentation</option>
                            <option value="Technical Support">Technical Support</option>
                            <option value="Legal & Compliance">Legal & Compliance</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Popular FAQs Section -->
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Popular <span class="text-gradient">Questions</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Most frequently asked questions about KMFSL services and processes.</p>
            </div>
            
            <div class="max-w-4xl mx-auto space-y-4">
                <!-- Popular FAQ Item 1 -->
                <div class="bg-white rounded-xl shadow-lg border border-indigo-100">
                    <button class="faq-question w-full p-6 text-left flex items-center justify-between hover:bg-indigo-50 transition-colors rounded-xl" onclick="toggleFAQ(1)">
                        <div class="flex items-center">
                            <span class="bg-indigo-100 text-indigo-600 text-xs font-semibold px-2 py-1 rounded-full mr-3">Popular</span>
                            <h3 class="text-lg font-semibold text-secondary-800">What services does KMFSL provide?</h3>
                        </div>
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-5 h-5 text-secondary-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path>
                        </svg>
                    </button>
                    <div class="faq-answer hidden px-6 pb-6" id="answer-1">
                        <p class="text-secondary-600 leading-relaxed">KMFSL specializes in financial asset recovery services including IEPF claims, share transmission, demat services, unclaimed dividend recovery, insurance recovery, and NRI asset recovery. We also provide comprehensive wealth management solutions and consultation services.</p>
                    </div>
                </div>
                
                <!-- Popular FAQ Item 2 -->
                <div class="bg-white rounded-xl shadow-lg border border-indigo-100">
                    <button class="faq-question w-full p-6 text-left flex items-center justify-between hover:bg-indigo-50 transition-colors rounded-xl" onclick="toggleFAQ(2)">
                        <div class="flex items-center">
                            <span class="bg-indigo-100 text-indigo-600 text-xs font-semibold px-2 py-1 rounded-full mr-3">Popular</span>
                            <h3 class="text-lg font-semibold text-secondary-800">How is KMFSL different from other asset recovery companies?</h3>
                        </div>
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-5 h-5 text-secondary-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path>
                        </svg>
                    </button>
                    <div class="faq-answer hidden px-6 pb-6" id="answer-2">
                        <p class="text-secondary-600 leading-relaxed">KMFSL stands out with our 15+ years of experience, 96.8% success rate, recovery of ₹500+ crores for clients, advanced digital solutions, transparent processes, and dedicated client support. We offer end-to-end services with no hidden charges and provide regular updates throughout the recovery process.</p>
                    </div>
                </div>
                
                <!-- Popular FAQ Item 3 -->
                <div class="bg-white rounded-xl shadow-lg border border-indigo-100">
                    <button class="faq-question w-full p-6 text-left flex items-center justify-between hover:bg-indigo-50 transition-colors rounded-xl" onclick="toggleFAQ(3)">
                        <div class="flex items-center">
                            <span class="bg-indigo-100 text-indigo-600 text-xs font-semibold px-2 py-1 rounded-full mr-3">Popular</span>
                            <h3 class="text-lg font-semibold text-secondary-800">How long does the asset recovery process take?</h3>
                        </div>
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-5 h-5 text-secondary-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path>
                        </svg>
                    </button>
                    <div class="faq-answer hidden px-6 pb-6" id="answer-3">
                        <p class="text-secondary-600 leading-relaxed">The timeline varies depending on the type of asset and complexity of the case. Typically, IEPF claims take 15-30 days, share transmission takes 20-45 days, and unclaimed dividend recovery takes 10-25 days. We provide estimated timelines during initial consultation and keep you updated throughout the process.</p>
                    </div>
                </div>
                
                <!-- Popular FAQ Item 4 -->
                <div class="bg-white rounded-xl shadow-lg border border-indigo-100">
                    <button class="faq-question w-full p-6 text-left flex items-center justify-between hover:bg-indigo-50 transition-colors rounded-xl" onclick="toggleFAQ(4)">
                        <div class="flex items-center">
                            <span class="bg-indigo-100 text-indigo-600 text-xs font-semibold px-2 py-1 rounded-full mr-3">Popular</span>
                            <h3 class="text-lg font-semibold text-secondary-800">What are KMFSL's service charges?</h3>
                        </div>
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-5 h-5 text-secondary-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path>
                        </svg>
                    </button>
                    <div class="faq-answer hidden px-6 pb-6" id="answer-4">
                        <p class="text-secondary-600 leading-relaxed">Our fee structure is transparent and success-based. We charge consultation fees, processing fees, and success fees (percentage of recovered amount). No hidden charges. Detailed fee structure is provided during initial consultation. Payment is required only after successful recovery for success fees.</p>
                    </div>
                </div>
                
                <!-- Popular FAQ Item 5 -->
                <div class="bg-white rounded-xl shadow-lg border border-indigo-100">
                    <button class="faq-question w-full p-6 text-left flex items-center justify-between hover:bg-indigo-50 transition-colors rounded-xl" onclick="toggleFAQ(5)">
                        <div class="flex items-center">
                            <span class="bg-indigo-100 text-indigo-600 text-xs font-semibold px-2 py-1 rounded-full mr-3">Popular</span>
                            <h3 class="text-lg font-semibold text-secondary-800">Does KMFSL provide services for NRIs?</h3>
                        </div>
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-5 h-5 text-secondary-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path>
                        </svg>
                    </button>
                    <div class="faq-answer hidden px-6 pb-6" id="answer-5">
                        <p class="text-secondary-600 leading-relaxed">Yes, KMFSL offers specialized NRI services for asset recovery in India. We handle all processes remotely, provide FEMA compliance support, assist with Power of Attorney requirements, and serve clients in 50+ countries. Our NRI desk provides dedicated support for international clients.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- All FAQs Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">All <span class="text-gradient">FAQs</span> (15)</h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Browse through all frequently asked questions or use the search above to find specific information.</p>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
                <div class="lg:col-span-2">
                    <div class="space-y-4" id="allFAQs">
                        <!-- All FAQ items will be populated by JavaScript -->
                    </div>
                </div>
                <div class="lg:col-span-1">
                    <div class="space-y-8">
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h3 class="text-lg font-semibold text-secondary-800 mb-4">FAQ Categories</h3>
                            <div class="space-y-2">
                                <button class="category-filter-btn w-full flex items-center justify-between p-3 rounded-lg transition-colors hover:bg-gray-50" data-category="KMFSL Services">
                                    <span class="text-sm font-medium">KMFSL Services</span>
                                    <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">4</span>
                                </button>
                                <button class="category-filter-btn w-full flex items-center justify-between p-3 rounded-lg transition-colors hover:bg-gray-50" data-category="Account & Billing">
                                    <span class="text-sm font-medium">Account & Billing</span>
                                    <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">2</span>
                                </button>
                                <button class="category-filter-btn w-full flex items-center justify-between p-3 rounded-lg transition-colors hover:bg-gray-50" data-category="Process & Timeline">
                                    <span class="text-sm font-medium">Process & Timeline</span>
                                    <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">3</span>
                                </button>
                                <button class="category-filter-btn w-full flex items-center justify-between p-3 rounded-lg transition-colors hover:bg-gray-50" data-category="Documentation">
                                    <span class="text-sm font-medium">Documentation</span>
                                    <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">2</span>
                                </button>
                                <button class="category-filter-btn w-full flex items-center justify-between p-3 rounded-lg transition-colors hover:bg-gray-50" data-category="Technical Support">
                                    <span class="text-sm font-medium">Technical Support</span>
                                    <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">2</span>
                                </button>
                                <button class="category-filter-btn w-full flex items-center justify-between p-3 rounded-lg transition-colors hover:bg-gray-50" data-category="Legal & Compliance">
                                    <span class="text-sm font-medium">Legal & Compliance</span>
                                    <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">2</span>
                                </button>
                            </div>
                        </div>
                        <div class="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl p-6 text-white">
                            <h3 class="text-lg font-semibold mb-3">Still Need Help?</h3>
                            <p class="text-sm mb-4 opacity-90">Can't find the answer you're looking for? Our support team is here to help.</p>
                            <div class="space-y-3">
                                <a href="tel:+917070972333" class="w-full bg-white text-indigo-600 py-2 rounded-lg font-semibold text-sm hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                    </svg>
                                    Call Support
                                </a>
                                <a href="mailto:support@kmfsl.com" class="w-full border border-white text-white py-2 rounded-lg font-semibold text-sm hover:bg-white hover:text-indigo-600 transition-colors flex items-center justify-center gap-2">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                    </svg>
                                    Email Support
                                </a>
                                <a href="https://wa.me/917070972333" class="w-full bg-green-500 text-white py-2 rounded-lg font-semibold text-sm hover:bg-green-600 transition-colors flex items-center justify-center gap-2">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-3 h-3" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path>
                                    </svg>
                                    WhatsApp
                                </a>
                            </div>
                        </div>
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h3 class="text-lg font-semibold text-secondary-800 mb-4">Quick Links</h3>
                            <div class="space-y-3">
                                <a href="/contact" class="block text-sm text-secondary-600 hover:text-primary-600 transition-colors">Contact Us</a>
                                <a href="/services" class="block text-sm text-secondary-600 hover:text-primary-600 transition-colors">Our Services</a>
                                <a href="/about" class="block text-sm text-secondary-600 hover:text-primary-600 transition-colors">About KMFSL</a>
                                <a href="/resources/downloads" class="block text-sm text-secondary-600 hover:text-primary-600 transition-colors">Downloads</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Contact Support Section -->
    <section class="section-padding bg-gradient-to-r from-indigo-600 to-purple-600">
        <div class="container-custom text-center text-white">
            <h2 class="text-3xl font-bold mb-4">Need Personalized Assistance?</h2>
            <p class="text-xl mb-8 max-w-2xl mx-auto">Our expert team is available 24/7 to provide personalized support and answer any questions not covered in our FAQ section.</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="/contact" class="bg-white text-indigo-600 py-3 px-6 rounded-lg font-semibold hover:bg-gray-100 transition-colors">Contact Support Team</a>
                <a href="tel:+917070972333" class="border-2 border-white text-white py-3 px-6 rounded-lg font-semibold hover:bg-white hover:text-indigo-600 transition-colors">Call: +91 70709 72333</a>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- ChatBot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
    
    <!-- FAQ JavaScript -->
    <script>
        // FAQ data
        const faqs = [
            {
                id: 1,
                category: 'KMFSL Services',
                question: 'What services does KMFSL provide?',
                answer: 'KMFSL specializes in financial asset recovery services including IEPF claims, share transmission, demat services, unclaimed dividend recovery, insurance recovery, and NRI asset recovery. We also provide comprehensive wealth management solutions and consultation services.',
                popular: true
            },
            {
                id: 2,
                category: 'KMFSL Services',
                question: 'How is KMFSL different from other asset recovery companies?',
                answer: 'KMFSL stands out with our 15+ years of experience, 96.8% success rate, recovery of ₹500+ crores for clients, advanced digital solutions, transparent processes, and dedicated client support. We offer end-to-end services with no hidden charges and provide regular updates throughout the recovery process.',
                popular: true
            },
            {
                id: 3,
                category: 'Process & Timeline',
                question: 'How long does the asset recovery process take?',
                answer: 'The timeline varies depending on the type of asset and complexity of the case. Typically, IEPF claims take 15-30 days, share transmission takes 20-45 days, and unclaimed dividend recovery takes 10-25 days. We provide estimated timelines during initial consultation and keep you updated throughout the process.',
                popular: true
            },
            {
                id: 4,
                category: 'Account & Billing',
                question: 'What are KMFSL\'s service charges?',
                answer: 'Our fee structure is transparent and success-based. We charge consultation fees, processing fees, and success fees (percentage of recovered amount). No hidden charges. Detailed fee structure is provided during initial consultation. Payment is required only after successful recovery for success fees.',
                popular: true
            },
            {
                id: 5,
                category: 'Documentation',
                question: 'What documents do I need to provide to KMFSL?',
                answer: 'Required documents vary by service but typically include PAN card, Aadhaar card, bank details, investment proofs (share certificates, demat statements), and relevant supporting documents. Our team provides a comprehensive checklist during onboarding and assists with document preparation.',
                popular: false
            },
            {
                id: 6,
                category: 'KMFSL Services',
                question: 'Does KMFSL provide services for NRIs?',
                answer: 'Yes, KMFSL offers specialized NRI services for asset recovery in India. We handle all processes remotely, provide FEMA compliance support, assist with Power of Attorney requirements, and serve clients in 50+ countries. Our NRI desk provides dedicated support for international clients.',
                popular: true
            },
            {
                id: 7,
                category: 'Process & Timeline',
                question: 'How does KMFSL track and update clients on progress?',
                answer: 'We provide regular updates through multiple channels: SMS alerts, email notifications, client portal dashboard, and dedicated relationship manager. Clients can track their case status 24/7 through our online portal and receive weekly progress reports.',
                popular: false
            },
            {
                id: 8,
                category: 'Legal & Compliance',
                question: 'Is KMFSL legally authorized to handle asset recovery?',
                answer: 'Yes, KMFSL is a registered company with all necessary licenses and certifications. We comply with SEBI, RBI, and other regulatory requirements. Our team includes qualified legal experts, chartered accountants, and financial advisors. We maintain full transparency and legal compliance in all operations.',
                popular: false
            },
            {
                id: 9,
                category: 'Technical Support',
                question: 'How can I access KMFSL\'s client portal?',
                answer: 'After registration, you receive login credentials for our secure client portal. The portal allows you to track case progress, upload documents, communicate with our team, view recovery status, and access important updates. Technical support is available 24/7 for portal-related queries.',
                popular: false
            },
            {
                id: 10,
                category: 'Account & Billing',
                question: 'What payment methods does KMFSL accept?',
                answer: 'We accept multiple payment methods including bank transfers, online payments, UPI, credit/debit cards, and cheques. For international clients, we accept wire transfers and international payment gateways. All transactions are secure and documented with proper receipts.',
                popular: false
            },
            {
                id: 11,
                category: 'KMFSL Services',
                question: 'Can KMFSL help with insurance claim recovery?',
                answer: 'Yes, we specialize in insurance recovery including matured life insurance policies, unclaimed health insurance benefits, motor insurance claims, and property insurance settlements. Our insurance recovery team has expertise in dealing with all major insurance companies in India.',
                popular: false
            },
            {
                id: 12,
                category: 'Process & Timeline',
                question: 'What happens if KMFSL cannot recover my assets?',
                answer: 'While we have a 96.8% success rate, if recovery is not possible, you only pay the consultation and processing fees (not the success fee). We provide detailed explanation of why recovery was not possible and suggest alternative options if available. Our no-recovery, minimal-fee policy ensures client protection.',
                popular: false
            },
            {
                id: 13,
                category: 'Documentation',
                question: 'How does KMFSL ensure document security?',
                answer: 'We maintain highest security standards for document handling: encrypted digital storage, secure physical storage, limited access protocols, regular security audits, and proper disposal after retention period. All documents are handled by authorized personnel only and client confidentiality is strictly maintained.',
                popular: false
            },
            {
                id: 14,
                category: 'Technical Support',
                question: 'What if I face technical issues with KMFSL\'s online services?',
                answer: 'Our technical support team is available 24/7 through phone, email, and live chat. We provide step-by-step guidance, remote assistance if needed, and ensure all technical issues are resolved promptly. We also provide user guides and video tutorials for common processes.',
                popular: false
            },
            {
                id: 15,
                category: 'Legal & Compliance',
                question: 'How does KMFSL handle disputes or complaints?',
                answer: 'We have a structured grievance redressal mechanism: dedicated complaint handling team, escalation matrix, timeline-bound resolution, and senior management review. Most issues are resolved within 48 hours. We also provide external dispute resolution options if needed.',
                popular: false
            }
        ];
        
        let currentCategory = 'All';
        let searchTerm = '';
        
        // Initialize FAQ functionality
        document.addEventListener('DOMContentLoaded', function() {
            renderAllFAQs();
            setupEventListeners();
        });
        
        function setupEventListeners() {
            // Search functionality
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.addEventListener('input', function(e) {
                    searchTerm = e.target.value.toLowerCase();
                    renderAllFAQs();
                });
            }
            
            // Category filter dropdown
            const categoryFilter = document.getElementById('categoryFilter');
            if (categoryFilter) {
                categoryFilter.addEventListener('change', function(e) {
                    currentCategory = e.target.value;
                    renderAllFAQs();
                });
            }
            
            // Category filter buttons in sidebar
            document.querySelectorAll('.category-filter-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    currentCategory = this.dataset.category;
                    renderAllFAQs();
                });
            });
        }
        
        function renderAllFAQs() {
            const container = document.getElementById('allFAQs');
            const filteredFAQs = faqs.filter(faq => {
                const matchesSearch = faq.question.toLowerCase().includes(searchTerm) || 
                                    faq.answer.toLowerCase().includes(searchTerm);
                const matchesCategory = currentCategory === 'All' || faq.category === currentCategory;
                return matchesSearch && matchesCategory;
            });
            
            if (filteredFAQs.length === 0) {
                container.innerHTML = '<div class="text-center py-8"><p class="text-secondary-600">No FAQs found matching your search criteria.</p></div>';
                return;
            }
            
            container.innerHTML = filteredFAQs.map(faq => `
                <div class="bg-white rounded-xl shadow-lg border" data-category="${faq.category}">
                    <button class="w-full p-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors rounded-xl" onclick="toggleFAQ(${faq.id})">
                        <div class="flex items-center">
                            <span class="bg-gray-100 text-secondary-600 text-xs font-semibold px-2 py-1 rounded-full mr-3">${faq.category}</span>
                            ${faq.popular ? '<span class="bg-indigo-100 text-indigo-600 text-xs font-semibold px-2 py-1 rounded-full mr-3">Popular</span>' : ''}
                            <h3 class="text-lg font-semibold text-secondary-800">${faq.question}</h3>
                        </div>
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="w-5 h-5 text-secondary-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path>
                        </svg>
                    </button>
                    <div class="faq-answer hidden px-6 pb-6" id="answer-${faq.id}">
                        <p class="text-secondary-600 leading-relaxed">${faq.answer}</p>
                    </div>
                </div>
            `).join('');
            
            // No need to re-attach event listeners as onclick attributes handle the events
        }
        
        function toggleFAQ(id) {
            const answer = document.getElementById(`answer-${id}`);
            if (!answer) return;
            
            const question = answer.previousElementSibling;
            if (!question) return;
            
            const icon = question.querySelector('svg');
            if (!icon) return;
            
            if (answer.classList.contains('hidden')) {
                answer.classList.remove('hidden');
                icon.style.transform = 'rotate(180deg)';
            } else {
                answer.classList.add('hidden');
                icon.style.transform = 'rotate(0deg)';
            }
        }
    </script>
    
    <style>
        .category-btn {
            @apply px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 border border-gray-300 text-gray-700 hover:border-indigo-300 hover:text-indigo-600;
        }
        
        .category-btn.active {
            @apply bg-indigo-600 text-white border-indigo-600 shadow-lg;
        }
        
        .text-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
    </style>
</body>
</html>