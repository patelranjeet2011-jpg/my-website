<?php
require_once '../includes/header.php';
?>

<style>
.btn-primary {
    background-color: #3b82f6;
    color: white;
    padding: 8px 16px;
    border-radius: 6px;
    font-weight: 600;
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: background-color 0.2s;
}

.btn-primary:hover {
    background-color: #2563eb;
}

.btn-secondary {
    background-color: #6b7280;
    color: white;
    padding: 8px 16px;
    border-radius: 6px;
    font-weight: 600;
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: background-color 0.2s;
}

.btn-secondary:hover {
    background-color: #4b5563;
}

.download-category-btn {
    padding: 10px 20px;
    border: 2px solid #e5e7eb;
    background: white;
    color: #6b7280;
    border-radius: 25px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
}

.download-category-btn:hover,
.download-category-btn.active {
    background: #3b82f6;
    color: white;
    border-color: #3b82f6;
}

.card {
    background: white;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.2s;
}

.card:hover {
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}
</style>

<!-- Hero Slider Section -->
<section class="relative overflow-hidden" style="margin-top: 80px;">
    <div class="hero-slider">
        <!-- Complete Node.js Style Slider with 8 Slides -->
        <?php include '../complete-nodejs-slider-content.php'; ?>
    </div>
    
    <!-- Scroll Indicator -->
    <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
    </div>
</section>

<!-- Downloads Hero Section -->
<section class="section-padding bg-gradient-to-br from-blue-50 via-white to-green-50">
    <div class="container-custom">
        <div class="text-center mb-16">
            <div class="inline-flex items-center bg-blue-100 text-blue-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                    <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                </svg>
                Essential Downloads
            </div>
            <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">Forms & <span class="text-gradient">Documents</span></h1>
            <p class="text-xl text-secondary-600 max-w-4xl mx-auto leading-relaxed mb-8">Download essential forms, guides, and documents for KMFSL's financial recovery services. Fill forms online and get instant PDF downloads for your convenience.</p>
            <div class="text-sm text-secondary-500">
                <p>All forms are updated as per latest regulations</p>
                <p>Available in PDF format with online fill option</p>
            </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <div class="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow duration-300">
                <div class="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="w-6 h-6" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-secondary-800 mb-2">15+ Forms</h3>
                <p class="text-sm text-secondary-600">Essential application forms for all services</p>
            </div>
            <div class="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow duration-300">
                <div class="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 110c23.196 0 42 18.804 42 42s-18.804 42-42 42-42-18.804-42-42 18.804-42 42-42zm56 254c0 6.627-5.373 12-12 12h-88c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h12v-64h-12c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h64c6.627 0 12 5.373 12 12v100h12c6.627 0 12 5.373 12 12v24z"></path>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-secondary-800 mb-2">Online Fill</h3>
                <p class="text-sm text-secondary-600">Fill forms online and download PDF instantly</p>
            </div>
            <div class="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow duration-300">
                <div class="w-12 h-12 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-secondary-800 mb-2">Updated Forms</h3>
                <p class="text-sm text-secondary-600">Latest versions as per current regulations</p>
            </div>
            <div class="bg-white rounded-xl p-6 shadow-lg text-center hover:shadow-xl transition-shadow duration-300">
                <div class="w-12 h-12 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-secondary-800 mb-2">Free Access</h3>
                <p class="text-sm text-secondary-600">All documents available at no cost</p>
            </div>
        </div>
    </div>
</section>

<!-- Download Categories -->
<section class="section-padding">
    <div class="container-custom">
        <!-- Category Filter -->
        <div class="flex flex-wrap justify-center gap-4 mb-12">
            <button class="download-category-btn active" data-category="all">All Downloads</button>
            <button class="download-category-btn" data-category="forms">Application Forms</button>
            <button class="download-category-btn" data-category="guides">Process Guides</button>
            <button class="download-category-btn" data-category="samples">Sample Documents</button>
            <button class="download-category-btn" data-category="legal">Legal Documents</button>
        </div>
        
        <!-- Downloads Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="downloads-grid">
            
            <!-- ISR 1 Form -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-red-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">ISR 1 - Register/Change PAN & KYC Details</h3>
                        <p class="text-secondary-600 text-sm mb-4">Form for registering or changing PAN and KYC details with IEPF Authority.</p>
                        <div class="flex space-x-2">
                            <button onclick="openFormModal('isr1')" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                                </svg>
                                Fill Online
                            </button>
                            <a href="#" onclick="downloadTemplate('isr1')" class="btn-secondary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download PDF
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ISR 2 Form -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-blue-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">ISR 2 - Confirmation of Signature</h3>
                        <p class="text-secondary-600 text-sm mb-4">Confirmation of signature of securities holder by bank for IEPF claims.</p>
                        <div class="flex space-x-2">
                            <button onclick="openFormModal('isr2')" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                                </svg>
                                Fill Online
                            </button>
                            <a href="#" onclick="downloadTemplate('isr2')" class="btn-secondary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download PDF
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ISR 3 Form -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-green-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">ISR 3 - Declaration to Opting out Nomination</h3>
                        <p class="text-secondary-600 text-sm mb-4">Declaration form for opting out of nomination facility.</p>
                        <div class="flex space-x-2">
                            <button onclick="openFormModal('isr3')" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                                </svg>
                                Fill Online
                            </button>
                            <a href="#" onclick="downloadTemplate('isr3')" class="btn-secondary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download PDF
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ISR 4 Form -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-purple-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">ISR 4 - Request for Issue of Duplicate Certificate and other Service Requests</h3>
                        <p class="text-secondary-600 text-sm mb-4">Request form for duplicate certificate and other service requests.</p>
                        <div class="flex space-x-2">
                            <button onclick="openFormModal('isr4')" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                                </svg>
                                Online Form
                            </button>
                            <a href="#" onclick="downloadTemplate('isr4')" class="btn-secondary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download PDF
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SH 13 Form -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-orange-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">SH 13 - Nomination Form</h3>
                        <p class="text-secondary-600 text-sm mb-4">Nomination form for securities and mutual fund investments.</p>
                        <div class="flex space-x-2">
                            <button onclick="openFormModal('sh13')" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                                </svg>
                                Online Form
                            </button>
                            <a href="#" onclick="downloadTemplate('sh13')" class="btn-secondary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download PDF
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SH 14 Form -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-teal-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">SH 14 - Cancellation of Nomination</h3>
                        <p class="text-secondary-600 text-sm mb-4">Form for cancellation of nomination in securities and mutual funds.</p>
                        <div class="flex space-x-2">
                            <button onclick="openFormModal('sh14')" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                                </svg>
                                Online Form
                            </button>
                            <a href="#" onclick="downloadTemplate('sh14')" class="btn-secondary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download PDF
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- JSR 5 Form -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-indigo-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">JSR 5 - Annexure C - Request for Transmission of Securities by Nominee or Legal Heir</h3>
                        <p class="text-secondary-600 text-sm mb-4">Request form for transmission of securities by nominee or legal heir.</p>
                        <div class="flex space-x-2">
                            <a href="#" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Annexure D -->
            <div class="download-item card" data-category="legal">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-pink-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">Annexure D</h3>
                        <p class="text-secondary-600 text-sm mb-4">Individual Affidavit to be given by ALL the Legal Heirs OR Legal Heir Succession Certificate/Probate of Will / Will / Letter of Administration/Court Certificate for its equivalent certificate/Court Decree.</p>
                        <div class="flex space-x-2">
                            <a href="#" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Annexure E -->
            <div class="download-item card" data-category="legal">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-yellow-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">Annexure E</h3>
                        <p class="text-secondary-600 text-sm mb-4">Bond of Indemnity to be furnished jointly by all Legal Heir(s) including the Claimant(s).</p>
                        <div class="flex space-x-2">
                            <a href="#" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Annexure F -->
            <div class="download-item card" data-category="legal">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-cyan-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">Annexure F</h3>
                        <p class="text-secondary-600 text-sm mb-4">No Objection Certificate from the Legal Heir(s).</p>
                        <div class="flex space-x-2">
                            <a href="#" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form A -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-emerald-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">Form - A</h3>
                        <p class="text-secondary-600 text-sm mb-4">Affidavit For issuance of duplicate securities.</p>
                        <div class="flex space-x-2">
                            <a href="#" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form B -->
            <div class="download-item card" data-category="forms">
                <div class="flex items-start space-x-4">
                    <div class="w-12 h-12 bg-rose-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="text-rose-600 text-xl" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 64c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8v-16zm192.81 248H304c8.84 0 16 7.16 16 16s-7.16 16-16 16h-47.19c-16.45 0-31.27-9.14-38.64-23.86-2.95-5.92-8.09-6.52-10.17-6.52s-7.22.59-10.02 6.19l-7.67 15.34a15.986 15.986 0 0 1-14.31 8.84c-.38 0-.75-.02-1.14-.05-6.45-.45-12-4.75-14.03-10.89L144 354.59l-10.61 31.88c-5.89 17.66-22.38 29.53-41 29.53H80c-8.84 0-16-7.16-16-16s7.16-16 16-16h12.39c4.83 0 9.11-3.08 10.64-7.66l18.19-54.64c3.3-9.81 12.44-16.41 22.78-16.41s19.48 6.59 22.77 16.41l13.88 41.64c19.77-16.19 54.05-9.7 66 14.16 2.02 4.06 5.96 6.5 10.16 6.5zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"></path>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-bold text-secondary-800 mb-2">Form - B</h3>
                        <p class="text-secondary-600 text-sm mb-4">Indemnity For issuance of duplicate securities.</p>
                        <div class="flex space-x-2">
                            <a href="#" class="btn-primary text-sm px-4 py-2">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"></path>
                                </svg>
                                Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<!-- Footer -->
<?php include '../includes/footer.php'; ?>

<script>
    function openFormModal(formType) {
        // For ISR2, use dedicated PHP template
        if (formType === 'isr2') {
            window.open('isr2_form.php', '_blank', 'width=1200,height=800,scrollbars=yes,resizable=yes');
            return;
        }
        
        // For other forms, use dynamic generation
        var formTitles = {
            'isr1': 'ISR 1 - Register/Change PAN & KYC Details',
            'isr3': 'ISR 3 - Declaration to Opting out Nomination',
            'isr4': 'ISR 4 - Request for Issue of Duplicate Certificate',
            'sh13': 'SH 13 - Nomination Form',
            'sh14': 'SH 14 - Cancellation of Nomination'
        };
        
        var newWindow = window.open('', '_blank', 'width=1000,height=700,scrollbars=yes,resizable=yes');
        var formContent = createFormHTML(formType, formTitles[formType] || 'Form');
        
        newWindow.document.write(formContent);
        newWindow.document.close();
    }
    
    function createFormHTML(formType, title) {
        var html = '<!DOCTYPE html>';
        html += '<html><head>';
        html += '<title>' + title + '<\/title>';
        html += '<meta charset="UTF-8">';
        html += '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
        html += '<style>';
        html += 'body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }';
        html += '.container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.1); }';
        html += '.header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 8px; margin-bottom: 25px; text-align: center; }';
        html += '.header h1 { margin: 0; font-size: 24px; }';
        html += '.header p { margin: 10px 0 0 0; opacity: 0.9; }';
        html += '.form-group { margin-bottom: 20px; }';
        html += '.form-row { display: flex; gap: 15px; margin-bottom: 20px; }';
        html += '.form-col { flex: 1; }';
        html += 'label { display: block; margin-bottom: 8px; font-weight: bold; color: #333; font-size: 14px; }';
        html += 'input, textarea, select { width: 100%; padding: 12px; border: 2px solid #e1e5e9; border-radius: 6px; box-sizing: border-box; font-size: 14px; transition: border-color 0.3s; }';
        html += 'input:focus, textarea:focus, select:focus { border-color: #667eea; outline: none; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }';
        html += '.required { color: #e74c3c; }';
        html += '.btn { padding: 12px 25px; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: bold; margin: 8px; transition: all 0.3s; }';
        html += '.btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }';
        html += '.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4); }';
        html += '.btn-secondary { background: #6c757d; color: white; }';
        html += '.btn-secondary:hover { background: #5a6268; }';
        html += '.form-actions { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 2px solid #f1f3f4; }';
        html += '@media (max-width: 600px) { .form-row { flex-direction: column; } .container { padding: 20px; } }';
        html += '<\/style>';
         html += '<\/head><body>';
        
        html += '<div class="container">';
        html += '<div class="header">';
        html += '<h1>' + title + '</h1>';
        html += '<p>Please fill out all required fields marked with <span class="required">*</span></p>';
        html += '</div>';
        
        html += '<form id="onlineForm" onsubmit="return submitForm(event)">';
        
        // Common fields for all forms
        html += '<div class="form-row">';
        html += '<div class="form-col">';
        html += '<div class="form-group">';
        html += '<label>Full Name <span class="required">*</span></label>';
        html += '<input type="text" name="fullName" required>';
        html += '</div></div>';
        html += '<div class="form-col">';
        html += '<div class="form-group">';
        html += '<label>Email Address <span class="required">*</span></label>';
        html += '<input type="email" name="email" required>';
        html += '</div></div>';
        html += '</div>';
        
        html += '<div class="form-row">';
        html += '<div class="form-col">';
        html += '<div class="form-group">';
        html += '<label>Phone Number <span class="required">*</span></label>';
        html += '<input type="tel" name="phone" required>';
        html += '</div></div>';
        html += '<div class="form-col">';
        html += '<div class="form-group">';
        html += '<label>PAN Number <span class="required">*</span></label>';
        html += '<input type="text" name="pan" required pattern="[A-Z]{5}[0-9]{4}[A-Z]{1}" placeholder="ABCDE1234F" style="text-transform: uppercase;">';
        html += '</div></div>';
        html += '</div>';
        
        // Form-specific fields based on form type
        html += getFormSpecificFields(formType);
        
        html += '<div class="form-group">';
        html += '<label>Complete Address <span class="required">*</span></label>';
        html += '<textarea name="address" rows="3" required placeholder="Enter your complete address"></textarea>';
        html += '</div>';
        
        html += '<div class="form-row">';
        html += '<div class="form-col">';
        html += '<div class="form-group">';
        html += '<label>City <span class="required">*</span></label>';
        html += '<input type="text" name="city" required>';
        html += '</div></div>';
        html += '<div class="form-col">';
        html += '<div class="form-group">';
        html += '<label>State <span class="required">*</span></label>';
        html += '<input type="text" name="state" required>';
        html += '</div></div>';
        html += '<div class="form-col">';
        html += '<div class="form-group">';
        html += '<label>PIN Code <span class="required">*</span></label>';
        html += '<input type="text" name="pincode" required pattern="[0-9]{6}" maxlength="6">';
        html += '</div></div>';
        html += '</div>';
        
        html += '<div class="form-actions">';
        html += '<button type="submit" class="btn btn-primary">Submit Form</button>';
        html += '<button type="button" onclick="window.print()" class="btn btn-secondary">Print Form</button>';
        html += '<button type="button" onclick="window.close()" class="btn btn-secondary">Close</button>';
        html += '</div>';
        
        html += '<\/form><\/div>';
         
         html += '<script>';
         html += 'function submitForm(event) {';
         html += 'event.preventDefault();';
         html += 'var formData = new FormData(event.target);';
         html += 'var data = {};';
         html += 'for (var pair of formData.entries()) {';
         html += 'data[pair[0]] = pair[1];';
         html += '}';
         html += 'alert(\"Form submitted successfully! Thank you for your submission.\");';
         html += 'console.log(\"Form Data:\", data);';
         html += 'return false;';
         html += '}';
         html += '<\/script>';
         
         html += '<\/body><\/html>';
        return html;
    }
    
    function getFormSpecificFields(formType) {
        var fields = '';
        
        switch(formType) {
            case 'isr1':
                 // ISR-1 specific fields based on user's template
                 fields += '<div class="form-group">';
                 fields += '<label>Request Type <span class="required">*</span></label>';
                 fields += '<div style="display: flex; flex-wrap: wrap; gap: 15px; margin-top: 8px;">';
                 fields += '<label style="font-weight: normal;"><input type="checkbox" name="requestType[]" value="pan"> PAN</label>';
                 fields += '<label style="font-weight: normal;"><input type="checkbox" name="requestType[]" value="signature"> Signature</label>';
                 fields += '<label style="font-weight: normal;"><input type="checkbox" name="requestType[]" value="mobile"> Mobile Number</label>';
                 fields += '<label style="font-weight: normal;"><input type="checkbox" name="requestType[]" value="bank"> Bank Details</label>';
                 fields += '<label style="font-weight: normal;"><input type="checkbox" name="requestType[]" value="address"> Registered Address</label>';
                 fields += '<label style="font-weight: normal;"><input type="checkbox" name="requestType[]" value="email"> E-mail Address</label>';
                 fields += '</div></div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Name of the Issuer Company <span class="required">*</span></label>';
                 fields += '<input type="text" name="issuerCompany" required>';
                 fields += '</div>';
                 fields += '<div class="form-row">';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>Face Value of Securities</label>';
                 fields += '<input type="text" name="faceValue">';
                 fields += '</div></div>';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>Distinctive Number From</label>';
                 fields += '<input type="text" name="distinctiveFrom">';
                 fields += '</div></div>';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>Distinctive Number To</label>';
                 fields += '<input type="text" name="distinctiveTo">';
                 fields += '</div></div>';
                 fields += '</div>';
                 fields += '<div class="form-row">';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>Name of Bank & Branch</label>';
                 fields += '<input type="text" name="bankBranch">';
                 fields += '</div></div>';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>IFSC Code</label>';
                 fields += '<input type="text" name="ifscCode">';
                 fields += '</div></div>';
                 fields += '</div>';
                 fields += '<div class="form-row">';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>Bank Account Number</label>';
                 fields += '<input type="text" name="bankAccount">';
                 fields += '</div></div>';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>Account Type</label>';
                 fields += '<select name="accountType">';
                 fields += '<option value="">Select Account Type</option>';
                 fields += '<option value="savings">Savings</option>';
                 fields += '<option value="current">Current</option>';
                 fields += '<option value="nri">NRI</option>';
                 fields += '<option value="nre">NRE</option>';
                 fields += '<option value="other">Any Other</option>';
                 fields += '</select></div></div>';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Demat Account Number (16 digit DP Id/Client Id)</label>';
                 fields += '<input type="text" name="dematAccount" maxlength="16">';
                 fields += '</div>';
                 break;
                
            case 'isr2':
                 // ISR-2 specific fields based on user's template
                 fields += '<div class="form-group">';
                 fields += '<label>Bank Name <span class="required">*</span></label>';
                 fields += '<input type="text" name="bankName" required>';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Bank Branch Name <span class="required">*</span></label>';
                 fields += '<input type="text" name="bankBranch" required>';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Branch Address</label>';
                 fields += '<textarea name="branchAddress" rows="3" placeholder="Complete branch address with PIN code"></textarea>';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Bank Phone Number</label>';
                 fields += '<input type="tel" name="bankPhone">';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Account Opening Date</label>';
                 fields += '<input type="date" name="accountOpeningDate">';
                 fields += '</div>';
                 fields += '<div class="form-row">';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>1st Account Holder Name <span class="required">*</span></label>';
                 fields += '<input type="text" name="firstHolder" required>';
                 fields += '</div></div>';
                 fields += '<div class="form-col">';
                 fields += '<div class="form-group">';
                 fields += '<label>2nd Account Holder Name</label>';
                 fields += '<input type="text" name="secondHolder">';
                 fields += '</div></div>';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>3rd Account Holder Name</label>';
                 fields += '<input type="text" name="thirdHolder">';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Bank Manager Name</label>';
                 fields += '<input type="text" name="managerName">';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Employee Code</label>';
                 fields += '<input type="text" name="employeeCode">';
                 fields += '</div>';
                 fields += '<div class="form-group">';
                 fields += '<label>Manager Email Address</label>';
                 fields += '<input type="email" name="managerEmail">';
                 fields += '</div>';
                 break;
                
            case 'isr3':
                fields += '<div class="form-group">';
                fields += '<label>Reason for Opting Out <span class="required">*</span></label>';
                fields += '<textarea name="optOutReason" rows="3" required placeholder="Please specify your reason for opting out of nomination"></textarea>';
                fields += '</div>';
                break;
                
            case 'isr4':
                fields += '<div class="form-row">';
                fields += '<div class="form-col">';
                fields += '<div class="form-group">';
                fields += '<label>Certificate Type <span class="required">*</span></label>';
                fields += '<select name="certificateType" required>';
                fields += '<option value="">Select Certificate Type</option>';
                fields += '<option value="share">Share Certificate</option>';
                fields += '<option value="debenture">Debenture Certificate</option>';
                fields += '<option value="other">Other</option>';
                fields += '</select>';
                fields += '</div></div>';
                fields += '<div class="form-col">';
                fields += '<div class="form-group">';
                fields += '<label>Certificate Number</label>';
                fields += '<input type="text" name="certificateNumber">';
                fields += '</div></div>';
                fields += '</div>';
                break;
                
            case 'sh13':
                fields += '<div class="form-row">';
                fields += '<div class="form-col">';
                fields += '<div class="form-group">';
                fields += '<label>Nominee Name <span class="required">*</span></label>';
                fields += '<input type="text" name="nomineeName" required>';
                fields += '</div></div>';
                fields += '<div class="form-col">';
                fields += '<div class="form-group">';
                fields += '<label>Relationship <span class="required">*</span></label>';
                fields += '<select name="relationship" required>';
                fields += '<option value="">Select Relationship</option>';
                fields += '<option value="spouse">Spouse</option>';
                fields += '<option value="son">Son</option>';
                fields += '<option value="daughter">Daughter</option>';
                fields += '<option value="father">Father</option>';
                fields += '<option value="mother">Mother</option>';
                fields += '<option value="brother">Brother</option>';
                fields += '<option value="sister">Sister</option>';
                fields += '<option value="other">Other</option>';
                fields += '</select>';
                fields += '</div></div>';
                fields += '</div>';
                fields += '<div class="form-row">';
                fields += '<div class="form-col">';
                fields += '<div class="form-group">';
                fields += '<label>Nominee Date of Birth</label>';
                fields += '<input type="date" name="nomineeDOB">';
                fields += '</div></div>';
                fields += '<div class="form-col">';
                fields += '<div class="form-group">';
                fields += '<label>Nominee Age</label>';
                fields += '<input type="number" name="nomineeAge" min="1" max="120">';
                fields += '</div></div>';
                fields += '</div>';
                break;
                
            case 'sh14':
                fields += '<div class="form-group">';
                fields += '<label>Existing Nominee Name</label>';
                fields += '<input type="text" name="existingNomineeName">';
                fields += '</div>';
                fields += '<div class="form-group">';
                fields += '<label>Reason for Cancellation <span class="required">*</span></label>';
                fields += '<textarea name="cancellationReason" rows="3" required placeholder="Please specify your reason for cancelling nomination"></textarea>';
                fields += '</div>';
                break;
        }
        
        return fields;
    }
    
    function downloadTemplate(formType) {
        alert('Template for ' + formType.toUpperCase() + ' will be downloaded. Please contact KMFSL for assistance.');
    }
</script>