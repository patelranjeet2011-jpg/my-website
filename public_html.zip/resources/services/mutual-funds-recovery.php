<?php
// Redirect to correct path
header('Location: /services/mutual-funds-recovery.php');
exit();
?>