<?php
// Redirect to correct path
header('Location: /services/wealth-samadhan.php');
exit();
?>