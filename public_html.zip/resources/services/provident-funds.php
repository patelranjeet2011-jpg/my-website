<?php
// Redirect to correct path
header('Location: /services/provident-funds.php');
exit();
?>