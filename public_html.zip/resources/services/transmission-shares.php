<?php
// Redirect to correct path
header('Location: /services/transmission-shares.php');
exit();
?>