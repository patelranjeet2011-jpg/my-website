<?php
// Redirect to correct path
header('Location: /services/debtor-recovery.php');
exit();
?>