<?php
// Redirect to correct path
header('Location: /services/unclaimed-dividends.php');
exit();
?>