<?php
// Redirect to correct path
header('Location: /services/property-claim.php');
exit();
?>