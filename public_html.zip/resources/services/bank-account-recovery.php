<?php
// Redirect to correct path
header('Location: /services/bank-account-recovery.php');
exit();
?>