<?php
// Redirect to correct path
header('Location: /services/demat-physical-shares.php');
exit();
?>