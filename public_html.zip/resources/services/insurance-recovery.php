<?php
// Redirect to correct path
header('Location: /services/insurance-recovery.php');
exit();
?>