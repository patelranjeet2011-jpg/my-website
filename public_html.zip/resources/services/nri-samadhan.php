<?php
// Redirect to correct path
header('Location: /services/nri-samadhan.php');
exit();
?>