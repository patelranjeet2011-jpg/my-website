<?php
// PHP code for processing the form and generating the PDF

// FPDF library ko include karein
// Agar aapke server par FPDF nahi hai, to ise download karke upload karein.
// https://www.fpdf.org/
require('fpdf/fpdf.php');

// Form submit hone par
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Form se data prapt karein
    $bankName = $_POST['bankName'];
    $branchName = $_POST['branchName'];
    $bankPhone = $_POST['bankPhone'];
    $bankEmail = $_POST['bankEmail'];
    $bankAccount = $_POST['bankAccount'];
    $accountOpenDate = $_POST['accountOpenDate'];
    $holder1Name = $_POST['holder1Name'];

    // Nayi PDF banayein
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);

    // Document ka title
    $pdf->Cell(0, 10, 'Form ISR - 2', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Confirmation of Signature of securities holder by the Banker', 0, 1, 'C');

    // Data ko PDF mein jodein
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, '1. Bank Name and Branch', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Bank Name: ' . $bankName, 0, 1);
    $pdf->Cell(0, 10, 'Branch Name: ' . $branchName, 0, 1);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, '2. Bank contact details', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Bank Phone Number: ' . $bankPhone, 0, 1);
    $pdf->Cell(0, 10, 'Bank Email: ' . $bankEmail, 0, 1);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, '3. Bank Account number', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Account Number: ' . $bankAccount, 0, 1);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, '4. Account opening date', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Opening Date: ' . $accountOpenDate, 0, 1);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, '5. Account holder(s) name(s)', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, '1) ' . $holder1Name, 0, 1);

    // PDF ko browser mein bhejein
    $pdf->Output('I', 'KMFSL_ISR2_Form.pdf');
    exit;
}
?>

<!-- HTML Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Form</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .form-container { max-width: 600px; margin: auto; background-color: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="email"], input[type="date"] { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { padding: 10px 15px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>ऑनलाइन फॉर्म</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="bankName">1. बैंक का नाम:</label>
                <input type="text" id="bankName" name="bankName" required>
            </div>
            <div class="form-group">
                <label for="branchName">2. शाखा का नाम:</label>
                <input type="text" id="branchName" name="branchName" required>
            </div>
            <div class="form-group">
                <label for="bankPhone">3. बैंक का फोन नंबर:</label>
                <input type="text" id="bankPhone" name="bankPhone">
            </div>
            <div class="form-group">
                <label for="bankEmail">4. बैंक का ईमेल:</label>
                <input type="email" id="bankEmail" name="bankEmail">
            </div>
            <div class="form-group">
                <label for="bankAccount">5. बैंक खाता संख्या:</label>
                <input type="text" id="bankAccount" name="bankAccount" required>
            </div>
            <div class="form-group">
                <label for="accountOpenDate">6. खाता खोलने की तारीख:</label>
                <input type="date" id="accountOpenDate" name="accountOpenDate">
            </div>
            <div class="form-group">
                <label for="holder1Name">7. खाता धारक का नाम:</label>
                <input type="text" id="holder1Name" name="holder1Name" required>
            </div>
            <button type="submit">PDF जेनरेट करें</button>
        </form>
    </div>
</body>
</html>
