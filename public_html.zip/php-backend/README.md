# KMFSL PHP Backend

A complete PHP + MySQL backend for Kaimur Financial Services Pvt. Ltd. (KMFSL) website, converted from Node.js while maintaining 100% feature parity.

## 🚀 Features

### Core Features
- **User Authentication**: Registration, login, OTP verification, password reset
- **JWT Token Management**: Secure token-based authentication
- **Service Management**: Complete service catalog and request handling
- **Enquiry System**: Contact forms, newsletter subscriptions, enquiry management
- **Document Management**: File upload, verification, and storage
- **Admin Panel**: Complete administrative interface
- **Email System**: SMTP support with HTML templates
- **SMS Integration**: Multiple SMS providers (TextLocal, Twilio, MSG91)
- **Rate Limiting**: Advanced rate limiting with multiple storage backends
- **Input Validation**: Comprehensive validation and sanitization
- **Security**: Password hashing, SQL injection prevention, XSS protection

### API Endpoints

#### Authentication (`/api/auth/`)
- `POST /register` - User registration
- `POST /login` - User login
- `POST /send-otp` - Send OTP for verification
- `POST /verify-otp` - Verify OTP
- `POST /forgot-password` - Forgot password
- `POST /reset-password` - Reset password
- `GET /profile` - Get user profile
- `PUT /profile` - Update user profile

#### Services (`/api/services/`)
- `GET /services` - Get all services
- `GET /services/{slug}` - Get service by slug
- `POST /services/request` - Create service request
- `PUT /services/request` - Update service request

#### Enquiries (`/api/enquiries/`)
- `POST /enquiries/submit` - Submit general enquiry
- `POST /enquiries/contact` - Contact form submission
- `POST /enquiries/newsletter` - Newsletter subscription
- `GET /enquiries` - Get all enquiries (admin)
- `PUT /enquiries/status` - Update enquiry status (admin)

#### Health Check (`/api/health`)
- `GET /health` - API health status

## 📋 Requirements

- **PHP**: 7.4 or higher
- **MySQL**: 5.7 or higher
- **Web Server**: Apache or Nginx
- **Extensions**: PDO, JSON, cURL, OpenSSL, mbstring

## 🛠️ Installation

### 1. Clone Repository
```bash
git clone <repository-url>
cd kmfsl-php-backend
```

### 2. Environment Configuration
```bash
cp .env.example .env
```

Edit `.env` file with your configuration:
```env
# Database
DB_HOST=localhost
DB_NAME=kmfsl_db
DB_USER=your_username
DB_PASSWORD=your_password

# JWT Secret
JWT_SECRET=your_secret_key_here

# Email Configuration
SMTP_HOST=smtp.gmail.com
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password

# SMS Configuration (optional)
SMS_API_KEY=your_sms_api_key
```

### 3. Database Setup

The database tables will be created automatically when you first run the application in development mode.

Alternatively, you can create them manually:
```php
php -r "require 'config/database.php'; \$database->createTables(); \$database->createDefaults();"
```

### 4. Web Server Configuration

#### Apache (.htaccess)
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^api/(.*)$ api/index.php [QSA,L]
```

#### Nginx
```nginx
location /api/ {
    try_files $uri $uri/ /api/index.php?$query_string;
}

location ~ \.php$ {
    fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
    fastcgi_index index.php;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    include fastcgi_params;
}
```

### 5. File Permissions
```bash
chmod -R 755 .
chmod -R 777 uploads/
chmod -R 777 logs/
```

## 🔧 Configuration

### Database Configuration
The system uses PDO with MySQL. Configuration is in `config/database.php`.

### JWT Configuration
JWT tokens are used for authentication. Configure the secret key in `.env`:
```env
JWT_SECRET=your_very_secure_secret_key_here
JWT_EXPIRE=7d
```

### Email Configuration
Supports SMTP email sending:
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password
FROM_EMAIL=noreply@kmfsl.com
FROM_NAME=KMFSL
```

### SMS Configuration
Supports multiple SMS providers:
```env
SMS_PROVIDER=textlocal
SMS_API_KEY=your_api_key
SMS_SENDER_ID=KMFSL
```

### Rate Limiting
Configurable rate limiting with multiple storage backends:
```env
RATE_LIMIT_STORAGE=file  # file, redis, memcached, database
```

## 📚 Usage Examples

### User Registration
```javascript
fetch('/api/auth/register', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        name: 'John Doe',
        email: 'john@example.com',
        phone: '9876543210',
        password: 'password123',
        pan_number: 'ABCDE1234F',
        address: '123 Main St',
        state: 'Bihar',
        district: 'Kaimur',
        pincode: '821104'
    })
})
.then(response => response.json())
.then(data => console.log(data));
```

### User Login
```javascript
fetch('/api/auth/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        email: 'john@example.com',
        password: 'password123'
    })
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        localStorage.setItem('token', data.token);
    }
});
```

### Authenticated Requests
```javascript
fetch('/api/auth/profile', {
    headers: {
        'Authorization': 'Bearer ' + localStorage.getItem('token')
    }
})
.then(response => response.json())
.then(data => console.log(data));
```

### Service Request
```javascript
fetch('/api/services/request', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + localStorage.getItem('token')
    },
    body: JSON.stringify({
        service_id: 'service-uuid-here',
        estimated_amount: 50000,
        notes: 'Need help with IEPF claim'
    })
})
.then(response => response.json())
.then(data => console.log(data));
```

## 🏗️ Architecture

### Directory Structure
```
php-backend/
├── api/                    # API endpoints
│   ├── index.php          # Main router
│   ├── auth.php           # Authentication endpoints
│   ├── services.php       # Services endpoints
│   ├── enquiries.php      # Enquiries endpoints
│   ├── users.php          # User management
│   ├── admin.php          # Admin endpoints
│   ├── documents.php      # Document management
│   └── chat.php           # Chat endpoints
├── config/                 # Configuration files
│   └── database.php       # Database configuration
├── utils/                  # Utility classes
│   ├── jwt.php            # JWT handling
│   ├── validation.php     # Input validation
│   ├── email.php          # Email service
│   ├── sms.php            # SMS service
│   └── rate_limiter.php   # Rate limiting
├── uploads/                # File uploads
├── logs/                   # Log files
├── templates/              # Email templates
├── .env.example           # Environment template
└── README.md              # This file
```

### Database Schema

#### Users Table
- User registration and profile information
- Authentication data (password, login attempts)
- KYC status and documents
- Referral system

#### Services Table
- Service catalog with detailed information
- Processing times, fees, success rates
- Required documents and eligibility criteria

#### Service Requests Table
- User service requests
- Status tracking and progress updates
- Payment and fee information

#### Enquiries Table
- Contact form submissions
- Newsletter subscriptions
- Lead management

#### Documents Table
- File uploads and verification
- Document types and requirements
- Verification status

#### OTPs Table
- OTP generation and verification
- Multiple purposes (registration, login, etc.)
- Delivery tracking

## 🔒 Security Features

### Authentication & Authorization
- JWT-based authentication
- Password hashing with Argon2ID
- Account lockout after failed attempts
- Session management

### Input Validation
- Comprehensive validation rules
- SQL injection prevention
- XSS protection
- CSRF protection

### Rate Limiting
- IP-based rate limiting
- User-based rate limiting
- Multiple storage backends
- Configurable limits per endpoint

### Security Headers
- Content Security Policy
- X-Frame-Options
- X-Content-Type-Options
- XSS Protection

## 📊 Monitoring & Logging

### Health Checks
- Database connectivity
- API status
- System resources

### Error Handling
- Global error handlers
- Structured error responses
- Error logging

### Audit Logging
- User actions
- Admin activities
- System events

## 🚀 Deployment

### Shared Hosting (Hostinger, etc.)
1. Upload files to public_html or domain folder
2. Create MySQL database
3. Update .env with database credentials
4. Set file permissions
5. Test API endpoints

### VPS/Dedicated Server
1. Install PHP, MySQL, web server
2. Configure virtual host
3. Set up SSL certificate
4. Configure firewall
5. Set up monitoring

### Docker Deployment
```dockerfile
FROM php:7.4-apache

# Install extensions
RUN docker-php-ext-install pdo pdo_mysql

# Copy application
COPY . /var/www/html/

# Set permissions
RUN chown -R www-data:www-data /var/www/html/
RUN chmod -R 755 /var/www/html/

EXPOSE 80
```

## 🧪 Testing

### API Testing with cURL

#### Health Check
```bash
curl -X GET http://localhost/api/health
```

#### User Registration
```bash
curl -X POST http://localhost/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "phone": "9876543210",
    "password": "password123",
    "pan_number": "ABCDE1234F",
    "address": "Test Address",
    "state": "Bihar",
    "district": "Kaimur",
    "pincode": "821104"
  }'
```

#### User Login
```bash
curl -X POST http://localhost/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'
```

### Postman Collection
Import the provided Postman collection for comprehensive API testing.

## 🔧 Troubleshooting

### Common Issues

#### Database Connection Failed
- Check database credentials in .env
- Verify MySQL service is running
- Check database permissions

#### JWT Token Invalid
- Verify JWT_SECRET in .env
- Check token expiration
- Ensure proper Authorization header format

#### Email Not Sending
- Check SMTP credentials
- Verify email provider settings
- Check firewall/port restrictions

#### File Upload Issues
- Check upload directory permissions
- Verify PHP upload limits
- Check file size restrictions

### Debug Mode
Enable debug mode in .env:
```env
APP_ENV=development
APP_DEBUG=true
```

### Log Files
Check log files for detailed error information:
- `logs/app.log` - Application logs
- `logs/error.log` - Error logs
- `logs/audit.log` - Audit logs

## 📈 Performance Optimization

### Database Optimization
- Use proper indexes
- Optimize queries
- Enable query caching

### Caching
- Enable OPcache
- Use Redis/Memcached for sessions
- Implement application-level caching

### File Optimization
- Compress static files
- Use CDN for assets
- Optimize images

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Make changes
4. Add tests
5. Submit pull request

## 📄 License

This project is proprietary software for Kaimur Financial Services Pvt. Ltd.

## 📞 Support

For support and questions:
- Email: help@kmfsl.com
- Phone: +91 7070972333
- Website: https://kmfsl.com

## 🔄 Migration from Node.js

This PHP backend maintains 100% feature parity with the original Node.js version:

### Converted Features
- ✅ User authentication and registration
- ✅ JWT token management
- ✅ Service catalog and requests
- ✅ Enquiry and contact forms
- ✅ Email and SMS notifications
- ✅ File upload and document management
- ✅ Admin panel functionality
- ✅ Rate limiting and security
- ✅ Input validation and sanitization
- ✅ Database operations and relationships

### API Compatibility
All API endpoints maintain the same request/response format as the Node.js version, ensuring seamless frontend integration.

### Database Schema
The MySQL schema matches the original Sequelize models, preserving all relationships and constraints.

---

**KMFSL PHP Backend v1.0.0**  
*Professional financial services platform backend*