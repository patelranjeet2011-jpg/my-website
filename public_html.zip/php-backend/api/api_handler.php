<?php
/**
 * Main API Router
 * KMFSL PHP Backend - API Entry Point
 */

// Set error reporting for development
if (($_ENV['APP_ENV'] ?? 'development') === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Set headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_ENV['FRONTEND_URL'] ?? 'http://localhost:3000'));
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Load environment variables if .env file exists
if (file_exists('../.env')) {
    $lines = file('../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($key, $value) = explode('=', $line, 2);
            $_ENV[trim($key)] = trim($value, '"\' ');
        }
    }
}

// === START: यह है ज़रूरी बदलाव ===
$requestMethod = $_SERVER['REQUEST_METHOD'];

// जांचें कि क्या एंडपॉइंट एक GET पैरामीटर के रूप में भेजा गया है
if (isset($_GET['path'])) {
    $path = $_GET['path'];
    $pathParts = explode('/', $path); // e.g., 'enquiries/contact' becomes ['enquiries', 'contact']
} else {
    // अगर नहीं, तो क्लीन URL के लिए पुराने तरीके का उपयोग करें
    $requestUri = $_SERVER['REQUEST_URI'];
    $path = parse_url($requestUri, PHP_URL_PATH);
    $basePath = '/api'; // Adjust if your base path is different, e.g., '/php-backend/api'
    if (strpos($path, $basePath) === 0) {
        $path = substr($path, strlen($basePath));
    }
    $path = trim($path, '/');
    $pathParts = explode('/', $path);
}
$mainRoute = $pathParts[0] ?? '';
// === END: यह है ज़रूरी बदलाव ===

// Route to appropriate API endpoint
try {
    switch ($mainRoute) {
        case '':
        case 'health':
            handleHealthCheck();
            break;
            
        case 'auth':
            routeToAuth($pathParts);
            break;
            
        case 'services':
            routeToServices($pathParts);
            break;
            
        case 'enquiries':
            routeToEnquiries($pathParts);
            break;
            
        case 'users':
            routeToUsers($pathParts);
            break;
            
        case 'admin':
            routeToAdmin($pathParts);
            break;
            
        case 'documents':
            routeToDocuments($pathParts);
            break;
            
        case 'chat':
            routeToChat($pathParts);
            break;
            
        default:
            throw new Exception('API endpoint not found', 404);
    }
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'timestamp' => date('c'),
        'path' => $path ?? ''
    ]);
}

/**
 * Health check endpoint
 */
function handleHealthCheck() {
    // Test database connection
    $dbStatus = 'disconnected';
    try {
        require_once '../config/database.php';
        $stmt = $pdo->query('SELECT 1');
        $dbStatus = 'connected';
    } catch (Exception $e) {
        $dbStatus = 'error: ' . $e->getMessage();
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'KMFSL API Server is running',
        'timestamp' => date('c'),
        'environment' => $_ENV['APP_ENV'] ?? 'development',
        'version' => '1.0.0',
        'database' => $dbStatus,
        'php_version' => PHP_VERSION,
        'memory_usage' => memory_get_usage(true),
        'uptime' => getServerUptime()
    ]);
}

/**
 * Route to authentication endpoints
 */
function routeToAuth($pathParts) {
    // Remove 'auth' from path parts
    array_shift($pathParts);
    
    // Set the endpoint for auth.php
    $_SERVER['REQUEST_URI'] = '/' . implode('/', $pathParts);
    
    require_once 'auth.php';
}

/**
 * Route to services endpoints
 */
function routeToServices($pathParts) {
    // Remove 'services' from path parts
    array_shift($pathParts);
    
    // Set the endpoint for services.php
    $_SERVER['REQUEST_URI'] = '/' . implode('/', $pathParts);
    
    require_once 'services.php';
}

/**
 * Route to enquiries endpoints
 */
function routeToEnquiries($pathParts) {
    // Remove 'enquiries' from path parts
    array_shift($pathParts);
    
    // Set the endpoint for enquiries.php
    $_SERVER['REQUEST_URI'] = '/' . implode('/', $pathParts);
    
    require_once 'enquiries.php';
}

/**
 * Route to users endpoints
 */
function routeToUsers($pathParts) {
    // Remove 'users' from path parts
    array_shift($pathParts);
    
    // Set the endpoint for users.php
    $_SERVER['REQUEST_URI'] = '/' . implode('/', $pathParts);
    
    require_once 'users.php';
}

/**
 * Route to admin endpoints
 */
function routeToAdmin($pathParts) {
    // Remove 'admin' from path parts
    array_shift($pathParts);
    
    // Set the endpoint for admin.php
    $_SERVER['REQUEST_URI'] = '/' . implode('/', $pathParts);
    
    require_once 'admin.php';
}

/**
 * Route to documents endpoints
 */
function routeToDocuments($pathParts) {
    // Remove 'documents' from path parts
    array_shift($pathParts);
    
    // Set the endpoint for documents.php
    $_SERVER['REQUEST_URI'] = '/' . implode('/', $pathParts);
    
    require_once 'documents.php';
}

/**
 * Route to chat endpoints
 */
function routeToChat($pathParts) {
    // Remove 'chat' from path parts
    array_shift($pathParts);
    
    // Set the endpoint for chat.php
    $_SERVER['REQUEST_URI'] = '/' . implode('/', $pathParts);
    
    require_once 'chat.php';
}

/**
 * Get server uptime
 */
function getServerUptime() {
    if (function_exists('sys_getloadavg')) {
        $uptime = shell_exec('uptime');
        if ($uptime) {
            return trim($uptime);
        }
    }
    return 'Unknown';
}

/**
 * Global error handler
 */
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    
    $error = [
        'success' => false,
        'message' => 'Internal server error',
        'error' => [
            'type' => 'PHP Error',
            'severity' => $severity,
            'message' => $message,
            'file' => $file,
            'line' => $line
        ],
        'timestamp' => date('c')
    ];
    
    // Log error
    error_log(json_encode($error));
    
    // Don't expose internal errors in production
    if (($_ENV['APP_ENV'] ?? 'development') !== 'development') {
        unset($error['error']);
    }
    
    http_response_code(500);
    echo json_encode($error);
    exit;
});

/**
 * Global exception handler
 */
set_exception_handler(function($exception) {
    $error = [
        'success' => false,
        'message' => $exception->getMessage(),
        'error' => [
            'type' => get_class($exception),
            'code' => $exception->getCode(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString()
        ],
        'timestamp' => date('c')
    ];
    
    // Log error
    error_log(json_encode($error));
    
    // Don't expose internal errors in production
    if (($_ENV['APP_ENV'] ?? 'development') !== 'development') {
        unset($error['error']);
        $error['message'] = 'Internal server error';
    }
    
    http_response_code($exception->getCode() ?: 500);
    echo json_encode($error);
    exit;
});

/**
 * CORS helper function
 */
function setCORSHeaders() {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $allowedOrigins = [
        $_ENV['FRONTEND_URL'] ?? 'http://localhost:3000',
        'http://localhost:3000',
        'http://localhost:3001',
        'https://kmfsl.com',
        'https://www.kmfsl.com'
    ];
    
    if (in_array($origin, $allowedOrigins)) {
        header('Access-Control-Allow-Origin: ' . $origin);
    }
    
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); // 24 hours
}

/**
 * Rate limiting helper
 */
function applyGlobalRateLimit() {
    require_once '../utils/rate_limiter.php';
    
    $rateLimiter = new RateLimiter();
    $clientIP = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'];
    
    // Global rate limit: 1000 requests per hour
    if (!$rateLimiter->checkLimit('global', $clientIP, 1000, 3600)) {
        http_response_code(429);
        echo json_encode([
            'success' => false,
            'message' => 'Rate limit exceeded. Please try again later.',
            'retry_after' => 3600
        ]);
        exit;
    }
}

/**
 * Security headers
 */
function setSecurityHeaders() {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Content-Security-Policy: default-src \'self\'; script-src \'self\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data: https:; font-src \'self\' https:');
    
    // Remove server information
    header_remove('X-Powered-By');
    header_remove('Server');
}

// Apply security measures
setSecurityHeaders();
setCORSHeaders();

// Apply global rate limiting in production
if (($_ENV['APP_ENV'] ?? 'development') === 'production') {
    applyGlobalRateLimit();
}

?>