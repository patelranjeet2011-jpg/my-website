<?php
// सर्वर को सभी एरर दिखाने के लिए मजबूर करता है
error_reporting(E_ALL);
ini_set('display_errors', 1);

// यह database.php फ़ाइल का पूरा रास्ता बनाता है
$configPath = __DIR__ . '/../config/database.php';

echo "Checking for file at this path: <br><b>" . $configPath . "</b><br><br>";

// यह जांचता है कि फ़ाइल मौजूद है या नहीं
if (file_exists($configPath)) {
    echo "<h1>SUCCESS!</h1>";
    echo "The database config file was found. The path is correct.";
} else {
    echo "<h1>ERROR!</h1>";
    echo "The database config file was NOT found. This is the root cause of the problem.";
}
?>