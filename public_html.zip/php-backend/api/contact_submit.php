<?php
// Enforce error reporting to see any issues
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set headers for JSON response and CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_SERVER['HTTP_ORIGIN'] ?? '*'));
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method Not Allowed']);
    exit();
}

// Include necessary files (using confirmed correct paths)
require_once '../config/database.php';
require_once '../utils/email.php';

// This is the function that handles the form logic
function handleContactFormSubmission() {
    global $pdo;

    $input = json_decode(file_get_contents('php://input'), true);

    // Basic validation
    if (empty($input['name']) || empty($input['email']) || empty($input['phone']) || empty($input['message'])) {
        throw new Exception('Validation failed: Please fill all required fields.', 400);
    }

    $name = trim($input['name']);
    $email = strtolower(trim($input['email']));
    $phone = trim($input['phone']);
    $service = $input['service'] ?? '';
    $preferredContact = $input['preferred_contact'] ?? 'email';
    $message = trim($input['message']);
    
    // --- Generate a simple UUID if the function is not available globally ---
    $enquiryId = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
    // ---

    $stmt = $pdo->prepare("
        INSERT INTO enquiries (
            id, name, email, phone, service, subject, message, source,
            status, ip_address, user_agent, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $enquiryId, $name, $email, $phone, $service, 'Contact Form Enquiry',
        "Preferred Contact: {$preferredContact}\n\nMessage: {$message}",
        'website', 'new', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
    
    // Send notification email
    try {
        $emailService = new EmailService();
        $enquiry = [
            'name' => $name, 'email' => $email, 'phone' => $phone, 'service' => $service,
            'subject' => 'Contact Form Enquiry',
            'message' => "Preferred Contact: {$preferredContact}\n\nMessage: {$message}",
            'source' => 'website', 'ip_address' => $_SERVER['REMOTE_ADDR'],
            'created_at' => date('Y-m-d H:i:s')
        ];
        $emailService->sendEnquiryNotification($enquiry);
    } catch (Exception $e) {
        // Log the email error but don't stop the success response
        error_log('Contact form notification failed: ' . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Thank you for contacting us! We will get back to you within 24 hours.'
    ]);
}

// Execute the function
try {
    handleContactFormSubmission();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>