<?php
/**
 * Authentication API Endpoints
 * KMFSL PHP Backend - User Authentication
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_ENV['FRONTEND_URL'] ?? 'http://localhost:3000'));
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/database.php';
require_once '../utils/jwt.php';
require_once '../utils/email.php';
require_once '../utils/sms.php';
require_once '../utils/validation.php';
require_once '../utils/rate_limiter.php';

// Rate limiting
$rateLimiter = new RateLimiter();

// Get request method and path
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));
$endpoint = end($pathParts);

try {
    switch ($method) {
        case 'POST':
            switch ($endpoint) {
                case 'register':
                    handleRegister();
                    break;
                case 'login':
                    handleLogin();
                    break;
                case 'send-otp':
                    handleSendOTP();
                    break;
                case 'verify-otp':
                    handleVerifyOTP();
                    break;
                case 'forgot-password':
                    handleForgotPassword();
                    break;
                case 'reset-password':
                    handleResetPassword();
                    break;
                case 'refresh-token':
                    handleRefreshToken();
                    break;
                case 'logout':
                    handleLogout();
                    break;
                default:
                    throw new Exception('Endpoint not found', 404);
            }
            break;
        case 'GET':
            switch ($endpoint) {
                case 'profile':
                    handleGetProfile();
                    break;
                case 'verify-token':
                    handleVerifyToken();
                    break;
                default:
                    throw new Exception('Endpoint not found', 404);
            }
            break;
        case 'PUT':
            switch ($endpoint) {
                case 'profile':
                    handleUpdateProfile();
                    break;
                case 'change-password':
                    handleChangePassword();
                    break;
                default:
                    throw new Exception('Endpoint not found', 404);
            }
            break;
        default:
            throw new Exception('Method not allowed', 405);
    }
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * Handle user registration
 */
function handleRegister() {
    global $pdo, $rateLimiter;
    
    // Rate limiting
    if (!$rateLimiter->checkLimit('auth', $_SERVER['REMOTE_ADDR'], 5, 900)) { // 5 attempts per 15 minutes
        throw new Exception('Too many authentication attempts, please try again later.', 429);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validation
    $validator = new Validator();
    $validator->required('name', $input['name'] ?? '')
             ->minLength(2)->maxLength(100);
    $validator->required('email', $input['email'] ?? '')
             ->email();
    $validator->required('phone', $input['phone'] ?? '')
             ->phone();
    $validator->required('password', $input['password'] ?? '')
             ->minLength(6);
    $validator->required('pan_number', $input['pan_number'] ?? '')
             ->pan();
    $validator->required('address', $input['address'] ?? '');
    $validator->required('state', $input['state'] ?? '');
    $validator->required('district', $input['district'] ?? '');
    $validator->required('pincode', $input['pincode'] ?? '')
             ->pincode();
    
    if (!$validator->isValid()) {
        throw new Exception('Validation failed: ' . implode(', ', $validator->getErrors()), 400);
    }
    
    $name = trim($input['name']);
    $email = strtolower(trim($input['email']));
    $phone = trim($input['phone']);
    $password = $input['password'];
    $panNumber = strtoupper(trim($input['pan_number']));
    $address = trim($input['address']);
    $country = $input['country'] ?? 'India';
    $state = trim($input['state']);
    $district = trim($input['district']);
    $pincode = trim($input['pincode']);
    $referralCode = $input['referral_code'] ?? null;
    
    // Check if user already exists
    $stmt = $pdo->prepare("
        SELECT id, email, phone, pan_number 
        FROM users 
        WHERE email = ? OR phone = ? OR pan_number = ?
    ");
    $stmt->execute([$email, $phone, $panNumber]);
    $existingUser = $stmt->fetch();
    
    if ($existingUser) {
        $field = 'account';
        if ($existingUser['email'] === $email) $field = 'email';
        elseif ($existingUser['phone'] === $phone) $field = 'phone number';
        elseif ($existingUser['pan_number'] === $panNumber) $field = 'PAN number';
        
        throw new Exception("User with this {$field} already exists", 400);
    }
    
    // Handle referral code
    $referredBy = null;
    if ($referralCode) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ? AND is_active = 1");
        $stmt->execute([$referralCode]);
        $referrer = $stmt->fetch();
        if ($referrer) {
            $referredBy = $referrer['id'];
        }
    }
    
    // Generate referral code
    $newReferralCode = generateReferralCode();
    
    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_ARGON2ID);
    
    // Create user
    $userId = generateUUID();
    $stmt = $pdo->prepare("
        INSERT INTO users (
            id, name, email, phone, password, pan_number, address, country, 
            state, district, pincode, referral_code, referred_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $userId, $name, $email, $phone, $hashedPassword, $panNumber, $address,
        $country, $state, $district, $pincode, $newReferralCode, $referredBy
    ]);
    
    // Generate JWT token
    $payload = [
        'user' => [
            'id' => $userId,
            'email' => $email,
            'role' => 'user'
        ]
    ];
    
    $jwt = new JWT();
    $token = $jwt->encode($payload);
    
    // Get user data
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    unset($user['password']);
    
    // Send welcome email
    try {
        $emailService = new EmailService();
        $emailService->sendWelcomeEmail($email, $name);
    } catch (Exception $e) {
        error_log('Welcome email failed: ' . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'User registered successfully',
        'token' => $token,
        'user' => $user
    ]);
}

/**
 * Handle user login
 */
function handleLogin() {
    global $pdo, $rateLimiter;
    
    // Rate limiting
    if (!$rateLimiter->checkLimit('auth', $_SERVER['REMOTE_ADDR'], 5, 900)) {
        throw new Exception('Too many authentication attempts, please try again later.', 429);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validation
    $validator = new Validator();
    $validator->required('email', $input['email'] ?? '')
             ->email();
    $validator->required('password', $input['password'] ?? '');
    
    if (!$validator->isValid()) {
        throw new Exception('Validation failed: ' . implode(', ', $validator->getErrors()), 400);
    }
    
    $email = strtolower(trim($input['email']));
    $password = $input['password'];
    
    // Find user
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user) {
        throw new Exception('Invalid credentials', 400);
    }
    
    // Check if account is active
    if (!$user['is_active']) {
        throw new Exception('Account is deactivated. Please contact support.', 400);
    }
    
    // Check if account is locked
    if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
        throw new Exception('Account is temporarily locked due to too many failed login attempts.', 400);
    }
    
    // Verify password
    if (!password_verify($password, $user['password'])) {
        // Increment login attempts
        incrementLoginAttempts($user['id']);
        throw new Exception('Invalid credentials', 400);
    }
    
    // Reset login attempts and update last login
    resetLoginAttempts($user['id']);
    updateLastLogin($user['id']);
    
    // Generate JWT token
    $payload = [
        'user' => [
            'id' => $user['id'],
            'email' => $user['email'],
            'role' => 'user'
        ]
    ];
    
    $jwt = new JWT();
    $token = $jwt->encode($payload);
    
    // Remove sensitive data
    unset($user['password'], $user['password_reset_token'], $user['password_reset_expires'], 
          $user['login_attempts'], $user['locked_until']);
    
    echo json_encode([
        'success' => true,
        'message' => 'Login successful',
        'token' => $token,
        'user' => $user
    ]);
}

/**
 * Handle send OTP
 */
function handleSendOTP() {
    global $pdo, $rateLimiter;
    
    // Rate limiting for OTP
    if (!$rateLimiter->checkLimit('otp', $_SERVER['REMOTE_ADDR'], 3, 300)) { // 3 attempts per 5 minutes
        throw new Exception('Too many OTP requests, please try again later.', 429);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validation
    $validator = new Validator();
    $validator->required('type', $input['type'] ?? '')
             ->in(['email', 'sms']);
    $validator->required('value', $input['value'] ?? '');
    $validator->required('purpose', $input['purpose'] ?? '')
             ->in(['registration', 'login', 'password_reset', 'email_verification', 'phone_verification']);
    
    if (!$validator->isValid()) {
        throw new Exception('Validation failed: ' . implode(', ', $validator->getErrors()), 400);
    }
    
    $type = $input['type'];
    $value = $input['value'];
    $purpose = $input['purpose'];
    
    // Validate email or phone format
    if ($type === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format', 400);
    }
    
    if ($type === 'sms' && !preg_match('/^[6-9]\d{9}$/', $value)) {
        throw new Exception('Invalid phone number format', 400);
    }
    
    // Generate OTP
    $otpCode = generateOTP();
    $expiresAt = date('Y-m-d H:i:s', time() + (10 * 60)); // 10 minutes
    
    // Save OTP
    $otpId = generateUUID();
    $stmt = $pdo->prepare("
        INSERT INTO otps (id, type, purpose, recipient, otp_code, expires_at, ip_address, user_agent) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $otpId, $type, $purpose, $value, $otpCode, $expiresAt,
        $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
    
    // Send OTP
    $deliveryResult = ['success' => false];
    
    if ($type === 'email') {
        try {
            $emailService = new EmailService();
            $deliveryResult = $emailService->sendOTP($value, $otpCode, $purpose);
        } catch (Exception $e) {
            error_log('Email OTP failed: ' . $e->getMessage());
        }
    } elseif ($type === 'sms') {
        try {
            $smsService = new SMSService();
            $deliveryResult = $smsService->sendOTP($value, $otpCode);
        } catch (Exception $e) {
            error_log('SMS OTP failed: ' . $e->getMessage());
        }
    }
    
    // Update delivery status
    $stmt = $pdo->prepare("
        UPDATE otps 
        SET delivery_status = ?, delivery_response = ? 
        WHERE id = ?
    ");
    
    $stmt->execute([
        $deliveryResult['success'] ? 'sent' : 'failed',
        json_encode($deliveryResult),
        $otpId
    ]);
    
    if (!$deliveryResult['success']) {
        throw new Exception('Failed to send OTP. Please try again.', 500);
    }
    
    echo json_encode([
        'success' => true,
        'message' => "OTP sent successfully to your {$type}",
        'expires_in' => 10
    ]);
}

/**
 * Handle verify OTP
 */
function handleVerifyOTP() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validation
    $validator = new Validator();
    $validator->required('type', $input['type'] ?? '')
             ->in(['email', 'sms']);
    $validator->required('value', $input['value'] ?? '');
    $validator->required('purpose', $input['purpose'] ?? '')
             ->in(['registration', 'login', 'password_reset', 'email_verification', 'phone_verification']);
    $validator->required('otp', $input['otp'] ?? '')
             ->minLength(4)->maxLength(10);
    
    if (!$validator->isValid()) {
        throw new Exception('Validation failed: ' . implode(', ', $validator->getErrors()), 400);
    }
    
    $type = $input['type'];
    $value = $input['value'];
    $purpose = $input['purpose'];
    $otpCode = $input['otp'];
    
    // Find valid OTP
    $stmt = $pdo->prepare("
        SELECT * FROM otps 
        WHERE type = ? AND purpose = ? AND recipient = ? AND otp_code = ? 
        AND expires_at > NOW() AND is_verified = 0 AND attempts < max_attempts
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    
    $stmt->execute([$type, $purpose, $value, $otpCode]);
    $otpRecord = $stmt->fetch();
    
    if (!$otpRecord) {
        throw new Exception('Invalid or expired OTP', 400);
    }
    
    // Increment attempts
    $stmt = $pdo->prepare("UPDATE otps SET attempts = attempts + 1 WHERE id = ?");
    $stmt->execute([$otpRecord['id']]);
    
    // Mark as verified
    $stmt = $pdo->prepare("
        UPDATE otps 
        SET is_verified = 1, verified_at = NOW() 
        WHERE id = ?
    ");
    $stmt->execute([$otpRecord['id']]);
    
    // Update user verification status if applicable
    if ($purpose === 'email_verification' || $purpose === 'phone_verification') {
        $field = $purpose === 'email_verification' ? 'email' : 'phone';
        $verificationField = $purpose === 'email_verification' ? 'email_verified' : 'phone_verified';
        
        $stmt = $pdo->prepare("UPDATE users SET {$verificationField} = 1 WHERE {$field} = ?");
        $stmt->execute([$value]);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'OTP verified successfully'
    ]);
}

/**
 * Handle get profile
 */
function handleGetProfile() {
    global $pdo;
    
    $user = authenticateUser();
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user['id']]);
    $userData = $stmt->fetch();
    
    if (!$userData) {
        throw new Exception('User not found', 404);
    }
    
    // Remove sensitive data
    unset($userData['password'], $userData['password_reset_token'], 
          $userData['password_reset_expires'], $userData['login_attempts'], 
          $userData['locked_until']);
    
    echo json_encode([
        'success' => true,
        'user' => $userData
    ]);
}

/**
 * Helper functions
 */
function authenticateUser() {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';
    
    if (!$authHeader || !preg_match('/Bearer\s+(\S+)/', $authHeader, $matches)) {
        throw new Exception('Authorization token required', 401);
    }
    
    $token = $matches[1];
    $jwt = new JWT();
    
    try {
        $payload = $jwt->decode($token);
        return $payload['user'];
    } catch (Exception $e) {
        throw new Exception('Invalid or expired token', 401);
    }
}

function incrementLoginAttempts($userId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        UPDATE users 
        SET login_attempts = login_attempts + 1,
            locked_until = CASE 
                WHEN login_attempts + 1 >= 5 THEN DATE_ADD(NOW(), INTERVAL 2 HOUR)
                ELSE locked_until 
            END
        WHERE id = ?
    ");
    $stmt->execute([$userId]);
}

function resetLoginAttempts($userId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        UPDATE users 
        SET login_attempts = 0, locked_until = NULL 
        WHERE id = ?
    ");
    $stmt->execute([$userId]);
}

function updateLastLogin($userId) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $stmt->execute([$userId]);
}

function generateUUID() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function generateReferralCode() {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $result = 'KMFSL';
    for ($i = 0; $i < 6; $i++) {
        $result .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    return $result;
}

function generateOTP($length = 6) {
    $otp = '';
    for ($i = 0; $i < $length; $i++) {
        $otp .= mt_rand(0, 9);
    }
    return $otp;
}

?>