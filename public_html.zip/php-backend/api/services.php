<?php
/**
 * Services API Endpoints
 * KMFSL PHP Backend - Service Management
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_ENV['FRONTEND_URL'] ?? 'http://localhost:3000'));
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/database.php';
require_once '../utils/jwt.php';
require_once '../utils/validation.php';
require_once '../utils/rate_limiter.php';

// Rate limiting
$rateLimiter = new RateLimiter();

// Get request method and path
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));
$endpoint = end($pathParts);

try {
    switch ($method) {
        case 'GET':
            switch ($endpoint) {
                case 'services':
                    handleGetServices();
                    break;
                default:
                    // Check if it's a service by slug
                    if (preg_match('/^[a-z0-9-]+$/', $endpoint)) {
                        handleGetServiceBySlug($endpoint);
                    } else {
                        throw new Exception('Endpoint not found', 404);
                    }
            }
            break;
        case 'POST':
            switch ($endpoint) {
                case 'request':
                    handleCreateServiceRequest();
                    break;
                default:
                    throw new Exception('Endpoint not found', 404);
            }
            break;
        case 'PUT':
            switch ($endpoint) {
                case 'request':
                    handleUpdateServiceRequest();
                    break;
                default:
                    throw new Exception('Endpoint not found', 404);
            }
            break;
        default:
            throw new Exception('Method not allowed', 405);
    }
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * Get all services
 */
function handleGetServices() {
    global $pdo;
    
    $category = $_GET['category'] ?? null;
    $featured = $_GET['featured'] ?? null;
    $active = $_GET['active'] ?? 'true';
    $limit = (int)($_GET['limit'] ?? 50);
    $offset = (int)($_GET['offset'] ?? 0);
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if ($active === 'true') {
        $whereConditions[] = 'is_active = ?';
        $params[] = true;
    }
    
    if ($category) {
        $whereConditions[] = 'category = ?';
        $params[] = $category;
    }
    
    if ($featured === 'true') {
        $whereConditions[] = 'is_featured = ?';
        $params[] = true;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) FROM services {$whereClause}";
    $stmt = $pdo->prepare($countQuery);
    $stmt->execute($params);
    $totalCount = $stmt->fetchColumn();
    
    // Get services
    $query = "
        SELECT * FROM services 
        {$whereClause}
        ORDER BY priority DESC, name ASC 
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $services = $stmt->fetchAll();
    
    // Parse JSON fields
    foreach ($services as &$service) {
        $service['required_documents'] = json_decode($service['required_documents'], true) ?: [];
        $service['optional_documents'] = json_decode($service['optional_documents'], true) ?: [];
        $service['process_steps'] = json_decode($service['process_steps'], true) ?: [];
        $service['eligibility_criteria'] = json_decode($service['eligibility_criteria'], true) ?: [];
        $service['faqs'] = json_decode($service['faqs'], true) ?: [];
        $service['tags'] = json_decode($service['tags'], true) ?: [];
        $service['related_services'] = json_decode($service['related_services'], true) ?: [];
        $service['testimonials'] = json_decode($service['testimonials'], true) ?: [];
    }
    
    echo json_encode([
        'success' => true,
        'data' => $services,
        'pagination' => [
            'total' => $totalCount,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => ($offset + $limit) < $totalCount
        ]
    ]);
}

/**
 * Get service by slug
 */
function handleGetServiceBySlug($slug) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM services WHERE slug = ? AND is_active = ?");
    $stmt->execute([$slug, true]);
    $service = $stmt->fetch();
    
    if (!$service) {
        throw new Exception('Service not found', 404);
    }
    
    // Parse JSON fields
    $service['required_documents'] = json_decode($service['required_documents'], true) ?: [];
    $service['optional_documents'] = json_decode($service['optional_documents'], true) ?: [];
    $service['process_steps'] = json_decode($service['process_steps'], true) ?: [];
    $service['eligibility_criteria'] = json_decode($service['eligibility_criteria'], true) ?: [];
    $service['faqs'] = json_decode($service['faqs'], true) ?: [];
    $service['tags'] = json_decode($service['tags'], true) ?: [];
    $service['related_services'] = json_decode($service['related_services'], true) ?: [];
    $service['testimonials'] = json_decode($service['testimonials'], true) ?: [];
    
    // Get related services details if any
    if (!empty($service['related_services'])) {
        $placeholders = str_repeat('?,', count($service['related_services']) - 1) . '?';
        $stmt = $pdo->prepare("
            SELECT id, name, slug, description, category, processing_time, success_rate 
            FROM services 
            WHERE id IN ({$placeholders}) AND is_active = ?
        ");
        $params = array_merge($service['related_services'], [true]);
        $stmt->execute($params);
        $relatedServices = $stmt->fetchAll();
        $service['related_services_details'] = $relatedServices;
    }
    
    echo json_encode([
        'success' => true,
        'data' => $service
    ]);
}

/**
 * Create service request
 */
function handleCreateServiceRequest() {
    global $pdo, $rateLimiter;
    
    // Rate limiting
    if (!$rateLimiter->checkLimit('service_request', $_SERVER['REMOTE_ADDR'], 10, 3600)) {
        throw new Exception('Too many service requests, please try again later.', 429);
    }
    
    // Authenticate user
    $user = requireAuth();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validation
    $validator = ValidationRules::serviceRequest($input);
    if (!$validator->isValid()) {
        throw new Exception('Validation failed: ' . implode(', ', $validator->getErrors()), 400);
    }
    
    $serviceId = $input['service_id'];
    $estimatedAmount = $input['estimated_amount'] ?? null;
    $notes = $input['notes'] ?? '';
    $priority = $input['priority'] ?? 'medium';
    
    // Verify service exists
    $stmt = $pdo->prepare("SELECT * FROM services WHERE id = ? AND is_active = ?");
    $stmt->execute([$serviceId, true]);
    $service = $stmt->fetch();
    
    if (!$service) {
        throw new Exception('Service not found', 404);
    }
    
    // Generate request number
    $requestNumber = generateRequestNumber();
    
    // Create service request
    $serviceRequestId = generateUUID();
    $stmt = $pdo->prepare("
        INSERT INTO service_requests (
            id, user_id, service_id, request_number, status, priority,
            estimated_amount, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $serviceRequestId, $user['id'], $serviceId, $requestNumber, 'pending',
        $priority, $estimatedAmount, $notes
    ]);
    
    // Get created service request
    $stmt = $pdo->prepare("
        SELECT sr.*, s.name as service_name, s.processing_time, u.name as user_name, u.email as user_email
        FROM service_requests sr
        JOIN services s ON sr.service_id = s.id
        JOIN users u ON sr.user_id = u.id
        WHERE sr.id = ?
    ");
    $stmt->execute([$serviceRequestId]);
    $serviceRequest = $stmt->fetch();
    
    // Update service stats
    $stmt = $pdo->prepare("
        UPDATE services 
        SET total_requests = total_requests + 1 
        WHERE id = ?
    ");
    $stmt->execute([$serviceId]);
    
    // Update user stats
    $stmt = $pdo->prepare("
        UPDATE users 
        SET total_service_requests = total_service_requests + 1 
        WHERE id = ?
    ");
    $stmt->execute([$user['id']]);
    
    // Send notifications
    try {
        require_once '../utils/email.php';
        $emailService = new EmailService();
        
        // Send confirmation to user
        $emailService->sendServiceRequestConfirmation(
            ['name' => $serviceRequest['user_name'], 'email' => $serviceRequest['user_email']],
            $serviceRequest,
            ['name' => $serviceRequest['service_name'], 'processing_time' => $serviceRequest['processing_time']]
        );
        
        // Send notification to admin
        $emailService->sendServiceRequestNotification(
            $serviceRequest,
            ['name' => $serviceRequest['user_name'], 'email' => $serviceRequest['user_email'], 'phone' => $user['phone'] ?? ''],
            ['name' => $serviceRequest['service_name']]
        );
        
    } catch (Exception $e) {
        error_log('Service request notification failed: ' . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Service request created successfully',
        'data' => $serviceRequest
    ]);
}

/**
 * Update service request
 */
function handleUpdateServiceRequest() {
    global $pdo;
    
    // Authenticate user
    $user = requireAuth();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $requestId = $input['request_id'] ?? '';
    $notes = $input['notes'] ?? '';
    $estimatedAmount = $input['estimated_amount'] ?? null;
    
    if (empty($requestId)) {
        throw new Exception('Request ID is required', 400);
    }
    
    // Verify service request exists and belongs to user
    $stmt = $pdo->prepare("
        SELECT * FROM service_requests 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$requestId, $user['id']]);
    $serviceRequest = $stmt->fetch();
    
    if (!$serviceRequest) {
        throw new Exception('Service request not found', 404);
    }
    
    // Only allow updates if status is pending or in_progress
    if (!in_array($serviceRequest['status'], ['pending', 'in_progress'])) {
        throw new Exception('Cannot update completed or cancelled requests', 400);
    }
    
    // Update service request
    $updateFields = [];
    $params = [];
    
    if (!empty($notes)) {
        $updateFields[] = 'client_notes = ?';
        $params[] = $notes;
    }
    
    if ($estimatedAmount !== null) {
        $updateFields[] = 'estimated_amount = ?';
        $params[] = $estimatedAmount;
    }
    
    if (!empty($updateFields)) {
        $updateFields[] = 'updated_at = NOW()';
        $params[] = $requestId;
        
        $query = "UPDATE service_requests SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
    }
    
    // Get updated service request
    $stmt = $pdo->prepare("
        SELECT sr.*, s.name as service_name, s.processing_time
        FROM service_requests sr
        JOIN services s ON sr.service_id = s.id
        WHERE sr.id = ?
    ");
    $stmt->execute([$requestId]);
    $updatedRequest = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'message' => 'Service request updated successfully',
        'data' => $updatedRequest
    ]);
}

/**
 * Helper functions
 */
function generateRequestNumber() {
    $prefix = 'KMFSL';
    $timestamp = date('ymd');
    $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
    return $prefix . $timestamp . $random;
}

function generateUUID() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

?>