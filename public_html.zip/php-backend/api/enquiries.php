<?php
/**
 * Enquiries API Endpoints
 * KMFSL PHP Backend - Enquiry Management
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_ENV['FRONTEND_URL'] ?? 'http://localhost:3000'));
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/database.php';
require_once '../utils/jwt.php';
require_once '../utils/validation.php';
require_once '../utils/rate_limiter.php';
require_once '../utils/email.php';

// Rate limiting
$rateLimiter = new RateLimiter();

// Get request method and path
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));
$endpoint = end($pathParts);

try {
    switch ($method) {
        case 'GET':
            switch ($endpoint) {
                case 'enquiries':
                    handleGetEnquiries();
                    break;
                default:
                    // Check if it's an enquiry ID
                    if (preg_match('/^[a-f0-9-]{36}$/', $endpoint)) {
                        handleGetEnquiry($endpoint);
                    } else {
                        throw new Exception('Endpoint not found', 404);
                    }
            }
            break;
        case 'POST':
            switch ($endpoint) {
                case 'submit':
                    handleSubmitEnquiry();
                    break;
                case 'contact':
                    handleContactForm();
                    break;
                case 'newsletter':
                    handleNewsletterSubscription();
                    break;
                default:
                    throw new Exception('Endpoint not found', 404);
            }
            break;
        case 'PUT':
            switch ($endpoint) {
                case 'status':
                    handleUpdateEnquiryStatus();
                    break;
                default:
                    throw new Exception('Endpoint not found', 404);
            }
            break;
        default:
            throw new Exception('Method not allowed', 405);
    }
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * Submit general enquiry
 */
function handleSubmitEnquiry() {
    global $pdo, $rateLimiter;
    
    // Rate limiting
    if (!$rateLimiter->checkLimit('enquiry', $_SERVER['REMOTE_ADDR'], 5, 3600)) {
        throw new Exception('Too many enquiries, please try again later.', 429);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validation
    $validator = ValidationRules::enquiry($input);
    if (!$validator->isValid()) {
        throw new Exception('Validation failed: ' . implode(', ', $validator->getErrors()), 400);
    }
    
    $name = trim($input['name']);
    $email = strtolower(trim($input['email']));
    $phone = trim($input['phone']);
    $service = $input['service'] ?? '';
    $subject = $input['subject'] ?? '';
    $message = trim($input['message']);
    $source = $input['source'] ?? 'website';
    
    // Create enquiry
    $enquiryId = generateUUID();
    $stmt = $pdo->prepare("
        INSERT INTO enquiries (
            id, name, email, phone, service, subject, message, source,
            status, ip_address, user_agent, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $enquiryId, $name, $email, $phone, $service, $subject, $message, $source,
        'new', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
    
    // Get created enquiry
    $stmt = $pdo->prepare("SELECT * FROM enquiries WHERE id = ?");
    $stmt->execute([$enquiryId]);
    $enquiry = $stmt->fetch();
    
    // Send notification email
    try {
        $emailService = new EmailService();
        $emailService->sendEnquiryNotification($enquiry);
    } catch (Exception $e) {
        error_log('Enquiry notification failed: ' . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Thank you for your enquiry! We will contact you soon.',
        'data' => [
            'id' => $enquiry['id'],
            'status' => $enquiry['status'],
            'created_at' => $enquiry['created_at']
        ]
    ]);
}

/**
 * Handle contact form submission
 */
function handleContactForm() {
    global $pdo, $rateLimiter;
    
    // Rate limiting
    if (!$rateLimiter->checkLimit('contact', $_SERVER['REMOTE_ADDR'], 3, 1800)) {
        throw new Exception('Too many contact form submissions, please try again later.', 429);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validation
    $validator = new Validator();
    $validator->required('name', $input['name'] ?? '')
             ->minLength(2)->maxLength(100);
    $validator->required('email', $input['email'] ?? '')
             ->email();
    $validator->required('phone', $input['phone'] ?? '')
             ->phone();
    $validator->required('message', $input['message'] ?? '')
             ->minLength(10);
    $validator->optional('service', $input['service'] ?? '');
    $validator->optional('preferred_contact', $input['preferred_contact'] ?? '');
    
    if (!$validator->isValid()) {
        throw new Exception('Validation failed: ' . implode(', ', $validator->getErrors()), 400);
    }
    
    $name = trim($input['name']);
    $email = strtolower(trim($input['email']));
    $phone = trim($input['phone']);
    $service = $input['service'] ?? '';
    $preferredContact = $input['preferred_contact'] ?? 'email';
    $message = trim($input['message']);
    
    // Create enquiry
    $enquiryId = generateUUID();
    $stmt = $pdo->prepare("
        INSERT INTO enquiries (
            id, name, email, phone, service, subject, message, source,
            status, ip_address, user_agent, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $enquiryId, $name, $email, $phone, $service, 'Contact Form Enquiry',
        "Preferred Contact: {$preferredContact}\n\nMessage: {$message}",
        'website', 'new', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
    
    // Send notification email
    try {
        $emailService = new EmailService();
        $enquiry = [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'service' => $service,
            'subject' => 'Contact Form Enquiry',
            'message' => "Preferred Contact: {$preferredContact}\n\nMessage: {$message}",
            'source' => 'website',
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'created_at' => date('Y-m-d H:i:s')
        ];
        $emailService->sendEnquiryNotification($enquiry);
    } catch (Exception $e) {
        error_log('Contact form notification failed: ' . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Thank you for contacting us! We will get back to you within 24 hours.'
    ]);
}

/**
 * Handle newsletter subscription
 */
function handleNewsletterSubscription() {
    global $pdo, $rateLimiter;
    
    // Rate limiting
    if (!$rateLimiter->checkLimit('newsletter', $_SERVER['REMOTE_ADDR'], 5, 3600)) {
        throw new Exception('Too many subscription attempts, please try again later.', 429);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validation
    $validator = new Validator();
    $validator->required('email', $input['email'] ?? '')
             ->email();
    
    if (!$validator->isValid()) {
        throw new Exception('Validation failed: ' . implode(', ', $validator->getErrors()), 400);
    }
    
    $email = strtolower(trim($input['email']));
    
    // Check if already subscribed (create enquiry record)
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM enquiries 
        WHERE email = ? AND subject = 'Newsletter Subscription'
    ");
    $stmt->execute([$email]);
    $existingCount = $stmt->fetchColumn();
    
    if ($existingCount > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'You are already subscribed to our newsletter.'
        ]);
        return;
    }
    
    // Create newsletter subscription enquiry
    $enquiryId = generateUUID();
    $stmt = $pdo->prepare("
        INSERT INTO enquiries (
            id, name, email, phone, service, subject, message, source,
            status, ip_address, user_agent, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $stmt->execute([
        $enquiryId, 'Newsletter Subscriber', $email, '', 'Newsletter',
        'Newsletter Subscription', 'User subscribed to newsletter',
        'website', 'new', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
    
    // Send welcome email
    try {
        $emailService = new EmailService();
        $emailService->send(
            $email,
            'Welcome to KMFSL Newsletter',
            $emailService->getNewsletterWelcomeTemplate($email),
            true
        );
    } catch (Exception $e) {
        error_log('Newsletter welcome email failed: ' . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Thank you for subscribing! Check your email for confirmation.'
    ]);
}

/**
 * Get enquiries (admin only)
 */
function handleGetEnquiries() {
    // Require admin authentication
    $admin = requireAdmin();
    
    global $pdo;
    
    $status = $_GET['status'] ?? null;
    $service = $_GET['service'] ?? null;
    $source = $_GET['source'] ?? null;
    $limit = (int)($_GET['limit'] ?? 50);
    $offset = (int)($_GET['offset'] ?? 0);
    $search = $_GET['search'] ?? null;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if ($status) {
        $whereConditions[] = 'status = ?';
        $params[] = $status;
    }
    
    if ($service) {
        $whereConditions[] = 'service = ?';
        $params[] = $service;
    }
    
    if ($source) {
        $whereConditions[] = 'source = ?';
        $params[] = $source;
    }
    
    if ($search) {
        $whereConditions[] = '(name LIKE ? OR email LIKE ? OR phone LIKE ? OR message LIKE ?)';
        $searchTerm = "%{$search}%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) FROM enquiries {$whereClause}";
    $stmt = $pdo->prepare($countQuery);
    $stmt->execute($params);
    $totalCount = $stmt->fetchColumn();
    
    // Get enquiries
    $query = "
        SELECT * FROM enquiries 
        {$whereClause}
        ORDER BY created_at DESC 
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $enquiries = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'data' => $enquiries,
        'pagination' => [
            'total' => $totalCount,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => ($offset + $limit) < $totalCount
        ]
    ]);
}

/**
 * Get single enquiry (admin only)
 */
function handleGetEnquiry($enquiryId) {
    // Require admin authentication
    $admin = requireAdmin();
    
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM enquiries WHERE id = ?");
    $stmt->execute([$enquiryId]);
    $enquiry = $stmt->fetch();
    
    if (!$enquiry) {
        throw new Exception('Enquiry not found', 404);
    }
    
    echo json_encode([
        'success' => true,
        'data' => $enquiry
    ]);
}

/**
 * Update enquiry status (admin only)
 */
function handleUpdateEnquiryStatus() {
    // Require admin authentication
    $admin = requireAdmin();
    
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $enquiryId = $input['enquiry_id'] ?? '';
    $status = $input['status'] ?? '';
    $notes = $input['notes'] ?? '';
    $assignedTo = $input['assigned_to'] ?? null;
    $followUpDate = $input['follow_up_date'] ?? null;
    
    // Validation
    if (empty($enquiryId)) {
        throw new Exception('Enquiry ID is required', 400);
    }
    
    if (!in_array($status, ['new', 'contacted', 'converted', 'closed'])) {
        throw new Exception('Invalid status', 400);
    }
    
    // Verify enquiry exists
    $stmt = $pdo->prepare("SELECT * FROM enquiries WHERE id = ?");
    $stmt->execute([$enquiryId]);
    $enquiry = $stmt->fetch();
    
    if (!$enquiry) {
        throw new Exception('Enquiry not found', 404);
    }
    
    // Update enquiry
    $updateFields = ['status = ?', 'updated_at = NOW()'];
    $params = [$status];
    
    if (!empty($notes)) {
        $updateFields[] = 'notes = ?';
        $params[] = $notes;
    }
    
    if ($assignedTo !== null) {
        $updateFields[] = 'assigned_to = ?';
        $params[] = $assignedTo;
    }
    
    if ($followUpDate !== null) {
        $updateFields[] = 'follow_up_date = ?';
        $params[] = $followUpDate;
    }
    
    $params[] = $enquiryId;
    
    $query = "UPDATE enquiries SET " . implode(', ', $updateFields) . " WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    
    // Get updated enquiry
    $stmt = $pdo->prepare("SELECT * FROM enquiries WHERE id = ?");
    $stmt->execute([$enquiryId]);
    $updatedEnquiry = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'message' => 'Enquiry status updated successfully',
        'data' => $updatedEnquiry
    ]);
}

/**
 * Helper functions
 */
function generateUUID() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

?>