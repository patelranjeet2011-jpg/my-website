<?php
/**
 * Database Configuration and Connection
 * KMFSL PHP Backend - MySQL Database Connection
 */

class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    private $charset;
    private $pdo;
    
    public function __construct() {
        // Load environment variables or use defaults
        $this->host = $_ENV['DB_HOST'] ?? 'localhost';
        $this->db_name = $_ENV['DB_NAME'] ?? 'u259775287_Kaimur';
        $this->username = $_ENV['DB_USER'] ?? 'u259775287_kmfsl';
        $this->password = $_ENV['DB_PASSWORD'] ?? 'Kmfsl@2025';
        $this->port = $_ENV['DB_PORT'] ?? 3306;
        $this->charset = 'utf8mb4';
    }
    
    /**
     * Get database connection
     */
    public function getConnection() {
        if ($this->pdo === null) {
            try {
                $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db_name};charset={$this->charset}";
                
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$this->charset} COLLATE utf8mb4_unicode_ci",
                    PDO::ATTR_PERSISTENT => false,
                ];
                
                $this->pdo = new PDO($dsn, $this->username, $this->password, $options);
                
                // Set timezone to IST
                $this->pdo->exec("SET time_zone = '+05:30'");
                
            } catch (PDOException $e) {
                error_log('Database connection failed: ' . $e->getMessage());
                throw new Exception('Database connection failed: ' . $e->getMessage());
            }
        }
        
        return $this->pdo;
    }
    
    /**
     * Test database connection
     */
    public function testConnection() {
        try {
            $pdo = $this->getConnection();
            $stmt = $pdo->query('SELECT 1');
            return true;
        } catch (Exception $e) {
            error_log('Database test failed: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Create database tables
     */
    public function createTables() {
        $pdo = $this->getConnection();
        
        try {
            // Users table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS users (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(255) NOT NULL UNIQUE,
                    phone VARCHAR(15) NOT NULL UNIQUE,
                    password VARCHAR(255) NULL,
                    pan_number VARCHAR(10) NOT NULL UNIQUE,
                    address TEXT NOT NULL,
                    country VARCHAR(100) NOT NULL DEFAULT 'India',
                    state VARCHAR(100) NOT NULL,
                    district VARCHAR(100) NOT NULL,
                    pincode VARCHAR(10) NOT NULL,
                    email_verified BOOLEAN DEFAULT FALSE,
                    phone_verified BOOLEAN DEFAULT FALSE,
                    is_active BOOLEAN DEFAULT TRUE,
                    profile_picture VARCHAR(500) NULL,
                    biometric_enabled BOOLEAN DEFAULT FALSE,
                    biometric_type ENUM('fingerprint', 'face', 'both') NULL,
                    last_login TIMESTAMP NULL,
                    login_attempts INT DEFAULT 0,
                    locked_until TIMESTAMP NULL,
                    password_reset_token VARCHAR(255) NULL,
                    password_reset_expires TIMESTAMP NULL,
                    preferred_language VARCHAR(10) DEFAULT 'en',
                    timezone VARCHAR(50) DEFAULT 'Asia/Kolkata',
                    notification_preferences JSON DEFAULT (JSON_OBJECT('email', true, 'sms', true, 'push', true, 'whatsapp', false)),
                    kyc_status ENUM('pending', 'in_progress', 'completed', 'rejected') DEFAULT 'pending',
                    kyc_documents JSON DEFAULT (JSON_OBJECT()),
                    referral_code VARCHAR(20) UNIQUE NULL,
                    referred_by CHAR(36) NULL,
                    total_recovered_amount DECIMAL(15,2) DEFAULT 0.00,
                    total_service_requests INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_email (email),
                    INDEX idx_phone (phone),
                    INDEX idx_pan_number (pan_number),
                    INDEX idx_is_active (is_active),
                    INDEX idx_email_verified (email_verified),
                    INDEX idx_phone_verified (phone_verified),
                    INDEX idx_kyc_status (kyc_status),
                    FOREIGN KEY (referred_by) REFERENCES users(id) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // Services table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS services (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    name VARCHAR(200) NOT NULL,
                    slug VARCHAR(250) NOT NULL UNIQUE,
                    description TEXT NOT NULL,
                    detailed_description LONGTEXT NULL,
                    category ENUM('recovery', 'transmission', 'conversion', 'nri', 'property', 'legal', 'consultation', 'other') NOT NULL,
                    subcategory VARCHAR(100) NULL,
                    icon VARCHAR(100) DEFAULT '📋',
                    image VARCHAR(500) NULL,
                    is_active BOOLEAN DEFAULT TRUE,
                    is_featured BOOLEAN DEFAULT FALSE,
                    processing_time VARCHAR(100) DEFAULT '15-30 days',
                    base_fee DECIMAL(10,2) DEFAULT 0.00,
                    success_fee_percentage DECIMAL(5,2) DEFAULT 0.00,
                    minimum_amount DECIMAL(15,2) DEFAULT 0.00,
                    required_documents JSON DEFAULT (JSON_ARRAY()),
                    optional_documents JSON DEFAULT (JSON_ARRAY()),
                    process_steps JSON DEFAULT (JSON_ARRAY()),
                    eligibility_criteria JSON DEFAULT (JSON_ARRAY()),
                    faqs JSON DEFAULT (JSON_ARRAY()),
                    success_rate DECIMAL(5,2) DEFAULT 95.00,
                    total_requests INT DEFAULT 0,
                    completed_requests INT DEFAULT 0,
                    total_amount_recovered DECIMAL(15,2) DEFAULT 0.00,
                    average_processing_days INT NULL,
                    priority INT DEFAULT 0,
                    meta_title VARCHAR(200) NULL,
                    meta_description TEXT NULL,
                    meta_keywords TEXT NULL,
                    tags JSON DEFAULT (JSON_ARRAY()),
                    related_services JSON DEFAULT (JSON_ARRAY()),
                    testimonials JSON DEFAULT (JSON_ARRAY()),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_slug (slug),
                    INDEX idx_category (category),
                    INDEX idx_is_active (is_active),
                    INDEX idx_is_featured (is_featured),
                    INDEX idx_priority (priority)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // Service Requests table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS service_requests (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    user_id CHAR(36) NOT NULL,
                    service_id CHAR(36) NOT NULL,
                    request_number VARCHAR(50) UNIQUE NOT NULL,
                    status ENUM('pending', 'in_progress', 'completed', 'cancelled', 'on_hold') DEFAULT 'pending',
                    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
                    estimated_amount DECIMAL(15,2) NULL,
                    recovered_amount DECIMAL(15,2) DEFAULT 0.00,
                    service_fee DECIMAL(10,2) DEFAULT 0.00,
                    success_fee DECIMAL(10,2) DEFAULT 0.00,
                    total_fee DECIMAL(10,2) DEFAULT 0.00,
                    payment_status ENUM('pending', 'partial', 'paid', 'refunded') DEFAULT 'pending',
                    assigned_to CHAR(36) NULL,
                    started_at TIMESTAMP NULL,
                    completed_at TIMESTAMP NULL,
                    estimated_completion TIMESTAMP NULL,
                    notes TEXT NULL,
                    client_notes TEXT NULL,
                    internal_notes TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_service_id (service_id),
                    INDEX idx_request_number (request_number),
                    INDEX idx_status (status),
                    INDEX idx_priority (priority),
                    INDEX idx_assigned_to (assigned_to),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // Documents table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS documents (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    user_id CHAR(36) NOT NULL,
                    service_request_id CHAR(36) NULL,
                    document_type VARCHAR(100) NOT NULL,
                    document_name VARCHAR(255) NOT NULL,
                    original_name VARCHAR(255) NOT NULL,
                    file_path VARCHAR(500) NOT NULL,
                    file_size INT NOT NULL,
                    mime_type VARCHAR(100) NOT NULL,
                    is_verified BOOLEAN DEFAULT FALSE,
                    verified_by CHAR(36) NULL,
                    verified_at TIMESTAMP NULL,
                    verification_notes TEXT NULL,
                    is_required BOOLEAN DEFAULT TRUE,
                    upload_source ENUM('web', 'mobile', 'admin') DEFAULT 'web',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_service_request_id (service_request_id),
                    INDEX idx_document_type (document_type),
                    INDEX idx_is_verified (is_verified),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (service_request_id) REFERENCES service_requests(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // Enquiries table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS enquiries (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(255) NOT NULL,
                    phone VARCHAR(15) NOT NULL,
                    service VARCHAR(100) NULL,
                    subject VARCHAR(200) NULL,
                    message TEXT NOT NULL,
                    source ENUM('website', 'mobile', 'phone', 'email', 'whatsapp', 'other') DEFAULT 'website',
                    status ENUM('new', 'contacted', 'converted', 'closed') DEFAULT 'new',
                    assigned_to CHAR(36) NULL,
                    follow_up_date TIMESTAMP NULL,
                    notes TEXT NULL,
                    ip_address VARCHAR(45) NULL,
                    user_agent TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_email (email),
                    INDEX idx_phone (phone),
                    INDEX idx_service (service),
                    INDEX idx_status (status),
                    INDEX idx_source (source),
                    INDEX idx_assigned_to (assigned_to)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // OTP table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS otps (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    user_id CHAR(36) NULL,
                    type ENUM('email', 'sms') NOT NULL,
                    purpose ENUM('registration', 'login', 'password_reset', 'email_verification', 'phone_verification') NOT NULL,
                    recipient VARCHAR(255) NOT NULL,
                    otp_code VARCHAR(10) NOT NULL,
                    attempts INT DEFAULT 0,
                    max_attempts INT DEFAULT 3,
                    is_verified BOOLEAN DEFAULT FALSE,
                    verified_at TIMESTAMP NULL,
                    expires_at TIMESTAMP NOT NULL,
                    delivery_status ENUM('pending', 'sent', 'failed', 'delivered') DEFAULT 'pending',
                    delivery_response JSON NULL,
                    ip_address VARCHAR(45) NULL,
                    user_agent TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_type_purpose_recipient (type, purpose, recipient),
                    INDEX idx_otp_code (otp_code),
                    INDEX idx_expires_at (expires_at),
                    INDEX idx_is_verified (is_verified),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // Admin table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS admins (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(255) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL,
                    role ENUM('super_admin', 'admin', 'manager', 'agent') DEFAULT 'agent',
                    permissions JSON DEFAULT (JSON_ARRAY()),
                    is_active BOOLEAN DEFAULT TRUE,
                    last_login TIMESTAMP NULL,
                    login_attempts INT DEFAULT 0,
                    locked_until TIMESTAMP NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_email (email),
                    INDEX idx_role (role),
                    INDEX idx_is_active (is_active)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // Messages table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS messages (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    user_id CHAR(36) NULL,
                    service_request_id CHAR(36) NULL,
                    admin_id CHAR(36) NULL,
                    sender_type ENUM('user', 'admin', 'system') NOT NULL,
                    message_type ENUM('text', 'file', 'image', 'notification') DEFAULT 'text',
                    subject VARCHAR(200) NULL,
                    content TEXT NOT NULL,
                    attachments JSON DEFAULT (JSON_ARRAY()),
                    is_read BOOLEAN DEFAULT FALSE,
                    read_at TIMESTAMP NULL,
                    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_service_request_id (service_request_id),
                    INDEX idx_admin_id (admin_id),
                    INDEX idx_sender_type (sender_type),
                    INDEX idx_is_read (is_read),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (service_request_id) REFERENCES service_requests(id) ON DELETE CASCADE,
                    FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // Associates table
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS associates (
                    id CHAR(36) PRIMARY KEY DEFAULT (UUID()),
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(255) NOT NULL UNIQUE,
                    phone VARCHAR(15) NOT NULL UNIQUE,
                    pan_number VARCHAR(10) NOT NULL UNIQUE,
                    address TEXT NOT NULL,
                    state VARCHAR(100) NOT NULL,
                    district VARCHAR(100) NOT NULL,
                    pincode VARCHAR(10) NOT NULL,
                    qualification VARCHAR(200) NULL,
                    experience_years INT DEFAULT 0,
                    specialization JSON DEFAULT (JSON_ARRAY()),
                    commission_rate DECIMAL(5,2) DEFAULT 10.00,
                    bank_account_number VARCHAR(50) NULL,
                    bank_ifsc VARCHAR(20) NULL,
                    bank_name VARCHAR(100) NULL,
                    is_active BOOLEAN DEFAULT TRUE,
                    is_verified BOOLEAN DEFAULT FALSE,
                    verified_at TIMESTAMP NULL,
                    total_referrals INT DEFAULT 0,
                    total_commission DECIMAL(15,2) DEFAULT 0.00,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_email (email),
                    INDEX idx_phone (phone),
                    INDEX idx_pan_number (pan_number),
                    INDEX idx_is_active (is_active),
                    INDEX idx_is_verified (is_verified)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            echo "✅ Database tables created successfully.\n";
            
        } catch (PDOException $e) {
            error_log('Table creation failed: ' . $e->getMessage());
            throw new Exception('Table creation failed: ' . $e->getMessage());
        }
    }
    
    /**
     * Create default data
     */
    public function createDefaults() {
        $pdo = $this->getConnection();
        
        try {
            // Create default admin
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM admins WHERE email = ?");
            $stmt->execute(['admin@kmfsl.com']);
            
            if ($stmt->fetchColumn() == 0) {
                $hashedPassword = password_hash('admin123', PASSWORD_ARGON2ID);
                
                $stmt = $pdo->prepare("
                    INSERT INTO admins (name, email, password, role, is_active) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute(['Super Admin', 'admin@kmfsl.com', $hashedPassword, 'super_admin', true]);
                
                echo "✅ Default admin user created.\n";
            }
            
            // Create default services
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM services");
            $stmt->execute();
            
            if ($stmt->fetchColumn() == 0) {
                $defaultServices = [
                    [
                        'name' => 'IEPF Claim',
                        'slug' => 'iepf-claim',
                        'description' => 'Recover your unclaimed shares and dividends transferred to IEPF',
                        'category' => 'recovery',
                        'processing_time' => '15-30 days',
                        'required_documents' => json_encode(['PAN Card', 'Aadhaar Card', 'Bank Statement', 'Share Certificate'])
                    ],
                    [
                        'name' => 'Transmission of Shares',
                        'slug' => 'transmission-shares',
                        'description' => 'Transfer shares from deceased to legal heirs',
                        'category' => 'transmission',
                        'processing_time' => '20-45 days',
                        'required_documents' => json_encode(['Death Certificate', 'Legal Heir Certificate', 'PAN Card', 'Aadhaar Card'])
                    ],
                    [
                        'name' => 'Demat of Physical Shares',
                        'slug' => 'demat-physical-shares',
                        'description' => 'Convert physical share certificates to electronic format',
                        'category' => 'conversion',
                        'processing_time' => '10-20 days',
                        'required_documents' => json_encode(['Physical Share Certificates', 'PAN Card', 'Demat Account Details'])
                    ],
                    [
                        'name' => 'Unclaimed Dividends',
                        'slug' => 'unclaimed-dividends',
                        'description' => 'Claim your unpaid dividends from companies',
                        'category' => 'recovery',
                        'processing_time' => '15-25 days',
                        'required_documents' => json_encode(['PAN Card', 'Bank Details', 'Share Holding Proof'])
                    ],
                    [
                        'name' => 'Wealth Samadhan',
                        'slug' => 'wealth-samadhan',
                        'description' => 'Comprehensive wealth recovery solutions',
                        'category' => 'recovery',
                        'processing_time' => '30-60 days',
                        'required_documents' => json_encode(['PAN Card', 'Aadhaar Card', 'Bank Statement', 'Investment Proofs'])
                    ],
                    [
                        'name' => 'NRI Samadhan',
                        'slug' => 'nri-samadhan',
                        'description' => 'Specialized services for Non-Resident Indians',
                        'category' => 'nri',
                        'processing_time' => '20-40 days',
                        'required_documents' => json_encode(['Passport', 'PAN Card', 'NRI Status Proof', 'Power of Attorney'])
                    ]
                ];
                
                $stmt = $pdo->prepare("
                    INSERT INTO services (name, slug, description, category, processing_time, required_documents, is_active) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                
                foreach ($defaultServices as $service) {
                    $stmt->execute([
                        $service['name'],
                        $service['slug'],
                        $service['description'],
                        $service['category'],
                        $service['processing_time'],
                        $service['required_documents'],
                        true
                    ]);
                }
                
                echo "✅ Default services created.\n";
            }
            
        } catch (PDOException $e) {
            error_log('Default data creation failed: ' . $e->getMessage());
            throw new Exception('Default data creation failed: ' . $e->getMessage());
        }
    }
}

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

// Auto-create tables and defaults if in development
if (($_ENV['APP_ENV'] ?? 'development') === 'development') {
    try {
        $database->createTables();
        $database->createDefaults();
    } catch (Exception $e) {
        error_log('Database initialization failed: ' . $e->getMessage());
    }
}

?>