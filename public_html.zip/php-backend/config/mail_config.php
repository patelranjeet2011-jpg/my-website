<?php
// php-backend/config/mail_config.php

return [
    'host'       => 'smtp.hostinger.com',
    'port'       => 587,
    'username'   => 'noreply@kmfsl.in',      // <-- YAHAN APNA EMAIL DALEN
    'password'   => 'Kmfsl@2025', // <-- YAHAN US EMAIL KA PASSWORD DALEN
    'from_email' => 'noreply@kmfsl.in',      // <-- YAHAN APNA EMAIL DALEN
    'from_name'  => 'KMFSL Support'
];