<?php
/**
 * Rate Limiter Utility Class
 * KMFSL PHP Backend - API Rate Limiting
 */

class RateLimiter {
    private $storage;
    private $storageType;
    
    public function __construct($storageType = 'file') {
        $this->storageType = $storageType;
        
        switch ($storageType) {
            case 'redis':
                $this->initRedis();
                break;
            case 'memcached':
                $this->initMemcached();
                break;
            case 'database':
                $this->initDatabase();
                break;
            default:
                $this->initFileStorage();
        }
    }
    
    /**
     * Check if request is within rate limit
     */
    public function checkLimit($key, $identifier, $maxRequests, $windowSeconds) {
        $fullKey = $this->generateKey($key, $identifier);
        $currentTime = time();
        $windowStart = $currentTime - $windowSeconds;
        
        // Get current request count
        $requests = $this->getRequests($fullKey, $windowStart);
        
        // Check if limit exceeded
        if (count($requests) >= $maxRequests) {
            return false;
        }
        
        // Add current request
        $this->addRequest($fullKey, $currentTime);
        
        // Clean old requests
        $this->cleanOldRequests($fullKey, $windowStart);
        
        return true;
    }
    
    /**
     * Get remaining requests in current window
     */
    public function getRemainingRequests($key, $identifier, $maxRequests, $windowSeconds) {
        $fullKey = $this->generateKey($key, $identifier);
        $currentTime = time();
        $windowStart = $currentTime - $windowSeconds;
        
        $requests = $this->getRequests($fullKey, $windowStart);
        return max(0, $maxRequests - count($requests));
    }
    
    /**
     * Get time until rate limit resets
     */
    public function getResetTime($key, $identifier, $windowSeconds) {
        $fullKey = $this->generateKey($key, $identifier);
        $currentTime = time();
        $windowStart = $currentTime - $windowSeconds;
        
        $requests = $this->getRequests($fullKey, $windowStart);
        
        if (empty($requests)) {
            return 0;
        }
        
        $oldestRequest = min($requests);
        return max(0, $oldestRequest + $windowSeconds - $currentTime);
    }
    
    /**
     * Clear rate limit for specific key
     */
    public function clearLimit($key, $identifier) {
        $fullKey = $this->generateKey($key, $identifier);
        return $this->clearRequests($fullKey);
    }
    
    /**
     * Get rate limit info
     */
    public function getLimitInfo($key, $identifier, $maxRequests, $windowSeconds) {
        $fullKey = $this->generateKey($key, $identifier);
        $currentTime = time();
        $windowStart = $currentTime - $windowSeconds;
        
        $requests = $this->getRequests($fullKey, $windowStart);
        $requestCount = count($requests);
        
        return [
            'limit' => $maxRequests,
            'remaining' => max(0, $maxRequests - $requestCount),
            'reset_time' => $this->getResetTime($key, $identifier, $windowSeconds),
            'window_seconds' => $windowSeconds,
            'current_requests' => $requestCount
        ];
    }
    
    /**
     * Storage implementations
     */
    private function initFileStorage() {
        $this->storage = [
            'type' => 'file',
            'path' => sys_get_temp_dir() . '/kmfsl_rate_limit/'
        ];
        
        // Create directory if it doesn't exist
        if (!is_dir($this->storage['path'])) {
            mkdir($this->storage['path'], 0755, true);
        }
    }
    
    private function initRedis() {
        if (!extension_loaded('redis')) {
            throw new Exception('Redis extension not available');
        }
        
        $redis = new Redis();
        $redis->connect(
            $_ENV['REDIS_HOST'] ?? '127.0.0.1',
            $_ENV['REDIS_PORT'] ?? 6379
        );
        
        if (!empty($_ENV['REDIS_PASSWORD'])) {
            $redis->auth($_ENV['REDIS_PASSWORD']);
        }
        
        $this->storage = [
            'type' => 'redis',
            'connection' => $redis
        ];
    }
    
    private function initMemcached() {
        if (!extension_loaded('memcached')) {
            throw new Exception('Memcached extension not available');
        }
        
        $memcached = new Memcached();
        $memcached->addServer(
            $_ENV['MEMCACHED_HOST'] ?? '127.0.0.1',
            $_ENV['MEMCACHED_PORT'] ?? 11211
        );
        
        $this->storage = [
            'type' => 'memcached',
            'connection' => $memcached
        ];
    }
    
    private function initDatabase() {
        global $pdo;
        
        if (!$pdo) {
            throw new Exception('Database connection not available');
        }
        
        // Create rate limit table if it doesn't exist
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS rate_limits (
                id VARCHAR(255) PRIMARY KEY,
                requests TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        
        $this->storage = [
            'type' => 'database',
            'connection' => $pdo
        ];
    }
    
    /**
     * Storage operations
     */
    private function getRequests($key, $windowStart) {
        switch ($this->storage['type']) {
            case 'file':
                return $this->getRequestsFromFile($key, $windowStart);
            case 'redis':
                return $this->getRequestsFromRedis($key, $windowStart);
            case 'memcached':
                return $this->getRequestsFromMemcached($key, $windowStart);
            case 'database':
                return $this->getRequestsFromDatabase($key, $windowStart);
            default:
                return [];
        }
    }
    
    private function addRequest($key, $timestamp) {
        switch ($this->storage['type']) {
            case 'file':
                return $this->addRequestToFile($key, $timestamp);
            case 'redis':
                return $this->addRequestToRedis($key, $timestamp);
            case 'memcached':
                return $this->addRequestToMemcached($key, $timestamp);
            case 'database':
                return $this->addRequestToDatabase($key, $timestamp);
        }
    }
    
    private function cleanOldRequests($key, $windowStart) {
        switch ($this->storage['type']) {
            case 'file':
                return $this->cleanOldRequestsFromFile($key, $windowStart);
            case 'redis':
                return $this->cleanOldRequestsFromRedis($key, $windowStart);
            case 'memcached':
                return $this->cleanOldRequestsFromMemcached($key, $windowStart);
            case 'database':
                return $this->cleanOldRequestsFromDatabase($key, $windowStart);
        }
    }
    
    private function clearRequests($key) {
        switch ($this->storage['type']) {
            case 'file':
                return $this->clearRequestsFromFile($key);
            case 'redis':
                return $this->clearRequestsFromRedis($key);
            case 'memcached':
                return $this->clearRequestsFromMemcached($key);
            case 'database':
                return $this->clearRequestsFromDatabase($key);
        }
    }
    
    /**
     * File storage implementation
     */
    private function getRequestsFromFile($key, $windowStart) {
        $filename = $this->storage['path'] . md5($key) . '.json';
        
        if (!file_exists($filename)) {
            return [];
        }
        
        $data = json_decode(file_get_contents($filename), true);
        if (!$data || !isset($data['requests'])) {
            return [];
        }
        
        // Filter requests within window
        return array_filter($data['requests'], function($timestamp) use ($windowStart) {
            return $timestamp >= $windowStart;
        });
    }
    
    private function addRequestToFile($key, $timestamp) {
        $filename = $this->storage['path'] . md5($key) . '.json';
        
        $data = ['requests' => []];
        if (file_exists($filename)) {
            $existing = json_decode(file_get_contents($filename), true);
            if ($existing && isset($existing['requests'])) {
                $data = $existing;
            }
        }
        
        $data['requests'][] = $timestamp;
        file_put_contents($filename, json_encode($data), LOCK_EX);
    }
    
    private function cleanOldRequestsFromFile($key, $windowStart) {
        $filename = $this->storage['path'] . md5($key) . '.json';
        
        if (!file_exists($filename)) {
            return;
        }
        
        $data = json_decode(file_get_contents($filename), true);
        if (!$data || !isset($data['requests'])) {
            return;
        }
        
        $data['requests'] = array_filter($data['requests'], function($timestamp) use ($windowStart) {
            return $timestamp >= $windowStart;
        });
        
        if (empty($data['requests'])) {
            unlink($filename);
        } else {
            file_put_contents($filename, json_encode($data), LOCK_EX);
        }
    }
    
    private function clearRequestsFromFile($key) {
        $filename = $this->storage['path'] . md5($key) . '.json';
        if (file_exists($filename)) {
            unlink($filename);
        }
    }
    
    /**
     * Redis storage implementation
     */
    private function getRequestsFromRedis($key, $windowStart) {
        $redis = $this->storage['connection'];
        $requests = $redis->zRangeByScore($key, $windowStart, '+inf');
        return array_map('intval', $requests);
    }
    
    private function addRequestToRedis($key, $timestamp) {
        $redis = $this->storage['connection'];
        $redis->zAdd($key, $timestamp, $timestamp);
        $redis->expire($key, 3600); // Expire after 1 hour
    }
    
    private function cleanOldRequestsFromRedis($key, $windowStart) {
        $redis = $this->storage['connection'];
        $redis->zRemRangeByScore($key, '-inf', $windowStart - 1);
    }
    
    private function clearRequestsFromRedis($key) {
        $redis = $this->storage['connection'];
        $redis->del($key);
    }
    
    /**
     * Memcached storage implementation
     */
    private function getRequestsFromMemcached($key, $windowStart) {
        $memcached = $this->storage['connection'];
        $data = $memcached->get($key);
        
        if (!$data || !isset($data['requests'])) {
            return [];
        }
        
        return array_filter($data['requests'], function($timestamp) use ($windowStart) {
            return $timestamp >= $windowStart;
        });
    }
    
    private function addRequestToMemcached($key, $timestamp) {
        $memcached = $this->storage['connection'];
        $data = $memcached->get($key) ?: ['requests' => []];
        $data['requests'][] = $timestamp;
        $memcached->set($key, $data, 3600); // Expire after 1 hour
    }
    
    private function cleanOldRequestsFromMemcached($key, $windowStart) {
        $memcached = $this->storage['connection'];
        $data = $memcached->get($key);
        
        if (!$data || !isset($data['requests'])) {
            return;
        }
        
        $data['requests'] = array_filter($data['requests'], function($timestamp) use ($windowStart) {
            return $timestamp >= $windowStart;
        });
        
        if (empty($data['requests'])) {
            $memcached->delete($key);
        } else {
            $memcached->set($key, $data, 3600);
        }
    }
    
    private function clearRequestsFromMemcached($key) {
        $memcached = $this->storage['connection'];
        $memcached->delete($key);
    }
    
    /**
     * Database storage implementation
     */
    private function getRequestsFromDatabase($key, $windowStart) {
        $pdo = $this->storage['connection'];
        $stmt = $pdo->prepare("SELECT requests FROM rate_limits WHERE id = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        
        if (!$row) {
            return [];
        }
        
        $requests = json_decode($row['requests'], true) ?: [];
        return array_filter($requests, function($timestamp) use ($windowStart) {
            return $timestamp >= $windowStart;
        });
    }
    
    private function addRequestToDatabase($key, $timestamp) {
        $pdo = $this->storage['connection'];
        
        // Get existing requests
        $stmt = $pdo->prepare("SELECT requests FROM rate_limits WHERE id = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        
        $requests = [];
        if ($row) {
            $requests = json_decode($row['requests'], true) ?: [];
        }
        
        $requests[] = $timestamp;
        
        // Update or insert
        if ($row) {
            $stmt = $pdo->prepare("UPDATE rate_limits SET requests = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([json_encode($requests), $key]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO rate_limits (id, requests) VALUES (?, ?)");
            $stmt->execute([$key, json_encode($requests)]);
        }
    }
    
    private function cleanOldRequestsFromDatabase($key, $windowStart) {
        $pdo = $this->storage['connection'];
        $stmt = $pdo->prepare("SELECT requests FROM rate_limits WHERE id = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        
        if (!$row) {
            return;
        }
        
        $requests = json_decode($row['requests'], true) ?: [];
        $requests = array_filter($requests, function($timestamp) use ($windowStart) {
            return $timestamp >= $windowStart;
        });
        
        if (empty($requests)) {
            $stmt = $pdo->prepare("DELETE FROM rate_limits WHERE id = ?");
            $stmt->execute([$key]);
        } else {
            $stmt = $pdo->prepare("UPDATE rate_limits SET requests = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([json_encode($requests), $key]);
        }
    }
    
    private function clearRequestsFromDatabase($key) {
        $pdo = $this->storage['connection'];
        $stmt = $pdo->prepare("DELETE FROM rate_limits WHERE id = ?");
        $stmt->execute([$key]);
    }
    
    /**
     * Helper methods
     */
    private function generateKey($key, $identifier) {
        return 'rate_limit:' . $key . ':' . md5($identifier);
    }
    
    /**
     * Cleanup old rate limit data (should be called periodically)
     */
    public function cleanup($olderThanSeconds = 3600) {
        $cutoffTime = time() - $olderThanSeconds;
        
        switch ($this->storage['type']) {
            case 'file':
                $this->cleanupFiles($cutoffTime);
                break;
            case 'database':
                $this->cleanupDatabase($cutoffTime);
                break;
            // Redis and Memcached handle expiration automatically
        }
    }
    
    private function cleanupFiles($cutoffTime) {
        $files = glob($this->storage['path'] . '*.json');
        foreach ($files as $file) {
            if (filemtime($file) < $cutoffTime) {
                unlink($file);
            }
        }
    }
    
    private function cleanupDatabase($cutoffTime) {
        $pdo = $this->storage['connection'];
        $stmt = $pdo->prepare("DELETE FROM rate_limits WHERE updated_at < FROM_UNIXTIME(?)");
        $stmt->execute([$cutoffTime]);
    }
}

/**
 * Rate limiting middleware
 */
class RateLimitMiddleware {
    private $rateLimiter;
    private $limits;
    
    public function __construct($limits = []) {
        $this->rateLimiter = new RateLimiter();
        $this->limits = array_merge([
            'default' => ['requests' => 100, 'window' => 3600], // 100 requests per hour
            'auth' => ['requests' => 5, 'window' => 900], // 5 requests per 15 minutes
            'otp' => ['requests' => 3, 'window' => 300], // 3 requests per 5 minutes
            'upload' => ['requests' => 10, 'window' => 3600], // 10 uploads per hour
        ], $limits);
    }
    
    /**
     * Apply rate limiting
     */
    public function apply($limitType = 'default', $identifier = null) {
        $identifier = $identifier ?: $this->getClientIdentifier();
        $limit = $this->limits[$limitType] ?? $this->limits['default'];
        
        $allowed = $this->rateLimiter->checkLimit(
            $limitType,
            $identifier,
            $limit['requests'],
            $limit['window']
        );
        
        // Add rate limit headers
        $info = $this->rateLimiter->getLimitInfo(
            $limitType,
            $identifier,
            $limit['requests'],
            $limit['window']
        );
        
        header('X-RateLimit-Limit: ' . $info['limit']);
        header('X-RateLimit-Remaining: ' . $info['remaining']);
        header('X-RateLimit-Reset: ' . (time() + $info['reset_time']));
        
        if (!$allowed) {
            http_response_code(429);
            header('Retry-After: ' . $info['reset_time']);
            echo json_encode([
                'success' => false,
                'message' => 'Rate limit exceeded. Please try again later.',
                'retry_after' => $info['reset_time']
            ]);
            exit;
        }
        
        return true;
    }
    
    /**
     * Get client identifier
     */
    private function getClientIdentifier() {
        // Use IP address as default identifier
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'];
        
        // If user is authenticated, use user ID
        try {
            $user = getCurrentUser(false);
            if ($user) {
                return 'user:' . $user['id'];
            }
        } catch (Exception $e) {
            // User not authenticated, use IP
        }
        
        return 'ip:' . $ip;
    }
}

/**
 * Helper functions
 */
function applyRateLimit($limitType = 'default', $identifier = null) {
    $middleware = new RateLimitMiddleware();
    return $middleware->apply($limitType, $identifier);
}

function checkRateLimit($key, $identifier, $maxRequests, $windowSeconds) {
    $rateLimiter = new RateLimiter();
    return $rateLimiter->checkLimit($key, $identifier, $maxRequests, $windowSeconds);
}

?>