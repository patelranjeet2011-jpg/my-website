<?php
/**
 * JWT (JSON Web Token) Utility Class
 * KMFSL PHP Backend - JWT Token Management
 */

class JWT {
    private $secret;
    private $algorithm;
    private $expiration;
    
    public function __construct() {
        $this->secret = $_ENV['JWT_SECRET'] ?? 'kmfsl_secret_key_2024';
        $this->algorithm = 'HS256';
        $this->expiration = $_ENV['JWT_EXPIRE'] ?? '7d';
    }
    
    /**
     * Encode payload to JWT token
     */
    public function encode($payload, $expiration = null) {
        $header = [
            'typ' => 'JWT',
            'alg' => $this->algorithm
        ];
        
        $now = time();
        $exp = $expiration ? $this->parseExpiration($expiration) : $this->parseExpiration($this->expiration);
        
        $payload['iat'] = $now; // Issued at
        $payload['exp'] = $now + $exp; // Expiration
        $payload['iss'] = 'KMFSL'; // Issuer
        
        $headerEncoded = $this->base64UrlEncode(json_encode($header));
        $payloadEncoded = $this->base64UrlEncode(json_encode($payload));
        
        $signature = $this->sign($headerEncoded . '.' . $payloadEncoded);
        
        return $headerEncoded . '.' . $payloadEncoded . '.' . $signature;
    }
    
    /**
     * Decode JWT token to payload
     */
    public function decode($token) {
        $parts = explode('.', $token);
        
        if (count($parts) !== 3) {
            throw new Exception('Invalid token format');
        }
        
        list($headerEncoded, $payloadEncoded, $signature) = $parts;
        
        // Verify signature
        $expectedSignature = $this->sign($headerEncoded . '.' . $payloadEncoded);
        if (!hash_equals($signature, $expectedSignature)) {
            throw new Exception('Invalid token signature');
        }
        
        // Decode payload
        $payload = json_decode($this->base64UrlDecode($payloadEncoded), true);
        
        if (!$payload) {
            throw new Exception('Invalid token payload');
        }
        
        // Check expiration
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            throw new Exception('Token has expired');
        }
        
        return $payload;
    }
    
    /**
     * Verify if token is valid
     */
    public function verify($token) {
        try {
            $this->decode($token);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Get token expiration time
     */
    public function getExpiration($token) {
        try {
            $payload = $this->decode($token);
            return $payload['exp'] ?? null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Check if token is expired
     */
    public function isExpired($token) {
        $exp = $this->getExpiration($token);
        return $exp ? $exp < time() : true;
    }
    
    /**
     * Refresh token (generate new token with same payload)
     */
    public function refresh($token) {
        try {
            $payload = $this->decode($token);
            
            // Remove timing claims
            unset($payload['iat'], $payload['exp'], $payload['iss']);
            
            return $this->encode($payload);
        } catch (Exception $e) {
            throw new Exception('Cannot refresh invalid token');
        }
    }
    
    /**
     * Extract user data from token
     */
    public function getUser($token) {
        try {
            $payload = $this->decode($token);
            return $payload['user'] ?? null;
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Create access token
     */
    public function createAccessToken($user) {
        $payload = [
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'role' => $user['role'] ?? 'user'
            ],
            'type' => 'access'
        ];
        
        return $this->encode($payload, '1h'); // 1 hour expiration
    }
    
    /**
     * Create refresh token
     */
    public function createRefreshToken($user) {
        $payload = [
            'user' => [
                'id' => $user['id'],
                'email' => $user['email']
            ],
            'type' => 'refresh'
        ];
        
        return $this->encode($payload, '30d'); // 30 days expiration
    }
    
    /**
     * Create password reset token
     */
    public function createPasswordResetToken($user) {
        $payload = [
            'user' => [
                'id' => $user['id'],
                'email' => $user['email']
            ],
            'type' => 'password_reset',
            'nonce' => bin2hex(random_bytes(16))
        ];
        
        return $this->encode($payload, '1h'); // 1 hour expiration
    }
    
    /**
     * Create email verification token
     */
    public function createEmailVerificationToken($user) {
        $payload = [
            'user' => [
                'id' => $user['id'],
                'email' => $user['email']
            ],
            'type' => 'email_verification',
            'nonce' => bin2hex(random_bytes(16))
        ];
        
        return $this->encode($payload, '24h'); // 24 hours expiration
    }
    
    /**
     * Private methods
     */
    private function sign($data) {
        return $this->base64UrlEncode(hash_hmac('sha256', $data, $this->secret, true));
    }
    
    private function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    private function base64UrlDecode($data) {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
    }
    
    private function parseExpiration($expiration) {
        if (is_numeric($expiration)) {
            return (int) $expiration;
        }
        
        $unit = substr($expiration, -1);
        $value = (int) substr($expiration, 0, -1);
        
        switch ($unit) {
            case 's': // seconds
                return $value;
            case 'm': // minutes
                return $value * 60;
            case 'h': // hours
                return $value * 3600;
            case 'd': // days
                return $value * 86400;
            case 'w': // weeks
                return $value * 604800;
            case 'M': // months (30 days)
                return $value * 2592000;
            case 'y': // years (365 days)
                return $value * 31536000;
            default:
                return 3600; // Default 1 hour
        }
    }
}

/**
 * JWT Middleware for authentication
 */
class JWTMiddleware {
    private $jwt;
    
    public function __construct() {
        $this->jwt = new JWT();
    }
    
    /**
     * Authenticate request
     */
    public function authenticate($required = true) {
        $token = $this->extractToken();
        
        if (!$token) {
            if ($required) {
                throw new Exception('Authorization token required', 401);
            }
            return null;
        }
        
        try {
            $payload = $this->jwt->decode($token);
            return $payload['user'] ?? null;
        } catch (Exception $e) {
            if ($required) {
                throw new Exception('Invalid or expired token', 401);
            }
            return null;
        }
    }
    
    /**
     * Check if user has required role
     */
    public function requireRole($requiredRole) {
        $user = $this->authenticate(true);
        
        if (!$user || ($user['role'] ?? 'user') !== $requiredRole) {
            throw new Exception('Insufficient permissions', 403);
        }
        
        return $user;
    }
    
    /**
     * Check if user has any of the required roles
     */
    public function requireAnyRole($requiredRoles) {
        $user = $this->authenticate(true);
        $userRole = $user['role'] ?? 'user';
        
        if (!$user || !in_array($userRole, $requiredRoles)) {
            throw new Exception('Insufficient permissions', 403);
        }
        
        return $user;
    }
    
    /**
     * Extract token from request headers
     */
    private function extractToken() {
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        
        if (preg_match('/Bearer\s+(\S+)/', $authHeader, $matches)) {
            return $matches[1];
        }
        
        // Check for token in query parameter (for file downloads, etc.)
        return $_GET['token'] ?? null;
    }
}

/**
 * Helper function to get current authenticated user
 */
function getCurrentUser($required = true) {
    $middleware = new JWTMiddleware();
    return $middleware->authenticate($required);
}

/**
 * Helper function to require authentication
 */
function requireAuth() {
    $middleware = new JWTMiddleware();
    return $middleware->authenticate(true);
}

/**
 * Helper function to require admin role
 */
function requireAdmin() {
    $middleware = new JWTMiddleware();
    return $middleware->requireAnyRole(['admin', 'super_admin']);
}

/**
 * Helper function to require super admin role
 */
function requireSuperAdmin() {
    $middleware = new JWTMiddleware();
    return $middleware->requireRole('super_admin');
}

?>