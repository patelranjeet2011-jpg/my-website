<?php
/**
 * SMS Service Utility Class
 * KMFSL PHP Backend - SMS Management
 */

class SMSService {
    private $provider;
    private $apiKey;
    private $apiSecret;
    private $senderId;
    private $baseUrl;
    
    public function __construct() {
        $this->provider = $_ENV['SMS_PROVIDER'] ?? 'textlocal'; // textlocal, twilio, msg91, etc.
        $this->apiKey = $_ENV['SMS_API_KEY'] ?? '';
        $this->apiSecret = $_ENV['SMS_API_SECRET'] ?? '';
        $this->senderId = $_ENV['SMS_SENDER_ID'] ?? 'KMFSL';
        
        // Set base URL based on provider
        switch ($this->provider) {
            case 'textlocal':
                $this->baseUrl = 'https://api.textlocal.in/send/';
                break;
            case 'twilio':
                $this->baseUrl = 'https://api.twilio.com/2010-04-01/Accounts/';
                break;
            case 'msg91':
                $this->baseUrl = 'https://api.msg91.com/api/sendhttp.php';
                break;
            default:
                $this->baseUrl = '';
        }
    }
    
    /**
     * Send SMS
     */
    public function send($to, $message, $templateId = null) {
        try {
            // Validate phone number
            if (!$this->validatePhoneNumber($to)) {
                throw new Exception('Invalid phone number format');
            }
            
            // Check if SMS is enabled
            if (empty($this->apiKey)) {
                // Log the SMS instead of sending (for development)
                error_log("SMS to {$to}: {$message}");
                return [
                    'success' => true,
                    'message' => 'SMS logged (SMS service not configured)',
                    'provider' => 'log'
                ];
            }
            
            switch ($this->provider) {
                case 'textlocal':
                    return $this->sendViaTextLocal($to, $message);
                case 'twilio':
                    return $this->sendViaTwilio($to, $message);
                case 'msg91':
                    return $this->sendViaMsg91($to, $message, $templateId);
                default:
                    throw new Exception('SMS provider not supported');
            }
        } catch (Exception $e) {
            error_log('SMS sending failed: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'provider' => $this->provider
            ];
        }
    }
    
    /**
     * Send OTP SMS
     */
    public function sendOTP($phone, $otp, $expiryMinutes = 10) {
        $message = "Your KMFSL OTP is {$otp}. Valid for {$expiryMinutes} minutes. Do not share with anyone. - KMFSL";
        return $this->send($phone, $message);
    }
    
    /**
     * Send welcome SMS
     */
    public function sendWelcomeSMS($phone, $name) {
        $message = "Welcome to KMFSL, {$name}! Your account has been created successfully. Login to explore our financial recovery services. - KMFSL";
        return $this->send($phone, $message);
    }
    
    /**
     * Send service request confirmation SMS
     */
    public function sendServiceRequestConfirmation($phone, $name, $requestNumber, $serviceName) {
        $message = "Hi {$name}, your service request #{$requestNumber} for {$serviceName} has been received. We'll contact you within 24 hours. - KMFSL";
        return $this->send($phone, $message);
    }
    
    /**
     * Send status update SMS
     */
    public function sendStatusUpdate($phone, $name, $requestNumber, $status) {
        $statusMessages = [
            'in_progress' => 'is now in progress',
            'completed' => 'has been completed successfully',
            'on_hold' => 'is currently on hold',
            'cancelled' => 'has been cancelled'
        ];
        
        $statusText = $statusMessages[$status] ?? 'status has been updated';
        $message = "Hi {$name}, your service request #{$requestNumber} {$statusText}. Check your dashboard for details. - KMFSL";
        
        return $this->send($phone, $message);
    }
    
    /**
     * Send via TextLocal
     */
    private function sendViaTextLocal($to, $message) {
        $postData = [
            'apikey' => $this->apiKey,
            'numbers' => $this->formatPhoneNumber($to),
            'message' => $message,
            'sender' => $this->senderId
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->baseUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception('cURL error: ' . $error);
        }
        
        $result = json_decode($response, true);
        
        if ($httpCode === 200 && isset($result['status']) && $result['status'] === 'success') {
            return [
                'success' => true,
                'message' => 'SMS sent successfully',
                'provider' => 'textlocal',
                'response' => $result
            ];
        } else {
            throw new Exception('TextLocal API error: ' . ($result['errors'][0]['message'] ?? 'Unknown error'));
        }
    }
    
    /**
     * Send via Twilio
     */
    private function sendViaTwilio($to, $message) {
        $accountSid = $this->apiKey;
        $authToken = $this->apiSecret;
        $fromNumber = $_ENV['TWILIO_PHONE_NUMBER'] ?? '';
        
        if (empty($fromNumber)) {
            throw new Exception('Twilio phone number not configured');
        }
        
        $url = $this->baseUrl . $accountSid . '/Messages.json';
        
        $postData = [
            'From' => $fromNumber,
            'To' => $this->formatPhoneNumber($to, true),
            'Body' => $message
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, $accountSid . ':' . $authToken);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception('cURL error: ' . $error);
        }
        
        $result = json_decode($response, true);
        
        if ($httpCode === 201 && isset($result['sid'])) {
            return [
                'success' => true,
                'message' => 'SMS sent successfully',
                'provider' => 'twilio',
                'response' => $result
            ];
        } else {
            throw new Exception('Twilio API error: ' . ($result['message'] ?? 'Unknown error'));
        }
    }
    
    /**
     * Send via MSG91
     */
    private function sendViaMsg91($to, $message, $templateId = null) {
        $postData = [
            'authkey' => $this->apiKey,
            'mobiles' => $this->formatPhoneNumber($to),
            'message' => $message,
            'sender' => $this->senderId,
            'route' => '4', // Transactional route
            'country' => '91'
        ];
        
        if ($templateId) {
            $postData['DLT_TE_ID'] = $templateId;
        }
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->baseUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception('cURL error: ' . $error);
        }
        
        $result = json_decode($response, true);
        
        if ($httpCode === 200 && isset($result['type']) && $result['type'] === 'success') {
            return [
                'success' => true,
                'message' => 'SMS sent successfully',
                'provider' => 'msg91',
                'response' => $result
            ];
        } else {
            throw new Exception('MSG91 API error: ' . ($result['message'] ?? 'Unknown error'));
        }
    }
    
    /**
     * Validate phone number format
     */
    private function validatePhoneNumber($phone) {
        // Remove all non-numeric characters
        $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
        
        // Check if it's a valid Indian mobile number
        if (preg_match('/^[6-9]\d{9}$/', $cleanPhone)) {
            return true; // 10-digit Indian mobile
        }
        
        if (preg_match('/^91[6-9]\d{9}$/', $cleanPhone)) {
            return true; // With country code
        }
        
        return false;
    }
    
    /**
     * Format phone number for API
     */
    private function formatPhoneNumber($phone, $includeCountryCode = false) {
        // Remove all non-numeric characters
        $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
        
        // If it's a 10-digit number, add country code
        if (strlen($cleanPhone) === 10) {
            $cleanPhone = '91' . $cleanPhone;
        }
        
        // Remove country code if not needed
        if (!$includeCountryCode && strlen($cleanPhone) === 12 && substr($cleanPhone, 0, 2) === '91') {
            $cleanPhone = substr($cleanPhone, 2);
        }
        
        // Add + for international format if needed
        if ($includeCountryCode && strlen($cleanPhone) === 12) {
            $cleanPhone = '+' . $cleanPhone;
        }
        
        return $cleanPhone;
    }
    
    /**
     * Get SMS delivery status
     */
    public function getDeliveryStatus($messageId, $provider = null) {
        $provider = $provider ?: $this->provider;
        
        try {
            switch ($provider) {
                case 'textlocal':
                    return $this->getTextLocalStatus($messageId);
                case 'twilio':
                    return $this->getTwilioStatus($messageId);
                case 'msg91':
                    return $this->getMsg91Status($messageId);
                default:
                    return ['status' => 'unknown', 'message' => 'Provider not supported'];
            }
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Get account balance (if supported by provider)
     */
    public function getBalance() {
        try {
            switch ($this->provider) {
                case 'textlocal':
                    return $this->getTextLocalBalance();
                case 'msg91':
                    return $this->getMsg91Balance();
                default:
                    return ['balance' => 'unknown', 'message' => 'Balance check not supported'];
            }
        } catch (Exception $e) {
            return ['balance' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Private helper methods for status and balance checks
     */
    private function getTextLocalStatus($messageId) {
        // Implementation for TextLocal status check
        return ['status' => 'pending', 'message' => 'Status check not implemented'];
    }
    
    private function getTwilioStatus($messageId) {
        // Implementation for Twilio status check
        return ['status' => 'pending', 'message' => 'Status check not implemented'];
    }
    
    private function getMsg91Status($messageId) {
        // Implementation for MSG91 status check
        return ['status' => 'pending', 'message' => 'Status check not implemented'];
    }
    
    private function getTextLocalBalance() {
        $url = 'https://api.textlocal.in/balance/?apikey=' . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception('cURL error: ' . $error);
        }
        
        $result = json_decode($response, true);
        
        if (isset($result['balance'])) {
            return ['balance' => $result['balance'], 'currency' => 'INR'];
        } else {
            throw new Exception('Failed to get balance');
        }
    }
    
    private function getMsg91Balance() {
        $url = 'https://api.msg91.com/api/balance.php?authkey=' . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception('cURL error: ' . $error);
        }
        
        $result = json_decode($response, true);
        
        if (isset($result['balance'])) {
            return ['balance' => $result['balance'], 'currency' => 'INR'];
        } else {
            throw new Exception('Failed to get balance');
        }
    }
}

/**
 * Helper functions for quick SMS sending
 */
function sendSMS($to, $message) {
    $smsService = new SMSService();
    return $smsService->send($to, $message);
}

function sendOTPSMS($phone, $otp, $expiryMinutes = 10) {
    $smsService = new SMSService();
    return $smsService->sendOTP($phone, $otp, $expiryMinutes);
}

function sendWelcomeSMS($phone, $name) {
    $smsService = new SMSService();
    return $smsService->sendWelcomeSMS($phone, $name);
}

?>