<?php
/**
 * Email Service Utility Class - PHPMailer + dotenv integration
 * Path: php-backend/utils/email.php
 *
 * NOTE: Do NOT commit your .env with secrets to a public repo.
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$autoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
} else {
    // If composer autoload is not present, you should manually place PHPMailer in includes/phpmailer/src/
    // and uncomment the requires below:
    // require_once __DIR__ . '/../includes/phpmailer/src/Exception.php';
    // require_once __DIR__ . '/../includes/phpmailer/src/PHPMailer.php';
    // require_once __DIR__ . '/../includes/phpmailer/src/SMTP.php';
}

/**
 * EmailService: sends emails using SMTP (PHPMailer) or fallback to PHP mail()
 */
class EmailService {
    private $smtpHost;
    private $smtpPort;
    private $smtpUsername;
    private $smtpPassword;
    private $fromEmail;
    private $fromName;
    private $isSmtpEnabled;

    public function __construct() {
        // Try load .env if phpdotenv is installed (via composer)
        $basePath = dirname(__DIR__); // php-backend/
        if (file_exists($basePath . '/vendor/autoload.php') && class_exists('\\Dotenv\\Dotenv')) {
            try {
                $dotenv = Dotenv\Dotenv::createImmutable($basePath);
                $dotenv->safeLoad();
            } catch (Exception $e) {
                // ignore
                error_log('Dotenv load error: ' . $e->getMessage());
            }
        }

        // Load config from environment (.env) or server globals, with defaults
        $this->smtpHost = $_ENV['SMTP_HOST'] ?? ($_SERVER['SMTP_HOST'] ?? 'smtp.gmail.com');
        $this->smtpPort = $_ENV['SMTP_PORT'] ?? ($_SERVER['SMTP_PORT'] ?? 587);
        $this->smtpUsername = $_ENV['SMTP_USERNAME'] ?? ($_SERVER['SMTP_USERNAME'] ?? '');
        $this->smtpPassword = $_ENV['SMTP_PASSWORD'] ?? ($_SERVER['SMTP_PASSWORD'] ?? '');
        $this->fromEmail = $_ENV['FROM_EMAIL'] ?? ($_SERVER['FROM_EMAIL'] ?? 'noreply@kmfsl.in');
        $this->fromName = $_ENV['FROM_NAME'] ?? ($_SERVER['FROM_NAME'] ?? 'KMFSL');

        // Optional config file override (php-backend/config/mail_config.php)
        $configPath = $basePath . '/config/mail_config.php';
        if (file_exists($configPath)) {
            try {
                $cfg = require $configPath;
                $this->smtpHost = $cfg['host'] ?? $this->smtpHost;
                $this->smtpPort = $cfg['port'] ?? $this->smtpPort;
                $this->smtpUsername = $cfg['username'] ?? $this->smtpUsername;
                $this->smtpPassword = $cfg['password'] ?? $this->smtpPassword;
                $this->fromEmail = $cfg['from_email'] ?? $this->fromEmail;
                $this->fromName = $cfg['from_name'] ?? $this->fromName;
            } catch (Exception $e) {
                error_log('Mail config load error: ' . $e->getMessage());
            }
        }

        $this->isSmtpEnabled = !empty($this->smtpUsername) && !empty($this->smtpPassword) && !empty($this->smtpHost);
    }

    /**
     * Send email using SMTP (PHPMailer) or fallback to PHP mail()
     */
    public function send($to, $subject, $body, $isHtml = true, $attachments = []) {
        try {
            if ($this->isSmtpEnabled) {
                return $this->sendViaSMTP($to, $subject, $body, $isHtml, $attachments);
            } else {
                return $this->sendViaPHPMail($to, $subject, $body, $isHtml);
            }
        } catch (Exception $e) {
            error_log('Email sending failed: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Send via PHPMailer (SMTP)
     */
    private function sendViaSMTP($to, $subject, $body, $isHtml = true, $attachments = []) {
        // Ensure PHPMailer is available
        if (!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer')) {
            error_log('PHPMailer not found. Install with composer require phpmailer/phpmailer or place PHPMailer in includes/phpmailer/src/');
            return ['success' => false, 'error' => 'PHPMailer not installed'];
        }

        $mail = new PHPMailer(true);
        try {
            // Production-safe: disable verbose debug output
            $mail->SMTPDebug   = 0;
            $mail->Debugoutput = null;
            // Ensure Return-Path is set (helps deliverability)
            $mail->Sender = $this->fromEmail;

            // Single clean SMTP setup block
            $mail->isSMTP();
            $mail->Host       = $this->smtpHost;
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->smtpUsername;
            $mail->Password   = $this->smtpPassword;

            $port = (int)$this->smtpPort;
            if ($port === 465) {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            }
            $mail->Port = $port ?: 587;

            // Set from & recipient
            $mail->setFrom($this->fromEmail, $this->fromName);
            $mail->addAddress($to);
            $mail->addReplyTo($this->fromEmail, $this->fromName);

            // Attachments
            if (!empty($attachments) && is_array($attachments)) {
                foreach ($attachments as $filePath) {
                    if (file_exists($filePath)) {
                        $mail->addAttachment($filePath);
                    }
                }
            }

            // Content
            $mail->isHTML((bool)$isHtml);
            $mail->Subject = $subject;
            $mail->Body = $body;
            $mail->AltBody = $isHtml ? strip_tags($body) : $body;

            $mail->send();
            return ['success' => true, 'message' => 'Email sent via SMTP (PHPMailer)'];
        } catch (Exception $e) {
            error_log('PHPMailer error: ' . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Fallback: Send via PHP mail()
     */
    private function sendViaPHPMail($to, $subject, $body, $isHtml = true) {
        $headers = [
            'From: ' . $this->fromName . ' <' . $this->fromEmail . '>',
            'Reply-To: ' . $this->fromEmail,
            'X-Mailer: PHP/' . phpversion(),
            'MIME-Version: 1.0'
        ];

        $headers[] = $isHtml ? 'Content-Type: text/html; charset=UTF-8' : 'Content-Type: text/plain; charset=UTF-8';

        $success = mail($to, $subject, $body, implode("\r\n", $headers));
        return [
            'success' => $success,
            'message' => $success ? 'Email sent successfully (PHP mail())' : 'Failed to send email (PHP mail())'
        ];
    }

    /**
     * Existing template methods (copied from original file)
     */
    public function sendWelcomeEmail($email, $name) {
        $subject = 'Welcome to KMFSL - Account Created Successfully';
        $body = $this->getWelcomeEmailTemplate($name, $email);

        return $this->send($email, $subject, $body, true);
    }

    public function sendOTP($email, $otp, $purpose = 'verification') {
        $subject = "Your KMFSL OTP - {$otp}";
        $body = $this->getOTPEmailTemplate($otp, $purpose);

        return $this->send($email, $subject, $body, true);
    }

    public function sendPasswordResetEmail($email, $name, $resetToken) {
        $subject = 'Password Reset Request - KMFSL';
        $resetUrl = ($_ENV['FRONTEND_URL'] ?? 'http://localhost:3000') . '/reset-password?token=' . $resetToken;
        $body = $this->getPasswordResetEmailTemplate($name, $resetUrl);

        return $this->send($email, $subject, $body, true);
    }

    public function sendEnquiryNotification($enquiry) {
        $subject = 'New Enquiry from KMFSL Website - ' . $enquiry['name'];
        $body = $this->getEnquiryNotificationTemplate($enquiry);

        $adminEmail = $_ENV['ADMIN_EMAIL'] ?? 'admin@kmfsl.com';
        return $this->send($adminEmail, $subject, $body, true);
    }

    public function sendServiceRequestNotification($serviceRequest, $user, $service) {
        $subject = 'New Service Request - ' . $service['name'];
        $body = $this->getServiceRequestNotificationTemplate($serviceRequest, $user, $service);

        $adminEmail = $_ENV['ADMIN_EMAIL'] ?? 'admin@kmfsl.com';
        return $this->send($adminEmail, $subject, $body, true);
    }

    public function sendServiceRequestConfirmation($user, $serviceRequest, $service) {
        $subject = 'Service Request Confirmation - ' . $service['name'];
        $body = $this->getServiceRequestConfirmationTemplate($user, $serviceRequest, $service);

        return $this->send($user['email'], $subject, $body, true);
    }

    // ---------- Email templates (copied from original) ----------
    private function getWelcomeEmailTemplate($name, $email) {
        $loginUrl = ($_ENV['FRONTEND_URL'] ?? 'http://localhost:3000') . '/client/login';

        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Welcome to KMFSL</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Welcome to KMFSL!</h1>
                    <p>Your account has been created successfully</p>
                </div>
                <div class='content'>
                    <h2>Hello {$name},</h2>
                    <p>Thank you for joining KMFSL (Kaimur Financial Services Pvt. Ltd.). Your account has been created successfully with the email address: <strong>{$email}</strong></p>
                    
                    <p>With KMFSL, you can:</p>
                    <ul>
                        <li>Recover unclaimed shares and dividends from IEPF</li>
                        <li>Handle transmission of shares</li>
                        <li>Convert physical shares to demat format</li>
                        <li>Claim unclaimed dividends</li>
                        <li>Access specialized NRI services</li>
                        <li>Get comprehensive wealth recovery solutions</li>
                    </ul>
                    
                    <p>You can now login to your account and start exploring our services:</p>
                    <a href='{$loginUrl}' class='button'>Login to Your Account</a>
                    
                    <p>If you have any questions or need assistance, please don't hesitate to contact our support team at <a href='mailto:help@kmfsl.com'>help@kmfsl.com</a> or call us at +91 7070972333.</p>
                    
                    <p>Best regards,<br>The KMFSL Team</p>
                </div>
                <div class='footer'>
                    <p>© 2024 Kaimur Financial Services Pvt. Ltd. All rights reserved.</p>
                    <p>This email was sent to {$email}. If you didn't create an account, please ignore this email.</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }

    private function getOTPEmailTemplate($otp, $purpose) {
        $purposeText = [
            'registration' => 'complete your registration',
            'login' => 'login to your account',
            'password_reset' => 'reset your password',
            'email_verification' => 'verify your email address',
            'phone_verification' => 'verify your phone number'
        ];
        
        $purposeDescription = $purposeText[$purpose] ?? 'verify your identity';
        
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Your KMFSL OTP</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; text-align: center; }
                .otp { font-size: 36px; font-weight: bold; color: #667eea; background: white; padding: 20px; border-radius: 10px; margin: 20px 0; letter-spacing: 5px; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
                .warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Your OTP Code</h1>
                    <p>One-Time Password for KMFSL</p>
                </div>
                <div class='content'>
                    <h2>Verification Required</h2>
                    <p>Use the following OTP to {$purposeDescription}:</p>
                    
                    <div class='otp'>{$otp}</div>
                    
                    <p><strong>This OTP is valid for 10 minutes only.</strong></p>
                    
                    <div class='warning'>
                        <strong>Security Notice:</strong> Never share this OTP with anyone. KMFSL will never ask for your OTP over phone or email.
                    </div>
                    
                    <p>If you didn't request this OTP, please ignore this email or contact our support team immediately.</p>
                </div>
                <div class='footer'>
                    <p>© 2024 Kaimur Financial Services Pvt. Ltd. All rights reserved.</p>
                    <p>For support, contact us at <a href='mailto:help@kmfsl.com'>help@kmfsl.com</a> or +91 7070972333</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }

    private function getPasswordResetEmailTemplate($name, $resetUrl) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Password Reset - KMFSL</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
                .warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Password Reset Request</h1>
                    <p>Reset your KMFSL account password</p>
                </div>
                <div class='content'>
                    <h2>Hello {$name},</h2>
                    <p>We received a request to reset the password for your KMFSL account. If you made this request, click the button below to reset your password:</p>
                    
                    <a href='{$resetUrl}' class='button'>Reset Password</a>
                    
                    <p>This password reset link will expire in 1 hour for security reasons.</p>
                    
                    <div class='warning'>
                        <strong>Security Notice:</strong> If you didn't request a password reset, please ignore this email. Your password will remain unchanged.
                    </div>
                    
                    <p>If the button doesn't work, you can copy and paste this link into your browser:</p>
                    <p><a href='{$resetUrl}'>{$resetUrl}</a></p>
                    
                    <p>If you have any questions, please contact our support team at <a href='mailto:help@kmfsl.com'>help@kmfsl.com</a></p>
                    
                    <p>Best regards,<br>The KMFSL Team</p>
                </div>
                <div class='footer'>
                    <p>© 2024 Kaimur Financial Services Pvt. Ltd. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }

    private function getEnquiryNotificationTemplate($enquiry) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>New Enquiry - KMFSL</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #667eea; color: white; padding: 20px; text-align: center; }
                .content { background: #f9f9f9; padding: 20px; }
                .field { margin: 10px 0; }
                .label { font-weight: bold; color: #555; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>New Enquiry Received</h1>
                </div>
                <div class='content'>
                    <h2>Enquiry Details:</h2>
                    
                    <div class='field'>
                        <span class='label'>Name:</span> {$enquiry['name']}
                    </div>
                    <div class='field'>
                        <span class='label'>Email:</span> {$enquiry['email']}
                    </div>
                    <div class='field'>
                        <span class='label'>Phone:</span> {$enquiry['phone']}
                    </div>
                    <div class='field'>
                        <span class='label'>Service:</span> {$enquiry['service']}
                    </div>
                    <div class='field'>
                        <span class='label'>Subject:</span> {$enquiry['subject']}
                    </div>
                    <div class='field'>
                        <span class='label'>Message:</span><br>
                        {$enquiry['message']}
                    </div>
                    <div class='field'>
                        <span class='label'>Source:</span> {$enquiry['source']}
                    </div>
                    <div class='field'>
                        <span class='label'>IP Address:</span> {$enquiry['ip_address']}
                    </div>
                    <div class='field'>
                        <span class='label'>Submitted:</span> {$enquiry['created_at']}
                    </div>
                </div>
            </div>
        </body>
        </html>
        ";
    }

    private function getServiceRequestNotificationTemplate($serviceRequest, $user, $service) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>New Service Request - KMFSL</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #667eea; color: white; padding: 20px; text-align: center; }
                .content { background: #f9f9f9; padding: 20px; }
                .field { margin: 10px 0; }
                .label { font-weight: bold; color: #555; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>New Service Request</h1>
                </div>
                <div class='content'>
                    <h2>Service Request Details:</h2>
                    
                    <div class='field'>
                        <span class='label'>Request Number:</span> {$serviceRequest['request_number']}
                    </div>
                    <div class='field'>
                        <span class='label'>Service:</span> {$service['name']}
                    </div>
                    <div class='field'>
                        <span class='label'>Client Name:</span> {$user['name']}
                    </div>
                    <div class='field'>
                        <span class='label'>Client Email:</span> {$user['email']}
                    </div>
                    <div class='field'>
                        <span class='label'>Client Phone:</span> {$user['phone']}
                    </div>
                    <div class='field'>
                        <span class='label'>Estimated Amount:</span> ₹{$serviceRequest['estimated_amount']}
                    </div>
                    <div class='field'>
                        <span class='label'>Priority:</span> {$serviceRequest['priority']}
                    </div>
                    <div class='field'>
                        <span class='label'>Notes:</span><br>
                        {$serviceRequest['notes']}
                    </div>
                    <div class='field'>
                        <span class='label'>Submitted:</span> {$serviceRequest['created_at']}
                    </div>
                </div>
            </div>
        </body>
        </html>
        ";
    }

    private function getServiceRequestConfirmationTemplate($user, $serviceRequest, $service) {
        $dashboardUrl = ($_ENV['FRONTEND_URL'] ?? 'http://localhost:3000') . '/client/dashboard';

        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Service Request Confirmation - KMFSL</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
                .field { margin: 10px 0; }
                .label { font-weight: bold; color: #555; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Service Request Confirmed</h1>
                    <p>Your request has been received successfully</p>
                </div>
                <div class='content'>
                    <h2>Hello {$user['name']},</h2>
                    <p>Thank you for choosing KMFSL. Your service request has been received and is being processed.</p>
                    
                    <h3>Request Details:</h3>
                    <div class='field'>
                        <span class='label'>Request Number:</span> {$serviceRequest['request_number']}
                    </div>
                    <div class='field'>
                        <span class='label'>Service:</span> {$service['name']}
                    </div>
                    <div class='field'>
                        <span class='label'>Status:</span> {$serviceRequest['status']}
                    </div>
                    <div class='field'>
                        <span class='label'>Processing Time:</span> {$service['processing_time']}
                    </div>
                    
                    <p>You can track the progress of your request by logging into your dashboard:</p>
                    <a href='{$dashboardUrl}' class='button'>View Dashboard</a>
                    
                    <p>Our team will contact you within 24 hours to discuss the next steps. If you have any questions, please don't hesitate to contact us at <a href='mailto:help@kmfsl.com'>help@kmfsl.com</a> or +91 7070972333.</p>
                    
                    <p>Best regards,<br>The KMFSL Team</p>
                </div>
                <div class='footer'>
                    <p>© 2024 Kaimur Financial Services Pvt. Ltd. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
}

/**
 * Optional helper functions (convenience wrappers)
 */
function sendEmail($to, $subject, $body, $isHtml = true) {
    $emailService = new EmailService();
    return $emailService->send($to, $subject, $body, $isHtml);
}

function sendWelcomeEmail($email, $name) {
    $emailService = new EmailService();
    return $emailService->sendWelcomeEmail($email, $name);
}

function sendOTPEmail($email, $otp, $purpose = 'verification') {
    $emailService = new EmailService();
    return $emailService->sendOTP($email, $otp, $purpose);
}

?>