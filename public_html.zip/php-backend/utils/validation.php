<?php
/**
 * Validation Utility Class
 * KMFSL PHP Backend - Input Validation
 */

class Validator {
    private $errors = [];
    private $data = [];
    
    /**
     * Validate required field
     */
    public function required($field, $value, $message = null) {
        $this->data[$field] = $value;
        
        if (empty($value) && $value !== '0' && $value !== 0) {
            $this->errors[$field][] = $message ?: "{$field} is required";
        }
        
        return $this;
    }
    
    /**
     * Validate optional field (only validate if not empty)
     */
    public function optional($field, $value) {
        $this->data[$field] = $value;
        return $this;
    }
    
    /**
     * Validate email format
     */
    public function email($message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field][] = $message ?: "Invalid email format";
        }
        
        return $this;
    }
    
    /**
     * Validate phone number (Indian format)
     */
    public function phone($message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !preg_match('/^[6-9]\d{9}$/', $value)) {
            $this->errors[$field][] = $message ?: "Invalid phone number format";
        }
        
        return $this;
    }
    
    /**
     * Validate PAN number format
     */
    public function pan($message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', strtoupper($value))) {
            $this->errors[$field][] = $message ?: "Invalid PAN number format";
        }
        
        return $this;
    }
    
    /**
     * Validate pincode format
     */
    public function pincode($message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !preg_match('/^[1-9][0-9]{5}$/', $value)) {
            $this->errors[$field][] = $message ?: "Invalid pincode format";
        }
        
        return $this;
    }
    
    /**
     * Validate minimum length
     */
    public function minLength($length, $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && strlen($value) < $length) {
            $this->errors[$field][] = $message ?: "{$field} must be at least {$length} characters long";
        }
        
        return $this;
    }
    
    /**
     * Validate maximum length
     */
    public function maxLength($length, $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && strlen($value) > $length) {
            $this->errors[$field][] = $message ?: "{$field} must not exceed {$length} characters";
        }
        
        return $this;
    }
    
    /**
     * Validate exact length
     */
    public function length($length, $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && strlen($value) !== $length) {
            $this->errors[$field][] = $message ?: "{$field} must be exactly {$length} characters long";
        }
        
        return $this;
    }
    
    /**
     * Validate minimum value
     */
    public function min($min, $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && is_numeric($value) && (float)$value < $min) {
            $this->errors[$field][] = $message ?: "{$field} must be at least {$min}";
        }
        
        return $this;
    }
    
    /**
     * Validate maximum value
     */
    public function max($max, $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && is_numeric($value) && (float)$value > $max) {
            $this->errors[$field][] = $message ?: "{$field} must not exceed {$max}";
        }
        
        return $this;
    }
    
    /**
     * Validate numeric value
     */
    public function numeric($message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !is_numeric($value)) {
            $this->errors[$field][] = $message ?: "{$field} must be a number";
        }
        
        return $this;
    }
    
    /**
     * Validate integer value
     */
    public function integer($message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_INT)) {
            $this->errors[$field][] = $message ?: "{$field} must be an integer";
        }
        
        return $this;
    }
    
    /**
     * Validate boolean value
     */
    public function boolean($message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !in_array($value, [true, false, 1, 0, '1', '0', 'true', 'false'], true)) {
            $this->errors[$field][] = $message ?: "{$field} must be a boolean value";
        }
        
        return $this;
    }
    
    /**
     * Validate value is in array
     */
    public function in($array, $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !in_array($value, $array)) {
            $allowedValues = implode(', ', $array);
            $this->errors[$field][] = $message ?: "{$field} must be one of: {$allowedValues}";
        }
        
        return $this;
    }
    
    /**
     * Validate URL format
     */
    public function url($message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_URL)) {
            $this->errors[$field][] = $message ?: "Invalid URL format";
        }
        
        return $this;
    }
    
    /**
     * Validate date format
     */
    public function date($format = 'Y-m-d', $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value)) {
            $date = DateTime::createFromFormat($format, $value);
            if (!$date || $date->format($format) !== $value) {
                $this->errors[$field][] = $message ?: "Invalid date format. Expected format: {$format}";
            }
        }
        
        return $this;
    }
    
    /**
     * Validate regex pattern
     */
    public function regex($pattern, $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !preg_match($pattern, $value)) {
            $this->errors[$field][] = $message ?: "{$field} format is invalid";
        }
        
        return $this;
    }
    
    /**
     * Validate file upload
     */
    public function file($allowedTypes = [], $maxSize = null, $message = null) {
        $field = $this->getLastField();
        $file = $_FILES[$field] ?? null;
        
        if ($file && $file['error'] !== UPLOAD_ERR_NO_FILE) {
            // Check for upload errors
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $this->errors[$field][] = $message ?: "File upload failed";
                return $this;
            }
            
            // Check file size
            if ($maxSize && $file['size'] > $maxSize) {
                $maxSizeMB = round($maxSize / 1024 / 1024, 2);
                $this->errors[$field][] = $message ?: "File size must not exceed {$maxSizeMB}MB";
            }
            
            // Check file type
            if (!empty($allowedTypes)) {
                $fileType = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (!in_array($fileType, $allowedTypes)) {
                    $allowedTypesStr = implode(', ', $allowedTypes);
                    $this->errors[$field][] = $message ?: "File type must be one of: {$allowedTypesStr}";
                }
            }
        }
        
        return $this;
    }
    
    /**
     * Custom validation rule
     */
    public function custom($callback, $message = null) {
        $field = $this->getLastField();
        $value = $this->data[$field] ?? '';
        
        if (!empty($value) && !call_user_func($callback, $value)) {
            $this->errors[$field][] = $message ?: "{$field} is invalid";
        }
        
        return $this;
    }
    
    /**
     * Check if validation passed
     */
    public function isValid() {
        return empty($this->errors);
    }
    
    /**
     * Get all errors
     */
    public function getErrors() {
        $flatErrors = [];
        foreach ($this->errors as $field => $fieldErrors) {
            $flatErrors = array_merge($flatErrors, $fieldErrors);
        }
        return $flatErrors;
    }
    
    /**
     * Get errors by field
     */
    public function getFieldErrors() {
        return $this->errors;
    }
    
    /**
     * Get first error
     */
    public function getFirstError() {
        $errors = $this->getErrors();
        return $errors[0] ?? null;
    }
    
    /**
     * Clear all errors
     */
    public function clearErrors() {
        $this->errors = [];
        return $this;
    }
    
    /**
     * Get validated data
     */
    public function getData() {
        return $this->data;
    }
    
    /**
     * Get last field name
     */
    private function getLastField() {
        return array_key_last($this->data);
    }
}

/**
 * Sanitization utility class
 */
class Sanitizer {
    /**
     * Sanitize string
     */
    public static function string($value) {
        return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * Sanitize email
     */
    public static function email($value) {
        return filter_var(trim($value), FILTER_SANITIZE_EMAIL);
    }
    
    /**
     * Sanitize integer
     */
    public static function integer($value) {
        return filter_var($value, FILTER_SANITIZE_NUMBER_INT);
    }
    
    /**
     * Sanitize float
     */
    public static function float($value) {
        return filter_var($value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    }
    
    /**
     * Sanitize URL
     */
    public static function url($value) {
        return filter_var(trim($value), FILTER_SANITIZE_URL);
    }
    
    /**
     * Sanitize phone number
     */
    public static function phone($value) {
        return preg_replace('/[^0-9]/', '', $value);
    }
    
    /**
     * Sanitize PAN number
     */
    public static function pan($value) {
        return strtoupper(preg_replace('/[^A-Z0-9]/', '', $value));
    }
    
    /**
     * Sanitize filename
     */
    public static function filename($value) {
        return preg_replace('/[^a-zA-Z0-9._-]/', '', $value);
    }
    
    /**
     * Sanitize array
     */
    public static function array($array, $callback = null) {
        if (!is_array($array)) {
            return [];
        }
        
        if ($callback) {
            return array_map($callback, $array);
        }
        
        return array_map([self::class, 'string'], $array);
    }
    
    /**
     * Remove HTML tags
     */
    public static function stripTags($value, $allowedTags = '') {
        return strip_tags($value, $allowedTags);
    }
    
    /**
     * Sanitize for database
     */
    public static function forDatabase($value) {
        return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
    }
}

/**
 * Helper functions for quick validation
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePhone($phone) {
    return preg_match('/^[6-9]\d{9}$/', $phone);
}

function validatePAN($pan) {
    return preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', strtoupper($pan));
}

function validatePincode($pincode) {
    return preg_match('/^[1-9][0-9]{5}$/', $pincode);
}

function validatePassword($password, $minLength = 6) {
    return strlen($password) >= $minLength;
}

function validateRequired($value) {
    return !empty($value) || $value === '0' || $value === 0;
}

/**
 * Validation rules for common fields
 */
class ValidationRules {
    public static function user($data) {
        $validator = new Validator();
        
        $validator->required('name', $data['name'] ?? '')
                 ->minLength(2)->maxLength(100);
        
        $validator->required('email', $data['email'] ?? '')
                 ->email();
        
        $validator->required('phone', $data['phone'] ?? '')
                 ->phone();
        
        if (isset($data['password'])) {
            $validator->required('password', $data['password'])
                     ->minLength(6);
        }
        
        $validator->required('pan_number', $data['pan_number'] ?? '')
                 ->pan();
        
        $validator->required('address', $data['address'] ?? '');
        $validator->required('state', $data['state'] ?? '');
        $validator->required('district', $data['district'] ?? '');
        
        $validator->required('pincode', $data['pincode'] ?? '')
                 ->pincode();
        
        return $validator;
    }
    
    public static function enquiry($data) {
        $validator = new Validator();
        
        $validator->required('name', $data['name'] ?? '')
                 ->minLength(2)->maxLength(100);
        
        $validator->required('email', $data['email'] ?? '')
                 ->email();
        
        $validator->required('phone', $data['phone'] ?? '')
                 ->phone();
        
        $validator->required('message', $data['message'] ?? '')
                 ->minLength(10);
        
        $validator->optional('service', $data['service'] ?? '');
        $validator->optional('subject', $data['subject'] ?? '');
        
        return $validator;
    }
    
    public static function serviceRequest($data) {
        $validator = new Validator();
        
        $validator->required('service_id', $data['service_id'] ?? '');
        
        if (isset($data['estimated_amount'])) {
            $validator->optional('estimated_amount', $data['estimated_amount'])
                     ->numeric()->min(0);
        }
        
        $validator->optional('notes', $data['notes'] ?? '');
        
        return $validator;
    }
}

?>