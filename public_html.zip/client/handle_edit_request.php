<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['reason'])) {
    $user_id = $_SESSION['user_id'];
    $reason = trim($_POST['reason']);

    try {
        $stmt = $pdo->prepare("INSERT INTO edit_requests (client_id, reason) VALUES (?, ?)");
        $stmt->execute([$user_id, $reason]);
        header('Location: dashboard.php?request=sent');
    } catch (PDOException $e) {
        header('Location: dashboard.php?error=request_failed');
    }
} else {
    header('Location: dashboard.php');
}
?>