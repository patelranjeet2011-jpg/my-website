<?php
// FINAL VERSION of handle_message.php

header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Authentication required.']);
    exit;
}

$sender = $_SESSION['user_id'];
$receiver = isset($_POST['receiver_id']) ? (int)$_POST['receiver_id'] : 0;
$msg = isset($_POST['message']) ? trim($_POST['message']) : '';

if ($sender < 1 || $receiver < 0 || $msg === '') {
    echo json_encode(['success'=>false,'error'=>'Invalid input']);
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, message, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$sender, $receiver, $msg]);
    $id = $pdo->lastInsertId();
    $created_at_stmt = $pdo->prepare("SELECT created_at FROM messages WHERE id = ?");
    $created_at_stmt->execute([$id]);
    $row = $created_at_stmt->fetch(PDO::FETCH_ASSOC);
    $created_at = $row['created_at'] ?? date('Y-m-d H:i:s');
    $safe_html = nl2br(htmlentities($msg, ENT_QUOTES, 'UTF-8'));

    echo json_encode(['success'=>true, 'message'=>[
        'id'=>$id, 'sender_id'=>$sender, 'receiver_id'=>$receiver,
        'message'=>$msg, 'created_at'=>$created_at, 'html'=>$safe_html
    ]]);

} catch (Exception $e) {
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}