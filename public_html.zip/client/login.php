<?php
session_start();

$error_message = '';
$success_message = '';
$login_method = $_POST['login_method'] ?? 'email';
$otp_sent = $_SESSION['otp_sent'] ?? false;

// Handle email login
if ($_POST && isset($_POST['email_login'])) {
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $password = trim($_POST['password'] ?? '');
    $remember_me = isset($_POST['rememberMe']);
    
    if (empty($email) || empty($password)) {
        $error_message = 'Please enter both email and password.';
    } elseif (!$email) {
        $error_message = 'Please enter a valid email address.';
    } else {
        // असली डेटाबेस ऑथेंटिकेशन
        try {
            // डेटाबेस से कनेक्ट करें
            require_once '../config/database.php';

            // ईमेल के आधार पर यूज़र को ढूंढें
            $stmt = $pdo->prepare("SELECT id, first_name, last_name, email, password FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // अगर यूज़र मौजूद है और पासवर्ड सही है, तो लॉगिन करें
            if ($user && password_verify($password, $user['password'])) {
                // पासवर्ड सही है! लॉगिन सफल।
                session_regenerate_id(true); // सुरक्षा के लिए सेशन ID बदलें

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['first_name'];
                $_SESSION['user_email'] = $user['email'];
                
                if ($remember_me) {
                    setcookie('remember_client', $email, time() + (86400 * 30), '/'); // 30 दिन
                }
                
                header('Location: dashboard.php');
                exit;
            } else {
                // यूज़र नहीं मिला या पासवर्ड गलत है
                $error_message = 'Invalid email or password.';
            }
        } catch (PDOException $e) {
            // डेटाबेस में कोई और समस्या
            $error_message = 'Login failed due to a system error. Please try again later.';
            // error_log($e->getMessage()); // आप चाहें तो एरर को लॉग कर सकते हैं
        }
    }
}

// Handle OTP login (यह अभी भी डेमो है)
if ($_POST && isset($_POST['otp_login'])) {
    $phone = htmlspecialchars(trim($_POST['phone'] ?? ''));
    
    if (!$otp_sent) {
        // Send OTP (demo)
        if (!empty($phone) && preg_match('/^[0-9]{10}$/', $phone)) {
            $_SESSION['otp_sent'] = true;
            $_SESSION['otp_phone'] = $phone;
            $_SESSION['demo_otp'] = '123456'; // Demo OTP
            $success_message = 'OTP sent to your phone number. Use 123456 for demo.';
            $otp_sent = true;
        } else {
            $error_message = 'Please enter a valid 10-digit phone number.';
        }
    } else {
        // Verify OTP
        $otp = trim($_POST['otp'] ?? '');
        if ($otp === $_SESSION['demo_otp']) {
            $_SESSION['client_logged_in'] = true;
            $_SESSION['client_name'] = 'OTP User';
            $_SESSION['client_phone'] = $_SESSION['otp_phone'];
            unset($_SESSION['otp_sent'], $_SESSION['otp_phone'], $_SESSION['demo_otp']);
            header('Location: dashboard.php');
            exit;
        } else {
            $error_message = 'Invalid OTP. Please try again.';
        }
    }
}

// Handle resend OTP (यह अभी भी डेमो है)
if ($_POST && isset($_POST['resend_otp'])) {
    $_SESSION['demo_otp'] = '123456';
    $success_message = 'OTP resent successfully. Use 123456 for demo.';
    $otp_sent = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Login - KMFSL | Access Your Account</title>
    <meta name="description" content="Login to your KMFSL client account to track your service requests, upload documents, and communicate with our team.">
    
    <?php include '../includes/styles.php'; ?>
</head>
<body class="min-h-screen bg-gradient-to-br from-primary-50 via-white to-accent-50">
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
            <div class="text-center">
                <div class="flex justify-center mb-4">
                    <a href="../index.php" class="hover:opacity-80 transition-opacity">
                        <img 
                            src="../kmfsl-logo.svg" 
                            alt="KMFSL - Kaimur Financial Services" 
                            class="h-20 w-auto"
                        />
                    </a>
                </div>
                <div class="mb-6">
                    <a href="../index.php" class="inline-flex items-center text-sm text-secondary-600 hover:text-primary-600 transition-colors">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg">
                            <path d="M280.37 148.26L96 300.11V464a16 16 0 0 0 16 16l112.06-.29a16 16 0 0 0 15.92-16V368a16 16 0 0 1 16-16h64a16 16 0 0 1 16 16v95.64a16 16 0 0 0 16 16.05L464 480a16 16 0 0 0 16-16V300L295.67 148.26a12.19 12.19 0 0 0-15.3 0zM571.6 251.47L488 182.56V44.05a12 12 0 0 0-12-12h-56a12 12 0 0 0-12 12v72.61L318.47 43a48 48 0 0 0-61 0L4.34 251.47a12 12 0 0 0-1.6 16.9l25.5 31A12 12 0 0 0 45.15 301l235.22-193.74a12.19 12.19 0 0 1 15.3 0L530.9 301a12 12 0 0 0 16.9-1.6l25.5-31a12 12 0 0 0-1.7-16.93z"></path>
                        </svg>
                        Back to Home
                    </a>
                </div>
                <h2 class="text-3xl font-bold text-secondary-800 mb-2">
                    Client <span class="text-gradient">Login</span>
                </h2>
                <p class="text-secondary-600">
                    Access your KMFSL client portal to track your claims and manage your account
                </p>
            </div>

            <div class="flex bg-gray-100 rounded-lg p-1">
                <button
                    onclick="setLoginMethod('email')"
                    id="email-tab"
                    class="flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors bg-white text-primary-600 shadow-sm"
                >
                    <i class="fas fa-user mr-2"></i>
                    Email Login
                </button>
                <button
                    onclick="setLoginMethod('phone')"
                    id="phone-tab"
                    class="flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors text-secondary-600 hover:text-secondary-800"
                >
                    <i class="fas fa-phone mr-2"></i>
                    OTP Login
                </button>
            </div>
            
            <div class="bg-white rounded-xl shadow-lg p-8">
                <?php if ($error_message): ?>
                    <div class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success_message): ?>
                    <div class="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded">
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                
                <div id="email-form" class="space-y-6">
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="login_method" value="email">
                        
                        <div>
                            <label for="email" class="block text-sm font-medium text-secondary-700 mb-2">
                                Email Address
                            </label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="h-5 w-5 text-secondary-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                </div>
                                <input
                                    id="email"
                                    name="email"
                                    type="email"
                                    required
                                    value="<?php echo htmlspecialchars($_POST['email'] ?? $_COOKIE['remember_client'] ?? ''); ?>"
                                    class="input-field pl-10"
                                    placeholder="Enter your email address"
                                />
                            </div>
                        </div>

                        <div>
                            <label for="password" class="block text-sm font-medium text-secondary-700 mb-2">
                                Password
                            </label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="h-5 w-5 text-secondary-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M400 224h-24v-72C376 68.2 307.8 0 224 0S72 68.2 72 152v72H48c-26.5 0-48 21.5-48 48v192c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V272c0-26.5-21.5-48-48-48zm-104 0H152v-72c0-39.7 32.3-72 72-72s72 32.3 72 72v72z"></path>
                                    </svg>
                                </div>
                                <input
                                    id="password"
                                    name="password"
                                    type="password"
                                    required
                                    class="input-field pl-10 pr-10"
                                    placeholder="Enter your password"
                                />
                                <button
                                    type="button"
                                    onclick="togglePassword()"
                                    class="absolute inset-y-0 right-0 pr-3 flex items-center"
                                >
                                    <svg id="password-icon" stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="h-5 w-5 text-secondary-400 hover:text-secondary-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <input
                                    id="rememberMe"
                                    name="rememberMe"
                                    type="checkbox"
                                    <?php echo isset($_COOKIE['remember_client']) ? 'checked' : ''; ?>
                                    class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
                                />
                                <label for="rememberMe" class="ml-2 block text-sm text-secondary-700">
                                    Remember me
                                </label>
                            </div>
                            <a href="forgot-password.php" class="text-sm text-primary-600 hover:text-primary-500">
    Forgot password?
</a>
                        </div>

                        <button
                            type="submit"
                            name="email_login"
                            class="btn-primary w-full flex items-center justify-center"
                        >
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="mr-2 h-5 w-5" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3z"></path>
                            </svg>
                            Sign In
                        </button>
                    </form>
                </div>
                
                <div id="phone-form" class="space-y-6 hidden">
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="login_method" value="phone">
                        
                        <div>
                            <label for="phone" class="block text-sm font-medium text-secondary-700 mb-2">
                                Phone Number
                            </label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="h-5 w-5 text-secondary-400" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C7.7 366.5 1.8 378.1 4.4 389.4l24 104C31.1 504.2 40.7 512 51.2 512 306.8 512 512 306.8 512 51.2c0-10.5-7.8-20.1-18.6-22.6z"></path>
                                    </svg>
                                </div>
                                <input
                                    id="phone"
                                    name="phone"
                                    type="tel"
                                    required
                                    value="<?php echo htmlspecialchars($_SESSION['otp_phone'] ?? ''); ?>"
                                    class="input-field pl-10"
                                    placeholder="Enter your phone number"
                                    <?php echo $otp_sent ? 'readonly' : ''; ?>
                                />
                            </div>
                        </div>

                        <?php if ($otp_sent): ?>
                        <div>
                            <label for="otp" class="block text-sm font-medium text-secondary-700 mb-2">
                                Enter OTP
                            </label>
                            <input
                                id="otp"
                                name="otp"
                                type="text"
                                maxlength="6"
                                class="input-field text-center text-2xl tracking-widest"
                                placeholder="000000"
                            />
                            <p class="text-sm text-secondary-600 mt-2">
                                OTP sent to your phone number. Valid for 10 minutes.
                            </p>
                        </div>
                        <?php endif; ?>

                        <button
                            type="submit"
                            name="otp_login"
                            class="btn-primary w-full flex items-center justify-center"
                        >
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="mr-2 h-5 w-5" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C7.7 366.5 1.8 378.1 4.4 389.4l24 104C31.1 504.2 40.7 512 51.2 512 306.8 512 512 306.8 512 51.2c0-10.5-7.8-20.1-18.6-22.6z"></path>
                            </svg>
                            <?php echo $otp_sent ? 'Verify OTP' : 'Send OTP'; ?>
                        </button>

                        <?php if ($otp_sent): ?>
                        <button
                            type="submit"
                            name="resend_otp"
                            class="w-full text-sm text-primary-600 hover:text-primary-500"
                        >
                            Resend OTP
                        </button>
                        <?php endif; ?>
                    </form>
                </div>

                <div class="mt-6" id="biometric-section">
                    <div class="relative">
                        <div class="absolute inset-0 flex items-center">
                            <div class="w-full border-t border-secondary-300"></div>
                        </div>
                        <div class="relative flex justify-center text-sm">
                            <span class="px-2 bg-white text-secondary-500">Or continue with</span>
                        </div>
                    </div>
                    <button
                        onclick="handleBiometricLogin()"
                        class="mt-4 w-full flex items-center justify-center px-4 py-2 border border-secondary-300 rounded-md shadow-sm text-sm font-medium text-secondary-700 bg-white hover:bg-gray-50 transition-colors"
                    >
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="mr-2 h-5 w-5 text-primary-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M256.12 245.96c-13.25 0-24 10.74-24 24 1.14 72.25-8.14 141.9-27.7 211.55-2.73 9.72 2.15 30.49 23.12 30.49 10.48 0 20.11-6.92 23.09-17.52 13.53-47.91 31.04-125.41 29.48-224.52.01-13.25-10.73-24-23.99-24zm-.86-81.73C194 164.16 151.25 211.3 152.1 265.32c.75 47.94-3.75 95.91-13.37 142.55-2.69 12.98 5.67 25.69 18.64 28.36 13.05 2.67 25.67-5.66 28.36-18.64 10.34-50.09 15.17-101.58 14.37-153.02-.41-25.95 19.92-52.49 54.45-52.34 31.31.47 57.15 25.34 57.62 55.47.77 48.05-2.81 96.33-10.61 143.55-2.17 13.06 6.69 25.42 19.76 27.58 19.97 3.33 26.81-15.1 27.58-19.77 8.28-50.03 12.06-101.21 11.27-152.11-.88-55.8-47.94-101.88-104.91-102.72zm-110.69-19.78c-10.3-8.34-25.37-6.8-33.76 3.48-25.62 31.5-39.39 71.28-38.75 112 .59 37.58-2.47 75.27-9.11 112.05-2.34 13.05 6.31 25.53 19.36 27.89 20.11 3.5 27.07-14.81 27.89-19.36 7.19-39.84 10.5-80.66 9.86-121.33-.47-29.88 9.2-57.88 28-80.97 8.35-10.28 6.79-25.39-3.49-33.76zm109.47-62.33c-15.41-.41-30.87 1.44-45.78 4.97-12.89 3.06-20.87 15.98-17.83 28.89 3.06 12.89 16 20.83 28.89 17.83 11.05-2.61 22.47-3.77 34-3.69 75.43 1.13 137.73 61.5 138.88 134.58.59 37.88-1.28 76.11-5.58 113.63-1.5 13.17 7.95 25.08 21.11 26.58 16.72 1.95 25.51-11.88 26.58-21.11a929.06 929.06 0 0 0 5.89-119.85c-1.56-98.75-85.07-180.33-186.16-181.83zm252.07 121.45c-2.86-12.92-15.51-21.2-28.61-18.27-12.94 2.86-21.12 15.66-18.26 28.61 4.71 21.41 4.91 37.41 4.7 61.6-.11 13.27 10.55 24.09 23.8 24.2h.2c13.17 0 23.89-10.61 24-23.8.18-22.18.4-44.11-5.83-72.34zm-40.12-90.72C417.29 43.46 337.6 1.29 252.81.02 183.02-.82 118.47 24.91 70.46 72.94 24.09 119.37-.9 181.04.14 246.65l-.12 21.47c-.39 13.25 10.03 24.31 23.28 24.69.23.02.48.02.72.02 12.92 0 23.59-10.3 23.97-23.3l.16-23.64c-.83-52.5 19.16-101.86 56.28-139 38.76-38.8 91.34-59.67 147.68-58.86 69.45 1.03 134.73 35.56 174.62 92.39 7.61 10.86 22.56 13.45 33.42 5.86 10.84-7.62 13.46-22.59 5.84-33.43z"></path>
                        Biometric Login
                    </button>
                </div>

                <div class="mt-6">
                    <div class="relative">
                        <div class="absolute inset-0 flex items-center">
                            <div class="w-full border-t border-secondary-300"></div>
                        </div>
                        <div class="relative flex justify-center text-sm">
                            <span class="px-2 bg-white text-secondary-500">Or sign in with</span>
                        </div>
                    </div>
                    <div class="mt-4 grid grid-cols-2 gap-3">
                        <button
                            onclick="handleSocialLogin('google')"
                            class="w-full inline-flex justify-center py-2 px-4 border border-secondary-300 rounded-md shadow-sm bg-white text-sm font-medium text-secondary-500 hover:bg-gray-50 transition-colors"
                        >
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 488 512" class="h-5 w-5 text-red-500" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h240z"></path>
                            </svg>
                            <span class="ml-2">Google</span>
                        </button>
                        <button
                            onclick="handleSocialLogin('facebook')"
                            class="w-full inline-flex justify-center py-2 px-4 border border-secondary-300 rounded-md shadow-sm bg-white text-sm font-medium text-secondary-500 hover:bg-gray-50 transition-colors"
                        >
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="h-5 w-5 text-blue-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"></path>
                            </svg>
                            <span class="ml-2">Facebook</span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="text-center">
                <p class="text-secondary-600">
                    Don't have an account?
                    <a href="../become-associate.php" class="font-medium text-primary-600 hover:text-primary-500">
                        Sign up for free
                    </a>
                </p>
            </div>

            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div class="flex items-start">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="h-5 w-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3z"></path>
                    </svg>
                    <div>
                        <h3 class="text-sm font-medium text-blue-800 mb-1">Secure Login</h3>
                        <p class="text-sm text-blue-700">
                            Your login is protected with 256-bit SSL encryption. We never store your passwords in plain text.
                        </p>
                    </div>
                </div>
            </div>

            <div class="text-center space-y-2">
                <a href="../contact.php" class="text-sm text-secondary-600 hover:text-secondary-800 block">
                    Need help logging in?
                </a>
                <a href="../resources/faq.php" class="text-sm text-secondary-600 hover:text-secondary-800 block">
                    View FAQ
                </a>
            </div>
        </div>
    </div>
    
    <script>
        let currentLoginMethod = 'email';
        let biometricSupported = false;

        // Check biometric support
        if (window.PublicKeyCredential) {
            biometricSupported = true;
        } else {
            document.getElementById('biometric-section').style.display = 'none';
        }

        function setLoginMethod(method) {
            currentLoginMethod = method;
            
            // Hide all forms
            document.getElementById('email-form').classList.add('hidden');
            document.getElementById('phone-form').classList.add('hidden');
            
            // Remove active class from all tabs
            document.getElementById('email-tab').classList.remove('bg-white', 'text-primary-600', 'shadow-sm');
            document.getElementById('phone-tab').classList.remove('bg-white', 'text-primary-600', 'shadow-sm');
            document.getElementById('email-tab').classList.add('text-secondary-600', 'hover:text-secondary-800');
            document.getElementById('phone-tab').classList.add('text-secondary-600', 'hover:text-secondary-800');
            
            // Show selected form and activate tab
            if (method === 'email') {
                document.getElementById('email-form').classList.remove('hidden');
                document.getElementById('email-tab').classList.add('bg-white', 'text-primary-600', 'shadow-sm');
                document.getElementById('email-tab').classList.remove('text-secondary-600', 'hover:text-secondary-800');
                document.getElementById('biometric-section').style.display = biometricSupported ? 'block' : 'none';
            } else {
                document.getElementById('phone-form').classList.remove('hidden');
                document.getElementById('phone-tab').classList.add('bg-white', 'text-primary-600', 'shadow-sm');
                document.getElementById('phone-tab').classList.remove('text-secondary-600', 'hover:text-secondary-800');
                document.getElementById('biometric-section').style.display = 'none';
            }
        }

        function togglePassword() {
            const passwordField = document.getElementById('password');
            const passwordIcon = document.getElementById('password-icon');
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.innerHTML = '<path d="M320 400c-75.85 0-137.25-58.71-142.9-133.11L72.2 185.82c-13.79 17.3-26.48 35.59-36.72 55.59a32.35 32.35 0 0 0 0 29.19C89.71 376.41 197.07 448 320 448c26.91 0 52.87-4 77.89-10.46L346 397.39a144.13 144.13 0 0 1-26 2.61zm313.82 58.1l-110.55-85.44a331.25 331.25 0 0 0 81.25-102.07 32.35 32.35 0 0 0 0-29.19C550.29 135.59 442.93 64 320 64a308.15 308.15 0 0 0-147.32 37.7L45.46 3.37A16 16 0 0 0 23 6.18L3.37 31.45A16 16 0 0 0 6.18 53.9l588.36 454.73a16 16 0 0 0 22.46-2.81l19.64-25.27a16 16 0 0 0-2.82-22.45zm-183.72-142l-39.3-30.38A94.75 94.75 0 0 0 416 256a94.76 94.76 0 0 0-121.31-92.21A47.65 47.65 0 0 1 304 192a46.64 46.64 0 0 1-1.54 10l-73.61-56.89A142.31 142.31 0 0 1 320 112a143.92 143.92 0 0 1 144 144c0 21.63-5.29 41.79-13.9 60.11z"></path>';
            } else {
                passwordField.type = 'password';
                passwordIcon.innerHTML = '<path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z"></path>';
            }
        }

        async function handleBiometricLogin() {
            try {
                const credential = await navigator.credentials.create({
                    publicKey: {
                        challenge: new Uint8Array(32),
                        rp: { name: "KMFSL" },
                        user: {
                            id: new Uint8Array(16),
                            name: document.getElementById('email').value || 'user@kmfsl.com',
                            displayName: "KMFSL User"
                        },
                        pubKeyCredParams: [{ alg: -7, type: "public-key" }],
                        authenticatorSelection: {
                            authenticatorAttachment: "platform",
                            userVerification: "required"
                        }
                    }
                });
                
                if (credential) {
                    window.location.href = 'dashboard.php';
                }
            } catch (err) {
                alert('Biometric authentication failed: ' + err.message);
            }
        }

        function handleSocialLogin(provider) {
            alert('Social login with ' + provider + ' - Feature coming soon!');
        }

        // Initialize with correct method
        <?php if ($login_method === 'phone' || $otp_sent): ?>
            setLoginMethod('phone');
        <?php else: ?>
            setLoginMethod('email');
        <?php endif; ?>
    </script>
</body>
</html>
}
