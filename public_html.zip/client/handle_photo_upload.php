<?php
// handle_photo_upload.php
// Client or admin can POST a profile photo to this endpoint.
// Returns JSON: { success:true, file_path: "...", file_url: "..." } or { success:false, error: "..." }

header('Content-Type: application/json; charset=utf-8');
session_start();

// Adjust this path if your database.php is elsewhere
require_once __DIR__ . '/../config/database.php';

// --- Configuration ---
$MAX_BYTES = 5 * 1024 * 1024; // 5 MB
$ALLOWED_EXT = ['jpg','jpeg','png','webp'];
$UPLOAD_SUBDIR = 'uploads/profile_photos/'; // relative to document root

try {
    // Determine user id: prefer session, fallback to POST (hidden input)
    $sessionUserId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    $postedUserId  = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
    $user_id = $sessionUserId ?: $postedUserId;

    if ($user_id <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing parameters: user_id (login required)']);
        exit;
    }

    if (!isset($_FILES['profile_photo'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing parameters: profile_photo']);
        exit;
    }

    $file = $_FILES['profile_photo'];

    if (!is_uploaded_file($file['tmp_name'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'No file uploaded or invalid upload']);
        exit;
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'File upload error (' . $file['error'] . ')']);
        exit;
    }

    if ($file['size'] > $MAX_BYTES) {
        http_response_code(413);
        echo json_encode(['success' => false, 'error' => 'File too large. Max ' . ($MAX_BYTES/1024/1024) . 'MB']);
        exit;
    }

    // Validate image using getimagesize (safer than trusting extension)
    $imgInfo = @getimagesize($file['tmp_name']);
    if ($imgInfo === false) {
        http_response_code(415);
        echo json_encode(['success' => false, 'error' => 'Uploaded file is not a valid image']);
        exit;
    }

    // Determine extension and validate
    $origName = $file['name'];
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    if (!in_array($ext, $ALLOWED_EXT, true)) {
        http_response_code(415);
        echo json_encode(['success' => false, 'error' => 'Invalid file type. Allowed: ' . implode(', ', $ALLOWED_EXT)]);
        exit;
    }

    // Prepare upload directory (absolute on server)
    $uploadDir = __DIR__ . '/../' . trim($UPLOAD_SUBDIR, '/ ') . '/';
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Failed to create upload directory']);
            exit;
        }
    }

    // Create a safe, unique filename
    $safeRandom = bin2hex(random_bytes(8));
    $filename = 'user_' . $user_id . '_' . $safeRandom . '.' . $ext;
    $destination = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file']);
        exit;
    }

    // Optionally, you may add image resizing/compression here.

    // Save relative path in DB (no leading slash)
    $relativePath = rtrim($UPLOAD_SUBDIR, '/ ') . '/' . $filename;

    // Update users table - make sure $pdo is defined in your database.php
    $stmt = $pdo->prepare("UPDATE users SET profile_photo_path = ? WHERE id = ?");
    $stmt->execute([$relativePath, $user_id]);

    // Build absolute URL to return to client (for immediate preview)
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    // script path base (handles if site is in subfolder)
    $scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    $base = ($scriptDir === '/' || $scriptDir === '\\') ? '' : $scriptDir;
    $file_url = $protocol . $host . $base . '/' . ltrim($relativePath, '/');

    // Normalize possible double slashes (excluding the protocol part)
    $file_url = preg_replace('#([^:])//+#', '$1/', $file_url);

    echo json_encode(['success' => true, 'file_path' => $relativePath, 'file_url' => $file_url]);
    exit;

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
    exit;
}