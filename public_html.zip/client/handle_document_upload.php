<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $user_id = $_SESSION['user_id'];
    $document = $_FILES['document'];

    // --- BADLAV 1: Form se document ka naam lein ---
    $document_name = trim($_POST['document_name'] ?? '');
    // Agar user naam na de, to original file ka naam istemal karein
    if (empty($document_name)) {
        $document_name = basename($document['name']);
    }

    $uniqueFileName = time() . '_' . basename($document['name']);
    $fileTmpName = $document['tmp_name'];
    // File path ko 'uploads/documents/' folder mein save karein
    $fileDestination = 'uploads/documents/' . $uniqueFileName;
    $fullPath = '../' . $fileDestination;


    // Basic validation
    if ($document['size'] > 10000000) { // 10MB limit
        header('Location: dashboard.php?error=doc_too_large');
        exit();
    }

    if (move_uploaded_file($fileTmpName, $fullPath)) {
        // --- BADLAV 2: 'file_name' ko sahi column 'document_name' se badlein ---
        $stmt = $pdo->prepare("INSERT INTO documents (client_id, document_name, file_path) VALUES (?, ?, ?)");
        
        // --- BADLAV 3: Sahi variables ko query mein bhejein ---
        if ($stmt->execute([$user_id, $document_name, $fileDestination])) {
            header('Location: dashboard.php?doc_upload=success');
        } else {
            header('Location: dashboard.php?error=db_error');
        }
    } else {
        header('Location: dashboard.php?error=doc_upload_failed');
    }
} else {
    // Agar form sahi se submit na ho to error bhejein
    header('Location: dashboard.php?error=invalid_request');
}
?>