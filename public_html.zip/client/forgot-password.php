<?php
session_start();
require_once __DIR__ . '/../php-backend/utils/email.php';
require_once '../config/database.php'; // path adjust karein agar zaroorat ho
$error = '';
$success = '';
// simple CSRF token
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
        if (!$email) {
            $error = 'Please enter a valid email address.';
        } else {
            // Check if user exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Always show success to avoid leaking whether email exists
            if ($user) {
                // Create token
                $token = bin2hex(random_bytes(24));
                $expires_at = date('Y-m-d H:i:s', time() + 3600); // 1 hour

                // Save token (delete previous tokens for this email)
                $del = $pdo->prepare("DELETE FROM password_resets WHERE email = ?");
                $del->execute([$email]);

                $ins = $pdo->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
                $ins->execute([$email, $token, $expires_at]);

                // Prepare reset link (adjust domain/path if needed)
                $resetLink = "https://kmfsl.in/client/reset-password.php?token={$token}";

                // --- START: NEW EMAIL SENDING CODE ---

// Prepare HTML body for the email
$htmlBody = "
Hello,<br><br>
We received a request to reset your KMFSL account password. Click the link below to set a new password (valid for 1 hour):<br><br>
<a href='{$resetLink}' style='background-color:#667eea;color:white;padding:12px 20px;text-decoration:none;border-radius:5px;display:inline-block;'>Reset Your Password</a><br><br>
If you did not request this, please ignore this email.<br><br>
Regards,<br>
The KMFSL Team
";

// Use the EmailService to send the email
$emailService = new EmailService();
$emailService->send($email, 'KMFSL Password Reset Request', $htmlBody, true);

// --- END: NEW EMAIL SENDING CODE ---
                // even if mail fails, we won't show error to user for security reasons
            }

            // Generic success message
            $success = 'If an account with that email exists, a password reset link has been sent. Please check your email (and spam folder).';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Forgot Password — KMFSL</title>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <?php include '../includes/styles.php'; /* loads Tailwind / site CSS like your login page */ ?>
</head>
<body class="min-h-screen bg-gradient-to-br from-primary-50 via-white to-accent-50">
    <div class="min-h-screen flex items-center justify-center py-12 px-4">
        <div class="max-w-2xl w-full">
            <div class="flex items-center justify-center mb-8">
                <a href="../index.php" class="inline-flex items-center">
                    <img src="../kmfsl-logo.svg" alt="KMFSL" class="h-16 w-auto" />
                </a>
            </div>

            <div class="bg-white shadow-lg rounded-xl overflow-hidden">
                <div class="grid grid-cols-1 md:grid-cols-2">
                    <!-- left: Info -->
                    <div class="p-8 bg-gradient-to-b from-primary-600 to-primary-500 text-white">
                        <h3 class="text-2xl font-semibold mb-2">Reset your password</h3>
                        <p class="text-primary-100 mb-6">Enter the email associated with your account and we'll send a secure link to reset your password. This link will expire in 1 hour.</p>
                        <ul class="text-sm space-y-2">
                            <li class="flex items-start"><svg class="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 0 0-1.414 0L8 12.586 4.707 9.293a1 1 0 1 0-1.414 1.414l4 4a1 1 0 0 0 1.414 0l8-8a1 1 0 0 0 0-1.414z"/></svg>Secure link (1 hour)</li>
                            <li class="flex items-start"><svg class="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M2 5a2 2 0 0 1 2-2h8l4 4v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5z"/></svg>We never share your email</li>
                            <li class="flex items-start"><svg class="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a6 6 0 0 0-6 6v3H3a1 1 0 0 0 0 2h14a1 1 0 0 0 0-2h-1V8a6 6 0 0 0-6-6z"/></svg>Support available if you need help</li>
                        </ul>
                        <p class="mt-6 text-xs text-primary-100">If you don't receive an email within a few minutes, check your spam folder or contact support.</p>
                    </div>

                    <!-- right: Form -->
                    <div class="p-8">
                        <h4 class="text-xl font-semibold text-secondary-800 mb-4">Forgot Password</h4>

                        <?php if ($error): ?>
                            <div class="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded"><?php echo $success; ?></div>
                        <?php endif; ?>

                        <form method="POST" action="" class="space-y-4">
                            <input type="hidden" name="csrf" value="<?php echo htmlspecialchars($_SESSION['csrf']); ?>">
                            <label class="block text-sm font-medium text-secondary-700">Email address</label>
                            <input
                                name="email"
                                type="email"
                                required
                                placeholder="you@example.com"
                                value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                class="w-full border border-secondary-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                            />
                            <div class="flex items-center justify-between">
                                <a href="login.php" class="text-sm text-secondary-600 hover:text-primary-600">Back to login</a>
                                <button type="submit" class="inline-flex items-center px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-md shadow">
                                    Send reset link
                                </button>
                            </div>
                        </form>

                        <div class="mt-6 text-xs text-secondary-500">
                            Need help? <a href="../contact.php" class="text-primary-600 hover:underline">Contact support</a>
                        </div>
                    </div>
                </div>
            </div>

            <p class="mt-6 text-center text-sm text-secondary-500">KMFSL • Secure client portal</p>
        </div>
    </div>
</body>
</html>