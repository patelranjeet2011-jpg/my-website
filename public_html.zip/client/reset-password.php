<?php
session_start();
require_once '../config/database.php'; // path adjust karein agar zaroorat ho

$error = '';
$success = '';
$token = $_GET['token'] ?? '';
$showForm = true; // Variable to control form visibility

// If no token, stop immediately
if (!$token) {
    // We will show a generic error on the page instead of dying
    $error = 'Invalid or missing token in the URL. Please use the link from your email.';
    $showForm = false;
} else {
    // Verify token if it exists
    $stmt = $pdo->prepare("SELECT email, expires_at FROM password_resets WHERE token = ?");
    $stmt->execute([$token]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        $error = 'This link is invalid or has already been used. Please request a new password reset.';
        $showForm = false;
    } elseif (strtotime($row['expires_at']) < time()) {
        // Token expired, delete it for security
        $del = $pdo->prepare("DELETE FROM password_resets WHERE token = ?");
        $del->execute([$token]);
        $error = 'This link has expired. Please request a new password reset.';
        $showForm = false;
    }
}


// Handle form submission
if ($showForm && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = trim($_POST['password'] ?? '');
    $password_confirm = trim($_POST['password_confirm'] ?? '');

    if (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $password_confirm) {
        $error = 'The passwords do not match. Please try again.';
    } else {
        // All good, update user's password
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
        $update->execute([$hash, $row['email']]);

        // Delete the used token for security
        $del = $pdo->prepare("DELETE FROM password_resets WHERE token = ?");
        $del->execute([$token]);

        $success = 'Your password has been reset successfully! You can now log in with your new password.';
        $showForm = false; // Hide form on success
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Reset Password — KMFSL</title>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <?php include '../includes/styles.php'; /* This loads your site's CSS */ ?>
</head>
<body class="min-h-screen bg-gradient-to-br from-primary-50 via-white to-accent-50">
    <div class="min-h-screen flex items-center justify-center py-12 px-4">
        <div class="max-w-2xl w-full">
            <div class="flex items-center justify-center mb-8">
                <a href="../index.php" class="inline-flex items-center">
                    <img src="../kmfsl-logo.svg" alt="KMFSL" class="h-16 w-auto" />
                </a>
            </div>

            <div class="bg-white shadow-lg rounded-xl overflow-hidden">
                <div class="grid grid-cols-1 md:grid-cols-2">
                    <div class="p-8 bg-gradient-to-b from-primary-600 to-primary-500 text-white">
                        <h3 class="text-2xl font-semibold mb-2">Set your new password</h3>
                        <p class="text-primary-100 mb-6">Create a new, strong password for your account. Make sure it's something you don't use on other websites.</p>
                        <ul class="text-sm space-y-2">
                            <li class="flex items-start"><svg class="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 0 0-1.414 0L8 12.586 4.707 9.293a1 1 0 1 0-1.414 1.414l4 4a1 1 0 0 0 1.414 0l8-8a1 1 0 0 0 0-1.414z"/></svg>Strong & Secure</li>
                            <li class="flex items-start"><svg class="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M2 5a2 2 0 0 1 2-2h8l4 4v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5z"/></svg>Private & Confidential</li>
                            <li class="flex items-start"><svg class="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a6 6 0 0 0-6 6v3H3a1 1 0 0 0 0 2h14a1 1 0 0 0 0-2h-1V8a6 6 0 0 0-6-6z"/></svg>Immediate Access</li>
                        </ul>
                         <p class="mt-6 text-xs text-primary-100">Once your password is changed, you will be able to log in immediately with the new credentials.</p>
                    </div>

                    <div class="p-8">
                        <h4 class="text-xl font-semibold text-secondary-800 mb-4">Reset Your Password</h4>

                        <?php if ($error): ?>
                            <div class="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded">
                                <?php echo $success; ?>
                                <div class="mt-4">
                                     <a href="login.php" class="inline-flex items-center px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-md shadow">
                                        Proceed to Login
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($showForm): ?>
                        <form method="POST" action="" class="space-y-4">
                            <div>
                                <label for="password" class="block text-sm font-medium text-secondary-700">New Password</label>
                                <input
                                    id="password"
                                    name="password"
                                    type="password"
                                    required
                                    placeholder="Enter at least 6 characters"
                                    class="mt-1 w-full border border-secondary-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                                />
                            </div>
                            <div>
                                <label for="password_confirm" class="block text-sm font-medium text-secondary-700">Confirm New Password</label>
                                <input
                                    id="password_confirm"
                                    name="password_confirm"
                                    type="password"
                                    required
                                    placeholder="Enter the same password again"
                                    class="mt-1 w-full border border-secondary-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                                />
                            </div>
                            <div class="flex items-center justify-between">
                                <a href="login.php" class="text-sm text-secondary-600 hover:text-primary-600">Back to login</a>
                                <button type="submit" class="inline-flex items-center px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-md shadow">
                                    Set New Password
                                </button>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <p class="mt-6 text-center text-sm text-secondary-500">KMFSL • Secure client portal</p>
        </div>
    </div>
</body>
</html>