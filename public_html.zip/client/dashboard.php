<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Include database and fetch user data
require_once '../config/database.php';
$user_id = $_SESSION['user_id'];

try {
    // Fetch User Data
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        header('Location: logout.php');
        exit();
    }

    // Fetch Documents (client side)
    $doc_stmt = $pdo->prepare("SELECT * FROM documents WHERE client_id = ? ORDER BY created_at DESC");
    $doc_stmt->execute([$user_id]);
    $documents = $doc_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Work List
    $work_stmt = $pdo->prepare("SELECT * FROM work_list WHERE client_id = ? ORDER BY created_at DESC");
    $work_stmt->execute([$user_id]);
    $work_items = $work_stmt->fetchAll(PDO::FETCH_ASSOC);

    // For each work item fetch updates (so client sees work updates)
    if (!empty($work_items)) {
        $upd_stmt = $pdo->prepare("
            SELECT wu.*, wud.file_path, wud.original_name 
            FROM work_updates wu
            LEFT JOIN work_update_documents wud ON wu.id = wud.work_update_id
            WHERE wu.work_id = ? 
            ORDER BY wu.created_at DESC
        ");
        foreach ($work_items as &$wi) {
            $upd_stmt->execute([$wi['id']]);
            $wi['updates'] = $upd_stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        unset($wi);
    }

    // Fetch Messages
    $admin_id = 0;
    $msg_stmt = $pdo->prepare("SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC");
    $msg_stmt->execute([$user_id, $admin_id, $admin_id, $user_id]);
    $messages = $msg_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Helper: safe escape
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Dashboard - KMFSL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
      .message-bubble { display:inline-block; padding:10px 12px; border-radius:10px; max-width:70%; word-wrap:break-word; }
      .prose { max-width: 100%; }
    </style>
</head>
<body class="bg-gray-100 font-sans">
    <header class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <h1 class="text-2xl font-bold text-gray-800">KMFSL Client Portal</h1>
            <div class="flex items-center space-x-4">
                <span class="text-gray-700">Welcome, <?php echo h($user['first_name']); ?></span>
                <a href="logout.php" class="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700">
                    Logout
                </a>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2 space-y-8">
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-2xl font-bold text-gray-800">Personal Information</h2>
                        <button onclick="openModal('profileEditModal')" class="bg-blue-600 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center space-x-2">
                            <i class="fas fa-edit"></i>
                            <span>Edit Profile</span>
                        </button>
                    </div>
                    <div class="flex flex-col md:flex-row items-center gap-6">
                        <div class="flex-shrink-0 text-center">
                            <div id="profilePicContainer">
                                <?php
                                  $photo = !empty($user['profile_photo_path']) ? '../' . $user['profile_photo_path'] : '';
                                ?>
                                <?php if (!empty($photo)): ?>
                                    <img id="profilePic" src="<?php echo h($photo) . '?t=' . time(); ?>" alt="Profile Photo" class="w-24 h-24 rounded-full object-cover mb-2">
                                <?php else: ?>
                                    <div class="w-24 h-24 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-4xl font-bold mb-2">
                                        <?php echo h(strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1))); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <a href="#" onclick="openModal('photoUploadModal')" class="text-sm text-blue-600 hover:underline">Upload Photo</a>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 w-full">
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Full Name</label>
                                <p class="text-lg font-semibold text-gray-800"><?php echo h($user['first_name'] . ' ' . $user['last_name']); ?></p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Date of Birth</label>
                                <p class="text-lg font-semibold text-gray-800"><?php echo h(date('d-m-Y', strtotime($user['date_of_birth']))); ?></p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Email ID</label>
                                <p class="text-lg font-semibold text-gray-800"><?php echo h($user['email']); ?></p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Mobile Number</label>
                                <p class="text-lg font-semibold text-gray-800"><?php echo h($user['phone']); ?></p>
                            </div>
                             <div>
                                <label class="block text-sm font-medium text-gray-500">PAN Number</label>
                                <p class="text-lg font-semibold text-gray-800"><?php echo h($user['pan_number']); ?></p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-500">Join Date</label>
                                <p class="text-lg font-semibold text-gray-800"><?php echo h(date('d-m-Y', strtotime($user['created_at']))); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-md">
                    <div class="flex items-center justify-between mb-4">
                         <h2 class="text-2xl font-bold text-gray-800">Work Status</h2>
                         <div class="flex space-x-2">
                             <button onclick="openWorkListModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700">View Work List</button>
                             <button onclick="openModal('createWorkModal')" class="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700">Create Work List</button>
                         </div>
                    </div>
                    <div class="mt-4">
                        <?php
                        if (empty($work_items)) {
                            echo '<p class="text-gray-500">No work items found.</p>';
                        } else {
                            // Find the most recently updated work item
                            $most_recent_item = null;
                            $latest_update_time = 0;

                            foreach ($work_items as $item) {
                                if (!empty($item['updates'])) {
                                    $current_item_latest_update_time = strtotime($item['updates'][0]['created_at']);
                                    if ($current_item_latest_update_time > $latest_update_time) {
                                        $latest_update_time = $current_item_latest_update_time;
                                        $most_recent_item = $item;
                                    }
                                }
                            }
                            if ($most_recent_item === null) {
                                $most_recent_item = $work_items[0];
                            }

                            $company = h($most_recent_item['company_name'] ?? 'N/A');
                            $service = h($most_recent_item['task'] ?? $most_recent_item['service_type'] ?? 'N/A');
                            $status = h($most_recent_item['status']);
                            $status_color = ($status === 'Completed') ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800';
                        ?>
                        <div class="border rounded-lg p-4">
                            <div class="flex justify-between items-center mb-2">
                                <p class="text-sm text-gray-500">Most Recent Update</p>
                                <span class="text-sm font-semibold px-3 py-1 rounded-full <?php echo $status_color; ?>">
                                    <?php echo $status; ?>
                                </span>
                            </div>
                            <h3 class="text-lg font-bold text-gray-800"><?php echo $company; ?></h3>
                            <p class="text-md text-gray-600"><?php echo $service; ?></p>
                        </div>
                        <?php } ?>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-md">
                     <div class="flex items-center justify-between mb-4">
                         <h2 class="text-2xl font-bold text-gray-800">Documents</h2>
                         <button onclick="openModal('docUploadModal')" class="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700">Upload Document</button>
                    </div>
                     <div class="mt-4">
                        <?php if (empty($documents)): ?>
                            <p class="text-gray-500">A list of your documents will appear here.</p>
                        <?php else: ?>
                            <ul class="space-y-2">
                                <?php foreach ($documents as $doc): ?>
                                    <?php
                                      $doc_name = $doc['document_name'] ?? 'Document';
                                      $doc_path = $doc['file_path'] ?? '';
                                    ?>
                                    <li class="p-2 border rounded-md flex justify-between items-center">
                                        <div class="flex items-center space-x-3">
                                          <i class="fas fa-file-alt text-gray-500"></i>
                                          <span class="flex-grow"><?php echo h($doc_name); ?></span>
                                        </div>
                                        <a href="<?php echo h('../' . ltrim($doc_path, '/')); ?>" download class="text-blue-600 hover:underline">Download</a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-md flex flex-col">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Messages</h2>
                <div id="message-box" class="flex-grow space-y-4 overflow-y-auto border p-4 rounded-lg mb-4 bg-gray-50" style="height: 30rem;">
                    <?php if (empty($messages)): ?>
                        <p class="text-center text-gray-500">No messages yet. Start the conversation!</p>
                    <?php else: ?>
                         <?php foreach ($messages as $message): ?>
                            <?php if ($message['sender_id'] == $user_id): ?>
                                <div class="text-right">
                                    <p class="message-bubble bg-blue-500 text-white"><?php echo nl2br(h($message['message'])); ?></p>
                                    <span class="block text-xs text-gray-500 mt-1">You - <?php echo h(date('Y-m-d h:i A', strtotime($message['created_at']))); ?></span>
                                </div>
                            <?php else: ?>
                                <div class="text-left">
                                    <p class="message-bubble bg-gray-200 text-gray-800"><?php echo nl2br(h($message['message'])); ?></p>
                                    <span class="block text-xs text-gray-500 mt-1">Admin - <?php echo h(date('Y-m-d h:i A', strtotime($message['created_at']))); ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <form id="sendMessageForm">
                    <input type="hidden" name="receiver_id" value="<?php echo h($admin_id); ?>">
                    <textarea id="messageInput" name="message" class="w-full border rounded-lg p-2 focus:ring-2 focus:ring-blue-500" rows="3" placeholder="Type your message..." required></textarea>
                    <button type="submit" class="w-full mt-2 bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700">Send</button>
                    <div id="sendStatus" class="text-sm text-center mt-2"></div>
                </form>
            </div>
        </div>
    </main>
    
    <div id="profileEditModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-xl max-w-lg w-full p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">Request Profile Edit</h2>
            <form action="handle_edit_request.php" method="POST">
                <div class="space-y-4">
                    <div>
                        <label for="reason" class="block text-sm font-medium text-gray-700">Reason for Edit Request *</label>
                        <textarea id="reason" name="reason" rows="4" class="w-full mt-1 border rounded-lg p-2 focus:ring-2 focus:ring-blue-500" placeholder="Please explain which details you want to change and why..." required></textarea>
                    </div>
                </div>
                <div class="flex gap-3 mt-6 justify-end">
                    <button type="button" onclick="closeModal('profileEditModal')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300">Cancel</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Submit Request</button>
                </div>
            </form>
        </div>
    </div>
    <div id="photoUploadModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-xl max-w-lg w-full p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">Upload Profile Photo</h2>
            <form id="photoUploadForm" action="handle_photo_upload.php" method="POST" enctype="multipart/form-data">
                <input type="file" name="profile_photo" class="w-full border p-2 rounded" required>
                <input type="hidden" name="user_id" value="<?php echo h($user_id); ?>">
                <div class="flex gap-3 mt-6 justify-end">
                    <button type="button" onclick="closeModal('photoUploadModal')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300">Cancel</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Upload</button>
                </div>
            </form>
        </div>
    </div>
    <div id="docUploadModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-xl max-w-lg w-full p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">Upload Document</h2>
            <form id="docUploadForm" action="handle_document_upload.php" method="POST" enctype="multipart/form-data">
                <input type="text" name="document_name" placeholder="Document Name (optional)" class="w-full p-2 border rounded text-sm mb-2">
                <input type="file" name="document" class="w-full border p-2 rounded" required>
                <input type="hidden" name="client_id" value="<?php echo h($user_id); ?>">
                <div class="flex gap-3 mt-6 justify-end">
                    <button type="button" onclick="closeModal('docUploadModal')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300">Cancel</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Upload</button>
                </div>
            </form>
        </div>
    </div>
    <div id="createWorkModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-xl max-w-lg w-full p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">Create New Work Item</h2>
            <form action="handle_work_create.php" method="POST">
                <textarea name="task" rows="4" class="w-full mt-1 border rounded-lg p-2 focus:ring-2 focus:ring-blue-500" placeholder="Enter task description..." required></textarea>
                <input type="hidden" name="client_id" value="<?php echo h($user_id); ?>">
                <div class="flex gap-3 mt-6 justify-end">
                    <button type="button" onclick="closeModal('createWorkModal')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300">Cancel</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Add Task</button>
                </div>
            </form>
        </div>
    </div>
    
    <div id="viewWorkListModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full">
            <div class="p-4 border-b flex justify-between items-center">
                <h2 class="text-2xl font-bold text-gray-800">All Work Items</h2>
                <button type="button" onclick="closeModal('viewWorkListModal')" class="text-2xl font-bold text-gray-500 hover:text-gray-800">&times;</button>
            </div>
            <div id="workListContainer" class="p-6 max-h-[70vh] overflow-y-auto"></div>
        </div>
    </div>
    
    <div id="viewWorkDetailsModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-lg shadow-xl max-w-3xl w-full">
             <div class="p-4 border-b flex justify-between items-center">
                <h2 id="workDetailsTitle" class="text-2xl font-bold text-gray-800">Work Details</h2>
                <button type="button" onclick="closeModal('viewWorkDetailsModal')" class="text-2xl font-bold text-gray-500 hover:text-gray-800">&times;</button>
            </div>
            <div id="workUpdatesContainer" class="p-6 max-h-[70vh] overflow-y-auto space-y-4"></div>
        </div>
    </div>

    <script>
        function openModal(modalId) { document.getElementById(modalId).classList.remove('hidden'); }
        function closeModal(modalId) { document.getElementById(modalId).classList.add('hidden'); }
        var messageBox = document.getElementById('message-box');
        if(messageBox) { messageBox.scrollTop = messageBox.scrollHeight; }
        
        document.getElementById('sendMessageForm').addEventListener('submit', async function(e){
            e.preventDefault();
            const form = e.target;
            const status = document.getElementById('sendStatus');
            status.textContent = 'Sending...';
            const data = new FormData(form);
            const messageText = document.getElementById('messageInput').value.trim();
            if (!messageText) { status.textContent = 'Please write a message.'; return; }
            data.set('message', messageText);
            try {
                const res = await fetch('handle_message.php', { method: 'POST', body: data });
                const json = await res.json();
                if (json.success) {
                    const mb = document.getElementById('message-box');
                    const wrapper = document.createElement('div');
                    wrapper.className = 'text-right';
                    const bubble = document.createElement('p');
                    bubble.className = 'message-bubble bg-blue-500 text-white';
                    bubble.innerHTML = json.message.html || messageText;
                    wrapper.appendChild(bubble);
                    const time = document.createElement('span');
                    time.className = 'block text-xs text-gray-500 mt-1';
                    time.textContent = 'You - ' + new Date(json.message.created_at).toLocaleString();
                    wrapper.appendChild(time);
                    mb.appendChild(wrapper);
                    mb.scrollTop = mb.scrollHeight;
                    form.reset();
                    status.textContent = 'Sent';
                    setTimeout(()=> status.textContent = '', 1500);
                } else {
                    status.textContent = json.error || 'Failed to send';
                }
            } catch (err) {
                console.error('Send message error', err);
                status.textContent = 'Network error';
            }
        });

        document.getElementById('photoUploadForm').addEventListener('submit', async function(e) {
            e.preventDefault(); 
            const form = e.target;
            const formData = new FormData(form);
            const submitButton = form.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = 'Uploading...';
            try {
                const response = await fetch('handle_photo_upload.php', { method: 'POST', body: formData });
                const result = await response.json();
                if (result.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (result.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Upload error', error);
                alert('An error occurred during upload. Please try again.');
            } finally {
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
                form.reset();
            }
        });

        const workItemsData = <?php echo json_encode($work_items); ?>;

        function openWorkListModal() {
            const container = document.getElementById('workListContainer');
            container.innerHTML = '';
            if (!workItemsData || workItemsData.length === 0) {
                container.innerHTML = '<p class="text-gray-500">No work items found.</p>';
            } else {
                const table = document.createElement('table');
                table.className = 'w-full text-left border-collapse';
                table.innerHTML = `
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="p-3 border-b text-sm font-semibold text-gray-600 uppercase">COMPANY</th>
                            <th class="p-3 border-b text-sm font-semibold text-gray-600 uppercase">SERVICE</th>
                            <th class="p-3 border-b text-sm font-semibold text-gray-600 uppercase">STATUS</th>
                            <th class="p-3 border-b text-sm font-semibold text-gray-600 uppercase">ACTIONS</th>
                        </tr>
                    </thead>
                `;
                const tbody = document.createElement('tbody');
                workItemsData.forEach(item => {
                    const tr = document.createElement('tr');
                    tr.className = 'hover:bg-gray-50';
                    const company = item.company_name || 'N/A';
                    const service = item.task || item.service_type || 'N/A';
                    tr.innerHTML = `
                        <td class="p-3 border-b text-gray-700">${company}</td>
                        <td class="p-3 border-b text-gray-700">${service}</td>
                        <td class="p-3 border-b">
                            <span class="text-sm font-semibold px-3 py-1 rounded-full ${item.status === 'Completed' ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'}">
                                ${item.status}
                            </span>
                        </td>
                        <td class="p-3 border-b">
                            <button class="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600">View / Update</button>
                        </td>
                    `;
                    tr.querySelector('button').onclick = () => openWorkDetailsModal(item.id);
                    tbody.appendChild(tr);
                });
                table.appendChild(tbody);
                container.appendChild(table);
            }
            openModal('viewWorkListModal');
        }

        function openWorkDetailsModal(workId) {
            const item = workItemsData.find(w => w.id == workId);
            if (!item) { return; }
            const titleEl = document.getElementById('workDetailsTitle');
            const container = document.getElementById('workUpdatesContainer');
            titleEl.textContent = item.task || 'Work Details';
            container.innerHTML = '';

            if (!item.updates || item.updates.length === 0) {
                container.innerHTML = '<p class="text-gray-500">No updates found for this work item.</p>';
            } else {
                const uniqueUpdates = {};
                item.updates.forEach(update => {
                    if (!uniqueUpdates[update.id]) {
                        uniqueUpdates[update.id] = { ...update, documents: [] };
                    }
                    if (update.file_path) {
                        uniqueUpdates[update.id].documents.push({
                            file_path: update.file_path,
                            document_name: update.document_name || 'Download'
                        });
                    }
                });

                const groupedByDate = Object.values(uniqueUpdates).reduce((acc, update) => {
                    const date = new Date(update.created_at).toLocaleDateString('en-IN', {
                        year: 'numeric', month: 'long', day: 'numeric'
                    });
                    if (!acc[date]) { acc[date] = []; }
                    acc[date].push(update);
                    return acc;
                }, {});

                Object.keys(groupedByDate).sort((a, b) => new Date(b.split('-').reverse().join('-')) - new Date(a.split('-').reverse().join('-'))).forEach(date => {
                    const dateHeading = document.createElement('h3');
                    dateHeading.className = 'text-lg font-semibold text-gray-700 mt-4 border-b pb-2';
                    dateHeading.textContent = date;
                    container.appendChild(dateHeading);
                    
                    groupedByDate[date].forEach(update => {
                        const div = document.createElement('div');
                        div.className = 'p-4 border-l-4 border-blue-500 bg-blue-50 rounded-r-lg';
                        let documentsHTML = '';
                        if (update.documents.length > 0) {
                            const docLinks = update.documents.map(doc => {
                                const docUrl = '../' + doc.file_path.replace(/^\/*/, '');
                                return `<a href="${docUrl}" download class="text-blue-600 hover:underline font-semibold"><i class="fas fa-download mr-2"></i>${doc.document_name}</a>`;
                            }).join('<br>');
                            documentsHTML = `<div class="mt-2 space-y-1">${docLinks}</div>`;
                        }
                        div.innerHTML = `
                            <div class="prose max-w-none">${update.update_note}</div>
                            <p class="text-xs text-gray-500 mt-2">Time: ${new Date(update.created_at).toLocaleTimeString('en-IN')}</p>
                            ${documentsHTML}
                        `;
                        container.appendChild(div);
                    });
                });
            }
            closeModal('viewWorkListModal');
            openModal('viewWorkDetailsModal');
        }
    </script>
</body>
</html>