<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
// CSRF Token जेनरेट करें
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../php-backend/vendor/autoload.php';

// If user is already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$success_message = '';
$error_message = '';
$current_step = $_POST['current_step'] ?? 1;

// Initialize form data
$form_data = [
    'firstName' => $_POST['firstName'] ?? '',
    'lastName' => $_POST['lastName'] ?? '',
    'email' => $_POST['email'] ?? '',
    'phone' => $_POST['phone'] ?? '',
    'dateOfBirth' => $_POST['dateOfBirth'] ?? '',
    'gender' => $_POST['gender'] ?? '',
    'address' => $_POST['address'] ?? '',
    'city' => $_POST['city'] ?? '',
    'state' => $_POST['state'] ?? '',
    'pincode' => $_POST['pincode'] ?? '',
    'country' => $_POST['country'] ?? 'India',
    'password' => $_POST['password'] ?? '',
    'confirmPassword' => $_POST['confirmPassword'] ?? '',
    'panNumber' => $_POST['panNumber'] ?? '',
    'communicationPreference' => $_POST['communicationPreference'] ?? 'email',
    'marketingConsent' => isset($_POST['marketingConsent']),
    'termsAccepted' => isset($_POST['termsAccepted']),
    'privacyAccepted' => isset($_POST['privacyAccepted'])
];

$indian_states = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
    'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
    'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
    'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
    'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
    'Delhi', 'Jammu and Kashmir', 'Ladakh', 'Puducherry'
];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // स्टेप 1: सबसे पहले CSRF टोकन वेरिफाई करें
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Invalid CSRF token. Request blocked.');
    }

    // स्टेप 2: अब बाकी का कोड चलाएं
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'send_otp':
                if (!empty($form_data['email']) && filter_var($form_data['email'], FILTER_VALIDATE_EMAIL)) {
                    $_SESSION['otp_email'] = $form_data['email'];
                    $otp = random_int(100000, 999999);
                    $_SESSION['demo_otp'] = (string)$otp;
                    $_SESSION['otp_sent_time'] = time();
                    $_SESSION['otp_sent'] = true;
                    $_SESSION['otp_attempts'] = 0;

                    $mail = new PHPMailer(true);
                    try {
                        $smtpConfig = require __DIR__ . '/../../smtp_config.php';
                        $mail->isSMTP();
                        $mail->Host = $smtpConfig['host'];
                        $mail->SMTPAuth = true;
                        $mail->Username = $smtpConfig['username'];
                        $mail->Password = $smtpConfig['password'];
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                        $mail->Port = $smtpConfig['port'];

                        $mail->setFrom('noreply@kmfsl.in', 'KMFSL');
                        $mail->addAddress($form_data['email']);
                        $mail->isHTML(true);
                        $mail->Subject = 'KMFSL - Email Verification OTP';
                        $mail->Body = "Dear User,<br><br>Your OTP is: <b>$otp</b><br><br>This OTP is valid for 10 minutes.<br><br>Best regards,<br>KMFSL Team";
                        $mail->send();
                        $success_message = 'OTP sent to your email address. Please check your inbox.';
                        $current_step = 2;
                    } catch (Exception $e) {
                        $error_message = "OTP could not be sent. Mailer Error: {$mail->ErrorInfo}";
                    }
                } else {
                    $error_message = 'Please enter a valid email address.';
                }
                break;

            case 'verify_otp':
                $entered_otp = trim($_POST['otp'] ?? '');
                $otp_expiry_duration = 10 * 60; // 10 मिनट सेकंड में

                // पहले चेक करें कि OTP एक्सपायर तो नहीं हो गया
                if (!isset($_SESSION['otp_sent_time']) || (time() - $_SESSION['otp_sent_time']) > $otp_expiry_duration) {
                    $error_message = 'OTP has expired. Please request a new one.';
                    unset($_SESSION['otp_sent'], $_SESSION['demo_otp'], $_SESSION['otp_attempts'], $_SESSION['otp_sent_time']);
                    $current_step = 1;
                } elseif (isset($_SESSION['demo_otp']) && $entered_otp === (string)$_SESSION['demo_otp']) {
                    // अगर OTP सही है
                    $_SESSION['email_verified'] = true;
                    unset($_SESSION['otp_sent'], $_SESSION['demo_otp'], $_SESSION['otp_attempts'], $_SESSION['otp_sent_time']);
                    $success_message = 'Email address verified successfully!';
                    $current_step = 3;
                } else {
                    // अगर OTP गलत है
                    $_SESSION['otp_attempts'] = ($_SESSION['otp_attempts'] ?? 0) + 1;
                    if ($_SESSION['otp_attempts'] >= 3) {
                        $error_message = 'Maximum OTP attempts exceeded. Please request a new OTP.';
                        unset($_SESSION['otp_sent'], $_SESSION['demo_otp'], $_SESSION['otp_attempts'], $_SESSION['otp_sent_time']);
                        $current_step = 1;
                    } else {
                        $error_message = 'Invalid OTP. Attempts remaining: ' . (3 - $_SESSION['otp_attempts']);
                    }
                }
                break;

            case 'resend_otp':
                $otp = random_int(100000, 999999);
                $_SESSION['demo_otp'] = (string)$otp;
                $_SESSION['otp_sent_time'] = time();
                $_SESSION['otp_attempts'] = 0;

                $mail = new PHPMailer(true);
                try {
                    $smtpConfig = require __DIR__ . '/../../smtp_config.php';
                    $mail->isSMTP();
                    $mail->Host = $smtpConfig['host'];
                    $mail->SMTPAuth = true;
                    $mail->Username = $smtpConfig['username'];
                    $mail->Password = $smtpConfig['password'];
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port = $smtpConfig['port'];

                    $mail->setFrom('noreply@kmfsl.in', 'KMFSL');
                    $mail->addAddress($_SESSION['otp_email']);
                    $mail->isHTML(true);
                    $mail->Subject = 'KMFSL - Resent OTP';
                    $mail->Body = "Dear User,<br><br>Your new OTP is: <b>$otp</b><br><br>This OTP is valid for 10 minutes.<br><br>Best regards,<br>KMFSL Team";
                    $mail->send();
                    $success_message = 'OTP resent successfully. Please check your inbox.';
                } catch (Exception $e) {
                    $error_message = "OTP could not be resent. Mailer Error: {$mail->ErrorInfo}";
                }
                break;

            case 'next_step':
                // Validate email verification before proceeding
                if ($current_step == 1 && !isset($_SESSION['email_verified'])) {
                    $error_message = 'Please verify your email address first.';
                } else {
                    $current_step = min((int)$_POST['current_step'] + 1, 5);
                }
                break;
            case 'prev_step':
                $current_step = max((int)$_POST['current_step'] - 1, 1);
                break;
            case 'submit_registration':
                // Final registration
                require_once '../config/database.php';
                
                // Validation
                if (!isset($_SESSION['email_verified'])) {
                    $error_message = 'Email address must be verified before registration.';
                } elseif (empty($form_data['firstName']) || empty($form_data['lastName']) || 
                    empty($form_data['email']) || empty($form_data['phone']) || 
                    empty($form_data['password']) || empty($form_data['panNumber'])) {
                    $error_message = 'All required fields must be filled.';
                } elseif ($form_data['password'] !== $form_data['confirmPassword']) {
                    $error_message = 'Passwords do not match.';
                } elseif (strlen($form_data['password']) < 6) {
                    $error_message = 'Password must be at least 6 characters long.';
                } elseif (!$form_data['termsAccepted'] || !$form_data['privacyAccepted']) {
                    $error_message = 'You must accept the Terms & Conditions and Privacy Policy.';
                } else {
                    try {
                        // Check if email already exists
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                        $stmt->execute([$form_data['email']]);
                        
                        if ($stmt->rowCount() > 0) {
                            $error_message = 'Email already exists. Please use a different email.';
                        } else {
                            // Hash password
                            $hashed_password = password_hash($form_data['password'], PASSWORD_DEFAULT);
                            
                            // Insert new user
                            $stmt = $pdo->prepare("
                                INSERT INTO users (
                                    first_name, last_name, email, phone, date_of_birth, gender,
                                    address, city, state, pincode, country, password, pan_number,
                                    communication_preference, marketing_consent, created_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                            ");
                            
                            $stmt->execute([
                                $form_data['firstName'], $form_data['lastName'], $form_data['email'],
                                $form_data['phone'], $form_data['dateOfBirth'], $form_data['gender'],
                                $form_data['address'], $form_data['city'], $form_data['state'],
                                $form_data['pincode'], $form_data['country'], $hashed_password,
                                $form_data['panNumber'], $form_data['communicationPreference'],
                                $form_data['marketingConsent'] ? 1 : 0
                            ]);
                            
                            // Clear verification session
                            unset($_SESSION['email_verified'], $_SESSION['otp_email']);
                            
                            $success_message = 'Account created successfully! You can now login.';
                            $current_step = 6; // Success step
                        }
                    } catch (PDOException $e) {
    $error_message = 'Database Error: ' . $e->getMessage();
}
                }
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - KMFSL Client Portal</title>
    <meta name="description" content="Create your KMFSL client account to access our financial recovery services and track your claims.">
    
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gradient-to-br from-primary-50 via-white to-accent-50">
    <?php include '../includes/header.php'; ?>
    
    <div class="min-h-screen py-12 px-4 sm:px-6 lg:px-8" style="margin-top: 80px;">
        <div class="max-w-2xl mx-auto">
            <div class="text-center mb-8">
                 <div class="flex justify-center mb-4">
                     <a href="../index.php" class="hover:opacity-80 transition-opacity">
                         <img src="../kmfsl logo svg.svg" alt="KMFSL - Kaimur Financial Services" class="h-20 w-auto">
                     </a>
                 </div>
                 <div class="mb-6">
                     <a href="../index.php" class="inline-flex items-center text-sm text-secondary-600 hover:text-primary-600 transition-colors">
                         <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg">
                             <path d="M280.37 148.26L96 300.11V464a16 16 0 0 0 16 16l112.06-.29a16 16 0 0 0 15.92-16V368a16 16 0 0 1 16-16h64a16 16 0 0 1 16 16v95.64a16 16 0 0 0 16 16.05L464 480a16 16 0 0 0 16-16V300L295.67 148.26a12.19 12.19 0 0 0-15.3 0zM571.6 251.47L488 182.56V44.05a12 12 0 0 0-12-12h-56a12 12 0 0 0-12 12v72.61L318.47 43a48 48 0 0 0-61 0L4.34 251.47a12 12 0 0 0-1.6 16.9l25.5 31A12 12 0 0 0 45.15 301l235.22-193.74a12.19 12.19 0 0 1 15.3 0L530.9 301a12 12 0 0 0 16.9-1.6l25.5-31a12 12 0 0 0-1.7-16.93z"></path>
                         </svg>
                         Back to Home
                     </a>
                 </div>
                 <h2 class="text-3xl font-bold text-secondary-800 mb-2">
                     Create Your <span class="text-gradient">KMFSL Account</span>
                 </h2>
                 <p class="text-secondary-600">
                     Join thousands of clients who trust KMFSL for their financial asset recovery
                 </p>
             </div>

            <div class="mb-8">
                <div class="flex items-center justify-between">
                    <?php 
                    $steps = [
                        ['number' => 1, 'title' => 'Personal Info', 'description' => 'Basic information'],
                        ['number' => 2, 'title' => 'Email Verify', 'description' => 'OTP verification'],
                        ['number' => 3, 'title' => 'Address', 'description' => 'Contact details'],
                        ['number' => 4, 'title' => 'Account Setup', 'description' => 'Security & preferences'],
                        ['number' => 5, 'title' => 'Complete', 'description' => 'Finish registration']
                    ];
                    
                    foreach ($steps as $index => $step): 
                    ?>
                        <div class="flex items-center">
                            <div class="flex items-center justify-center w-10 h-10 rounded-full border-2 <?php echo $current_step >= $step['number'] ? 'bg-primary-600 border-primary-600 text-white' : 'border-secondary-300 text-secondary-500'; ?>">
                                <?php if ($current_step > $step['number']): ?>
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-5 h-5" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                    </svg>
                                <?php else: ?>
                                    <?php echo $step['number']; ?>
                                <?php endif; ?>
                            </div>
                            <?php if ($index < count($steps) - 1): ?>
                                <div class="w-full h-1 mx-4 <?php echo $current_step > $step['number'] ? 'bg-primary-600' : 'bg-secondary-200'; ?>"></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="flex justify-between mt-2">
                    <?php foreach ($steps as $step): ?>
                        <div class="text-center">
                            <p class="text-sm font-medium text-secondary-800"><?php echo $step['title']; ?></p>
                            <p class="text-xs text-secondary-500"><?php echo $step['description']; ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-8">
                <?php if ($current_step == 6 && $success_message): ?>
                    <div class="text-center">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-8 h-8 text-green-600" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                        </div>
                        <h3 class="text-2xl font-bold text-secondary-800 mb-2">Account Created Successfully!</h3>
                        <p class="text-secondary-600 mb-6"><?php echo htmlspecialchars($success_message); ?></p>
                        <a href="login.php" class="btn-primary">Continue to Login</a>
                    </div>
                <?php else: ?>
                    <?php if ($error_message): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <input type="hidden" name="current_step" value="<?php echo $current_step; ?>">
                        
                        <?php foreach ($form_data as $key => $value): ?>
                            <?php if (is_bool($value)): ?>
                                <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value ? '1' : '0'; ?>">
                            <?php else: ?>
                                <input type="hidden" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($value); ?>">
                            <?php endif; ?>
                        <?php endforeach; ?>
                        
                        <?php if ($current_step == 1): ?>
                            <div class="space-y-6">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-secondary-700 mb-2">First Name *</label>
                                        <input name="firstName" type="text" required value="<?php echo htmlspecialchars($form_data['firstName']); ?>" class="input-field" placeholder="Enter first name">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-secondary-700 mb-2">Last Name *</label>
                                        <input name="lastName" type="text" required value="<?php echo htmlspecialchars($form_data['lastName']); ?>" class="input-field" placeholder="Enter last name">
                                    </div>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                                    <div class="relative">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                        </svg>
                                        <input name="email" type="email" required value="<?php echo htmlspecialchars($form_data['email']); ?>" class="input-field pl-10" placeholder="Enter email address">
                                    </div>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                                    <div class="relative">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                        </svg>
                                        <input name="phone" type="tel" required value="<?php echo htmlspecialchars($form_data['phone']); ?>" class="input-field pl-10" placeholder="Enter phone number">
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-secondary-700 mb-2">Date of Birth *</label>
                                        <input name="dateOfBirth" type="date" required value="<?php echo htmlspecialchars($form_data['dateOfBirth']); ?>" class="input-field">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-secondary-700 mb-2">Gender *</label>
                                        <select name="gender" required class="input-field">
                                            <option value="">Select gender</option>
                                            <option value="male" <?php echo $form_data['gender'] == 'male' ? 'selected' : ''; ?>>Male</option>
                                            <option value="female" <?php echo $form_data['gender'] == 'female' ? 'selected' : ''; ?>>Female</option>
                                            <option value="other" <?php echo $form_data['gender'] == 'other' ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <?php if (!isset($_SESSION['email_verified'])): ?>
                                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                        <div class="flex items-center mb-3">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-5 h-5 text-blue-600 mr-2" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                            </svg>
                                            <h4 class="text-sm font-medium text-blue-800">Email Verification Required</h4>
                                        </div>
                                        <p class="text-sm text-blue-700 mb-3">We need to verify your email address before proceeding. Click the button below to receive an OTP.</p>
                                        <button type="submit" name="action" value="send_otp" class="btn-primary">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                                            </svg>
                                            Send OTP to Email
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                                        <div class="flex items-center">
                                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-5 h-5 text-green-600 mr-2" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                            </svg>
                                            <span class="text-sm font-medium text-green-800">Email address verified successfully!</span>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php elseif ($current_step == 2): ?>
                            <div class="space-y-6">
                                <div class="text-center">
                                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-8 h-8 text-blue-600" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                        </svg>
                                    </div>
                                    <h3 class="text-xl font-bold text-secondary-800 mb-2">Verify Your Email Address</h3>
                                    <p class="text-secondary-600 mb-6">We've sent a 6-digit OTP to <strong><?php echo htmlspecialchars($_SESSION['otp_email'] ?? $form_data['email']); ?></strong></p>
                                </div>
                                
                                <?php if ($success_message): ?>
                                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                                        <?php echo htmlspecialchars($success_message); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div>
                                    <label class="block text-sm font-medium text-secondary-700 mb-2">Enter OTP *</label>
                                    <div class="relative">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M400 224h-24v-72C376 68.2 307.8 0 224 0S72 68.2 72 152v72H48c-26.5 0-48 21.5-48 48v192c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V272c0-26.5-21.5-48-48-48zm-104 0H152v-72c0-39.7 32.3-72 72-72s72 32.3 72 72v72z"></path>
                                        </svg>
                                        <input name="otp" type="text" required class="input-field pl-10 text-center text-lg tracking-widest" placeholder="Enter 6-digit OTP" maxlength="6" pattern="[0-9]{6}">
                                    </div>
                                    <p class="text-sm text-secondary-500 mt-1">Demo OTP: 123456</p>
                                </div>
                                
                                <div class="flex space-x-4">
                                    <button type="submit" name="action" value="verify_otp" class="btn-primary flex-1">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                        </svg>
                                        Verify OTP
                                    </button>
                                    <button type="submit" name="action" value="resend_otp" class="btn-secondary">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M449.9 39.96l-48.5 48.53C362.5 53.19 311.4 32 256 32C161.5 32 78.59 92.34 49.58 182.2c-5.22 16.15 3.99 33.499 20.61 38.74c16.53 5.259 33.63-4 38.85-20.129C130.9 138.5 189.4 96 256 96c50.5 0 96.26 24.55 124.4 64H336c-8.84 0-16 7.16-16 16v16c0 8.84 7.16 16 16 16h128c8.84 0 16-7.16 16-16V48c0-8.84-7.16-16-16-16h-16c-8.84 0-16 7.16-16 16v-8.04zM0 304v144c0 8.84 7.16 16 16 16h16c8.84 0 16-7.16 16-16v-80h44.4c28.14 39.45 73.9 64 124.4 64c66.6 0 125.1-42.5 146.9-104.8c5.22-16.129-2.28-33.469-18.81-38.729c-16.53-5.239-33.63 4.011-38.85 20.141C284.1 373.5 225.6 416 159 416c-50.5 0-96.26-24.55-124.4-64H80c8.84 0 16-7.16 16-16v-16c0-8.84-7.16-16-16-16H16c-8.84 0-16 7.16-16 16z"></path>
                                        </svg>
                                        Resend OTP
                                    </button>
                                </div>
                                
                                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                                    <div class="flex items-start">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-5 h-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M506.3 417l-213.3-364c-16.33-28-57.54-28-73.98 0l-213.2 364C-10.59 444.9 9.849 480 42.74 480h426.6C502.1 480 522.6 445 506.3 417zM232 168c0-13.25 10.75-24 24-24S280 154.8 280 168v128c0 13.25-10.75 24-23.1 24S232 309.3 232 296V168zM256 416c-17.36 0-31.44-14.08-31.44-31.44c0-17.36 14.07-31.44 31.44-31.44s31.44 14.08 31.44 31.44C287.4 401.9 273.4 416 256 416z"></path>
                                        </svg>
                                        <div>
                                            <h4 class="text-sm font-medium text-yellow-800 mb-1">Important</h4>
                                            <p class="text-sm text-yellow-700">You have <?php echo 3 - ($_SESSION['otp_attempts'] ?? 0); ?> attempts remaining. After 3 failed attempts, you'll need to request a new OTP.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php elseif ($current_step == 3): ?>
                            <div class="space-y-6">
                                <div>
                                    <label class="block text-sm font-medium text-secondary-700 mb-2">Address *</label>
                                    <div class="relative">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="absolute left-3 top-3 text-secondary-400 w-4 h-4" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"></path>
                                        </svg>
                                        <textarea name="address" required class="input-field pl-10 h-20 resize-none" placeholder="Enter complete address"><?php echo htmlspecialchars($form_data['address']); ?></textarea>
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-secondary-700 mb-2">City *</label>
                                        <input name="city" type="text" required value="<?php echo htmlspecialchars($form_data['city']); ?>" class="input-field" placeholder="Enter city">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-secondary-700 mb-2">State *</label>
                                        <select name="state" required class="input-field">
                                            <option value="">Select state</option>
                                            <?php foreach ($indian_states as $state): ?>
                                                <option value="<?php echo $state; ?>" <?php echo $form_data['state'] == $state ? 'selected' : ''; ?>><?php echo $state; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-secondary-700 mb-2">PIN Code *</label>
                                        <input name="pincode" type="text" required value="<?php echo htmlspecialchars($form_data['pincode']); ?>" class="input-field" placeholder="Enter PIN code" maxlength="6">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-secondary-700 mb-2">Country *</label>
                                        <input name="country" type="text" value="<?php echo htmlspecialchars($form_data['country']); ?>" class="input-field" readonly>
                                    </div>
                                </div>
                            </div>
                        <?php elseif ($current_step == 4): ?>
                            <div class="space-y-6">
                                <div>
                                    <label class="block text-sm font-medium text-secondary-700 mb-2">PAN Number *</label>
                                    <div class="relative">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M528 32H48C21.5 32 0 53.5 0 80v16h576V80c0-26.5-21.5-48-48-48zM0 432c0 26.5 21.5 48 48 48h480c26.5 0 48-21.5 48-48V128H0v304zm64-216c0-4.4 3.6-8 8-8h112c4.4 0 8 3.6 8 8v16c0 4.4-3.6 8-8 8H72c-4.4 0-8-3.6-8-8v-16z"></path>
                                        </svg>
                                        <input name="panNumber" type="text" required value="<?php echo htmlspecialchars($form_data['panNumber']); ?>" class="input-field pl-10 uppercase" placeholder="Enter PAN number" maxlength="10">
                                    </div>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-secondary-700 mb-2">Password *</label>
                                    <div class="relative">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M400 224h-24v-72C376 68.2 307.8 0 224 0S72 68.2 72 152v72H48c-26.5 0-48 21.5-48 48v192c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V272c0-26.5-21.5-48-48-48zm-104 0H152v-72c0-39.7 32.3-72 72-72s72 32.3 72 72v72z"></path>
                                        </svg>
                                        <input name="password" type="password" required value="<?php echo htmlspecialchars($form_data['password']); ?>" class="input-field pl-10" placeholder="Create password" minlength="6">
                                    </div>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-secondary-700 mb-2">Confirm Password *</label>
                                    <div class="relative">
                                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M400 224h-24v-72C376 68.2 307.8 0 224 0S72 68.2 72 152v72H48c-26.5 0-48 21.5-48 48v192c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V272c0-26.5-21.5-48-48-48zm-104 0H152v-72c0-39.7 32.3-72 72-72s72 32.3 72 72v72z"></path>
                                        </svg>
                                        <input name="confirmPassword" type="password" required value="<?php echo htmlspecialchars($form_data['confirmPassword']); ?>" class="input-field pl-10" placeholder="Confirm password">
                                    </div>
                                    <?php if (!empty($form_data['password']) && !empty($form_data['confirmPassword']) && $form_data['password'] !== $form_data['confirmPassword']): ?>
                                        <p class="text-red-500 text-sm mt-1">Passwords do not match</p>
                                    <?php endif; ?>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-secondary-700 mb-2">Communication Preference</label>
                                    <div class="space-y-2">
                                        <label class="flex items-center">
                                            <input type="radio" name="communicationPreference" value="email" <?php echo $form_data['communicationPreference'] == 'email' ? 'checked' : ''; ?> class="mr-2"> Email
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="communicationPreference" value="sms" <?php echo $form_data['communicationPreference'] == 'sms' ? 'checked' : ''; ?> class="mr-2"> SMS
                                        </label>
                                        <label class="flex items-center">
                                            <input type="radio" name="communicationPreference" value="both" <?php echo $form_data['communicationPreference'] == 'both' ? 'checked' : ''; ?> class="mr-2"> Both Email & SMS
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="space-y-3">
                                    <label class="flex items-start">
                                        <input type="checkbox" name="termsAccepted" <?php echo $form_data['termsAccepted'] ? 'checked' : ''; ?> class="mt-1 mr-3" required>
                                        <span class="text-sm text-secondary-700">
                                            I agree to the <a href="../terms-conditions.php" class="text-primary-600 hover:text-primary-500" target="_blank">Terms & Conditions</a> *
                                        </span>
                                    </label>
                                    <label class="flex items-start">
                                        <input type="checkbox" name="privacyAccepted" <?php echo $form_data['privacyAccepted'] ? 'checked' : ''; ?> class="mt-1 mr-3" required>
                                        <span class="text-sm text-secondary-700">
                                            I agree to the <a href="../privacy-policy.php" class="text-primary-600 hover:text-primary-500" target="_blank">Privacy Policy</a> *
                                        </span>
                                    </label>
                                    <label class="flex items-start">
                                        <input type="checkbox" name="marketingConsent" <?php echo $form_data['marketingConsent'] ? 'checked' : ''; ?> class="mt-1 mr-3">
                                        <span class="text-sm text-secondary-700">
                                            I agree to receive marketing communications and updates about KMFSL services
                                        </span>
                                    </label>
                                </div>
                            </div>
                        <?php elseif ($current_step == 5): ?>
                            <div class="space-y-6">
                                <div class="text-center mb-6">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-16 h-16 text-primary-600 mx-auto mb-4" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                                    </svg>
                                    <h3 class="text-lg font-semibold text-secondary-800 mb-2">Review Your Information</h3>
                                    <p class="text-secondary-600">Please review your details before creating your account.</p>
                                </div>
                                
                                <div class="bg-gray-50 rounded-lg p-4 space-y-3">
                                    <div class="grid grid-cols-2 gap-4">
                                        <div><strong>Name:</strong> <?php echo htmlspecialchars($form_data['firstName'] . ' ' . $form_data['lastName']); ?></div>
                                        <div><strong>Email:</strong> <?php echo htmlspecialchars($form_data['email']); ?></div>
                                        <div><strong>Phone:</strong> <?php echo htmlspecialchars($form_data['phone']); ?></div>
                                        <div><strong>Date of Birth:</strong> <?php echo htmlspecialchars($form_data['dateOfBirth']); ?></div>
                                        <div><strong>Gender:</strong> <?php echo htmlspecialchars(ucfirst($form_data['gender'])); ?></div>
                                        <div><strong>PAN:</strong> <?php echo htmlspecialchars($form_data['panNumber']); ?></div>
                                    </div>
                                    <div><strong>Address:</strong> <?php echo htmlspecialchars($form_data['address'] . ', ' . $form_data['city'] . ', ' . $form_data['state'] . ' - ' . $form_data['pincode']); ?></div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="flex justify-between mt-8">
                            <?php if ($current_step > 1): ?>
                                <button type="submit" name="action" value="prev_step" class="btn-secondary">Previous</button>
                            <?php endif; ?>
                            
                            <?php if ($current_step == 2): ?>
                                <?php elseif ($current_step < 5): ?>
                                <button type="submit" name="action" value="next_step" class="btn-primary ml-auto">Next</button>
                            <?php else: ?>
                                <button type="submit" name="action" value="submit_registration" class="btn-primary ml-auto flex items-center">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                    </svg>
                                    Create Account
                                </button>
                            <?php endif; ?>
                        </div>
                    </form>
                    
                    <?php if ($current_step == 1): ?>
                        <div class="mt-8">
                            <div class="relative">
                                <div class="absolute inset-0 flex items-center">
                                    <div class="w-full border-t border-secondary-300"></div>
                                </div>
                                <div class="relative flex justify-center text-sm">
                                    <span class="px-2 bg-white text-secondary-500">Or sign up with</span>
                                </div>
                            </div>
                            <div class="mt-4 grid grid-cols-2 gap-3">
                                <button class="w-full inline-flex justify-center py-2 px-4 border border-secondary-300 rounded-md shadow-sm bg-white text-sm font-medium text-secondary-500 hover:bg-gray-50 transition-colors">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 488 512" class="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h240z"></path>
                                    </svg>
                                    <span class="ml-2">Google</span>
                                </button>
                                <button class="w-full inline-flex justify-center py-2 px-4 border border-secondary-300 rounded-md shadow-sm bg-white text-sm font-medium text-secondary-500 hover:bg-gray-50 transition-colors">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" class="h-5 w-5 text-blue-600" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path>
                                    </svg>
                                    <span class="ml-2">Facebook</span>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            
            <?php if ($current_step != 5): ?>
                <div class="text-center mt-6">
                    <p class="text-secondary-600">
                        Already have an account? 
                        <a href="login.php" class="font-medium text-primary-600 hover:text-primary-500">Sign in here</a>
                    </p>
                </div>
            <?php endif; ?>
            
            <?php if ($current_step != 5): ?>
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
                    <div class="flex items-start">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="h-5 w-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" xmlns="http://www.w3.org/2000/svg">
                            <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                        </svg>
                        <div>
                            <h3 class="text-sm font-medium text-blue-800 mb-1">Your Data is Secure</h3>
                            <p class="text-sm text-blue-700">
                                We use bank-level security to protect your personal information. Your data is encrypted and never shared with third parties.
                            </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
    
    <?php include '../includes/chatbot.php'; ?>
</body>
</html>
}
