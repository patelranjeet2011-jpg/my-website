<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['task'])) {
    $user_id = $_SESSION['user_id'];
    $task = trim($_POST['task']);

    try {
        $stmt = $pdo->prepare("INSERT INTO work_list (client_id, task) VALUES (?, ?)");
        $stmt->execute([$user_id, $task]);
        header('Location: dashboard.php?work=created');
    } catch (PDOException $e) {
        header('Location: dashboard.php?error=work_failed');
    }
} else {
    header('Location: dashboard.php');
}
?>