<?php
date_default_timezone_set('Asia/Kolkata');

// Database Configuration
class Database {
    private $host = 'localhost';
    private $db_name = 'u259775287_Kaimur';
    private $username = 'u259775287_kmfsl';
    private $password = 'Kmfsl@2025';
    private $conn;
    
    // Get database connection
    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            // ---> सुधार 1: MySQL का टाइमज़ोन यहाँ सेट किया गया है <---
            $this->conn->exec("SET time_zone = '+05:30';");

        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        
        return $this->conn;
    }
    
    // Create tables if they don't exist
    public function createTables() {
        $conn = $this->getConnection();
        
        // Users table
        $users_table = "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            phone VARCHAR(20),
            password VARCHAR(255),
            pan_number VARCHAR(20),
            address TEXT,
            city VARCHAR(100),
            state VARCHAR(100),
            pincode VARCHAR(10),
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        
        // Enquiries table
        $enquiries_table = "CREATE TABLE IF NOT EXISTS enquiries (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            phone VARCHAR(20),
            service VARCHAR(255),
            message TEXT,
            status ENUM('new', 'in_progress', 'completed') DEFAULT 'new',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        
        // Service requests table
        $service_requests_table = "CREATE TABLE IF NOT EXISTS service_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            service_type VARCHAR(255) NOT NULL,
            description TEXT,
            amount DECIMAL(15,2),
            status ENUM('pending', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
            priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
            assigned_to VARCHAR(255),
            progress INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )";
        
        // Documents table
        $documents_table = "CREATE TABLE IF NOT EXISTS documents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            service_request_id INT,
            document_name VARCHAR(255) NOT NULL,
            document_type VARCHAR(100),
            file_path VARCHAR(500),
            file_size INT,
            status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
            verified_by VARCHAR(255),
            verified_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (service_request_id) REFERENCES service_requests(id) ON DELETE CASCADE
        )";
        
        // Messages table
        $messages_table = "CREATE TABLE IF NOT EXISTS messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            sender_type ENUM('admin', 'client') NOT NULL,
            message TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )";
        
        // Admin users table
        $admin_table = "CREATE TABLE IF NOT EXISTS admin_users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            full_name VARCHAR(255),
            role ENUM('super_admin', 'admin', 'manager') DEFAULT 'admin',
            status ENUM('active', 'inactive') DEFAULT 'active',
            last_login TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        
        // Newsletter subscribers table
        $newsletter_table = "CREATE TABLE IF NOT EXISTS newsletter_subscribers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) UNIQUE NOT NULL,
            status ENUM('active', 'unsubscribed') DEFAULT 'active',
            subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        try {
            $conn->exec($users_table);
            $conn->exec($enquiries_table);
            $conn->exec($service_requests_table);
            $conn->exec($documents_table);
            $conn->exec($messages_table);
            $conn->exec($admin_table);
            $conn->exec($newsletter_table);
            
            // Create default admin user if not exists
            $check_admin = $conn->prepare("SELECT COUNT(*) FROM admin_users WHERE username = 'admin'");
            $check_admin->execute();
            
            if ($check_admin->fetchColumn() == 0) {
                $default_password = password_hash('admin123', PASSWORD_DEFAULT);
                $create_admin = $conn->prepare(
                    "INSERT INTO admin_users (username, email, password, full_name, role) 
                     VALUES ('admin', 'admin@kmfsl.in', ?, 'System Administrator', 'super_admin')"
                );
                $create_admin->execute([$default_password]);
            }
            
            return true;
        } catch(PDOException $exception) {
            echo "Table creation error: " . $exception->getMessage();
            return false;
        }
    }
}

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

// ---> सुधार 2: इस लाइन को कमेंट कर दिया गया है या हटा दें <---
// एक बार टेबल बन जाने के बाद, इसे हर बार चलाने की ज़रूरत नहीं है।
// $database->createTables(); 
?>