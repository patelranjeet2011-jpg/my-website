<?php
// admin/work_details.php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Work Details - Admin - KMFSL</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.tiny.cloud/1/jn3guezlo3pzgafi7ik0r6ivcxdtkzmukvehwt1tjc84gp4t/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
  <style>
    .chat-box::-webkit-scrollbar { width: 6px; }
    .chat-box::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 6px; }
  </style>
</head>
<body class="min-h-screen bg-gray-100">
  <?php include '../includes/header.php'; ?>

  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div id="pageContent" class="space-y-6">
      <div class="flex items-center justify-between">
        <h1 id="pageTitle" class="text-2xl font-bold text-gray-800">Loading...</h1>
        <div>
          <a href="dashboard.php" class="text-sm text-gray-600 hover:underline mr-3">← Back to Dashboard</a>
        </div>
      </div>

      <div id="mainGrid" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div id="leftCol" class="lg:col-span-2 space-y-6">
          <div id="workDetailsCard" class="bg-white rounded-lg shadow p-6">
            <div class="flex justify-between items-start mb-4">
              <h2 class="text-lg font-semibold">Work Details</h2>
              <div>
                <button id="editWorkBtn" class="text-sm bg-blue-50 text-blue-700 px-3 py-1 rounded-md hidden">Edit</button>
              </div>
            </div>
            <div id="workDetailsGrid" class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-700"></div>
          </div>

          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold mb-3">Add New Update</h3>
            <form id="addUpdateForm" enctype="multipart/form-data" class="space-y-3">
              <input type="hidden" name="work_id" id="form_work_id">
              <input type="hidden" name="client_id_for_refresh" id="form_client_id">
              <label class="block text-sm font-medium">Update Note</label>
              <textarea id="updateNoteEditor" name="update_note"></textarea>

              <label class="block text-sm font-medium">Attach Document(s) (Optional)</label>
              <input type="file" name="update_document[]" multiple class="block w-full text-sm">

              <div class="flex justify-end">
                <button id="addUpdateBtn" type="submit" class="bg-purple-600 text-white px-4 py-2 rounded-md font-semibold">Add Update</button>
              </div>
              <div id="addUpdateStatus" class="text-sm text-center mt-2"></div>
            </form>
          </div>
        </div>

        <div class="space-y-6">
          <div class="bg-white rounded-lg shadow p-5">
            <h3 class="font-semibold mb-3">Updates Log</h3>
            <div id="updatesLog" class="max-h-72 overflow-y-auto space-y-2 text-sm text-gray-700"></div>
          </div>

          <div class="bg-white rounded-lg shadow p-5">
            <h3 class="font-semibold mb-3">Work Documents</h3>
            <form id="uploadWorkDocForm" class="space-y-3" enctype="multipart/form-data">
              <input type="hidden" name="work_id" id="upload_work_id">
              <input type="text" name="document_name" placeholder="Document Name (e.g., PAN Card)" class="w-full p-2 border rounded text-sm" required>
              <input type="file" name="work_document" class="w-full text-sm" required>
              <button class="w-full bg-blue-600 text-white py-2 rounded-md font-semibold" type="submit">Upload Document</button>
            </form>
            <div id="workDocumentsList" class="mt-4 max-h-40 overflow-y-auto text-sm"></div>
          </div>
        </div>
      </div>
    </div>
  </div>

<script>
(function(){
  const params = new URLSearchParams(window.location.search);
  const workId = params.get('work_id') || '';
  if (!workId) {
    document.getElementById('pageContent').innerHTML = '<div class="bg-white p-6 rounded shadow">No work selected.</div>';
    return;
  }
  document.getElementById('pageTitle').innerText = 'Updating Work';

  tinymce.init({
    selector: '#updateNoteEditor',
    plugins: 'lists link image table code help wordcount',
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist outdent indent | link image',
    height: 220,
    menubar: false
  });

  async function loadWork() {
    try {
      const res = await fetch(`api/get_work_details.php?work_id=${encodeURIComponent(workId)}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error || 'Error fetching work');

      const { work, updates = [], documents = [] } = data;
      const clientName = work.client_name || work.client || '';
      document.getElementById('pageTitle').innerText = `Updating Work for ${clientName || 'Client'}`;

      const grid = document.getElementById('workDetailsGrid');
      grid.innerHTML = `
        <div><p class="text-xs text-gray-500">Company</p><p class="font-semibold">${escapeHtml(work.company_name || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">Service</p><p class="font-semibold">${escapeHtml(work.service_type || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">Folio Number</p><p class="font-semibold">${escapeHtml(work.folio_number || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">Status</p><p class="font-semibold">${escapeHtml(work.status || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">RTA Contact</p><p class="font-semibold">${escapeHtml(work.rta_contact_number || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">RTA Email</p><p class="font-semibold">${work.rta_email ? `<a href="mailto:${escapeHtml(work.rta_email)}" class="text-blue-600 hover:underline">${escapeHtml(work.rta_email)}</a>` : 'N/A'}</p></div>
        <div class="sm:col-span-2"><p class="text-xs text-gray-500">Initial Notes</p><p class="text-gray-700 whitespace-pre-wrap">${escapeHtml(work.initial_notes || 'N/A')}</p></div>
      `;

      document.getElementById('form_work_id').value = work.id;
      document.getElementById('form_client_id').value = work.client_id || '';
      document.getElementById('upload_work_id').value = work.id;

      const updatesContainer = document.getElementById('updatesLog');
      if (!updates || updates.length === 0) {
        updatesContainer.innerHTML = '<p class="text-sm text-gray-500">No updates yet.</p>';
      } else {
        updatesContainer.innerHTML = updates.map(u => `
          <div class="p-3 bg-gray-50 rounded border">
            <div class="text-sm text-gray-700 mb-2">${u.update_note}</div>
            <div class="text-xs text-gray-500 flex justify-between items-center">
              <div>${new Date(u.created_at).toLocaleString()}</div>
              <div>${(u.documents || []).map(d => `<a class="text-blue-600 hover:underline ml-2" href="../${escapeHtml(d.file_path)}" target="_blank">[${escapeHtml(d.document_name)}]</a>`).join('')}</div>
            </div>
          </div>
        `).join('');
      }

      const docsList = document.getElementById('workDocumentsList');
      if (!documents || documents.length === 0) {
        docsList.innerHTML = '<p class="text-sm text-gray-500">No documents uploaded.</p>';
      } else {
        docsList.innerHTML = documents.map(d => `
          <div class="flex justify-between items-center p-2 border-b">
            <div class="text-sm font-medium">${escapeHtml(d.document_name)}</div>
            <div><a href="../${escapeHtml(d.file_path)}" target="_blank" class="text-blue-600 hover:underline text-sm">View</a></div>
          </div>
        `).join('');
      }

    } catch (err) {
      document.getElementById('pageContent').innerHTML = `<div class="bg-white p-6 rounded shadow text-red-600">Error: ${escapeHtml(err.message)}</div>`;
      console.error(err);
    }
  }

  function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, function(m){ return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]; }); }

  document.getElementById('addUpdateForm').addEventListener('submit', async function(e){
    e.preventDefault();
    const btn = document.getElementById('addUpdateBtn');
    btn.disabled = true; btn.innerText = 'Saving...';
    const status = document.getElementById('addUpdateStatus');

    const updateContent = (tinymce.get('updateNoteEditor') && tinymce.get('updateNoteEditor').getContent) ? tinymce.get('updateNoteEditor').getContent() : document.querySelector('#updateNoteEditor').value;
    if (!updateContent.trim()) {
      alert('Please write an update note.');
      btn.disabled = false; btn.innerText = 'Add Update';
      return;
    }

    const form = new FormData(this);
    form.set('update_note', updateContent);

    try {
      const res = await fetch('api/add_work_update.php', { method: 'POST', body: form });
      const result = await res.json();
      if (result.success) {
        status.className = 'text-sm text-green-600 mt-2';
        status.innerText = 'Update added.';
        if (tinymce.get('updateNoteEditor')) tinymce.get('updateNoteEditor').setContent('');
        this.reset();
        await loadWork();
      } else throw new Error(result.error || 'Failed to add update');
    } catch (err) {
      status.className = 'text-sm text-red-600 mt-2';
      status.innerText = 'Error: ' + err.message;
      console.error(err);
    } finally {
      btn.disabled = false; btn.innerText = 'Add Update';
    }
  });

  document.getElementById('uploadWorkDocForm').addEventListener('submit', async function(e){
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    btn.disabled = true; btn.innerText = 'Uploading...';
    try {
      const res = await fetch('api/upload_work_document.php', { method: 'POST', body: new FormData(this) });
      const result = await res.json();
      if (result.success) {
        this.reset();
        await loadWork();
      } else throw new Error(result.error || 'Upload failed');
    } catch (err) {
      alert('Error uploading document: ' + err.message);
      console.error(err);
    } finally {
      btn.disabled = false; btn.innerText = 'Upload Document';
    }
  });

  loadWork();
})();
</script>
</body>
</html>