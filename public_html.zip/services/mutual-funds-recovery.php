<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mutual Funds Recovery - KMFSL | Professional MF Recovery Services</title>
    <meta name="description" content="Expert assistance in recovering unclaimed mutual fund investments, dividends, and matured amounts. Our specialized team works with 40+ AMCs to trace and recover your forgotten investments with complete transparency and efficiency.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Mutual Funds Recovery Hero Section -->
    <section class="section-padding bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <div class="inline-flex items-center bg-blue-100 text-blue-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <svg class="mr-2 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                        <path d="M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z"></path>
                    </svg>
                    Professional Mutual Fund Recovery
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                    Mutual Funds <span class="text-gradient">Recovery</span>
                </h1>
                <p class="text-xl text-secondary-600 max-w-4xl mx-auto leading-relaxed mb-8">
                    Expert assistance in recovering unclaimed mutual fund investments, dividends, and matured amounts. Our specialized team works with 40+ AMCs to trace and recover your forgotten investments with complete transparency and efficiency.
                </p>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">₹95+ Crores</div>
                        <div class="text-sm text-secondary-600">MF Amount Recovered</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 640 512">
                                <path d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">4,500+</div>
                        <div class="text-sm text-secondary-600">Successful Cases</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 384 512">
                                <path d="M97.12 362.63c-8.69-8.69-4.16-6.24-25.12-11.85-9.51-2.55-17.87-7.45-25.43-13.32L1.2 448.7c-4.39 10.77 3.81 22.47 15.43 22.03l52.69-2.01L105.56 507c8 8.44 22.04 5.81 26.43-4.96l52.05-127.62c-10.84 6.04-22.87 9.58-35.31 9.58-19.5 0-37.82-7.59-51.61-21.37zM382.8 448.7l-45.37-111.24c-7.56 5.88-15.92 10.77-25.43 13.32-21.07 5.64-16.45 3.18-25.12 11.85-13.79 13.78-32.12 21.37-51.62 21.37-12.44 0-24.47-3.55-35.31-9.58L252 502.04c4.39 10.77 18.44 13.4 26.43 4.96l36.25-38.28 52.69 2.01c11.62.44 19.82-11.27 15.43-22.03zM263 340c15.28-15.55 17.03-14.21 38.79-20.14 13.89-3.79 24.75-14.84 28.47-28.98 7.48-28.4 5.54-24.97 25.95-45.75 10.17-10.35 14.14-25.44 10.42-39.58-7.47-28.38-7.48-24.42 0-52.83 3.72-14.14-.25-29.23-10.42-39.58-20.41-20.78-18.47-17.36-25.95-45.75-3.72-14.14-14.58-25.19-28.47-28.98-27.88-7.61-24.52-5.62-44.95-26.41-10.17-10.35-25-14.4-38.89-10.61-27.87 7.6-23.98 7.61-51.9 0-13.89-3.79-28.72.25-38.89 10.61-20.41 20.78-17.05 18.8-44.94 26.41-13.89 3.79-24.75 14.84-28.47 28.98-7.47 28.39-5.54 24.97-25.95 45.75-10.17 10.35-14.15 25.44-10.42 39.58 7.47 28.36 7.48 24.4 0 52.82-3.72 14.14.25 29.23 10.42 39.59 20.41 20.78 18.47 17.35 25.95 45.75 3.72 14.14 14.58 25.19 28.47 28.98C104.6 325.96 106.27 325 121 340c13.23 13.47 33.84 15.88 49.74 5.82a39.676 39.676 0 0 1 42.53 0c15.89 10.06 36.5 7.65 49.73-5.82zM97.66 175.96c0-53.03 42.24-96.02 94.34-96.02s94.34 42.99 94.34 96.02-42.24 96.02-94.34 96.02-94.34-42.99-94.34-96.02z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">96.8%</div>
                        <div class="text-sm text-secondary-600">Recovery Rate</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">18 Days</div>
                        <div class="text-sm text-secondary-600">Average Time</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Types of MF Recovery Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                    Types of <span class="text-gradient">MF Recovery</span>
                </h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">
                    We handle various types of mutual fund recoveries with specialized expertise.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z"></path>
                            </svg>
                        </div>
                        <div class="text-right">
                            <div class="text-sm font-semibold text-blue-600">10-15 days</div>
                            <div class="text-xs text-secondary-500">Avg: ₹25,000</div>
                        </div>
                    </div>
                    <h3 class="text-xl font-semibold text-secondary-800 mb-3">Unclaimed Dividends</h3>
                    <p class="text-secondary-600 mb-4">Recovery of unclaimed dividends from equity and debt mutual fund schemes.</p>
                    <div class="grid grid-cols-2 gap-2">
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Equity Fund Dividends</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Debt Fund Dividends</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Hybrid Fund Dividends</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Sectoral Fund Dividends</span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 448 512">
                                <path d="M400 0H48C22.4 0 0 22.4 0 48v416c0 25.6 22.4 48 48 48h352c25.6 0 48-22.4 48-48V48c0-25.6-22.4-48-48-48zM128 435.2c0 6.4-6.4 12.8-12.8 12.8H76.8c-6.4 0-12.8-6.4-12.8-12.8v-38.4c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v38.4zm0-128c0 6.4-6.4 12.8-12.8 12.8H76.8c-6.4 0-12.8-6.4-12.8-12.8v-38.4c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v38.4zm128 128c0 6.4-6.4 12.8-12.8 12.8h-38.4c-6.4 0-12.8-6.4-12.8-12.8v-38.4c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v38.4zm0-128c0 6.4-6.4 12.8-12.8 12.8h-38.4c-6.4 0-12.8-6.4-12.8-12.8v-38.4c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v38.4zm128 128c0 6.4-6.4 12.8-12.8 12.8h-38.4c-6.4 0-12.8-6.4-12.8-12.8V268.8c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v166.4zm0-256c0 6.4-6.4 12.8-12.8 12.8H76.8c-6.4 0-12.8-6.4-12.8-12.8V76.8C64 70.4 70.4 64 76.8 64h294.4c6.4 0 12.8 6.4 12.8 12.8v102.4z"></path>
                            </svg>
                        </div>
                        <div class="text-right">
                            <div class="text-sm font-semibold text-blue-600">15-20 days</div>
                            <div class="text-xs text-secondary-500">Avg: ₹85,000</div>
                        </div>
                    </div>
                    <h3 class="text-xl font-semibold text-secondary-800 mb-3">Matured Investments</h3>
                    <p class="text-secondary-600 mb-4">Recovery of matured mutual fund investments and SIP amounts.</p>
                    <div class="grid grid-cols-2 gap-2">
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Matured SIPs</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Closed-end Funds</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Fixed Maturity Plans</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Capital Protection Funds</span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 384 512">
                                <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm64 236c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-64c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-72v8c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12zm96-114.1v6.1H256V0h6.1c6.4 0 12.5 2.5 17 7l97.9 98c4.5 4.5 7 10.6 7 16.9z"></path>
                            </svg>
                        </div>
                        <div class="text-right">
                            <div class="text-sm font-semibold text-blue-600">12-18 days</div>
                            <div class="text-xs text-secondary-500">Avg: ₹45,000</div>
                        </div>
                    </div>
                    <h3 class="text-xl font-semibold text-secondary-800 mb-3">Dormant Folios</h3>
                    <p class="text-secondary-600 mb-4">Reactivation and recovery from dormant mutual fund folios.</p>
                    <div class="grid grid-cols-2 gap-2">
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Inactive Accounts</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Lost Folios</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Forgotten Investments</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Old Statements</span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M496 128v16a8 8 0 0 1-8 8h-24v12c0 6.627-5.373 12-12 12H60c-6.627 0-12-5.373-12-12v-12H24a8 8 0 0 1-8-8v-16a8 8 0 0 1 4.941-7.392l232-88a7.996 7.996 0 0 1 6.118 0l232 88A8 8 0 0 1 496 128zm-24 304H40c-13.255 0-24 10.745-24 24v16a8 8 0 0 0 8 8h464a8 8 0 0 0 8-8v-16c0-13.255-10.745-24-24-24zM96 192v192H60c-6.627 0-12 5.373-12 12v20h416v-20c0-6.627-5.373-12-12-12h-36V192h-64v192h-64V192h-64v192h-64V192H96z"></path>
                            </svg>
                        </div>
                        <div class="text-right">
                            <div class="text-sm font-semibold text-blue-600">20-25 days</div>
                            <div class="text-xs text-secondary-500">Avg: ₹1,25,000</div>
                        </div>
                    </div>
                    <h3 class="text-xl font-semibold text-secondary-800 mb-3">Transmission Claims</h3>
                    <p class="text-secondary-600 mb-4">Transfer of mutual fund units to legal heirs after investor demise.</p>
                    <div class="grid grid-cols-2 gap-2">
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Nominee Claims</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Legal Heir Transfer</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Succession Claims</span>
                        </div>
                        <div class="flex items-center text-sm text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Joint Holder Transfer</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- AMC Partners Section -->
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">AMC <span class="text-gradient">Partners</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">We work with all major Asset Management Companies for comprehensive recovery services.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">SBI Mutual Fund</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-blue-600">1,200+</div>
                            <div class="text-xs text-secondary-500">Folios Recovered</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹15 Cr</div>
                            <div class="text-xs text-secondary-500">Amount Recovered</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">HDFC Mutual Fund</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-blue-600">1,000+</div>
                            <div class="text-xs text-secondary-500">Folios Recovered</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹12 Cr</div>
                            <div class="text-xs text-secondary-500">Amount Recovered</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">ICICI Prudential</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-blue-600">900+</div>
                            <div class="text-xs text-secondary-500">Folios Recovered</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹11 Cr</div>
                            <div class="text-xs text-secondary-500">Amount Recovered</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Reliance Mutual Fund</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-blue-600">800+</div>
                            <div class="text-xs text-secondary-500">Folios Recovered</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹10 Cr</div>
                            <div class="text-xs text-secondary-500">Amount Recovered</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Aditya Birla Sun Life</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-blue-600">700+</div>
                            <div class="text-xs text-secondary-500">Folios Recovered</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹8 Cr</div>
                            <div class="text-xs text-secondary-500">Amount Recovered</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Axis Mutual Fund</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-blue-600">600+</div>
                            <div class="text-xs text-secondary-500">Folios Recovered</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹7 Cr</div>
                            <div class="text-xs text-secondary-500">Amount Recovered</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">UTI Mutual Fund</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-blue-600">500+</div>
                            <div class="text-xs text-secondary-500">Folios Recovered</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹6 Cr</div>
                            <div class="text-xs text-secondary-500">Amount Recovered</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">DSP Mutual Fund</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-blue-600">400+</div>
                            <div class="text-xs text-secondary-500">Folios Recovered</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹5 Cr</div>
                            <div class="text-xs text-secondary-500">Amount Recovered</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Recovery Process Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Our Recovery <span class="text-gradient">Process</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Systematic approach to ensure complete mutual fund recovery with transparency.</p>
            </div>
            <div class="space-y-12">
                <div class="flex flex-col lg:flex-row items-center gap-8 ">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">1</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Folio Identification</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">2-3 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Identify and verify mutual fund folios across various AMCs and schemes.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">PAN Card</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Investment Records</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Bank Statements</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-blue-600 font-bold">1</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col lg:flex-row items-center gap-8 lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">2</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Documentation Preparation</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">3-4 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Prepare required documents and application forms for recovery process.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">KYC Documents</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Folio Statements</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Identity Proofs</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-blue-600 font-bold">2</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col lg:flex-row items-center gap-8 ">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">3</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">AMC Coordination</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">5-7 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Coordinate with Asset Management Companies for claim processing.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Claim Applications</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Supporting Documents</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Verification Forms</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2