<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IEPF Claim Services - KMFSL | Recover Your Unclaimed Shares & Dividends</title>
    <meta name="description" content="Expert IEPF claim recovery services with 98% success rate. Recover your unclaimed shares and dividends transferred to IEPF with professional assistance.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- IEPF Hero Section -->
    <section class="section-padding bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div class="container-custom">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                    <div class="inline-flex items-center bg-blue-100 text-blue-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                        <svg class="mr-2 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                        </svg>
                        Most Popular Service
                    </div>
                    <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                        <span class="text-gradient">IEPF Claim</span> Services
                    </h1>
                    <p class="text-xl text-secondary-600 mb-8 leading-relaxed">
                        Recover your unclaimed shares and dividends transferred to IEPF with our expert assistance. We have successfully recovered over ₹50 crores for 5000+ clients with a 98% success rate.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a href="#consultation" class="btn-primary inline-flex items-center justify-center">
                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M505.12019,19.09375c-1.18945-5.53125-6.65819-11-12.207-12.1875C460.716,0,435.507,0,410.40747,0,307.17523,0,245.26909,55.20312,199.05238,128H94.83772c-16.34763.01562-35.55658,11.875-42.88664,26.48438L2.51562,253.29688A28.4,28.4,0,0,0,0,264a24.00867,24.00867,0,0,0,24.00582,24H127.81618l-22.47457,22.46875c-11.36521,11.36133-12.99607,32.25781,0,45.25L156.24582,406.625c11.15623,11.1875,32.15619,13.15625,45.27726,0l22.47457-22.46875V488a24.00867,24.00867,0,0,0,24.00581,24,28.55934,28.55934,0,0,0,10.707-2.51562l98.72834-49.39063c14.62888-7.29687,26.50776-26.5,26.50776-42.85937V312.79688c72.59375-46.3125,128.03125-108.40626,128.03125-211.09376C512.07526,76.5,512.07526,51.29688,505.12019,19.09375ZM384.04033,168A40,40,0,1,1,424.05,128,40.02322,40.02322,0,0,1,384.04033,168Z"></path>
                            </svg>
                            Start IEPF Claim
                        </a>
                        <a href="tel:+917070972333" class="btn-secondary inline-flex items-center justify-center">
                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                            </svg>
                            Call Expert: +91 7070972333
                        </a>
                    </div>
                </div>
                <div class="relative">
                    <div class="bg-white rounded-2xl shadow-2xl p-8">
                        <div class="text-center mb-6">
                            <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <svg class="w-8 h-8 text-blue-600" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm61.8-104.4l-84.9-61.7c-3.1-2.3-4.9-5.9-4.9-9.7V116c0-6.6 5.4-12 12-12h32c6.6 0 12 5.4 12 12v141.7l66.8 48.6c5.4 3.9 6.5 11.4 2.6 16.8L334.6 349c-3.9 5.3-11.4 6.5-16.8 2.6z"></path>
                                </svg>
                            </div>
                            <h3 class="text-2xl font-bold text-secondary-800 mb-2">Quick IEPF Check</h3>
                            <p class="text-secondary-600">Find your unclaimed assets in 2 minutes</p>
                        </div>
                        <form class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">PAN Number *</label>
                                <input type="text" class="input-field" placeholder="Enter your PAN number" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Mobile Number *</label>
                                <input type="tel" class="input-field" placeholder="Enter mobile number" required>
                            </div>
                            <button type="submit" class="btn-primary w-full">
                                Check My IEPF Assets
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                    Need Immediate <span class="text-gradient">Assistance</span>?
                </h2>
                <p class="text-lg text-secondary-600">
                    Our IEPF specialists are available to help you with urgent queries.
                </p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
                <a href="tel:+917070972333" class="card text-center group hover:scale-105 transition-all duration-300">
                    <svg class="w-12 h-12 text-blue-600 mx-auto mb-4 group-hover:text-blue-700" fill="currentColor" viewBox="0 0 512 512">
                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                    </svg>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-2">Call Our Experts</h3>
                    <p class="text-secondary-600 mb-3">Speak directly with our IEPF specialists</p>
                    <span class="text-blue-600 font-semibold">+91 7070972333</span>
                </a>
                
                <a href="mailto:iepf@kmfsl.com" class="card text-center group hover:scale-105 transition-all duration-300">
                    <svg class="w-12 h-12 text-green-600 mx-auto mb-4 group-hover:text-green-700" fill="currentColor" viewBox="0 0 512 512">
                        <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                    </svg>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-2">Email Us</h3>
                    <p class="text-secondary-600 mb-3">Send us your IEPF related queries</p>
                    <span class="text-green-600 font-semibold">iepf@kmfsl.com</span>
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- Chatbot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
</body>
</html>