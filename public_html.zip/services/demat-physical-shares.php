<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demat Physical Shares Services - KMFSL | Convert Physical to Electronic</title>
    <meta name="description" content="Convert your physical share certificates to electronic format for easy trading. We have successfully dematerialized ₹150Cr+ worth of shares with 99% success rate.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Demat Hero Section -->
    <section class="section-padding bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div class="container-custom">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                    <div class="inline-flex items-center bg-blue-100 text-blue-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                        <svg class="mr-2 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M0 168v-16c0-13.255 10.745-24 24-24h360V80c0-21.367 25.899-32.042 40.971-16.971l80 80c9.372 9.373 9.372 24.569 0 33.941l-80 80C409.956 271.982 384 261.456 384 240v-48H24c-13.255 0-24-10.745-24-24zm488 152H128v-48c0-21.314-25.862-32.08-40.971-16.971l-80 80c-9.372 9.373-9.372 24.569 0 33.941l80 80C102.057 463.997 128 453.437 128 432v-48h360c13.255 0 24-10.745 24-24v-16c0-13.255-10.745-24-24-24z"></path>
                        </svg>
                        Digital Transformation
                    </div>
                    <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                        <span class="text-gradient">Demat</span> Physical Shares
                    </h1>
                    <p class="text-xl text-secondary-600 mb-8 leading-relaxed">
                        Convert your physical share certificates to electronic format for easy trading and management. We have successfully dematerialized ₹150Cr+ worth of shares with 99% success rate.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a class="btn-primary" href="#process">Start Demat Process</a>
                        <a class="btn-secondary" href="#consultation">Free Consultation</a>
                    </div>
                </div>
                <div class="relative">
                    <div class="w-full h-96 bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl flex items-center justify-center">
                        <div class="text-center">
                            <svg class="w-24 h-24 text-blue-600 mx-auto mb-4" fill="currentColor" viewBox="0 0 640 512">
                                <path d="M624 416H381.54c-.74 19.81-14.71 32-32.74 32H288c-18.69 0-33.02-17.47-32.77-32H16c-8.8 0-16 7.2-16 16v16c0 35.2 28.8 64 64 64h512c35.2 0 64-28.8 64-64v-16c0-8.8-7.2-16-16-16zM576 48c0-26.4-21.6-48-48-48H112C85.6 0 64 21.6 64 48v336h512V48zm-64 272H128V64h384v256z"></path>
                            </svg>
                            <h3 class="text-2xl font-bold text-secondary-800 mb-2">₹150Cr+ Converted</h3>
                            <p class="text-secondary-600">4000+ Certificates Processed</p>
                        </div>
                    </div>
                    <div class="absolute -top-4 -right-4 w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center animate-bounce">
                        <svg class="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 320 512">
                            <path d="M272 0H48C21.5 0 0 21.5 0 48v416c0 26.5 21.5 48 48 48h224c26.5 0 48-21.5 48-48V48c0-26.5-21.5-48-48-48zM160 480c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32z"></path>
                        </svg>
                    </div>
                    <div class="absolute -bottom-4 -left-4 w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center animate-bounce" style="animation-delay: 0.5s;">
                        <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="section-padding bg-blue-600">
        <div class="container-custom">
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center text-white">
                <div>
                    <div class="text-3xl font-bold mb-2">₹150Cr+</div>
                    <div class="text-blue-200">Shares Dematerialized</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">4000+</div>
                    <div class="text-blue-200">Certificates Converted</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">99%</div>
                    <div class="text-blue-200">Success Rate</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">10-20</div>
                    <div class="text-blue-200">Days Processing</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Benefits Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Benefits of <span class="text-gradient">Dematerialization</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Transform your physical certificates into digital format for modern trading and investment management.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <svg class="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" fill="currentColor" viewBox="0 0 640 512">
                            <path d="M624 416H381.54c-.74 19.81-14.71 32-32.74 32H288c-18.69 0-33.02-17.47-32.77-32H16c-8.8 0-16 7.2-16 16v16c0 35.2 28.8 64 64 64h512c35.2 0 64-28.8 64-64v-16c0-8.8-7.2-16-16-16zM576 48c0-26.4-21.6-48-48-48H112C85.6 0 64 21.6 64 48v336h512V48zm-64 272H128V64h384v256z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-blue-600 mb-2">Instant Trading</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Digital Trading</h3>
                    <p class="text-secondary-600">Trade shares instantly online without physical certificates hassle.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <svg class="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-blue-600 mb-2">100% Secure</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Secure Storage</h3>
                    <p class="text-secondary-600">Electronic format eliminates risk of loss, theft, or damage of certificates.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <svg class="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-blue-600 mb-2">10-20 Days</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Quick Process</h3>
                    <p class="text-secondary-600">Complete demat process in just 10-20 days with proper documentation.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <svg class="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-blue-600 mb-2">Portfolio View</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Easy Management</h3>
                    <p class="text-secondary-600">Track all your investments in one place with real-time portfolio updates.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Go Digital Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Why Go <span class="text-gradient">Digital</span>?
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Discover the advantages of electronic shares over physical certificates.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">🏦</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">No Physical Storage</h3>
                    <p class="text-secondary-600">Eliminate the need for physical storage and safekeeping of certificates</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">⚡</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">Instant Transfers</h3>
                    <p class="text-secondary-600">Transfer shares instantly without lengthy paperwork and procedures</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">🔢</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">Fractional Trading</h3>
                    <p class="text-secondary-600">Buy and sell shares in any quantity, including fractional shares</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">💰</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">Corporate Actions</h3>
                    <p class="text-secondary-600">Automatic processing of dividends, bonuses, and rights issues</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">📊</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">Portfolio Tracking</h3>
                    <p class="text-secondary-600">Real-time portfolio valuation and performance tracking</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">🏛️</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">Loan Against Shares</h3>
                    <p class="text-secondary-600">Easy pledging of shares for loans and margin trading</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section id="process" class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Our <span class="text-gradient">Demat Process</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Simple 6-step process to convert your physical shares to electronic format.
                </p>
            </div>

            <div class="space-y-12">
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">01</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Document Verification</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">1-2 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Verification of physical share certificates and supporting documents.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Original Certificates</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">PAN Card</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Demat Account</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-blue-600 font-bold">01</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">02</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">DRF Preparation</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">1 Day</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Preparation of Dematerialization Request Form (DRF) with accurate details.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">DRF Form</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Certificate Details</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Signature Verification</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-blue-600 font-bold">02</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">03</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Depository Submission</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">1-2 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Submission of documents to depository participant (DP) for processing.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">DP Submission</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Processing Fees</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Acknowledgment</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-blue-600 font-bold">03</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">04</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Company Verification</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">5-10 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Company registrar verifies the certificates and approves dematerialization.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Company Verification</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Registrar Approval</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">System Update</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-blue-600 font-bold">04</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">05</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Electronic Credit</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">2-3 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Shares credited to your demat account in electronic format.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Demat Credit</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Confirmation SMS</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Account Update</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-blue-600 font-bold">05</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">06</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Trading Ready</h3>
                                </div>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-3 py-1 rounded-full">1 Day</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Shares ready for online trading and portfolio management.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Trading Access</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Portfolio Update</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Market Ready</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-blue-600 font-bold">06</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Required Documents Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Required <span class="text-gradient">Documents</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Complete list of documents required for smooth dematerialization process.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Share Certificates</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Original Physical Share Certificates</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Share Certificate Numbers</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Folio Numbers</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Distinctive Numbers</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Identity Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">PAN Card (Original + Copy)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Aadhaar Card</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Passport (for NRIs)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Address Proof</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Demat Account</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Demat Account Number</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">DP ID and Client ID</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Demat Account Statement</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Bank Account Details</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Additional Documents</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Power of Attorney (if applicable)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Corporate Resolution (for companies)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Nomination Form</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Specimen Signature</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Success Stories Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Client <span class="text-gradient">Success Stories</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Real experiences from clients who have successfully converted their physical shares.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Amit Sharma</h4>
                            <p class="text-sm text-secondary-600">Mumbai</p>
                        </div>
                        <div class="text-right">
                             <div class="text-lg font-bold text-green-600">₹3.2 Lakhs</div>
                             <div class="text-xs text-secondary-500">Portfolio Value</div>
                         </div>
                     </div>
                     <p class="text-secondary-700 italic mb-4">"Excellent service! They handled all the paperwork and my shares were credited to demat account exactly on time."</p>
                     <div class="flex items-center justify-between text-xs">
                         <span class="bg-blue-100 text-blue-600 font-medium px-2 py-1 rounded">8 Certificates</span>
                         <span class="text-secondary-500">Completed in 15 days</span>
                     </div>
                 </div>
                 
                 <div class="card">
                     <div class="flex items-center justify-between mb-4">
                         <div>
                             <h4 class="font-semibold text-secondary-800">Rajesh Patel</h4>
                             <p class="text-sm text-secondary-600">Ahmedabad</p>
                         </div>
                         <div class="text-right">
                             <div class="text-lg font-bold text-green-600">₹12.8 Lakhs</div>
                             <div class="text-xs text-secondary-500">Portfolio Value</div>
                         </div>
                     </div>
                     <p class="text-secondary-700 italic mb-4">"Professional team with great expertise. Now I can trade my inherited shares easily through mobile app."</p>
                     <div class="flex items-center justify-between text-xs">
                         <span class="bg-blue-100 text-blue-600 font-medium px-2 py-1 rounded">25 Certificates</span>
                         <span class="text-secondary-500">Completed in 18 days</span>
                     </div>
                 </div>
             </div>
         </div>
     </section>

     <!-- FAQ Section -->
     <section class="section-padding bg-gray-50">
         <div class="container-custom">
             <div class="text-center mb-16">
                 <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                     Frequently Asked <span class="text-gradient">Questions</span>
                 </h2>
                 <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                     Get answers to common questions about dematerialization process.
                 </p>
             </div>

             <div class="max-w-4xl mx-auto space-y-6">
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: What is dematerialization of shares?</h3>
                     <p class="text-secondary-600 leading-relaxed">A: Dematerialization is the process of converting physical share certificates into electronic format, making them easier to trade and manage.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: How long does the demat process take?</h3>
                     <p class="text-secondary-600 leading-relaxed">A: The complete dematerialization process typically takes 10-20 days from submission of documents to credit of shares in demat account.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: What are the charges for dematerialization?</h3>
                     <p class="text-secondary-600 leading-relaxed">A: Charges vary by depository participant (DP) but typically range from ₹25-50 per certificate. We provide transparent pricing with no hidden costs.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: Can I trade shares immediately after demat?</h3>
                     <p class="text-secondary-600 leading-relaxed">A: Yes, once shares are credited to your demat account, you can trade them immediately through your broker.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: What happens to my physical certificates?</h3>
                     <p class="text-secondary-600 leading-relaxed">A: Physical certificates are cancelled and destroyed by the company after successful dematerialization. You receive electronic shares in your demat account.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: Is dematerialization mandatory?</h3>
                     <p class="text-secondary-600 leading-relaxed">A: While not mandatory, dematerialization is highly recommended for easy trading, better security, and efficient portfolio management.</p>
                 </div>
             </div>
         </div>
     </section>

     <!-- CTA Section -->
     <section class="section-padding bg-gradient-to-r from-blue-600 to-purple-600">
         <div class="container-custom text-center text-white">
             <h2 class="text-4xl font-bold mb-4">Ready to Go Digital?</h2>
             <p class="text-xl mb-8 max-w-2xl mx-auto">
                 Transform your physical share certificates into electronic format for modern, hassle-free trading and investment management.
             </p>
             <div class="flex flex-col sm:flex-row gap-4 justify-center">
                 <a class="btn-primary bg-white text-blue-600 hover:bg-gray-100" href="#consultation">Start Demat Process</a>
                 <a href="tel:+917070972333" class="btn-secondary border-white text-white hover:bg-white hover:text-blue-600">Call Expert: +91 7070972333</a>
             </div>
         </div>
     </section>

     <!-- Consultation Form Section -->
     <section id="consultation" class="section-padding">
         <div class="container-custom">
             <div class="max-w-4xl mx-auto">
                 <div class="text-center mb-12">
                     <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                         Get Your <span class="text-gradient">Free Demat Consultation</span>
                     </h2>
                     <p class="text-xl text-secondary-600">
                         Fill out the form below and our demat experts will contact you within 24 hours to guide you through the conversion process.
                     </p>
                 </div>
                 
                 <div class="card max-w-4xl mx-auto">
                     <div class="text-center mb-8">
                         <div class="flex justify-center mb-6">
                             <img src="../kmfsl logo svg.svg" alt="KMFSL - Kaimur Financial Services" class="h-24 w-auto">
                         </div>
                         <h3 class="text-2xl font-bold text-secondary-800 mb-2">Demat Consultation Form</h3>
                         <p class="text-secondary-600">Let our experts help you convert your physical shares to electronic format</p>
                     </div>
                     
                     <form class="space-y-6">
                         <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                             <div>
                                 <label class="block text-sm font-medium text-secondary-700 mb-2">Full Name *</label>
                                 <div class="relative">
                                     <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 448 512">
                                         <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                     </svg>
                                     <input type="text" name="name" class="input-field pl-10" placeholder="Enter your full name" required>
                                 </div>
                             </div>
                             <div>
                                 <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                                 <div class="relative">
                                     <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                                         <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                     </svg>
                                     <input type="email" name="email" class="input-field pl-10" placeholder="Enter your email address" required>
                                 </div>
                             </div>
                             <div>
                                 <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                                 <div class="relative">
                                     <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                                         <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                     </svg>
                                     <input type="tel" name="phone" class="input-field pl-10" placeholder="Enter your phone number" required>
                                 </div>
                             </div>
                             <div>
                                 <label class="block text-sm font-medium text-secondary-700 mb-2">Service Required *</label>
                                 <select name="service" class="input-field" required>
                                     <option value="">Select a service</option>
                                     <option value="IEPF Claim">IEPF Claim</option>
                                     <option value="Transmission of Shares">Transmission of Shares</option>
                                     <option value="Demat of Physical Shares">Demat of Physical Shares</option>
                                     <option value="Unclaimed Dividends">Unclaimed Dividends</option>
                                     <option value="Conversion of Shares/Debentures">Conversion of Shares/Debentures</option>
                                     <option value="Property Claim Samadhan">Property Claim Samadhan</option>
                                     <option value="Debtor Recovery">Debtor Recovery</option>
                                     <option value="Recovery of Unclaimed Mutual Funds">Recovery of Unclaimed Mutual Funds</option>
                                     <option value="Recovery of Inoperative Bank Accounts">Recovery of Inoperative Bank Accounts</option>
                                     <option value="Provident Funds Claim">Provident Funds Claim</option>
                                     <option value="Recovery of Unclaimed Matured Insurance">Recovery of Unclaimed Matured Insurance</option>
                                     <option value="Wealth Samadhan">Wealth Samadhan</option>
                                     <option value="NRI Samadhan">NRI Samadhan</option>
                                     <option value="Other">Other</option>
                                 </select>
                             </div>
                         </div>
                         <div>
                             <label class="block text-sm font-medium text-secondary-700 mb-2">Preferred Contact Method</label>
                             <div class="flex space-x-4">
                                 <label class="flex items-center">
                                     <input type="radio" name="preferredContact" class="mr-2" value="email" checked>
                                     Email
                                 </label>
                                 <label class="flex items-center">
                                     <input type="radio" name="preferredContact" class="mr-2" value="phone">
                                     Phone
                                 </label>
                                 <label class="flex items-center">
                                     <input type="radio" name="preferredContact" class="mr-2" value="whatsapp">
                                     WhatsApp
                                 </label>
                             </div>
                         </div>
                         <div>
                             <label class="block text-sm font-medium text-secondary-700 mb-2">Message *</label>
                             <textarea name="message" rows="4" class="input-field resize-none" placeholder="Please describe your requirements or any specific questions you have..." required></textarea>
                         </div>
                         <div class="text-center">
                             <button type="submit" class="btn-primary inline-flex items-center justify-center min-w-[200px]">
                                 <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 512 512">
                                     <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                                 </svg>
                                 Send Enquiry
                             </button>
                         </div>
                         <div class="text-center text-sm text-secondary-500">
                             <p>By submitting this form, you agree to our <a href="../privacy-policy.php" class="text-primary-600 hover:underline">Privacy Policy</a> and <a href="../terms-conditions.php" class="text-primary-600 hover:underline">Terms & Conditions</a>.</p>
                         </div>
                     </form>
                 </div>
             </div>
         </div>
     </section>

     <!-- Footer -->
     <?php include '../includes/footer.php'; ?>
     
     <!-- Chatbot -->
     <?php include '../includes/chatbot.php'; ?>
     
     <!-- Slider JavaScript -->
     <?php include '../complete-nodejs-slider.php'; ?>
 </body>
 </html>