<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transmission of Shares Services - KMFSL | Legal Share Transfer</title>
    <meta name="description" content="Professional legal assistance for smooth transmission of shares from deceased to legal heirs. Expert team with 95% success rate and 20+ years experience.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Transmission Hero Section -->
    <section class="section-padding bg-gradient-to-br from-green-50 via-white to-blue-50">
        <div class="container-custom">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                    <div class="inline-flex items-center bg-green-100 text-green-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                        <svg class="mr-2 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M0 168v-16c0-13.255 10.745-24 24-24h360V80c0-21.367 25.899-32.042 40.971-16.971l80 80c9.372 9.373 9.372 24.569 0 33.941l-80 80C409.956 271.982 384 261.456 384 240v-48H24c-13.255 0-24-10.745-24-24zm488 152H128v-48c0-21.314-25.862-32.08-40.971-16.971l-80 80c-9.372 9.373-9.372 24.569 0 33.941l80 80C102.057 463.997 128 453.437 128 432v-48h360c13.255 0 24-10.745 24-24v-16c0-13.255-10.745-24-24-24z"></path>
                        </svg>
                        Legal Transmission Service
                    </div>
                    <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                        <span class="text-gradient">Transmission</span> of Shares
                    </h1>
                    <p class="text-xl text-secondary-600 mb-8 leading-relaxed">
                        Professional legal assistance for smooth transmission of shares from deceased to legal heirs. Our expert team has successfully handled 3000+ transmission cases with 95% success rate.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a class="btn-primary" href="#process">Start Transmission</a>
                        <a class="btn-secondary" href="#consultation">Legal Consultation</a>
                    </div>
                </div>
                <div class="relative">
                    <div class="w-full h-96 bg-gradient-to-br from-green-100 to-blue-100 rounded-2xl flex items-center justify-center">
                        <div class="text-center">
                            <svg class="w-24 h-24 text-green-600 mx-auto mb-4" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M0 168v-16c0-13.255 10.745-24 24-24h360V80c0-21.367 25.899-32.042 40.971-16.971l80 80c9.372 9.373 9.372 24.569 0 33.941l-80 80C409.956 271.982 384 261.456 384 240v-48H24c-13.255 0-24-10.745-24-24zm488 152H128v-48c0-21.314-25.862-32.08-40.971-16.971l-80 80c-9.372 9.373-9.372 24.569 0 33.941l80 80C102.057 463.997 128 453.437 128 432v-48h360c13.255 0 24-10.745 24-24v-16c0-13.255-10.745-24-24-24z"></path>
                            </svg>
                            <h3 class="text-2xl font-bold text-secondary-800 mb-2">₹25Cr+ Transmitted</h3>
                            <p class="text-secondary-600">3000+ Successful Cases</p>
                        </div>
                    </div>
                    <div class="absolute -top-4 -right-4 w-20 h-20 bg-green-500 rounded-full flex items-center justify-center animate-bounce">
                        <svg class="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                        </svg>
                    </div>
                    <div class="absolute -bottom-4 -left-4 w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center animate-bounce" style="animation-delay: 0.5s;">
                        <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 640 512">
                            <path d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="section-padding bg-green-600">
        <div class="container-custom">
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center text-white">
                <div>
                    <div class="text-3xl font-bold mb-2">₹25Cr+</div>
                    <div class="text-green-200">Shares Transmitted</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">3000+</div>
                    <div class="text-green-200">Successful Cases</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">95%</div>
                    <div class="text-green-200">Success Rate</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">20-45</div>
                    <div class="text-green-200">Days Processing</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Types of Transmission Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Types of <span class="text-gradient">Share Transmission</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    We handle all types of share transmission cases with expert legal guidance.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Survivorship</h3>
                        <span class="text-xs font-semibold px-2 py-1 rounded-full bg-green-100 text-green-600">Simple</span>
                    </div>
                    <p class="text-secondary-600 mb-4">Transfer to surviving joint holder in case of joint shareholding</p>
                    <div class="mb-4">
                        <h4 class="text-sm font-semibold text-secondary-700 mb-2">Key Documents:</h4>
                        <ul class="space-y-1">
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Death Certificate
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Joint Holding Proof
                            </li>
                        </ul>
                    </div>
                    <div class="text-sm text-green-600 font-semibold">Timeline: 15-20 days</div>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Legal Heir</h3>
                        <span class="text-xs font-semibold px-2 py-1 rounded-full bg-yellow-100 text-yellow-600">Moderate</span>
                    </div>
                    <p class="text-secondary-600 mb-4">Transfer to legal heirs as per succession laws</p>
                    <div class="mb-4">
                        <h4 class="text-sm font-semibold text-secondary-700 mb-2">Key Documents:</h4>
                        <ul class="space-y-1">
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Succession Certificate
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Legal Heir Certificate
                            </li>
                        </ul>
                    </div>
                    <div class="text-sm text-green-600 font-semibold">Timeline: 30-45 days</div>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Will/Testament</h3>
                        <span class="text-xs font-semibold px-2 py-1 rounded-full bg-yellow-100 text-yellow-600">Moderate</span>
                    </div>
                    <p class="text-secondary-600 mb-4">Transfer as per registered will or testament</p>
                    <div class="mb-4">
                        <h4 class="text-sm font-semibold text-secondary-700 mb-2">Key Documents:</h4>
                        <ul class="space-y-1">
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Probate of Will
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Registered Will
                            </li>
                        </ul>
                    </div>
                    <div class="text-sm text-green-600 font-semibold">Timeline: 25-40 days</div>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Court Order</h3>
                        <span class="text-xs font-semibold px-2 py-1 rounded-full bg-red-100 text-red-600">Complex</span>
                    </div>
                    <p class="text-secondary-600 mb-4">Transfer as per court decree in disputed cases</p>
                    <div class="mb-4">
                        <h4 class="text-sm font-semibold text-secondary-700 mb-2">Key Documents:</h4>
                        <ul class="space-y-1">
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Court Decree
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Legal Documentation
                            </li>
                        </ul>
                    </div>
                    <div class="text-sm text-green-600 font-semibold">Timeline: 45-60 days</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Benefits Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Why Choose Our <span class="text-gradient">Transmission Services</span>?
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    We provide compassionate and professional legal support during difficult times.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors duration-300">
                        <svg class="w-8 h-8 text-green-600 group-hover:text-white transition-colors duration-300" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M504.971 199.362l-22.627-22.627c-9.373-9.373-24.569-9.373-33.941 0l-5.657 5.657L329.608 69.255l5.657-5.657c9.373-9.373 9.373-24.569 0-33.941L312.638 7.029c-9.373-9.373-24.569-9.373-33.941 0L154.246 131.48c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l5.657-5.657 39.598 39.598-81.04 81.04-5.657-5.657c-12.497-12.497-32.758-12.497-45.255 0L9.373 412.118c-12.497 12.497-12.497 32.758 0 45.255l45.255 45.255c12.497 12.497 32.758 12.497 45.255 0l114.745-114.745c12.497-12.497 12.497-32.758 0-45.255l-5.657-5.657 81.04-81.04 39.598 39.598-5.657 5.657c-9.373 9.373-9.373 24.569 0 33.941l22.627 22.627c9.373 9.373 24.569 9.373 33.941 0l124.451-124.451c9.372-9.372 9.372-24.568 0-33.941z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-green-600 mb-2">20+ Years Exp</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Legal Expertise</h3>
                    <p class="text-secondary-600">Expert legal team with 20+ years experience in share transmission cases.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors duration-300">
                        <svg class="w-8 h-8 text-green-600 group-hover:text-white transition-colors duration-300" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-green-600 mb-2">20-45 Days</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Quick Processing</h3>
                    <p class="text-secondary-600">Complete transmission process in 20-45 days with proper documentation.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors duration-300">
                        <svg class="w-8 h-8 text-green-600 group-hover:text-white transition-colors duration-300" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-green-600 mb-2">95% Success</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Success Guarantee</h3>
                    <p class="text-secondary-600">95% success rate with our proven legal methodology and documentation.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors duration-300">
                        <svg class="w-8 h-8 text-green-600 group-hover:text-white transition-colors duration-300" fill="currentColor" viewBox="0 0 640 512">
                            <path d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-green-600 mb-2">3000+ Families</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Family Support</h3>
                    <p class="text-secondary-600">Compassionate support during difficult times with dedicated assistance.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section id="process" class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Our <span class="text-gradient">Transmission Process</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Systematic 6-step legal process to ensure smooth transmission of shares to rightful heirs.
                </p>
            </div>

            <div class="space-y-12">
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">01</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Initial Consultation</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">1 Day</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Free consultation to understand your case and assess required documentation.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Death Certificate</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Share Certificates</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Legal Heir Documents</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">01</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">02</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Document Verification</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">3-5 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Verification of all legal documents and preparation of transmission application.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Succession Certificate</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Probate</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Legal Heir Certificate</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">02</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">03</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Legal Documentation</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">5-7 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Preparation of all legal documents including affidavits and indemnity bonds.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Affidavits</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Indemnity Bond</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">NOC from other heirs</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">03</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">04</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Company Filing</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">2-3 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Filing transmission application with company registrar and follow-up.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Transmission Form</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Supporting Documents</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Company Fees</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">04</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">05</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Processing & Approval</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">10-25 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Regular follow-up with company for processing and approval of transmission.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Company Verification</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Board Approval</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Registrar Processing</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">05</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">06</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Share Transfer</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">3-5 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Final transfer of shares to legal heirs with new share certificates.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">New Certificates</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Demat Credit</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Transfer Confirmation</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">06</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Required Documents Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Required <span class="text-gradient">Documents</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Comprehensive list of documents required for different types of share transmission.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Death Related Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Death Certificate (Original)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Medical Certificate</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Hospital Records (if applicable)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Post Mortem Report (if applicable)</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Legal Heir Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Succession Certificate</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Probate of Will</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Legal Heir Certificate</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Family Tree/Genealogy</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Share Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Original Share Certificates</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Dividend Warrants</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Demat Account Statement</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Company Annual Reports</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Identity Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">PAN Card (Deceased & Heirs)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Aadhaar Card (All Heirs)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Passport (if NRI)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Address Proof</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Additional Documents</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Marriage Certificate</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Birth Certificate (Children)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Adoption Certificate (if applicable)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Renunciation Deed (if applicable)</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Success Stories Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Client <span class="text-gradient">Success Stories</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Real stories from families who have successfully completed share transmission with our help.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Sunita Sharma</h4>
                            <p class="text-sm text-secondary-600">Delhi</p>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold text-green-600">₹4.2 Lakhs</div>
                            <div class="text-xs text-secondary-500">Share Value</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">"KMFSL helped us transmit my father's shares smoothly during a difficult time. Their legal team handled everything professionally."</p>
                    <div class="flex items-center justify-between text-xs">
                        <span class="bg-green-100 text-green-600 font-medium px-2 py-1 rounded">Legal Heir Transmission</span>
                        <span class="text-secondary-500">Completed in 35 days</span>
                    </div>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Rajesh Kumar</h4>
                            <p class="text-sm text-secondary-600">Mumbai</p>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold text-green-600">₹2.8 Lakhs</div>
                            <div class="text-xs text-secondary-500">Share Value</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">"Excellent service for share transmission. They guided us through the entire legal process and completed everything on time."</p>
                    <div class="flex items-center justify-between text-xs">
                        <span class="bg-green-100 text-green-600 font-medium px-2 py-1 rounded">Will-based Transmission</span>
                        <span class="text-secondary-500">Completed in 28 days</span>
                    </div>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Priya Patel</h4>
                            <p class="text-sm text-secondary-600">Ahmedabad</p>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold text-green-600">₹6.5 Lakhs</div>
                            <div class="text-xs text-secondary-500">Share Value</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">"Being an NRI, I was worried about the legal complexities. KMFSL made the transmission process hassle-free."</p>
                    <div class="flex items-center justify-between text-xs">
                        <span class="bg-green-100 text-green-600 font-medium px-2 py-1 rounded">NRI Transmission</span>
                        <span class="text-secondary-500">Completed in 42 days</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Frequently Asked <span class="text-gradient">Questions</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Get answers to common questions about share transmission process.
                </p>
            </div>

            <div class="max-w-4xl mx-auto space-y-6">
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: What is transmission of shares?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: Transmission of shares is the transfer of shares from a deceased shareholder to their legal heirs or nominees without any consideration (money exchange).</p>
                </div>
                
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: What documents are required for share transmission?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: Key documents include death certificate, succession certificate or probate, legal heir certificate, original share certificates, and identity proofs of all heirs.</p>
                </div>
                
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: How long does the transmission process take?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: The process typically takes 20-45 days depending on the complexity of the case and completeness of documentation.</p>
                </div>
                
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: Can shares be transmitted without a will?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: Yes, shares can be transmitted without a will through succession certificate or legal heir certificate as per applicable succession laws.</p>
                </div>
                
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: What if there are multiple legal heirs?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: In case of multiple heirs, shares can be transmitted jointly or as per the succession certificate. All heirs need to provide consent and documentation.</p>
                </div>
                
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: Are there any charges for share transmission?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: Companies may charge nominal processing fees. Our service charges are transparent and discussed upfront with no hidden costs.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="section-padding bg-gradient-to-r from-green-600 to-blue-600">
        <div class="container-custom text-center text-white">
            <h2 class="text-4xl font-bold mb-4">Need Help with Share Transmission?</h2>
            <p class="text-xl mb-8 max-w-2xl mx-auto">
                Our legal experts are here to guide you through the entire transmission process with compassion and professionalism during difficult times.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a class="btn-primary bg-white text-green-600 hover:bg-gray-100" href="#consultation">Free Legal Consultation</a>
                <a href="tel:+917070972333" class="btn-secondary border-white text-white hover:bg-white hover:text-green-600">Call Expert: +91 7070972333</a>
            </div>
        </div>
    </section>

    <!-- Consultation Form Section -->
    <section id="consultation" class="section-padding">
        <div class="container-custom">
            <div class="max-w-4xl mx-auto">
                <div class="text-center mb-12">
                    <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                        Get Your <span class="text-gradient">Free Legal Consultation</span>
                    </h2>
                    <p class="text-xl text-secondary-600">
                        Fill out the form below and our legal experts will contact you within 24 hours to discuss your transmission case and provide guidance.
                    </p>
                </div>
                
                <div class="card max-w-4xl mx-auto">
                    <div class="text-center mb-8">
                        <div class="flex justify-center mb-6">
                            <img src="../kmfsl logo svg.svg" alt="KMFSL - Kaimur Financial Services" class="h-24 w-auto">
                        </div>
                        <h3 class="text-2xl font-bold text-secondary-800 mb-2">Share Transmission Consultation</h3>
                        <p class="text-secondary-600">Let our legal experts help you with the transmission process</p>
                    </div>
                    
                    <form class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Full Name *</label>
                                <div class="relative">
                                    <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 448 512">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <input type="text" name="name" class="input-field pl-10" placeholder="Enter your full name" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                                <div class="relative">
                                    <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                                        <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                    </svg>
                                    <input type="email" name="email" class="input-field pl-10" placeholder="Enter your email address" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                                <div class="relative">
                                    <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                    </svg>
                                    <input type="tel" name="phone" class="input-field pl-10" placeholder="Enter your phone number" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Service Required *</label>
                                <select name="service" class="input-field" required>
                                    <option value="">Select a service</option>
                                    <option value="IEPF Claim">IEPF Claim</option>
                                    <option value="Transmission of Shares">Transmission of Shares</option>
                                    <option value="Demat of Physical Shares">Demat of Physical Shares</option>
                                    <option value="Unclaimed Dividends">Unclaimed Dividends</option>
                                    <option value="Conversion of Shares/Debentures">Conversion of Shares/Debentures</option>
                                    <option value="Property Claim Samadhan">Property Claim Samadhan</option>
                                    <option value="Debtor Recovery">Debtor Recovery</option>
                                    <option value="Recovery of Unclaimed Mutual Funds">Recovery of Unclaimed Mutual Funds</option>
                                    <option value="Recovery of Inoperative Bank Accounts">Recovery of Inoperative Bank Accounts</option>
                                    <option value="Provident Funds Claim">Provident Funds Claim</option>
                                    <option value="Recovery of Unclaimed Matured Insurance">Recovery of Unclaimed Matured Insurance</option>
                                    <option value="Wealth Samadhan">Wealth Samadhan</option>
                                    <option value="NRI Samadhan">NRI Samadhan</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Preferred Contact Method</label>
                            <div class="flex space-x-4">
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="email" checked>
                                    Email
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="phone">
                                    Phone
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="whatsapp">
                                    WhatsApp
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Message *</label>
                            <textarea name="message" rows="4" class="input-field resize-none" placeholder="Please describe your requirements or any specific questions you have..." required></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn-primary inline-flex items-center justify-center min-w-[200px]">
                                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 512 512">
                                    <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                                </svg>
                                Send Enquiry
                            </button>
                        </div>
                        <div class="text-center text-sm text-secondary-500">
                            <p>By submitting this form, you agree to our <a href="../privacy-policy.php" class="text-primary-600 hover:underline">Privacy Policy</a> and <a href="../terms-conditions.php" class="text-primary-600 hover:underline">Terms & Conditions</a>.</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- Chatbot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
</body>
</html>