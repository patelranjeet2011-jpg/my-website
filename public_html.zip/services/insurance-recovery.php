<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Recovery - KMFSL | Recover Your Unclaimed Insurance Benefits</title>
    <meta name="description" content="Professional insurance recovery services for life, health, motor, and general insurance policies. Expert assistance with 87% success rate.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Insurance Recovery Hero Section -->
    <section class="section-padding bg-gradient-to-br from-green-50 via-white to-blue-50">
        <div class="container-custom">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                    <div class="inline-flex items-center bg-green-100 text-green-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M575.7 280.8C547.1 144.5 437.3 62.6 320 49.9V32c0-17.7-14.3-32-32-32s-32 14.3-32 32v17.9C138.3 62.6 29.5 144.5.3 280.8c-2.2 10.1 8.5 21.3 18.7 11.4 52-55 107.7-52.4 158.6 37 5.3 9.5 14.9 8.6 19.7 0 20.2-35.4 44.9-73.2 90.7-73.2 58.5 0 88.2 68.8 90.7 73.2 4.8 8.6 14.4 9.5 19.7 0 51-89.5 107.1-91.4 158.6-37 10.3 10 20.9-1.3 18.7-11.4zM256 301.7V432c0 8.8-7.2 16-16 16-7.8 0-13.2-5.3-15.1-10.7-5.9-16.7-24.1-25.4-40.8-19.5-16.7 5.9-25.4 24.2-19.5 40.8 11.2 31.9 41.6 53.3 75.4 53.3 44.1 0 80-35.9 80-80V301.6c-9.1-7.9-19.8-13.6-32-13.6-12.3.1-22.4 4.8-32 13.7z"></path>
                        </svg>
                        Insurance Recovery Service
                    </div>
                    <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                        <span class="text-gradient">Insurance</span> Recovery
                    </h1>
                    <p class="text-xl text-secondary-600 mb-8 leading-relaxed">
                        Recover your unclaimed insurance benefits from matured policies, death claims, and pending settlements. We have successfully recovered ₹45Cr+ in insurance benefits with 87% success rate.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a class="btn-primary" href="/services/insurance-recovery#process">Start Recovery Process</a>
                        <a class="btn-secondary" href="/services/insurance-recovery#consultation">Free Assessment</a>
                    </div>
                </div>
                <div class="relative">
                    <div class="w-full h-96 bg-gradient-to-br from-green-100 to-blue-100 rounded-2xl flex items-center justify-center">
                        <div class="text-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-24 h-24 text-green-600 mx-auto mb-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M575.7 280.8C547.1 144.5 437.3 62.6 320 49.9V32c0-17.7-14.3-32-32-32s-32 14.3-32 32v17.9C138.3 62.6 29.5 144.5.3 280.8c-2.2 10.1 8.5 21.3 18.7 11.4 52-55 107.7-52.4 158.6 37 5.3 9.5 14.9 8.6 19.7 0 20.2-35.4 44.9-73.2 90.7-73.2 58.5 0 88.2 68.8 90.7 73.2 4.8 8.6 14.4 9.5 19.7 0 51-89.5 107.1-91.4 158.6-37 10.3 10 20.9-1.3 18.7-11.4zM256 301.7V432c0 8.8-7.2 16-16 16-7.8 0-13.2-5.3-15.1-10.7-5.9-16.7-24.1-25.4-40.8-19.5-16.7 5.9-25.4 24.2-19.5 40.8 11.2 31.9 41.6 53.3 75.4 53.3 44.1 0 80-35.9 80-80V301.6c-9.1-7.9-19.8-13.6-32-13.6-12.3.1-22.4 4.8-32 13.7z"></path>
                            </svg>
                            <h3 class="text-2xl font-bold text-secondary-800 mb-2">₹45Cr+ Recovered</h3>
                            <p class="text-secondary-600">2000+ Successful Claims</p>
                        </div>
                    </div>
                    <div class="absolute -top-4 -right-4 w-20 h-20 bg-green-500 rounded-full flex items-center justify-center animate-bounce">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-8 h-8 text-white" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                        </svg>
                    </div>
                    <div class="absolute -bottom-4 -left-4 w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center animate-bounce" style="animation-delay: 0.5s;">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" class="w-6 h-6 text-white" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M308 96c6.627 0 12-5.373 12-12V44c0-6.627-5.373-12-12-12H12C5.373 32 0 37.373 0 44v44.748c0 6.627 5.373 12 12 12h85.28c27.308 0 48.261 9.958 60.97 27.252H12c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h158.757c-6.217 36.086-32.961 58.632-74.757 58.632H12c-6.627 0-12 5.373-12 12v53.012c0 3.349 1.4 6.546 3.861 8.818l165.052 152.356a12.001 12.001 0 0 0 8.139 3.182h82.562c10.924 0 16.166-13.408 8.139-20.818L116.871 319.906c76.499-2.34 131.144-53.395 138.318-127.906H308c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-58.69c-3.486-11.541-8.28-22.246-14.252-32H308z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="section-padding bg-green-600">
        <div class="container-custom">
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center text-white">
                <div>
                    <div class="text-3xl font-bold mb-2">₹45Cr+</div>
                    <div class="text-green-200">Insurance Recovered</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">2000+</div>
                    <div class="text-green-200">Successful Claims</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">87%</div>
                    <div class="text-green-200">Success Rate</div>
                </div>
                <div>
                    <div class="text-3xl font-bold mb-2">30-60</div>
                    <div class="text-green-200">Days Processing</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Types of Insurance Recovery Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">Types of <span class="text-gradient">Insurance Recovery</span></h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">We specialize in recovering benefits from all types of insurance policies.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-center mb-4">
                        <div class="text-4xl mb-3 group-hover:scale-110 transition-transform duration-300">👨‍👩‍👧‍👦</div>
                        <h3 class="text-lg font-semibold text-secondary-800 group-hover:text-green-600 transition-colors">Life Insurance</h3>
                    </div>
                    <p class="text-secondary-600 mb-4 text-sm">Matured life insurance policies, endowment plans, and death claims</p>
                    <div class="flex justify-between text-sm mb-4">
                        <div>
                            <span class="text-secondary-500">Avg Recovery:</span>
                            <div class="font-semibold text-green-600">₹4.5L</div>
                        </div>
                        <div>
                            <span class="text-secondary-500">Success Rate:</span>
                            <div class="font-semibold text-green-600">92%</div>
                        </div>
                    </div>
                    <div>
                        <h4 class="text-sm font-semibold text-secondary-700 mb-2">Coverage:</h4>
                        <ul class="space-y-1">
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Maturity Claims
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Death Benefits
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Bonus Payments
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Surrender Value
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-center mb-4">
                        <div class="text-4xl mb-3 group-hover:scale-110 transition-transform duration-300">🏥</div>
                        <h3 class="text-lg font-semibold text-secondary-800 group-hover:text-green-600 transition-colors">Health Insurance</h3>
                    </div>
                    <p class="text-secondary-600 mb-4 text-sm">Unclaimed health insurance benefits and cashless treatment refunds</p>
                    <div class="flex justify-between text-sm mb-4">
                        <div>
                            <span class="text-secondary-500">Avg Recovery:</span>
                            <div class="font-semibold text-green-600">₹85K</div>
                        </div>
                        <div>
                            <span class="text-secondary-500">Success Rate:</span>
                            <div class="font-semibold text-green-600">88%</div>
                        </div>
                    </div>
                    <div>
                        <h4 class="text-sm font-semibold text-secondary-700 mb-2">Coverage:</h4>
                        <ul class="space-y-1">
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Cashless Claims
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Reimbursements
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Critical Illness
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Family Floater
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-center mb-4">
                        <div class="text-4xl mb-3 group-hover:scale-110 transition-transform duration-300">🚗</div>
                        <h3 class="text-lg font-semibold text-secondary-800 group-hover:text-green-600 transition-colors">Motor Insurance</h3>
                    </div>
                    <p class="text-secondary-600 mb-4 text-sm">Vehicle insurance claims, accident benefits, and third-party settlements</p>
                    <div class="flex justify-between text-sm mb-4">
                        <div>
                            <span class="text-secondary-500">Avg Recovery:</span>
                            <div class="font-semibold text-green-600">₹1.2L</div>
                        </div>
                        <div>
                            <span class="text-secondary-500">Success Rate:</span>
                            <div class="font-semibold text-green-600">85%</div>
                        </div>
                    </div>
                    <div>
                        <h4 class="text-sm font-semibold text-secondary-700 mb-2">Coverage:</h4>
                        <ul class="space-y-1">
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Accident Claims
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Third Party
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Own Damage
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Total Loss
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="text-center mb-4">
                        <div class="text-4xl mb-3 group-hover:scale-110 transition-transform duration-300">🏠</div>
                        <h3 class="text-lg font-semibold text-secondary-800 group-hover:text-green-600 transition-colors">General Insurance</h3>
                    </div>
                    <p class="text-secondary-600 mb-4 text-sm">Property, travel, and other general insurance policy benefits</p>
                    <div class="flex justify-between text-sm mb-4">
                        <div>
                            <span class="text-secondary-500">Avg Recovery:</span>
                            <div class="font-semibold text-green-600">₹2.8L</div>
                        </div>
                        <div>
                            <span class="text-secondary-500">Success Rate:</span>
                            <div class="font-semibold text-green-600">83%</div>
                        </div>
                    </div>
                    <div>
                        <h4 class="text-sm font-semibold text-secondary-700 mb-2">Coverage:</h4>
                        <ul class="space-y-1">
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Property Claims
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Travel Insurance
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Fire Claims
                            </li>
                            <li class="text-xs text-secondary-600 flex items-center">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                                </svg>
                                Burglary Claims
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Choose Our Insurance Recovery Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">Why Choose Our <span class="text-gradient">Insurance Recovery</span>?</h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">Our specialized insurance recovery team ensures maximum benefit recovery with professional expertise.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors duration-300">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-8 h-8 text-green-600 group-hover:text-white transition-colors duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M575.7 280.8C547.1 144.5 437.3 62.6 320 49.9V32c0-17.7-14.3-32-32-32s-32 14.3-32 32v17.9C138.3 62.6 29.5 144.5.3 280.8c-2.2 10.1 8.5 21.3 18.7 11.4 52-55 107.7-52.4 158.6 37 5.3 9.5 14.9 8.6 19.7 0 20.2-35.4 44.9-73.2 90.7-73.2 58.5 0 88.2 68.8 90.7 73.2 4.8 8.6 14.4 9.5 19.7 0 51-89.5 107.1-91.4 158.6-37 10.3 10 20.9-1.3 18.7-11.4zM256 301.7V432c0 8.8-7.2 16-16 16-7.8 0-13.2-5.3-15.1-10.7-5.9-16.7-24.1-25.4-40.8-19.5-16.7 5.9-25.4 24.2-19.5 40.8 11.2 31.9 41.6 53.3 75.4 53.3 44.1 0 80-35.9 80-80V301.6c-9.1-7.9-19.8-13.6-32-13.6-12.3.1-22.4 4.8-32 13.7z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-green-600 mb-2">All Types</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">All Policy Types</h3>
                    <p class="text-secondary-600">Recover matured life, health, motor, and general insurance policies.</p>
                </div>
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors duration-300">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-8 h-8 text-green-600 group-hover:text-white transition-colors duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-green-600 mb-2">30-60 Days</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Quick Recovery</h3>
                    <p class="text-secondary-600">Complete insurance recovery process in 30-60 days with expert assistance.</p>
                </div>
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors duration-300">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-8 h-8 text-green-600 group-hover:text-white transition-colors duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-green-600 mb-2">87% Success</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">High Success Rate</h3>
                    <p class="text-secondary-600">87% success rate in recovering unclaimed insurance benefits.</p>
                </div>
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-600 transition-colors duration-300">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 640 512" class="w-8 h-8 text-green-600 group-hover:text-white transition-colors duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M434.7 64h-85.9c-8 0-15.7 3-21.6 8.4l-98.3 90c-.1.1-.2.3-.3.4-16.6 15.6-16.3 40.5-2.1 56 12.7 13.9 39.4 17.6 56.1 2.7.1-.1.3-.1.4-.2l79.9-73.2c6.5-5.9 16.7-5.5 22.6 1 6 6.5 5.5 16.6-1 22.6l-26.1 23.9L504 313.8c2.9 2.4 5.5 5 7.9 7.7V128l-54.6-54.6c-5.9-6-14.1-9.4-22.6-9.4zM544 128.2v223.9c0 17.7 14.3 32 32 32h64V128.2h-96zm48 223.9c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16-7.2 16-16 16zM0 384h64c17.7 0 32-14.3 32-32V128.2H0V384zm48-63.9c8.8 0 16 7.2 16 16s-7.2 16-16 16-16-7.2-16-16c0-8.9 7.2-16 16-16zm435.9 18.6L334.6 217.5l-30 27.5c-29.7 27.1-75.2 24.5-101.7-4.4-26.9-29.4-24.8-74.9 4.4-101.7L289.1 64h-83.8c-8.5 0-16.6 3.4-22.6 9.4L128 128v223.9h18.3l90.5 81.9c27.4 22.3 67.7 18.1 90-9.3l.2-.2 17.9 15.5c15.9 13 39.4 10.5 52.3-5.4l31.4-38.6 5.4 4.4c13.7 11.1 33.9 9.1 45-4.7l9.5-11.7c11.2-13.8 9.1-33.9-4.6-45.1z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-green-600 mb-2">15+ Years Exp</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Insurance Expertise</h3>
                    <p class="text-secondary-600">Specialized team with deep knowledge of insurance regulations.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Recovery Process Section -->
    <section id="process" class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">Our <span class="text-gradient">Recovery Process</span></h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">Systematic 5-step process to recover your unclaimed insurance benefits efficiently.</p>
            </div>
            <div class="space-y-12">
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">01</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Policy Identification</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">3-5 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Identify and locate your unclaimed insurance policies across different companies.</p>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">01</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex items-center lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">02</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Document Collection</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">5-7 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Gather all necessary documents including policy papers, identity proofs, and claim forms.</p>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">02</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">03</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Claim Filing</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">2-3 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Professional filing of insurance claims with proper documentation and legal compliance.</p>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">03</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex items-center lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">04</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Company Processing</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">15-30 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Follow-up with insurance companies for claim processing and approval.</p>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">04</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex items-center lg:flex-row">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">05</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Settlement</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">5-10 Days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Final settlement and disbursement of insurance benefits to your account.</p>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">05</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Required Documents Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">Required <span class="text-gradient">Documents</span></h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">Complete list of documents required for different types of insurance recovery.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Policy Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Original Insurance Policy</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Premium Payment Receipts</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Policy Schedule/Certificate</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Bonus Certificates (if any)</span>
                        </li>
                    </ul>
                </div>
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Identity Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">PAN Card (Policyholder)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Aadhaar Card</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Passport (for NRIs)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Address Proof</span>
                        </li>
                    </ul>
                </div>
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Claim Documents</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Claim Form (Duly Filled)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Death Certificate (if applicable)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Medical Reports</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Hospital Bills/Receipts</span>
                        </li>
                    </ul>
                </div>
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Nominee/Legal Heir</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Nominee Identity Proof</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Legal Heir Certificate</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Succession Certificate</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Family Tree/Relationship Proof</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Client Success Stories Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">Client <span class="text-gradient">Success Stories</span></h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">Real experiences from clients who have successfully recovered their insurance benefits.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Sunita Devi</h4>
                            <p class="text-sm text-secondary-600">Patna</p>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold text-green-600">₹5.2 Lakhs</div>
                            <div class="text-xs text-secondary-500">Recovered</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">"KMFSL helped me recover my husband's life insurance policy that I didn't even know existed. The process was smooth and professional."</p>
                    <div class="flex items-center justify-between text-xs">
                        <span class="bg-green-100 text-green-600 font-medium px-2 py-1 rounded">Life Insurance</span>
                        <span class="text-secondary-500">Completed in 45 days</span>
                    </div>
                </div>
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Ramesh Gupta</h4>
                            <p class="text-sm text-secondary-600">Lucknow</p>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold text-green-600">₹1.8 Lakhs</div>
                            <div class="text-xs text-secondary-500">Recovered</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">"Excellent service for motor insurance claim recovery. They handled all the paperwork and got me the full settlement amount."</p>
                    <div class="flex items-center justify-between text-xs">
                        <span class="bg-green-100 text-green-600 font-medium px-2 py-1 rounded">Motor Insurance</span>
                        <span class="text-secondary-500">Completed in 35 days</span>
                    </div>
                </div>
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Kavita Sharma</h4>
                            <p class="text-sm text-secondary-600">Jaipur</p>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold text-green-600">₹3.5 Lakhs</div>
                            <div class="text-xs text-secondary-500">Recovered</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">"Professional team with great expertise in health insurance claims. They recovered my medical reimbursements efficiently."</p>
                    <div class="flex items-center justify-between text-xs">
                        <span class="bg-green-100 text-green-600 font-medium px-2 py-1 rounded">Health Insurance</span>
                        <span class="text-secondary-500">Completed in 28 days</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">Frequently Asked <span class="text-gradient">Questions</span></h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">Get answers to common questions about insurance recovery process.</p>
            </div>
            <div class="max-w-4xl mx-auto space-y-6">
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: How do I know if I have unclaimed insurance benefits?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: You can check with insurance companies directly, or we can help you search across multiple insurers using your personal details and policy information.</p>
                </div>
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: What types of insurance claims can be recovered?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: We handle all types including life insurance maturity/death claims, health insurance reimbursements, motor insurance claims, and general insurance benefits.</p>
                </div>
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: How long does the insurance recovery process take?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: The process typically takes 30-60 days depending on the insurance company, claim type, and completeness of documentation.</p>
                </div>
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: What if the insurance company has been merged or closed?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: We have expertise in handling claims from merged, acquired, or closed insurance companies through successor entities or regulatory authorities.</p>
                </div>
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: Can I claim insurance benefits of deceased family members?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: Yes, legal heirs and nominees can claim insurance benefits with proper documentation including death certificate and legal heir certificates.</p>
                </div>
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Q: Are there any time limits for claiming insurance benefits?</h3>
                    <p class="text-secondary-600 leading-relaxed">A: While there are statutory time limits, many can be extended with proper justification. We help navigate these requirements effectively.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="section-padding bg-gradient-to-r from-green-600 to-blue-600">
        <div class="container-custom text-center text-white">
            <h2 class="text-4xl font-bold mb-4">Recover Your Insurance Benefits Today!</h2>
            <p class="text-xl mb-8 max-w-2xl mx-auto">Don't let your insurance benefits remain unclaimed. Our expert team is ready to help you recover what's rightfully yours with professional guidance and support.</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a class="btn-primary bg-white text-green-600 hover:bg-gray-100" href="/services/insurance-recovery#consultation">Start Recovery Process</a>
                <a href="tel:+917070972333" class="btn-secondary border-white text-white hover:bg-white hover:text-green-600">Call Expert: +91 7070972333</a>
            </div>
        </div>
    </section>

    <!-- Consultation Form Section -->
    <section id="consultation" class="section-padding">
        <div class="container-custom">
            <div class="max-w-4xl mx-auto">
                <div class="text-center mb-12">
                    <h2 class="text-4xl font-bold text-secondary-800 mb-4">Get Your <span class="text-gradient">Free Insurance Assessment</span></h2>
                    <p class="text-xl text-secondary-600">Fill out the form below and our insurance recovery experts will contact you within 24 hours to assess your case and provide a recovery plan.</p>
                </div>
                <div class="card max-w-4xl mx-auto">
                    <div class="text-center mb-8">
                        <div class="flex justify-center mb-6">
                            <img src="/kmfsl logo svg.svg" alt="KMFSL - Kaimur Financial Services" class="h-24 w-auto">
                        </div>
                        <h3 class="text-2xl font-bold text-secondary-800 mb-2">Insurance Recovery Assessment</h3>
                        <p class="text-secondary-600">Let our experts help you recover your unclaimed insurance benefits</p>
                    </div>
                    <form class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Full Name *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <input type="text" name="name" class="input-field pl-10" placeholder="Enter your full name" value="">
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                    </svg>
                                    <input type="email" name="email" class="input-field pl-10" placeholder="Enter your email address" value="">
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                    </svg>
                                    <input type="tel" name="phone" class="input-field pl-10" placeholder="Enter your phone number" value="">
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Service Required *</label>
                                <select name="service" class="input-field">
                                    <option value="">Select a service</option>
                                    <option value="IEPF Claim">IEPF Claim</option>
                                    <option value="Transmission of Shares">Transmission of Shares</option>
                                    <option value="Demat of Physical Shares">Demat of Physical Shares</option>
                                    <option value="Unclaimed Dividends">Unclaimed Dividends</option>
                                    <option value="Conversion of Shares/Debentures">Conversion of Shares/Debentures</option>
                                    <option value="Property Claim Samadhan">Property Claim Samadhan</option>
                                    <option value="Debtor Recovery">Debtor Recovery</option>
                                    <option value="Recovery of Unclaimed Mutual Funds">Recovery of Unclaimed Mutual Funds</option>
                                    <option value="Recovery of Inoperative Bank Accounts">Recovery of Inoperative Bank Accounts</option>
                                    <option value="Provident Funds Claim">Provident Funds Claim</option>
                                    <option value="Recovery of Unclaimed Matured Insurance">Recovery of Unclaimed Matured Insurance</option>
                                    <option value="Wealth Samadhan">Wealth Samadhan</option>
                                    <option value="NRI Samadhan">NRI Samadhan</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Preferred Contact Method</label>
                            <div class="flex space-x-4">
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="email" checked="">
                                    Email
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="phone">
                                    Phone
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="whatsapp">
                                    WhatsApp
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Message *</label>
                            <textarea name="message" rows="4" class="input-field resize-none" placeholder="Please describe your requirements or any specific questions you have..."></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn-primary inline-flex items-center justify-center min-w-[200px]">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                                </svg>
                                Send Enquiry
                            </button>
                        </div>
                        <div class="text-center text-sm text-secondary-500">
                            <p>By submitting this form, you agree to our <a href="/resources/privacy-policy" class="text-primary-600 hover:underline">Privacy Policy</a> and <a href="/resources/terms-conditions" class="text-primary-600 hover:underline">Terms & Conditions</a>.</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- Chatbot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
</body>
</html>