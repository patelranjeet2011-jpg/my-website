<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Account Recovery - KMFSL | Dormant Account & FD Recovery Services</title>
    <meta name="description" content="Professional bank account recovery services for dormant accounts, unclaimed fixed deposits, and forgotten savings. Expert assistance with 94.5% success rate across 50+ banks.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Bank Account Recovery Hero Section -->
    <section class="section-padding bg-gradient-to-br from-cyan-50 via-white to-blue-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <div class="inline-flex items-center bg-cyan-100 text-cyan-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M496 128v16a8 8 0 0 1-8 8h-24v12c0 6.627-5.373 12-12 12H60c-6.627 0-12-5.373-12-12v-12H24a8 8 0 0 1-8-8v-16a8 8 0 0 1 4.941-7.392l232-88a7.996 7.996 0 0 1 6.118 0l232 88A8 8 0 0 1 496 128zm-24 304H40c-13.255 0-24 10.745-24 24v16a8 8 0 0 0 8 8h464a8 8 0 0 0 8-8v-16c0-13.255-10.745-24-24-24zM96 192v192H60c-6.627 0-12 5.373-12 12v20h416v-20c0-6.627-5.373-12-12-12h-36V192h-64v192h-64V192h-64v192h-64V192H96z"></path>
                    </svg>
                    Professional Bank Account Recovery
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                    Bank Account <span class="text-gradient">Recovery</span>
                </h1>
                <p class="text-xl text-secondary-600 max-w-4xl mx-auto leading-relaxed mb-8">
                    Expert assistance in recovering dormant bank accounts, unclaimed fixed deposits, and forgotten savings. Our specialized team works with 50+ banks to trace and recover your unclaimed banking assets with complete transparency and efficiency.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="#consultation" class="btn-primary inline-flex items-center justify-center">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M505.12019,19.09375c-1.18945-5.53125-6.65819-11-12.207-12.1875C460.716,0,435.507,0,410.40747,0,307.17523,0,245.26909,55.20312,199.05238,128H94.83772c-16.34763.01562-35.55658,11.875-42.88664,26.48438L2.51562,253.29688A28.4,28.4,0,0,0,0,264a24.00867,24.00867,0,0,0,24.00582,24H127.81618l-22.47457,22.46875c-11.36521,11.36133-12.99607,32.25781,0,45.25L156.24582,406.625c11.15623,11.1875,32.15619,13.15625,45.27726,0l22.47457-22.46875V488a24.00867,24.00867,0,0,0,24.00581,24,28.55934,28.55934,0,0,0,10.707-2.51562l98.72834-49.39063c14.62888-7.29687,26.50776-26.5,26.50776-42.85937V312.79688c72.59375-46.3125,128.03125-108.40626,128.03125-211.09376C512.07526,76.5,512.07526,51.29688,505.12019,19.09375ZM384.04033,168A40,40,0,1,1,424.05,128,40.02322,40.02322,0,0,1,384.04033,168Z"></path>
                        </svg>
                        Start Recovery Process
                    </a>
                    <a href="tel:+917070972333" class="btn-secondary inline-flex items-center justify-center">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                        </svg>
                        Call Expert: +91 7070972333
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Recovery Process Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Our Recovery <span class="text-gradient">Process</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Systematic approach to ensure complete bank account recovery with transparency.</p>
            </div>
            <div class="space-y-12">
                <div class="flex flex-col lg:flex-row items-center gap-8">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-cyan-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">1</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Account Search</h3>
                                </div>
                                <span class="bg-cyan-100 text-cyan-600 text-xs font-semibold px-3 py-1 rounded-full">3-5 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Comprehensive search for dormant accounts across all major banks.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">PAN Card</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Aadhaar Card</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Bank Records</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-cyan-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-cyan-600 font-bold">1</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col lg:flex-row items-center gap-8 lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-cyan-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">2</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Account Verification</h3>
                                </div>
                                <span class="bg-cyan-100 text-cyan-600 text-xs font-semibold px-3 py-1 rounded-full">2-4 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Verify account details, balance, and dormancy status with banks.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Identity Verification</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Account Confirmation</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Balance Inquiry</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-cyan-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-cyan-600 font-bold">2</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col lg:flex-row items-center gap-8">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-cyan-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">3</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Documentation</h3>
                                </div>
                                <span class="bg-cyan-100 text-cyan-600 text-xs font-semibold px-3 py-1 rounded-full">3-5 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Prepare required documents and claim applications.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Claim Forms</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">KYC Documents</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Supporting Papers</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-cyan-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-cyan-600 font-bold">3</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col lg:flex-row items-center gap-8 lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-cyan-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">4</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Bank Coordination</h3>
                                </div>
                                <span class="bg-cyan-100 text-cyan-600 text-xs font-semibold px-3 py-1 rounded-full">5-10 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Submit applications and coordinate with bank officials.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Application Submission</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Bank Meetings</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Document Verification</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-cyan-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-cyan-600 font-bold">4</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col lg:flex-row items-center gap-8">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-cyan-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">5</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Account Reactivation</h3>
                                </div>
                                <span class="bg-cyan-100 text-cyan-600 text-xs font-semibold px-3 py-1 rounded-full">5-8 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Reactivate dormant accounts and process fund recovery.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Account Reactivation</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">KYC Update</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Fund Transfer</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-cyan-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-cyan-600 font-bold">5</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col lg:flex-row items-center gap-8 lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-cyan-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">6</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Fund Recovery</h3>
                                </div>
                                <span class="bg-cyan-100 text-cyan-600 text-xs font-semibold px-3 py-1 rounded-full">2-3 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Complete fund recovery and transfer to active account.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Fund Transfer</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Account Closure</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Final Documentation</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-cyan-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-cyan-600 font-bold">6</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Account Coverage Section -->
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Account <span class="text-gradient">Coverage</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Recovery services across all types of bank accounts and deposit schemes.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Savings Accounts</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-cyan-600">3,500+</div>
                            <div class="text-xs text-secondary-500">Cases Handled</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹35,000</div>
                            <div class="text-xs text-secondary-500">Avg Recovery</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Fixed Deposits</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-cyan-600">2,000+</div>
                            <div class="text-xs text-secondary-500">Cases Handled</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹85,000</div>
                            <div class="text-xs text-secondary-500">Avg Recovery</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Recurring Deposits</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-cyan-600">800+</div>
                            <div class="text-xs text-secondary-500">Cases Handled</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹25,000</div>
                            <div class="text-xs text-secondary-500">Avg Recovery</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Current Accounts</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-cyan-600">400+</div>
                            <div class="text-xs text-secondary-500">Cases Handled</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹1,25,000</div>
                            <div class="text-xs text-secondary-500">Avg Recovery</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">NRI Accounts</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-cyan-600">300+</div>
                            <div class="text-xs text-secondary-500">Cases Handled</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹2,15,000</div>
                            <div class="text-xs text-secondary-500">Avg Recovery</div>
                        </div>
                    </div>
                </div>
                <div class="card text-center">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Joint Accounts</h3>
                    <div class="space-y-2">
                        <div>
                            <div class="text-xl font-bold text-cyan-600">600+</div>
                            <div class="text-xs text-secondary-500">Cases Handled</div>
                        </div>
                        <div>
                            <div class="text-lg font-semibold text-secondary-700">₹55,000</div>
                            <div class="text-xs text-secondary-500">Avg Recovery</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Common Issues Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Common <span class="text-gradient">Issues</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">We resolve various bank account related issues with expert guidance.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Forgotten Bank Accounts</h3>
                    <p class="text-secondary-600 mb-4">Accounts opened years ago and forgotten due to relocation or job changes.</p>
                    <div class="bg-cyan-50 rounded-lg p-4">
                        <h4 class="text-sm font-semibold text-cyan-800 mb-2">Our Solution:</h4>
                        <p class="text-cyan-700 text-sm">Systematic search across all banks using PAN and Aadhaar linking.</p>
                    </div>
                </div>
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Dormant Account Status</h3>
                    <p class="text-secondary-600 mb-4">Accounts become dormant due to no transactions for extended periods.</p>
                    <div class="bg-cyan-50 rounded-lg p-4">
                        <h4 class="text-sm font-semibold text-cyan-800 mb-2">Our Solution:</h4>
                        <p class="text-cyan-700 text-sm">Account reactivation through proper KYC updation and documentation.</p>
                    </div>
                </div>
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Matured Deposits</h3>
                    <p class="text-secondary-600 mb-4">Fixed deposits that have matured but remain unclaimed.</p>
                    <div class="bg-cyan-50 rounded-lg p-4">
                        <h4 class="text-sm font-semibold text-cyan-800 mb-2">Our Solution:</h4>
                        <p class="text-cyan-700 text-sm">Identification and recovery of matured deposits with accrued interest.</p>
                    </div>
                </div>
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Deceased Account Access</h3>
                    <p class="text-secondary-600 mb-4">Difficulty in accessing deceased person's bank accounts and deposits.</p>
                    <div class="bg-cyan-50 rounded-lg p-4">
                        <h4 class="text-sm font-semibold text-cyan-800 mb-2">Our Solution:</h4>
                        <p class="text-cyan-700 text-sm">Legal heir process and proper succession documentation.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Required Documents Section -->
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Required <span class="text-gradient">Documents</span></h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Complete list of documents required for bank account recovery process.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Identity Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">PAN Card</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Aadhaar Card</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Passport</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Voter ID</span>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Bank Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Old Passbooks</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Account Statements</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Cheque Books</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Bank Receipts</span>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Address Proof</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Current Address Proof</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Old Address Proof</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Utility Bills</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Rent Agreement</span>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Additional Documents</h3>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Death Certificate</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Legal Heir Certificate</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Succession Certificate</span>
                        </div>
                        <div class="flex items-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-secondary-600 text-sm">Nomination Forms</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Choose KMFSL Section -->
    <section class="section-padding bg-gradient-to-br from-cyan-50 to-blue-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">Why Choose <span class="text-gradient">KMFSL</span>?</h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">Experience the difference with our professional bank account recovery services.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="bg-white rounded-xl shadow-lg p-6 text-center hover:shadow-xl transition-all duration-300">
                    <div class="w-16 h-16 bg-cyan-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-8 h-8 text-cyan-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M496 128v16a8 8 0 0 1-8 8h-24v12c0 6.627-5.373 12-12 12H60c-6.627 0-12-5.373-12-12v-12H24a8 8 0 0 1-8-8v-16a8 8 0 0 1 4.941-7.392l232-88a7.996 7.996 0 0 1 6.118 0l232 88A8 8 0 0 1 496 128zm-24 304H40c-13.255 0-24 10.745-24 24v16a8 8 0 0 0 8 8h464a8 8 0 0 0 8-8v-16c0-13.255-10.745-24-24-24zM96 192v192H60c-6.627 0-12 5.373-12 12v20h416v-20c0-6.627-5.373-12-12-12h-36V192h-64v192h-64V192h-64v192h-64V192H96z"></path>
                        </svg>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Comprehensive Bank Network</h3>
                    <p class="text-secondary-600 text-sm">Coverage across 50+ banks including public, private, and cooperative banks.</p>
                </div>
                <div class="bg-white rounded-xl shadow-lg p-6 text-center hover:shadow-xl transition-all duration-300">
                    <div class="w-16 h-16 bg-cyan-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 640 512" class="w-8 h-8 text-cyan-600" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path>
                        </svg>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Expert Bank Relations</h3>