<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unclaimed Dividends Recovery Services - KMFSL | Recover Your Dividends</title>
    <meta name="description" content="Recover your unclaimed dividends from equity shares, mutual funds, preference shares, and debentures. We have recovered ₹35+ Crores with 96.8% success rate.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>
    
    <!-- Unclaimed Dividends Hero Section -->
    <section class="section-padding bg-gradient-to-br from-green-50 via-white to-blue-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <div class="inline-flex items-center bg-green-100 text-green-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                    <svg class="mr-2 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                        <path d="M0 405.3V448c0 35.3 86 64 192 64s192-28.7 192-64v-42.7C342.7 434.4 267.2 448 192 448S41.3 434.4 0 405.3zM320 128c106 0 192-28.7 192-64S426 0 320 0 128 28.7 128 64s86 64 192 64zM0 300.4V352c0 35.3 86 64 192 64s192-28.7 192-64v-51.6c-41.3 34-116.9 51.6-192 51.6S41.3 334.4 0 300.4zm416 11c57.3-11.1 96-31.7 96-55.4v-42.7c-23.2 16.4-57.3 27.6-96 34.5v63.6zM192 160C86 160 0 195.8 0 240s86 80 192 80 192-35.8 192-80-86-80-192-80zm219.3 56.3c60-10.8 100.7-32 100.7-56.3v-42.7c-35.5 25.1-96.5 38.6-160.7 41.8 29.5 14.3 51.2 33.5 60 57.2z"></path>
                    </svg>
                    Unclaimed Dividend Recovery
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                    Recover Your <span class="text-gradient">Unclaimed Dividends</span>
                </h1>
                <p class="text-xl text-secondary-600 max-w-4xl mx-auto leading-relaxed mb-8">
                    Don't let your hard-earned dividends remain unclaimed! Our expert team helps you recover unclaimed dividends from equity shares, mutual funds, preference shares, and debentures with a proven 96.8% success rate.
                </p>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg class="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M0 405.3V448c0 35.3 86 64 192 64s192-28.7 192-64v-42.7C342.7 434.4 267.2 448 192 448S41.3 434.4 0 405.3zM320 128c106 0 192-28.7 192-64S426 0 320 0 128 28.7 128 64s86 64 192 64zM0 300.4V352c0 35.3 86 64 192 64s192-28.7 192-64v-51.6c-41.3 34-116.9 51.6-192 51.6S41.3 334.4 0 300.4zm416 11c57.3-11.1 96-31.7 96-55.4v-42.7c-23.2 16.4-57.3 27.6-96 34.5v63.6zM192 160C86 160 0 195.8 0 240s86 80 192 80 192-35.8 192-80-86-80-192-80zm219.3 56.3c60-10.8 100.7-32 100.7-56.3v-42.7c-35.5 25.1-96.5 38.6-160.7 41.8 29.5 14.3 51.2 33.5 60 57.2z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">₹35+ Crores</div>
                        <div class="text-sm text-secondary-600">Dividends Recovered</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg class="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 640 512">
                                <path d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">4,200+</div>
                        <div class="text-sm text-secondary-600">Successful Claims</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg class="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 384 512">
                                <path d="M97.12 362.63c-8.69-8.69-4.16-6.24-25.12-11.85-9.51-2.55-17.87-7.45-25.43-13.32L1.2 448.7c-4.39 10.77 3.81 22.47 15.43 22.03l52.69-2.01L105.56 507c8 8.44 22.04 5.81 26.43-4.96l52.05-127.62c-10.84 6.04-22.87 9.58-35.31 9.58-19.5 0-37.82-7.59-51.61-21.37zM382.8 448.7l-45.37-111.24c-7.56 5.88-15.92 10.77-25.43 13.32-21.07 5.64-16.45 3.18-25.12 11.85-13.79 13.78-32.12 21.37-51.62 21.37-12.44 0-24.47-3.55-35.31-9.58L252 502.04c4.39 10.77 18.44 13.4 26.43 4.96l36.25-38.28 52.69 2.01c11.62.44 19.82-11.27 15.43-22.03zM263 340c15.28-15.55 17.03-14.21 38.79-20.14 13.89-3.79 24.75-14.84 28.47-28.98 7.48-28.4 5.54-24.97 25.95-45.75 10.17-10.35 14.14-25.44 10.42-39.58-7.47-28.38-7.48-24.42 0-52.83 3.72-14.14-.25-29.23-10.42-39.58-20.41-20.78-18.47-17.36-25.95-45.75-3.72-14.14-14.58-25.19-28.47-28.98-27.88-7.61-24.52-5.62-44.95-26.41-10.17-10.35-25-14.4-38.89-10.61-27.87 7.6-23.98 7.61-51.9 0-13.89-3.79-28.72.25-38.89 10.61-20.41 20.78-17.05 18.8-44.94 26.41-13.89 3.79-24.75 14.84-28.47 28.98-7.47 28.39-5.54 24.97-25.95 45.75-10.17 10.35-14.15 25.44-10.42 39.58 7.47 28.36 7.48 24.4 0 52.82-3.72 14.14.25 29.23 10.42 39.59 20.41 20.78 18.47 17.35 25.95 45.75 3.72 14.14 14.58 25.19 28.47 28.98C104.6 325.96 106.27 325 121 340c13.23 13.47 33.84 15.88 49.74 5.82a39.676 39.676 0 0 1 42.53 0c15.89 10.06 36.5 7.65 49.73-5.82zM97.66 175.96c0-53.03 42.24-96.02 94.34-96.02s94.34 42.99 94.34 96.02-42.24 96.02-94.34 96.02-94.34-42.99-94.34-96.02z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">96.8%</div>
                        <div class="text-sm text-secondary-600">Success Rate</div>
                    </div>
                    <div class="bg-white rounded-xl p-6 shadow-lg">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg class="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                            </svg>
                        </div>
                        <div class="text-2xl font-bold text-secondary-800 mb-1">15 Days</div>
                        <div class="text-sm text-secondary-600">Average Processing</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Types of Unclaimed Dividends Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                    Types of <span class="text-gradient">Unclaimed Dividends</span>
                </h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">
                    We help recover various types of unclaimed dividends and interest payments from different investment instruments.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z"></path>
                        </svg>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 text-center">Equity Dividends</h3>
                    <p class="text-secondary-600 text-sm mb-4 text-center">Unclaimed dividends from equity shares of listed companies.</p>
                    <div class="text-center mb-4">
                        <span class="bg-green-100 text-green-600 text-sm font-semibold px-3 py-1 rounded-full">₹18Cr+ Recovered</span>
                    </div>
                    <div class="space-y-2">
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Final Dividends</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Interim Dividends</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Special Dividends</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Bonus Dividends</span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M0 405.3V448c0 35.3 86 64 192 64s192-28.7 192-64v-42.7C342.7 434.4 267.2 448 192 448S41.3 434.4 0 405.3zM320 128c106 0 192-28.7 192-64S426 0 320 0 128 28.7 128 64s86 64 192 64zM0 300.4V352c0 35.3 86 64 192 64s192-28.7 192-64v-51.6c-41.3 34-116.9 51.6-192 51.6S41.3 334.4 0 300.4zm416 11c57.3-11.1 96-31.7 96-55.4v-42.7c-23.2 16.4-57.3 27.6-96 34.5v63.6zM192 160C86 160 0 195.8 0 240s86 80 192 80 192-35.8 192-80-86-80-192-80zm219.3 56.3c60-10.8 100.7-32 100.7-56.3v-42.7c-35.5 25.1-96.5 38.6-160.7 41.8 29.5 14.3 51.2 33.5 60 57.2z"></path>
                        </svg>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 text-center">Mutual Fund Dividends</h3>
                    <p class="text-secondary-600 text-sm mb-4 text-center">Unclaimed dividend distributions from mutual fund investments.</p>
                    <div class="text-center mb-4">
                        <span class="bg-green-100 text-green-600 text-sm font-semibold px-3 py-1 rounded-full">₹8Cr+ Recovered</span>
                    </div>
                    <div class="space-y-2">
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Equity Fund Dividends</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Debt Fund Dividends</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Hybrid Fund Dividends</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>ELSS Dividends</span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 512 512">
                            <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                        </svg>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 text-center">Preference Dividends</h3>
                    <p class="text-secondary-600 text-sm mb-4 text-center">Unclaimed dividends from preference shares and cumulative preferences.</p>
                    <div class="text-center mb-4">
                        <span class="bg-green-100 text-green-600 text-sm font-semibold px-3 py-1 rounded-full">₹5Cr+ Recovered</span>
                    </div>
                    <div class="space-y-2">
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Cumulative Preference</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Non-Cumulative Preference</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Redeemable Preference</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Convertible Preference</span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 448 512">
                            <path d="M400 0H48C22.4 0 0 22.4 0 48v416c0 25.6 22.4 48 48 48h352c25.6 0 48-22.4 48-48V48c0-25.6-22.4-48-48-48zM128 435.2c0 6.4-6.4 12.8-12.8 12.8H76.8c-6.4 0-12.8-6.4-12.8-12.8v-38.4c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v38.4zm0-128c0 6.4-6.4 12.8-12.8 12.8H76.8c-6.4 0-12.8-6.4-12.8-12.8v-38.4c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v38.4zm128 128c0 6.4-6.4 12.8-12.8 12.8h-38.4c-6.4 0-12.8-6.4-12.8-12.8v-38.4c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v38.4zm0-128c0 6.4-6.4 12.8-12.8 12.8h-38.4c-6.4 0-12.8-6.4-12.8-12.8v-38.4c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v38.4zm128 128c0 6.4-6.4 12.8-12.8 12.8h-38.4c-6.4 0-12.8-6.4-12.8-12.8V268.8c0-6.4 6.4-12.8 12.8-12.8h38.4c6.4 0 12.8 6.4 12.8 12.8v166.4zm0-256c0 6.4-6.4 12.8-12.8 12.8H76.8c-6.4 0-12.8-6.4-12.8-12.8V76.8C64 70.4 70.4 64 76.8 64h294.4c6.4 0 12.8 6.4 12.8 12.8v102.4z"></path>
                        </svg>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 text-center">Debenture Interest</h3>
                    <p class="text-secondary-600 text-sm mb-4 text-center">Unclaimed interest payments from debentures and bonds.</p>
                    <div class="text-center mb-4">
                        <span class="bg-green-100 text-green-600 text-sm font-semibold px-3 py-1 rounded-full">₹4Cr+ Recovered</span>
                    </div>
                    <div class="space-y-2">
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Corporate Bonds</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Government Securities</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Tax-Free Bonds</span>
                        </div>
                        <div class="flex items-center text-xs text-secondary-600">
                            <svg class="w-3 h-3 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span>Infrastructure Bonds</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Dividend Recovery Process Section -->
    <section class="section-padding bg-white">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                    Our Dividend Recovery <span class="text-gradient">Process</span>
                </h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">
                    Simple, systematic, and transparent process to recover your unclaimed dividends.
                </p>
            </div>

            <div class="space-y-12">
                <div class="flex flex-col lg:flex-row items-center gap-8">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">1</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Dividend Search</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">1-2 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">We search for your unclaimed dividends across multiple databases and registrars.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">PAN Card</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Folio Numbers</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Company Names</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">1</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex flex-col lg:flex-row items-center gap-8 lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">2</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Verification & Documentation</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">2-3 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Verify dividend entitlements and prepare necessary claim documents.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Identity Proof</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Address Proof</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Bank Details</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">2</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex flex-col lg:flex-row items-center gap-8">
                    <div class="w-full lg:w-1/2 lg:pr-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">3</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Claim Submission</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">1-2 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Submit claims to respective companies and registrars with proper documentation.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Signed Forms</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Supporting Documents</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Authorization</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">3</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex flex-col lg:flex-row items-center gap-8 lg:flex-row-reverse">
                    <div class="w-full lg:w-1/2 lg:pl-12">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center text-lg font-bold mr-4">4</div>
                                    <h3 class="text-xl font-semibold text-secondary-800">Follow-up & Recovery</h3>
                                </div>
                                <span class="bg-green-100 text-green-600 text-xs font-semibold px-3 py-1 rounded-full">10-20 days</span>
                            </div>
                            <p class="text-secondary-600 mb-4">Regular follow-up with companies until dividend amount is credited to your account.</p>
                            <div>
                                <h4 class="text-sm font-semibold text-secondary-700 mb-2">Requirements:</h4>
                                <div class="flex flex-wrap gap-2">
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Bank Account</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Regular Updates</span>
                                    <span class="bg-gray-100 text-secondary-600 text-xs font-medium px-2 py-1 rounded">Final Verification</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden lg:block w-1/2">
                        <div class="text-center">
                            <div class="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                                <span class="text-4xl text-green-600 font-bold">4</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Required Documents Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                    Required <span class="text-gradient">Documents</span>
                </h2>
                <p class="text-lg text-secondary-600 max-w-2xl mx-auto">
                    Complete list of documents required for smooth dividend recovery process.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-secondary-800">Identity Documents</h3>
                        <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Passport</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Voter ID</span>
                         </div>
                     </div>
                 </div>
                 
                 <div class="card">
                     <div class="flex items-center justify-between mb-4">
                         <h3 class="text-lg font-semibold text-secondary-800">Investment Proof</h3>
                         <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                     </div>
                     <div class="space-y-3">
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Share Certificates</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Demat Statements</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Folio Statements</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Purchase Receipts</span>
                         </div>
                     </div>
                 </div>
                 
                 <div class="card">
                     <div class="flex items-center justify-between mb-4">
                         <h3 class="text-lg font-semibold text-secondary-800">Banking Details</h3>
                         <span class="bg-red-100 text-red-600 text-xs font-semibold px-2 py-1 rounded-full">Mandatory</span>
                     </div>
                     <div class="space-y-3">
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Bank Passbook</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Cancelled Cheque</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Bank Statement</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">IFSC Details</span>
                         </div>
                     </div>
                 </div>
                 
                 <div class="card">
                     <div class="flex items-center justify-between mb-4">
                         <h3 class="text-lg font-semibold text-secondary-800">Additional Documents</h3>
                     </div>
                     <div class="space-y-3">
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Address Proof</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Signature Verification</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Nomination Forms</span>
                         </div>
                         <div class="flex items-center">
                             <svg class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                             </svg>
                             <span class="text-secondary-600 text-sm">Power of Attorney</span>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </section>

     <!-- Why Choose KMFSL Section -->
     <section class="section-padding bg-white">
         <div class="container-custom">
             <div class="text-center mb-16">
                 <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                     Why Choose <span class="text-gradient">KMFSL</span>?
                 </h2>
                 <p class="text-lg text-secondary-600 max-w-2xl mx-auto">
                     Experience the difference with our professional dividend recovery services.
                 </p>
             </div>

             <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                 <div class="card text-center hover:shadow-xl transition-all duration-300">
                     <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                         <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 640 512">
                             <path d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path>
                         </svg>
                     </div>
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Expert Assistance</h3>
                     <p class="text-secondary-600 text-sm">Professional guidance from experienced dividend recovery specialists.</p>
                 </div>
                 
                 <div class="card text-center hover:shadow-xl transition-all duration-300">
                     <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                         <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 384 512">
                             <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm64 236c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-64c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-72v8c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12zm96-114.1v6.1H256V0h6.1c6.4 0 12.5 2.5 17 7l97.9 98c4.5 4.5 7 10.6 7 16.9z"></path>
                         </svg>
                     </div>
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Complete Documentation</h3>
                     <p class="text-secondary-600 text-sm">We handle all paperwork and documentation requirements for you.</p>
                 </div>
                 
                 <div class="card text-center hover:shadow-xl transition-all duration-300">
                     <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                         <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 512 512">
                             <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"></path>
                         </svg>
                     </div>
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Fast Processing</h3>
                     <p class="text-secondary-600 text-sm">Quick turnaround time with regular updates on claim status.</p>
                 </div>
                 
                 <div class="card text-center hover:shadow-xl transition-all duration-300">
                     <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                         <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 384 512">
                             <path d="M97.12 362.63c-8.69-8.69-4.16-6.24-25.12-11.85-9.51-2.55-17.87-7.45-25.43-13.32L1.2 448.7c-4.39 10.77 3.81 22.47 15.43 22.03l52.69-2.01L105.56 507c8 8.44 22.04 5.81 26.43-4.96l52.05-127.62c-10.84 6.04-22.87 9.58-35.31 9.58-19.5 0-37.82-7.59-51.61-21.37zM382.8 448.7l-45.37-111.24c-7.56 5.88-15.92 10.77-25.43 13.32-21.07 5.64-16.45 3.18-25.12 11.85-13.79 13.78-32.12 21.37-51.62 21.37-12.44 0-24.47-3.55-35.31-9.58L252 502.04c4.39 10.77 18.44 13.4 26.43 4.96l36.25-38.28 52.69 2.01c11.62.44 19.82-11.27 15.43-22.03zM263 340c15.28-15.55 17.03-14.21 38.79-20.14 13.89-3.79 24.75-14.84 28.47-28.98 7.48-28.4 5.54-24.97 25.95-45.75 10.17-10.35 14.14-25.44 10.42-39.58-7.47-28.38-7.48-24.42 0-52.83 3.72-14.14-.25-29.23-10.42-39.58-20.41-20.78-18.47-17.36-25.95-45.75-3.72-14.14-14.58-25.19-28.47-28.98-27.88-7.61-24.52-5.62-44.95-26.41-10.17-10.35-25-14.4-38.89-10.61-27.87 7.6-23.98 7.61-51.9 0-13.89-3.79-28.72.25-38.89 10.61-20.41 20.78-17.05 18.8-44.94 26.41-13.89 3.79-24.75 14.84-28.47 28.98-7.47 28.39-5.54 24.97-25.95 45.75-10.17 10.35-14.15 25.44-10.42 39.58 7.47 28.36 7.48 24.4 0 52.82-3.72 14.14.25 29.23 10.42 39.59 20.41 20.78 18.47 17.35 25.95 45.75 3.72 14.14 14.58 25.19 28.47 28.98C104.6 325.96 106.27 325 121 340c13.23 13.47 33.84 15.88 49.74 5.82a39.676 39.676 0 0 1 42.53 0c15.89 10.06 36.5 7.65 49.73-5.82zM97.66 175.96c0-53.03 42.24-96.02 94.34-96.02s94.34 42.99 94.34 96.02-42.24 96.02-94.34 96.02-94.34-42.99-94.34-96.02z"></path>
                         </svg>
                     </div>
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">High Success Rate</h3>
                     <p class="text-secondary-600 text-sm">96.8% success rate in recovering unclaimed dividends for our clients.</p>
                 </div>
                 
                 <div class="card text-center hover:shadow-xl transition-all duration-300">
                     <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                         <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 640 512">
                             <path d="M434.7 64h-85.9c-8 0-15.7 3-21.6 8.4l-98.3 90c-.1.1-.2.3-.3.4-16.6 15.6-16.3 40.5-2.1 56 12.7 13.9 39.4 17.6 56.1 2.7.1-.1.3-.1.4-.2l79.9-73.2c6.5-5.9 16.7-5.5 22.6 1 6 6.5 5.5 16.6-1 22.6l-26.1 23.9L504 313.8c2.9 2.4 5.5 5 7.9 7.7V128l-54.6-54.6c-5.9-6-14.1-9.4-22.6-9.4zM544 128.2v223.9c0 17.7 14.3 32 32 32h64V128.2h-96zm48 223.9c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16-7.2 16-16 16zM0 384h64c17.7 0 32-14.3 32-32V128.2H0V384zm48-63.9c8.8 0 16 7.2 16 16s-7.2 16-16 16-16-7.2-16-16c0-8.9 7.2-16 16-16zm435.9 18.6L334.6 217.5l-30 27.5c-29.7 27.1-75.2 24.5-101.7-4.4-26.9-29.4-24.8-74.9 4.4-101.7L289.1 64h-83.8c-8.5 0-16.6 3.4-22.6 9.4L128 128v223.9h18.3l90.5 81.9c27.4 22.3 67.7 18.1 90-9.3l.2-.2 17.9 15.5c15.9 13 39.4 10.5 52.3-5.4l31.4-38.6 5.4 4.4c13.7 11.1 33.9 9.1 45-4.7l9.5-11.7c11.2-13.8 9.1-33.9-4.6-45.1z"></path>
                         </svg>
                     </div>
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">No Hidden Charges</h3>
                     <p class="text-secondary-600 text-sm">Transparent fee structure with no hidden costs or surprise charges.</p>
                 </div>
                 
                 <div class="card text-center hover:shadow-xl transition-all duration-300">
                     <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                         <svg class="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 496 512">
                             <path d="M336.5 160C322 70.7 287.8 8 248 8s-74 62.7-88.5 152h177zM152 256c0 22.2 1.2 43.5 3.3 64h185.3c2.1-20.5 3.3-41.8 3.3-64s-1.2-43.5-3.3-64H155.3c-2.1 20.5-3.3 41.8-3.3 64zm324.7-96c-28.6-67.9-86.5-120.4-158-141.6 24.4 33.8 41.2 84.7 50 141.6h108zM177.2 18.4C105.8 39.6 47.8 92.1 19.3 160h108c8.7-56.9 25.5-107.8 49.9-141.6zM487.4 192H372.7c2.1 21 3.3 42.5 3.3 64s-1.2 43-3.3 64h114.6c5.5-20.5 8.6-41.8 8.6-64s-3.1-43.5-8.5-64zM120 256c0-21.5 1.2-43 3.3-64H8.6C3.2 212.5 0 233.8 0 256s3.2 43.5 8.6 64h114.6c-2-21-3.2-42.5-3.2-64zm39.5 96c14.5 89.3 48.7 152 88.5 152s74-62.7 88.5-152h-177zm159.3 141.6c71.4-21.2 129.4-73.7 158-141.6h-108c-8.8 56.9-25.6 107.8-50 141.6zM19.3 352c28.6 67.9 86.5 120.4 158 141.6-24.4-33.8-41.2-84.7-50-141.6h-108z"></path>
                         </svg>
                     </div>
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">Pan-India Service</h3>
                     <p class="text-secondary-600 text-sm">Serving clients across India with specialized support for NRIs.</p>
                 </div>
             </div>
         </div>
     </section>

     <!-- Success Stories Section -->
     <section class="section-padding bg-gradient-to-br from-green-50 to-blue-50">
         <div class="container-custom">
             <div class="text-center mb-16">
                 <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                     Client <span class="text-gradient">Success Stories</span>
                 </h2>
                 <p class="text-lg text-secondary-600 max-w-2xl mx-auto">
                     Real experiences from clients who recovered their unclaimed dividends with our help.
                 </p>
             </div>

             <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                 <div class="bg-white rounded-xl p-6 shadow-lg">
                     <div class="flex items-center justify-between mb-4">
                         <div>
                             <h4 class="font-semibold text-secondary-800">Rajesh Kumar</h4>
                             <p class="text-sm text-secondary-600">Mumbai</p>
                         </div>
                         <div class="text-right">
                             <div class="text-lg font-bold text-green-600">₹2,45,000</div>
                             <div class="text-xs text-secondary-500">Recovered</div>
                         </div>
                     </div>
                     <p class="text-secondary-700 text-sm mb-4 italic">"KMFSL helped me recover dividends from 8 different companies. Their systematic approach and regular updates made the entire process smooth."</p>
                     <div class="flex text-yellow-400">
                         <span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span>
                     </div>
                 </div>
                 
                 <div class="bg-white rounded-xl p-6 shadow-lg">
                     <div class="flex items-center justify-between mb-4">
                         <div>
                             <h4 class="font-semibold text-secondary-800">Priya Sharma</h4>
                             <p class="text-sm text-secondary-600">Delhi</p>
                         </div>
                         <div class="text-right">
                             <div class="text-lg font-bold text-green-600">₹1,85,000</div>
                             <div class="text-xs text-secondary-500">Recovered</div>
                         </div>
                     </div>
                     <p class="text-secondary-700 text-sm mb-4 italic">"I had forgotten about my mutual fund dividends for years. KMFSL not only found them but also recovered the entire amount within 3 weeks."</p>
                     <div class="flex text-yellow-400">
                         <span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span>
                     </div>
                 </div>
                 
                 <div class="bg-white rounded-xl p-6 shadow-lg">
                     <div class="flex items-center justify-between mb-4">
                         <div>
                             <h4 class="font-semibold text-secondary-800">Dr. Suresh Patel</h4>
                             <p class="text-sm text-secondary-600">Ahmedabad</p>
                         </div>
                         <div class="text-right">
                             <div class="text-lg font-bold text-green-600">₹3,20,000</div>
                             <div class="text-xs text-secondary-500">Recovered</div>
                         </div>
                     </div>
                     <p class="text-secondary-700 text-sm mb-4 italic">"Professional service with complete transparency. They recovered dividends from companies I had invested in 15 years ago."</p>
                     <div class="flex text-yellow-400">
                         <span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span>
                     </div>
                 </div>
             </div>
         </div>
     </section>

     <!-- FAQ Section -->
     <section class="section-padding bg-white">
         <div class="container-custom">
             <div class="text-center mb-16">
                 <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                     Frequently Asked <span class="text-gradient">Questions</span>
                 </h2>
                 <p class="text-lg text-secondary-600 max-w-2xl mx-auto">
                     Common questions about unclaimed dividend recovery process.
                 </p>
             </div>

             <div class="max-w-4xl mx-auto space-y-6">
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">What are unclaimed dividends?</h3>
                     <p class="text-secondary-600">Unclaimed dividends are dividend payments that have not been collected by shareholders within the specified time period, usually 7 years, after which they are transferred to IEPF.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">How do I know if I have unclaimed dividends?</h3>
                     <p class="text-secondary-600">You can check for unclaimed dividends by searching company websites, registrar databases, or using our free dividend search service with your PAN and folio details.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">What is the time limit for claiming dividends?</h3>
                     <p class="text-secondary-600">Dividends can be claimed within 7 years from the date of declaration. After 7 years, they are transferred to IEPF and require a separate recovery process.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">What documents are required for dividend claims?</h3>
                     <p class="text-secondary-600">Basic documents include PAN card, identity proof, address proof, bank details, and investment proof such as share certificates or demat statements.</p>
                 </div>
                 
                 <div class="card">
                     <h3 class="text-lg font-semibold text-secondary-800 mb-3">How long does the dividend recovery process take?</h3>
                     <p class="text-secondary-600">The process typically takes 15-25 days depending on the company response and documentation completeness. We provide regular updates throughout the process.</p>
                 </div>
             </div>
         </div>
     </section>

     <!-- CTA Section -->
     <section class="section-padding bg-gradient-to-r from-green-600 to-blue-600">
         <div class="container-custom text-center text-white">
             <h2 class="text-3xl font-bold mb-4">Ready to Recover Your Unclaimed Dividends?</h2>
             <p class="text-xl mb-8 max-w-2xl mx-auto">
                 Join 4,200+ satisfied clients who have recovered ₹35+ Crores in unclaimed dividends. Get started with a free dividend search today.
             </p>
             <div class="flex flex-col sm:flex-row gap-4 justify-center">
                 <a class="bg-white text-green-600 py-3 px-6 rounded-lg font-semibold hover:bg-gray-100 transition-colors" href="#consultation">Start Free Search</a>
                 <a href="tel:+917070972333" class="border-2 border-white text-white py-3 px-6 rounded-lg font-semibold hover:bg-white hover:text-green-600 transition-colors">Call Expert: +91 7070972333</a>
             </div>
         </div>
     </section>

     <!-- Consultation Form Section -->
     <section id="consultation" class="section-padding bg-gray-50">
         <div class="container-custom">
             <div class="text-center mb-12">
                 <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                     Get Expert <span class="text-gradient">Dividend Recovery Assistance</span>
                 </h2>
                 <p class="text-lg text-secondary-600 max-w-2xl mx-auto">
                     Start your dividend recovery process today. Our experts will search and recover your unclaimed dividends.
                 </p>
             </div>
             
             <div class="card max-w-4xl mx-auto">
                 <div class="text-center mb-8">
                     <div class="flex justify-center mb-6">
                         <img src="../kmfsl logo svg.svg" alt="KMFSL - Kaimur Financial Services" class="h-24 w-auto">
                     </div>
                     <h3 class="text-2xl font-bold text-secondary-800 mb-2">Send us your enquiry</h3>
                     <p class="text-secondary-600">We'll get back to you within 24 hours</p>
                 </div>
                 
                 <form class="space-y-6">
                     <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                         <div>
                             <label class="block text-sm font-medium text-secondary-700 mb-2">Full Name *</label>
                             <div class="relative">
                                 <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 448 512">
                                     <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                 </svg>
                                 <input type="text" name="name" class="input-field pl-10" placeholder="Enter your full name" required>
                             </div>
                         </div>
                         <div>
                             <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                             <div class="relative">
                                 <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                                     <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                 </svg>
                                 <input type="email" name="email" class="input-field pl-10" placeholder="Enter your email address" required>
                             </div>
                         </div>
                         <div>
                             <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                             <div class="relative">
                                 <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" fill="currentColor" viewBox="0 0 512 512">
                                     <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                 </svg>
                                 <input type="tel" name="phone" class="input-field pl-10" placeholder="Enter your phone number" required>
                             </div>
                         </div>
                         <div>
                             <label class="block text-sm font-medium text-secondary-700 mb-2">Service Required *</label>
                             <select name="service" class="input-field" required>
                                 <option value="">Select a service</option>
                                 <option value="IEPF Claim">IEPF Claim</option>
                                 <option value="Transmission of Shares">Transmission of Shares</option>
                                 <option value="Demat of Physical Shares">Demat of Physical Shares</option>
                                 <option value="Unclaimed Dividends">Unclaimed Dividends</option>
                                 <option value="Conversion of Shares/Debentures">Conversion of Shares/Debentures</option>
                                 <option value="Property Claim Samadhan">Property Claim Samadhan</option>
                                 <option value="Debtor Recovery">Debtor Recovery</option>
                                 <option value="Recovery of Unclaimed Mutual Funds">Recovery of Unclaimed Mutual Funds</option>
                                 <option value="Recovery of Inoperative Bank Accounts">Recovery of Inoperative Bank Accounts</option>
                                 <option value="Provident Funds Claim">Provident Funds Claim</option>
                                 <option value="Recovery of Unclaimed Matured Insurance">Recovery of Unclaimed Matured Insurance</option>
                                 <option value="Wealth Samadhan">Wealth Samadhan</option>
                                 <option value="NRI Samadhan">NRI Samadhan</option>
                                 <option value="Other">Other</option>
                             </select>
                         </div>
                     </div>
                     <div>
                         <label class="block text-sm font-medium text-secondary-700 mb-2">Preferred Contact Method</label>
                         <div class="flex space-x-4">
                             <label class="flex items-center">
                                 <input type="radio" name="preferredContact" class="mr-2" value="email" checked>
                                 Email
                             </label>
                             <label class="flex items-center">
                                 <input type="radio" name="preferredContact" class="mr-2" value="phone">
                                 Phone
                             </label>
                             <label class="flex items-center">
                                 <input type="radio" name="preferredContact" class="mr-2" value="whatsapp">
                                 WhatsApp
                             </label>
                         </div>
                     </div>
                     <div>
                         <label class="block text-sm font-medium text-secondary-700 mb-2">Message *</label>
                         <textarea name="message" rows="4" class="input-field resize-none" placeholder="Please describe your requirements or any specific questions you have..." required></textarea>
                     </div>
                     <div class="text-center">
                         <button type="submit" class="btn-primary inline-flex items-center justify-center min-w-[200px]">
                             <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 512 512">
                                 <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                             </svg>
                             Send Enquiry
                         </button>
                     </div>
                     <div class="text-center text-sm text-secondary-500">
                         <p>By submitting this form, you agree to our <a href="../privacy-policy.php" class="text-primary-600 hover:underline">Privacy Policy</a> and <a href="../terms-conditions.php" class="text-primary-600 hover:underline">Terms & Conditions</a>.</p>
                     </div>
                 </form>
             </div>
         </div>
     </section>

     <!-- Footer -->
     <?php include '../includes/footer.php'; ?>
     
     <!-- Chatbot -->
     <?php include '../includes/chatbot.php'; ?>
     
     <!-- Slider JavaScript -->
     <?php include '../complete-nodejs-slider.php'; ?>
 </body>
 </html>