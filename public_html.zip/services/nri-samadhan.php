<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NRI Samadhan - KMFSL | Complete NRI Asset Recovery Solutions</title>
    <meta name="description" content="Specialized asset recovery services for NRIs. Recover unclaimed assets from India remotely with full legal compliance and dedicated NRI support.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <?php include '../includes/header.php'; ?>
    
    <!-- Hero Slider Section -->
    <section class="relative overflow-hidden" style="margin-top: 80px;">
        <div class="hero-slider">
            <!-- Complete Node.js Style Slider with 8 Slides -->
            <?php include '../complete-nodejs-slider-content.php'; ?>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce z-10">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </section>

    <!-- NRI Samadhan Hero Section -->
    <section class="section-padding bg-gradient-to-br from-blue-50 via-white to-green-50">
        <div class="container-custom">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                    <div class="inline-flex items-center bg-blue-100 text-blue-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 496 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M336.5 160C322 70.7 287.8 8 248 8s-74 62.7-88.5 152h177zM152 256c0 22.2 1.2 43.5 3.3 64h185.3c2.1-20.5 3.3-41.8 3.3-64s-1.2-43.5-3.3-64H155.3c-2.1 20.5-3.3 41.8-3.3 64zm324.7-96c-28.6-67.9-86.5-120.4-158-141.6 24.4 33.8 41.2 84.7 50 141.6h108zM177.2 18.4C105.8 39.6 47.8 92.1 19.3 160h108c8.7-56.9 25.5-107.8 49.9-141.6zM487.4 192H372.7c2.1 21 3.3 42.5 3.3 64s-1.2 43-3.3 64h114.6c5.5-20.5 8.6-41.8 8.6-64s-3.1-43.5-8.5-64zM120 256c0-21.5 1.2-43 3.3-64H8.6C3.2 212.5 0 233.8 0 256s3.2 43.5 8.6 64h114.6c-2-21-3.2-42.5-3.2-64zm39.5 96c14.5 89.3 48.7 152 88.5 152s74-62.7 88.5-152h-177zm159.3 141.6c71.4-21.2 129.4-73.7 158-141.6h-108c-8.8 56.9-25.6 107.8-50 141.6zM19.3 352c28.6 67.9 86.5 120.4 158 141.6-24.4-33.8-41.2-84.7-50-141.6h-108z"></path>
                        </svg>
                        NRI Specialized Service
                    </div>
                    <h1 class="text-4xl lg:text-6xl font-bold text-secondary-800 mb-6">
                        <span class="text-gradient">NRI Samadhan</span>
                    </h1>
                    <p class="text-xl text-secondary-600 mb-8 leading-relaxed">
                        Specialized financial asset recovery services for Non-Resident Indians. 
                        Recover your Indian investments remotely with complete legal compliance and expert support.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a class="btn-primary" href="#consultation">Free NRI Consultation</a>
                        <a class="btn-secondary" href="#services">View NRI Services</a>
                    </div>
                </div>
                <div class="relative">
                    <div class="w-full h-96 bg-gradient-to-br from-blue-100 to-green-100 rounded-2xl flex items-center justify-center">
                        <div class="text-center">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 496 512" class="w-24 h-24 text-blue-600 mx-auto mb-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M336.5 160C322 70.7 287.8 8 248 8s-74 62.7-88.5 152h177zM152 256c0 22.2 1.2 43.5 3.3 64h185.3c2.1-20.5 3.3-41.8 3.3-64s-1.2-43.5-3.3-64H155.3c-2.1 20.5-3.3 41.8-3.3 64zm324.7-96c-28.6-67.9-86.5-120.4-158-141.6 24.4 33.8 41.2 84.7 50 141.6h108zM177.2 18.4C105.8 39.6 47.8 92.1 19.3 160h108c8.7-56.9 25.5-107.8 49.9-141.6zM487.4 192H372.7c2.1 21 3.3 42.5 3.3 64s-1.2 43-3.3 64h114.6c5.5-20.5 8.6-41.8 8.6-64s-3.1-43.5-8.5-64zM120 256c0-21.5 1.2-43 3.3-64H8.6C3.2 212.5 0 233.8 0 256s3.2 43.5 8.6 64h114.6c-2-21-3.2-42.5-3.2-64zm39.5 96c14.5 89.3 48.7 152 88.5 152s74-62.7 88.5-152h-177zm159.3 141.6c71.4-21.2 129.4-73.7 158-141.6h-108c-8.8 56.9-25.6 107.8-50 141.6zM19.3 352c28.6 67.9 86.5 120.4 158 141.6-24.4-33.8-41.2-84.7-50-141.6h-108z"></path>
                            </svg>
                            <h3 class="text-2xl font-bold text-secondary-800 mb-2">50+ Countries</h3>
                            <p class="text-secondary-600">1800+ NRI Clients Served</p>
                        </div>
                    </div>
                    <!-- Floating elements -->
                    <div class="absolute -top-4 -right-4 w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center animate-bounce">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-8 h-8 text-white" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M480 192H365.71L260.61 8.06A16.014 16.014 0 0 0 246.71 0h-65.5c-10.63 0-18.3 10.17-15.38 20.39L214.86 192H112l-43.2-57.6c-3.02-4.03-7.77-6.4-12.8-6.4H16.01C5.6 128-2.04 137.78.49 147.88L32 256 .49 364.12C-2.04 374.22 5.6 384 16.01 384H56c5.04 0 9.78-2.37 12.8-6.4L112 320h102.86l-49.03 171.6c-2.92 10.22 4.75 20.4 15.38 20.4h65.5c5.74 0 11.04-3.08 13.89-8.06L365.71 320H480c35.35 0 96-28.65 96-64s-60.65-64-96-64z"></path>
                        </svg>
                    </div>
                    <div class="absolute -bottom-4 -left-4 w-16 h-16 bg-green-500 rounded-full flex items-center justify-center animate-bounce" style="animation-delay: 0.5s;">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" class="w-6 h-6 text-white" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M308 96c6.627 0 12-5.373 12-12V44c0-6.627-5.373-12-12-12H12C5.373 32 0 37.373 0 44v44.748c0 6.627 5.373 12 12 12h85.28c27.308 0 48.261 9.958 60.97 27.252H12c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h158.757c-6.217 36.086-32.961 58.632-74.757 58.632H12c-6.627 0-12 5.373-12 12v53.012c0 3.349 1.4 6.546 3.861 8.818l165.052 152.356a12.001 12.001 0 0 0 8.139 3.182h82.562c10.924 0 16.166-13.408 8.139-20.818L116.871 319.906c76.499-2.34 131.144-53.395 138.318-127.906H308c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-58.69c-3.486-11.541-8.28-22.246-14.252-32H308z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="section-padding bg-blue-600">
        <div class="container-custom">
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center text-white">
                <div>
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 640 512" class="w-12 h-12 mx-auto mb-4 text-blue-200" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z"></path>
                    </svg>
                    <div class="text-3xl font-bold mb-2">1800+</div>
                    <div class="text-blue-200">NRI Clients Served</div>
                </div>
                <div>
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 320 512" class="w-12 h-12 mx-auto mb-4 text-blue-200" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M308 96c6.627 0 12-5.373 12-12V44c0-6.627-5.373-12-12-12H12C5.373 32 0 37.373 0 44v44.748c0 6.627 5.373 12 12 12h85.28c27.308 0 48.261 9.958 60.97 27.252H12c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h158.757c-6.217 36.086-32.961 58.632-74.757 58.632H12c-6.627 0-12 5.373-12 12v53.012c0 3.349 1.4 6.546 3.861 8.818l165.052 152.356a12.001 12.001 0 0 0 8.139 3.182h82.562c10.924 0 16.166-13.408 8.139-20.818L116.871 319.906c76.499-2.34 131.144-53.395 138.318-127.906H308c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-58.69c-3.486-11.541-8.28-22.246-14.252-32H308z"></path>
                    </svg>
                    <div class="text-3xl font-bold mb-2">₹75Cr+</div>
                    <div class="text-blue-200">NRI Assets Recovered</div>
                </div>
                <div>
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 496 512" class="w-12 h-12 mx-auto mb-4 text-blue-200" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M336.5 160C322 70.7 287.8 8 248 8s-74 62.7-88.5 152h177zM152 256c0 22.2 1.2 43.5 3.3 64h185.3c2.1-20.5 3.3-41.8 3.3-64s-1.2-43.5-3.3-64H155.3c-2.1 20.5-3.3 41.8-3.3 64zm324.7-96c-28.6-67.9-86.5-120.4-158-141.6 24.4 33.8 41.2 84.7 50 141.6h108zM177.2 18.4C105.8 39.6 47.8 92.1 19.3 160h108c8.7-56.9 25.5-107.8 49.9-141.6zM487.4 192H372.7c2.1 21 3.3 42.5 3.3 64s-1.2 43-3.3 64h114.6c5.5-20.5 8.6-41.8 8.6-64s-3.1-43.5-8.5-64zM120 256c0-21.5 1.2-43 3.3-64H8.6C3.2 212.5 0 233.8 0 256s3.2 43.5 8.6 64h114.6c-2-21-3.2-42.5-3.2-64zm39.5 96c14.5 89.3 48.7 152 88.5 152s74-62.7 88.5-152h-177zm159.3 141.6c71.4-21.2 129.4-73.7 158-141.6h-108c-8.8 56.9-25.6 107.8-50 141.6zM19.3 352c28.6 67.9 86.5 120.4 158 141.6-24.4-33.8-41.2-84.7-50-141.6h-108z"></path>
                    </svg>
                    <div class="text-3xl font-bold mb-2">50+</div>
                    <div class="text-blue-200">Countries Covered</div>
                </div>
                <div>
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-12 h-12 mx-auto mb-4 text-blue-200" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                    </svg>
                    <div class="text-3xl font-bold mb-2">88%</div>
                    <div class="text-blue-200">NRI Success Rate</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Countries We Serve -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    <span class="text-gradient">Countries</span> We Serve
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    We provide specialized NRI services to clients across 50+ countries worldwide.
                </p>
            </div>
            
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-6">
                <div class="text-center group">
                    <div class="text-4xl mb-2 group-hover:scale-110 transition-transform duration-300">🇺🇸</div>
                    <h3 class="text-sm font-semibold text-secondary-800 mb-1">United States</h3>
                    <p class="text-xs text-secondary-600">450+ clients</p>
                </div>
                <div class="text-center group">
                    <div class="text-4xl mb-2 group-hover:scale-110 transition-transform duration-300">🇬🇧</div>
                    <h3 class="text-sm font-semibold text-secondary-800 mb-1">United Kingdom</h3>
                    <p class="text-xs text-secondary-600">320+ clients</p>
                </div>
                <div class="text-center group">
                    <div class="text-4xl mb-2 group-hover:scale-110 transition-transform duration-300">🇨🇦</div>
                    <h3 class="text-sm font-semibold text-secondary-800 mb-1">Canada</h3>
                    <p class="text-xs text-secondary-600">280+ clients</p>
                </div>
                <div class="text-center group">
                    <div class="text-4xl mb-2 group-hover:scale-110 transition-transform duration-300">🇦🇺</div>
                    <h3 class="text-sm font-semibold text-secondary-800 mb-1">Australia</h3>
                    <p class="text-xs text-secondary-600">240+ clients</p>
                </div>
                <div class="text-center group">
                    <div class="text-4xl mb-2 group-hover:scale-110 transition-transform duration-300">🇦🇪</div>
                    <h3 class="text-sm font-semibold text-secondary-800 mb-1">UAE</h3>
                    <p class="text-xs text-secondary-600">380+ clients</p>
                </div>
                <div class="text-center group">
                    <div class="text-4xl mb-2 group-hover:scale-110 transition-transform duration-300">🇸🇬</div>
                    <h3 class="text-sm font-semibold text-secondary-800 mb-1">Singapore</h3>
                    <p class="text-xs text-secondary-600">190+ clients</p>
                </div>
                <div class="text-center group">
                    <div class="text-4xl mb-2 group-hover:scale-110 transition-transform duration-300">🇩🇪</div>
                    <h3 class="text-sm font-semibold text-secondary-800 mb-1">Germany</h3>
                    <p class="text-xs text-secondary-600">150+ clients</p>
                </div>
                <div class="text-center group">
                    <div class="text-4xl mb-2 group-hover:scale-110 transition-transform duration-300">🇸🇦</div>
                    <h3 class="text-sm font-semibold text-secondary-800 mb-1">Saudi Arabia</h3>
                    <p class="text-xs text-secondary-600">220+ clients</p>
                </div>
            </div>
        </div>
    </section>

    <!-- NRI Services Section -->
    <section id="services" class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Specialized <span class="text-gradient">NRI Services</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Comprehensive asset recovery services designed specifically for Non-Resident Indians.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl">📊</div>
                        <div class="text-right">
                            <div class="text-sm text-green-600 font-semibold">Avg: ₹4.8L</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        IEPF Claims for NRIs
                    </h3>
                    <p class="text-secondary-600 mb-4">Recover unclaimed shares and dividends with Power of Attorney support</p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Remote Processing</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">POA Support</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Global Assistance</span>
                    </div>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl">🏦</div>
                        <div class="text-right">
                            <div class="text-sm text-green-600 font-semibold">Avg: ₹2.3L</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        NRI Bank Account Recovery
                    </h3>
                    <p class="text-secondary-600 mb-4">Reactivate dormant NRI accounts and recover unclaimed deposits</p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">NRE/NRO Accounts</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">KYC Compliance</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Remote Verification</span>
                    </div>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl">📈</div>
                        <div class="text-right">
                            <div class="text-sm text-green-600 font-semibold">Avg: ₹3.1L</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Investment Recovery
                    </h3>
                    <p class="text-secondary-600 mb-4">Claim unclaimed mutual funds, bonds, and other investments</p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">MF Recovery</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Bond Claims</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Dividend Recovery</span>
                    </div>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl">🛡️</div>
                        <div class="text-right">
                            <div class="text-sm text-green-600 font-semibold">Avg: ₹5.2L</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Insurance Claims
                    </h3>
                    <p class="text-secondary-600 mb-4">Recover matured insurance policies and unclaimed benefits</p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Policy Maturity</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Claim Processing</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Beneficiary Support</span>
                    </div>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl">💼</div>
                        <div class="text-right">
                            <div class="text-sm text-green-600 font-semibold">Avg: ₹3.8L</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        PF & Gratuity Claims
                    </h3>
                    <p class="text-secondary-600 mb-4">Claim PF and gratuity from Indian employers</p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">EPFO Claims</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Gratuity Recovery</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Tax Compliance</span>
                    </div>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-4xl">🏠</div>
                        <div class="text-right">
                            <div class="text-sm text-green-600 font-semibold">Avg: ₹15L</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Property Management
                    </h3>
                    <p class="text-secondary-600 mb-4">Manage and recover property-related assets in India</p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Property Claims</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Rental Recovery</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Legal Support</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Benefits Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Why NRIs Choose <span class="text-gradient">KMFSL</span>?
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    We understand the unique challenges faced by NRIs and provide tailored solutions.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 496 512" class="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M336.5 160C322 70.7 287.8 8 248 8s-74 62.7-88.5 152h177zM152 256c0 22.2 1.2 43.5 3.3 64h185.3c2.1-20.5 3.3-41.8 3.3-64s-1.2-43.5-3.3-64H155.3c-2.1 20.5-3.3 41.8-3.3 64zm324.7-96c-28.6-67.9-86.5-120.4-158-141.6 24.4 33.8 41.2 84.7 50 141.6h108zM177.2 18.4C105.8 39.6 47.8 92.1 19.3 160h108c8.7-56.9 25.5-107.8 49.9-141.6zM487.4 192H372.7c2.1 21 3.3 42.5 3.3 64s-1.2 43-3.3 64h114.6c5.5-20.5 8.6-41.8 8.6-64s-3.1-43.5-8.5-64zM120 256c0-21.5 1.2-43 3.3-64H8.6C3.2 212.5 0 233.8 0 256s3.2 43.5 8.6 64h114.6c-2-21-3.2-42.5-3.2-64zm39.5 96c14.5 89.3 48.7 152 88.5 152s74-62.7 88.5-152h-177zm159.3 141.6c71.4-21.2 129.4-73.7 158-141.6h-108c-8.8 56.9-25.6 107.8-50 141.6zM19.3 352c28.6 67.9 86.5 120.4 158 141.6-24.4-33.8-41.2-84.7-50-141.6h-108z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-blue-600 mb-2">50+ Countries</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Global Support</h3>
                    <p class="text-secondary-600">Dedicated support for NRIs across 50+ countries with local time zone assistance.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 576 512" class="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M480 192H365.71L260.61 8.06A16.014 16.014 0 0 0 246.71 0h-65.5c-10.63 0-18.3 10.17-15.38 20.39L214.86 192H112l-43.2-57.6c-3.02-4.03-7.77-6.4-12.8-6.4H16.01C5.6 128-2.04 137.78.49 147.88L32 256 .49 364.12C-2.04 374.22 5.6 384 16.01 384H56c5.04 0 9.78-2.37 12.8-6.4L112 320h102.86l-49.03 171.6c-2.92 10.22 4.75 20.4 15.38 20.4h65.5c5.74 0 11.04-3.08 13.89-8.06L365.71 320H480c35.35 0 96-28.65 96-64s-60.65-64-96-64z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-blue-600 mb-2">100% Remote</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Remote Processing</h3>
                    <p class="text-secondary-600">Complete asset recovery without visiting India. Handle everything remotely.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M466.5 83.7l-192-80a48.15 48.15 0 0 0-36.9 0l-192 80C27.7 91.1 16 108.6 16 128c0 198.5 114.5 335.7 221.5 380.3 11.8 4.9 25.1 4.9 36.9 0C360.1 472.6 496 349.3 496 128c0-19.4-11.7-36.9-29.5-44.3zM256.1 446.3l-.1-381 175.9 73.3c-3.3 151.4-82.1 261.1-175.8 307.7z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-blue-600 mb-2">FEMA Compliant</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Legal Compliance</h3>
                    <p class="text-secondary-600">Full compliance with FEMA, RBI guidelines, and NRI regulations.</p>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                            <path d="M192 208c0-17.67-14.33-32-32-32h-16c-35.35 0-64 28.65-64 64v48c0 35.35 28.65 64 64 64h16c17.67 0 32-14.33 32-32V208zm176 144c35.35 0 64-28.65 64-64v-48c0-35.35-28.65-64-64-64h-16c-17.67 0-32 14.33-32 32v112c0 17.67 14.33 32 32 32h16zM256 0C113.18 0 4.58 118.83 0 256v16c0 8.84 7.16 16 16 16h16c8.84 0 16-7.16 16-16v-16c0-114.69 93.31-208 208-208s208 93.31 208 208h-.12c.08 2.43.12 165.72.12 165.72 0 23.35-18.93 42.28-42.28 42.28H320c0-26.51-21.49-48-48-48h-32c-26.51 0-48 21.49-48 48s21.49 48 48 48h181.72c49.86 0 90.28-40.42 90.28-90.28V256C507.42 118.83 398.82 0 256 0z"></path>
                        </svg>
                    </div>
                    <div class="text-lg font-bold text-blue-600 mb-2">24/7 Support</div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3">Dedicated NRI Desk</h3>
                    <p class="text-secondary-600">Specialized NRI support team understanding unique challenges and requirements.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Our <span class="text-gradient">NRI Process</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Streamlined 6-step process designed specifically for NRI clients with remote processing capabilities.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold">01</div>
                        <div class="text-right">
                            <div class="text-xs text-blue-600 font-semibold">Video Call</div>
                            <div class="text-xs text-secondary-500">30 mins</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Initial Consultation
                    </h3>
                    <p class="text-secondary-600">Free consultation via video call to understand your requirements and assess potential recoverable assets.</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold">02</div>
                        <div class="text-right">
                            <div class="text-xs text-blue-600 font-semibold">Digital Upload</div>
                            <div class="text-xs text-secondary-500">3-5 days</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Document Collection
                    </h3>
                    <p class="text-secondary-600">Secure digital collection of required documents with guidance on attestation and apostille requirements.</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold">03</div>
                        <div class="text-right">
                            <div class="text-xs text-blue-600 font-semibold">Consulate/Remote</div>
                            <div class="text-xs text-secondary-500">5-7 days</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Power of Attorney
                    </h3>
                    <p class="text-secondary-600">Preparation and execution of POA at Indian consulate or through authorized representatives.</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold">04</div>
                        <div class="text-right">
                            <div class="text-xs text-blue-600 font-semibold">India Operations</div>
                            <div class="text-xs text-secondary-500">7-10 days</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Asset Search & Filing
                    </h3>
                    <p class="text-secondary-600">Comprehensive search across Indian financial institutions and filing of recovery applications.</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold">05</div>
                        <div class="text-right">
                            <div class="text-xs text-blue-600 font-semibold">Continuous</div>
                            <div class="text-xs text-secondary-500">15-30 days</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Processing & Follow-up
                    </h3>
                    <p class="text-secondary-600">Regular follow-up with authorities, handling queries, and providing status updates.</p>
                </div>
                
                <div class="card group hover:scale-105 transition-all duration-300">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-lg font-bold">06</div>
                        <div class="text-right">
                            <div class="text-xs text-blue-600 font-semibold">Bank Transfer</div>
                            <div class="text-xs text-secondary-500">2-3 days</div>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-3 group-hover:text-blue-600 transition-colors">
                        Recovery & Transfer
                    </h3>
                    <p class="text-secondary-600">Final recovery and transfer to your NRE/NRO account with complete documentation.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Documents Section -->
    <section class="section-padding">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    Required <span class="text-gradient">Documents</span> for NRIs
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Comprehensive list of documents required for NRI asset recovery with attestation guidelines.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-4">Identity & Citizenship</h3>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Valid Passport</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">PAN Card</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Aadhaar Card (if available)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">OCI/PIO Card (if applicable)</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-4">NRI Status Proof</h3>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Visa/Work Permit</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Employment Letter</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Tax Returns (Foreign Country)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Bank Statement (Foreign)</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-4">Financial Documents</h3>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">NRE/NRO Account Details</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Investment Proofs</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Share Certificates</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Insurance Policies</span>
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <h3 class="text-lg font-semibold text-secondary-800 mb-4">Legal Documents</h3>
                    <ul class="space-y-3">
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Power of Attorney</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Apostille/Attestation</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Address Proof (India & Abroad)</span>
                        </li>
                        <li class="flex items-center text-secondary-600">
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 text-green-500 mr-3 flex-shrink-0" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                <path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"></path>
                            </svg>
                            <span class="text-sm">Relationship Proof (if applicable)</span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="text-center mt-12">
                <div class="inline-flex items-center bg-yellow-100 text-yellow-800 px-6 py-3 rounded-lg">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 384 512" class="mr-2 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm64 236c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-64c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-72v8c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12zm96-114.1v6.1H256V0h6.1c6.4 0 12.5 2.5 17 7l97.9 98c4.5 4.5 7 10.6 7 16.9z"></path>
                    </svg>
                    <span class="font-medium">We provide complete guidance on document attestation and apostille requirements</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Success Stories Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                    NRI <span class="text-gradient">Success Stories</span>
                </h2>
                <p class="text-xl text-secondary-600 max-w-3xl mx-auto">
                    Real stories from NRI clients who have successfully recovered their Indian assets.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Rajesh Patel</h4>
                            <p class="text-sm text-secondary-600 flex items-center">
                                <span class="mr-2">🇺🇸</span>New Jersey, USA
                            </p>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-green-600">₹8.5 Lakhs</div>
                            <div class="text-xs text-secondary-500">Recovered</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">
                        "Living in the US for 15 years, I had completely forgotten about my Indian investments. KMFSL helped me recover everything without me having to visit India."
                    </p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">IEPF Claims</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">PF Recovery</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Bank Deposits</span>
                    </div>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Priya Sharma</h4>
                            <p class="text-sm text-secondary-600 flex items-center">
                                <span class="mr-2">🇬🇧</span>London, UK
                            </p>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-green-600">₹12.3 Lakhs</div>
                            <div class="text-xs text-secondary-500">Recovered</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">
                        "Excellent service for NRIs! They handled all the paperwork, POA, and recovery process. Very professional and transparent."
                    </p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Insurance Claims</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Mutual Funds</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">IEPF</span>
                    </div>
                </div>
                
                <div class="card">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h4 class="font-semibold text-secondary-800">Suresh Kumar</h4>
                            <p class="text-sm text-secondary-600 flex items-center">
                                <span class="mr-2">🇦🇪</span>Dubai, UAE
                            </p>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-green-600">₹6.8 Lakhs</div>
                            <div class="text-xs text-secondary-500">Recovered</div>
                        </div>
                    </div>
                    <p class="text-secondary-700 italic mb-4">
                        "Being in the Middle East, time zone was a concern. But their 24/7 support and regular updates made the process smooth."
                    </p>
                    <div class="flex flex-wrap gap-1">
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Bank Recovery</span>
                        <span class="bg-blue-100 text-blue-600 text-xs font-medium px-2 py-1 rounded">Property Claims</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="section-padding bg-gradient-to-r from-blue-600 to-green-600">
        <div class="container-custom text-center text-white">
            <h2 class="text-4xl font-bold mb-4">Recover Your Indian Assets from Anywhere!</h2>
            <p class="text-xl mb-8 max-w-2xl mx-auto">
                Don't let distance prevent you from claiming what's rightfully yours. Our specialized NRI services make asset recovery simple and hassle-free.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a class="btn-primary bg-white text-blue-600 hover:bg-gray-100" href="#consultation">Free NRI Consultation</a>
                <a href="https://wa.me/917070972333" target="_blank" rel="noopener noreferrer" class="btn-secondary border-white text-white hover:bg-white hover:text-blue-600">
                    WhatsApp Expert Support
                </a>
            </div>
        </div>
    </section>

    <!-- Consultation Form Section -->
    <section id="consultation" class="section-padding">
        <div class="container-custom">
            <div class="max-w-4xl mx-auto">
                <div class="text-center mb-12">
                    <h2 class="text-4xl font-bold text-secondary-800 mb-4">
                        Get Your <span class="text-gradient">Free NRI Consultation</span>
                    </h2>
                    <p class="text-xl text-secondary-600">
                        Fill out the form below and our NRI specialists will contact you within 24 hours to discuss your case and provide a preliminary assessment.
                    </p>
                </div>
                
                <div class="card max-w-4xl mx-auto">
                    <div class="text-center mb-8">
                        <div class="flex justify-center mb-6">
                            <img src="../kmfsl-logo.svg" alt="KMFSL - Kaimur Financial Services" class="h-24 w-auto">
                        </div>
                        <h3 class="text-2xl font-bold text-secondary-800 mb-2">NRI Asset Recovery Consultation</h3>
                        <p class="text-secondary-600">Let our NRI experts help you recover your Indian assets remotely</p>
                    </div>
                    
                    <form class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Full Name *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                    </svg>
                                    <input type="text" name="name" class="input-field pl-10" placeholder="Enter your full name">
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Email Address *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path>
                                    </svg>
                                    <input type="email" name="email" class="input-field pl-10" placeholder="Enter your email address">
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Phone Number *</label>
                                <div class="relative">
                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 w-4 h-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path>
                                    </svg>
                                    <input type="tel" name="phone" class="input-field pl-10" placeholder="Enter your phone number">
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-secondary-700 mb-2">Service Required *</label>
                                <select name="service" class="input-field">
                                    <option value="">Select a service</option>
                                    <option value="IEPF Claim">IEPF Claim</option>
                                    <option value="Transmission of Shares">Transmission of Shares</option>
                                    <option value="Demat of Physical Shares">Demat of Physical Shares</option>
                                    <option value="Unclaimed Dividends">Unclaimed Dividends</option>
                                    <option value="Conversion of Shares/Debentures">Conversion of Shares/Debentures</option>
                                    <option value="Property Claim Samadhan">Property Claim Samadhan</option>
                                    <option value="Debtor Recovery">Debtor Recovery</option>
                                    <option value="Recovery of Unclaimed Mutual Funds">Recovery of Unclaimed Mutual Funds</option>
                                    <option value="Recovery of Inoperative Bank Accounts">Recovery of Inoperative Bank Accounts</option>
                                    <option value="Provident Funds Claim">Provident Funds Claim</option>
                                    <option value="Recovery of Unclaimed Matured Insurance">Recovery of Unclaimed Matured Insurance</option>
                                    <option value="Wealth Samadhan">Wealth Samadhan</option>
                                    <option value="NRI Samadhan">NRI Samadhan</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Preferred Contact Method</label>
                            <div class="flex space-x-4">
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="email" checked>
                                    Email
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="phone">
                                    Phone
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="preferredContact" class="mr-2" value="whatsapp">
                                    WhatsApp
                                </label>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-secondary-700 mb-2">Message *</label>
                            <textarea name="message" rows="4" class="input-field resize-none" placeholder="Please describe your requirements or any specific questions you have..."></textarea>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn-primary inline-flex items-center justify-center min-w-[200px]">
                                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-4 h-4 mr-2" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path>
                                </svg>
                                Send Enquiry
                            </button>
                        </div>
                        
                        <div class="text-center text-sm text-secondary-500">
                            <p>By submitting this form, you agree to our <a href="../privacy-policy.php" class="text-primary-600 hover:underline">Privacy Policy</a> and <a href="../terms-conditions.php" class="text-primary-600 hover:underline">Terms & Conditions</a>.</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Support Section -->
    <section class="section-padding bg-gray-50">
        <div class="container-custom">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-secondary-800 mb-4">
                    24/7 <span class="text-gradient">NRI Support</span>
                </h2>
                <p class="text-lg text-secondary-600">
                    Our dedicated NRI support team is available round the clock to assist you.
                </p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-12 h-12 text-blue-600 mx-auto mb-4 group-hover:text-blue-700" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M192 208c0-17.67-14.33-32-32-32h-16c-35.35 0-64 28.65-64 64v48c0 35.35 28.65 64 64 64h16c17.67 0 32-14.33 32-32V208zm176 144c35.35 0 64-28.65 64-64v-48c0-35.35-28.65-64-64-64h-16c-17.67 0-32 14.33-32 32v112c0 17.67 14.33 32 32 32h16zM256 0C113.18 0 4.58 118.83 0 256v16c0 8.84 7.16 16 16 16h16c8.84 0 16-7.16 16-16v-16c0-114.69 93.31-208 208-208s208 93.31 208 208h-.12c.08 2.43.12 165.72.12 165.72 0 23.35-18.93 42.28-42.28 42.28H320c0-26.51-21.49-48-48-48h-32c-26.51 0-48 21.49-48 48s21.49 48 48 48h181.72c49.86 0 90.28-40.42 90.28-90.28V256C507.42 118.83 398.82 0 256 0z"></path>
                    </svg>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-2">Video Consultation</h3>
                    <p class="text-secondary-600 mb-3">Face-to-face consultation via video call</p>
                    <span class="text-blue-600 font-semibold">Book Free Call</span>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 496 512" class="w-12 h-12 text-green-600 mx-auto mb-4 group-hover:text-green-700" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M336.5 160C322 70.7 287.8 8 248 8s-74 62.7-88.5 152h177zM152 256c0 22.2 1.2 43.5 3.3 64h185.3c2.1-20.5 3.3-41.8 3.3-64s-1.2-43.5-3.3-64H155.3c-2.1 20.5-3.3 41.8-3.3 64zm324.7-96c-28.6-67.9-86.5-120.4-158-141.6 24.4 33.8 41.2 84.7 50 141.6h108zM177.2 18.4C105.8 39.6 47.8 92.1 19.3 160h108c8.7-56.9 25.5-107.8 49.9-141.6zM487.4 192H372.7c2.1 21 3.3 42.5 3.3 64s-1.2 43-3.3 64h114.6c5.5-20.5 8.6-41.8 8.6-64s-3.1-43.5-8.5-64zM120 256c0-21.5 1.2-43 3.3-64H8.6C3.2 212.5 0 233.8 0 256s3.2 43.5 8.6 64h114.6c-2-21-3.2-42.5-3.2-64zm39.5 96c14.5 89.3 48.7 152 88.5 152s74-62.7 88.5-152h-177zm159.3 141.6c71.4-21.2 129.4-73.7 158-141.6h-108c-8.8 56.9-25.6 107.8-50 141.6zM19.3 352c28.6 67.9 86.5 120.4 158 141.6-24.4-33.8-41.2-84.7-50-141.6h-108z"></path>
                    </svg>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-2">WhatsApp Support</h3>
                    <p class="text-secondary-600 mb-3">Instant support via WhatsApp</p>
                    <span class="text-green-600 font-semibold">+91 7070972333</span>
                </div>
                
                <div class="card text-center group hover:scale-105 transition-all duration-300">
                    <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 640 512" class="w-12 h-12 text-purple-600 mx-auto mb-4 group-hover:text-purple-700" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                        <path d="M434.7 64h-85.9c-8 0-15.7 3-21.6 8.4l-98.3 90c-.1.1-.2.3-.3.4-16.6 15.6-16.3 40.5-2.1 56 12.7 13.9 39.4 17.6 56.1 2.7.1-.1.3-.1.4-.2l79.9-73.2c6.5-5.9 16.7-5.5 22.6 1 6 6.5 5.5 16.6-1 22.6l-26.1 23.9L504 313.8c2.9 2.4 5.5 5 7.9 7.7V128l-54.6-54.6c-5.9-6-14.1-9.4-22.6-9.4zM544 128.2v223.9c0 17.7 14.3 32 32 32h64V128.2h-96zm48 223.9c-8.8 0-16-7.2-16-16s7.2-16 16-16 16 7.2 16 16-7.2 16-16 16zM0 384h64c17.7 0 32-14.3 32-32V128.2H0V384zm48-63.9c8.8 0 16 7.2 16 16s-7.2 16-16 16-16-7.2-16-16c0-8.9 7.2-16 16-16zm435.9 18.6L334.6 217.5l-30 27.5c-29.7 27.1-75.2 24.5-101.7-4.4-26.9-29.4-24.8-74.9 4.4-101.7L289.1 64h-83.8c-8.5 0-16.6 3.4-22.6 9.4L128 128v223.9h18.3l90.5 81.9c27.4 22.3 67.7 18.1 90-9.3l.2-.2 17.9 15.5c15.9 13 39.4 10.5 52.3-5.4l31.4-38.6 5.4 4.4c13.7 11.1 33.9 9.1 45-4.7l9.5-11.7c11.2-13.8 9.1-33.9-4.6-45.1z"></path>
                    </svg>
                    <h3 class="text-lg font-semibold text-secondary-800 mb-2">Dedicated Manager</h3>
                    <p class="text-secondary-600 mb-3">Personal relationship manager for your case</p>
                    <span class="text-purple-600 font-semibold">Assigned on Signup</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>
    
    <!-- Chatbot -->
    <?php include '../includes/chatbot.php'; ?>
    
    <!-- Slider JavaScript -->
    <?php include '../complete-nodejs-slider.php'; ?>
</body>
</html>