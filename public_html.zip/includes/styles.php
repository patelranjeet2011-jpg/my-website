<!-- Common Styles and Configuration -->
<!-- Google Fonts with Fallbacks -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

<!-- Font Awesome with Fallback -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">

<!-- Fallback Styles -->
<style>
    /* Font Fallbacks */
    body, html {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    }
    
    /* Font Awesome Fallback */
    .fas, .far, .fab, .fal, .fad {
        font-family: 'Font Awesome 6 Free', 'Font Awesome 6 Pro', sans-serif;
        font-weight: 900;
    }
    
    /* Ensure icons display even if font fails to load */
    .fas::before, .far::before, .fab::before {
        content: attr(data-fallback) !important;
    }
    
    /* Loading optimization */
    @media (prefers-reduced-motion: reduce) {
        * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }
    }
    
    /* Custom utility classes */
    .container-custom {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 1rem;
    }
    
    .text-gradient {
        background: linear-gradient(135deg, #3b82f6, #10b981);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .backdrop-blur-custom {
        backdrop-filter: blur(10px);
    }
</style>

<!-- Tailwind CSS -->
<script src="https://cdn.tailwindcss.com"></script>
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    primary: {
                        50: '#eff6ff',
                        100: '#dbeafe',
                        200: '#bfdbfe',
                        300: '#93c5fd',
                        400: '#60a5fa',
                        500: '#3b82f6',
                        600: '#2563eb',
                        700: '#1d4ed8',
                        800: '#1e40af',
                        900: '#1e3a8a'
                    },
                    secondary: {
                        50: '#f8fafc',
                        100: '#f1f5f9',
                        200: '#e2e8f0',
                        300: '#cbd5e1',
                        400: '#94a3b8',
                        500: '#64748b',
                        600: '#475569',
                        700: '#334155',
                        800: '#1e293b',
                        900: '#0f172a'
                    },
                    accent: {
                        50: '#fef7ee',
                        100: '#fdedd3',
                        200: '#fbd6a5',
                        300: '#f8b86d',
                        400: '#f59332',
                        500: '#f2750a',
                        600: '#e35d05',
                        700: '#bc4508',
                        800: '#95370e',
                        900: '#792f0f'
                    }
                },
                fontFamily: {
                    'sans': ['Inter', 'ui-sans-serif', 'system-ui'],
                    'serif': ['Georgia', 'ui-serif'],
                    'mono': ['ui-monospace', 'SFMono-Regular']
                },
                animation: {
                    'fade-in': 'fadeIn 0.5s ease-in-out',
                    'slide-up': 'slideUp 0.5s ease-out',
                    'slide-down': 'slideDown 0.5s ease-out',
                    'bounce-slow': 'bounce 2s infinite',
                    'float': 'float 3s ease-in-out infinite',
                    'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite'
                },
                keyframes: {
                    fadeIn: {
                        '0%': { opacity: '0' },
                        '100%': { opacity: '1' }
                    },
                    slideUp: {
                        '0%': { transform: 'translateY(20px)', opacity: '0' },
                        '100%': { transform: 'translateY(0)', opacity: '1' }
                    },
                    slideDown: {
                        '0%': { transform: 'translateY(-20px)', opacity: '0' },
                        '100%': { transform: 'translateY(0)', opacity: '1' }
                    },
                    float: {
                        '0%, 100%': { transform: 'translateY(0px)' },
                        '50%': { transform: 'translateY(-10px)' }
                    }
                },
                boxShadow: {
                    'custom': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
                    'custom-lg': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)'
                }
            }
        }
    }
</script>

<style>
    /* Reset default margins and padding */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    html, body {
        margin: 0;
        padding: 0;
        height: 100%;
        overflow-x: hidden;
    }
    
    /* Common Styles */
    .section-padding {
        padding-top: 5rem;
        padding-bottom: 5rem;
        padding-left: 1rem;
        padding-right: 1rem;
    }
    
    @media (min-width: 768px) {
        .section-padding {
            padding-left: 2rem;
            padding-right: 2rem;
        }
    }
    
    .container-custom {
        max-width: 80rem;
        margin: 0 auto;
    }
    
    .text-gradient {
        background: linear-gradient(to right, #2563eb, #f2750a);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .hero-gradient {
        background: linear-gradient(to bottom right, #eff6ff, #ffffff, #fef7ee);
    }
    
    .card {
        background: white;
        border-radius: 1rem;
        padding: 2rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        transition: all 0.3s ease;
        border: 1px solid #f1f5f9;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    .card-hover {
        transition: all 0.3s ease;
    }
    
    .card-hover:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    /* Button Styles */
    .btn-primary {
        background: linear-gradient(135deg, #2563eb, #f2750a);
        color: white;
        font-weight: 600;
        padding: 0.75rem 1.5rem;
        border-radius: 0.5rem;
        transition: all 0.3s ease;
        border: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(37, 99, 235, 0.3);
        background: linear-gradient(135deg, #1d4ed8, #e35d05);
    }
    
    .btn-secondary {
        background: white;
        color: #334155;
        font-weight: 600;
        padding: 0.75rem 1.5rem;
        border-radius: 0.5rem;
        transition: all 0.3s ease;
        border: 2px solid #e2e8f0;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
    }
    
    .btn-secondary:hover {
        background: #f8fafc;
        border-color: #2563eb;
        color: #2563eb;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    
    /* Header Backdrop Blur */
    .backdrop-blur-custom {
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
    }
    
    /* Scrollbar Styling */
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: #f1f5f9;
    }
    
    ::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: #94a3b8;
    }
    
    /* Base Styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Inter', sans-serif;
        line-height: 1.6;
        color: #1e293b;
        background-color: #ffffff;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }
    
    /* Mobile Responsive */
    @media (max-width: 768px) {
        .section-padding {
            padding-top: 3rem;
            padding-bottom: 3rem;
            padding-left: 1rem;
            padding-right: 1rem;
        }
    }
    
    /* Hero Slider Styles - Fixed Positioning */
    .hero-slider {
        position: relative;
        width: 100%;
        height: 70vh;
        min-height: 500px;
        max-height: 700px;
        overflow: hidden;
    }
    
    .slide {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        transition: opacity 0.5s ease-in-out;
        z-index: 1;
        display: flex;
        align-items: center;
    }
    
    .slide.active {
        opacity: 1;
        z-index: 2;
    }
    
    .slider-dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.5);
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .slider-dot.active {
        background: white;
        transform: scale(1.2);
        box-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
    }
    
    .slider-dot:hover {
        background: rgba(255, 255, 255, 0.8);
        transform: scale(1.1);
    }
    
    /* Mobile responsive slider */
     @media (max-width: 768px) {
         .hero-slider {
             height: 70vh;
             min-height: 450px;
             max-height: 550px;
         }
         
         .slide {
             min-height: 70vh;
         }
     }
     
     /* Tablet responsive slider */
     @media (min-width: 769px) and (max-width: 1024px) {
         .hero-slider {
             height: 70vh;
             min-height: 500px;
             max-height: 650px;
         }
     }
    
    /* Ensure slider content is properly positioned */
    .hero-slider .slide > div {
        width: 100%;
        height: 100%;
        position: relative;
    }
    
    /* Form Styles */
    .input-field {
        width: 100%;
        padding: 0.75rem 1rem;
        border: 1px solid #e2e8f0;
        border-radius: 0.5rem;
        font-size: 1rem;
        line-height: 1.5;
        color: #1e293b;
        background-color: #ffffff;
        transition: all 0.2s ease-in-out;
        min-height: 2.75rem;
    }
    
    .input-field.pl-10 {
        padding-left: 2.5rem;
    }
    
    .input-field:focus {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
    }
    
    .input-field:hover {
        border-color: #cbd5e1;
    }
    
    /* Icon positioning fix */
    .relative .absolute {
        pointer-events: none;
    }
    
    .relative svg {
        z-index: 10;
    }
    
    .error-message {
        color: #dc2626;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }
    
    .error-message.hidden {
        display: none;
    }
    
    /* Additional color utilities */
    .bg-primary-50 {
        background-color: #eff6ff;
    }
    
    .bg-green-50 {
        background-color: #f0fdf4;
    }
    
    .bg-blue-50 {
        background-color: #eff6ff;
    }
    
    .text-green-600 {
        color: #16a34a;
    }
    
    .text-blue-600 {
        color: #2563eb;
    }
</style>