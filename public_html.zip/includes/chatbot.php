<!-- ChatBot Component -->
<div id="chatbot-container" class="fixed bottom-6 right-6 font-inter" style="z-index: 9999;">
    <!-- Chat Button -->
    <div class="relative">
        <!-- Notification Badge -->
        <div class="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs font-bold animate-pulse">
            !
        </div>
        
        <button id="chat-toggle" class="w-16 h-16 bg-gradient-to-r from-primary-600 to-accent-500 hover:from-primary-700 hover:to-accent-600 text-white rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 flex items-center justify-center group relative overflow-hidden" style="position: fixed; bottom: 24px; right: 24px; z-index: 10000;">
            <!-- Animated Background -->
            <div class="absolute inset-0 bg-gradient-to-r from-primary-400 to-accent-400 opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
            
            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="w-6 h-6 group-hover:scale-110 transition-transform relative z-10" id="chat-icon" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                <path d="M192 208c0-17.67-14.33-32-32-32h-16c-35.35 0-64 28.65-64 64v48c0 35.35 28.65 64 64 64h16c17.67 0 32-14.33 32-32V208zm176 144c35.35 0 64-28.65 64-64v-48c0-35.35-28.65-64-64-64h-16c-17.67 0-32 14.33-32 32v112c0 17.67 14.33 32 32 32h16zM256 0C113.18 0 4.58 118.83 0 256v16c0 8.84 7.16 16 16 16h16c8.84 0 16-7.16 16-16v-16c0-114.69 93.31-208 208-208s208 93.31 208 208h-.12c.08 2.43.12 165.72.12 165.72 0 23.35-18.93 42.28-42.28 42.28H320c0-26.51-21.49-48-48-48h-32c-26.51 0-48 21.49-48 48s21.49 48 48 48h181.72c49.86 0 90.28-40.42 90.28-90.28V256C507.42 118.83 398.82 0 256 0z"/>
            </svg>
            <!-- Pulse Animation -->
            <div class="absolute inset-0 rounded-full bg-primary-400 animate-ping opacity-20"></div>
        </button>
        
        <!-- Tooltip -->
        <div id="chat-tooltip" class="absolute bottom-full right-0 mb-2 px-3 py-1 bg-gray-800 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
            💬 Need Help? Chat with AI Assistant
            <div class="absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-800"></div>
        </div>
    </div>
    
    <!-- Chat Window -->
    <div id="chat-window" class="hidden absolute bottom-24 right-0 w-96 h-[500px] bg-white rounded-2xl shadow-2xl border border-gray-100 flex flex-col overflow-hidden">
        <!-- Chat Header -->
        <div class="bg-gradient-to-r from-primary-600 to-accent-500 text-white p-4 flex items-center justify-between relative overflow-hidden">
            <!-- Background Pattern -->
            <div class="absolute inset-0 opacity-10">
                <div class="absolute top-0 left-0 w-20 h-20 bg-white rounded-full -translate-x-10 -translate-y-10"></div>
                <div class="absolute bottom-0 right-0 w-16 h-16 bg-white rounded-full translate-x-8 translate-y-8"></div>
            </div>
            
            <div class="flex items-center space-x-3 relative z-10">
                <div class="relative">
                    <!-- Colorful Star Icon -->
                    <div class="relative w-10 h-10 bg-white bg-opacity-20 rounded-full p-1">
                        <div class="absolute inset-1 bg-gradient-to-br from-blue-300 via-purple-300 to-pink-300 rounded-full transform rotate-45 opacity-90"></div>
                        <div class="absolute inset-2 bg-gradient-to-tr from-green-200 via-yellow-200 to-red-200 rounded-full transform -rotate-12 opacity-90"></div>
                    </div>
                    <div class="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white flex items-center justify-center">
                        <div class="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
                    </div>
                </div>
                <div>
                    <h3 class="font-bold text-lg">KMFSL AI Assistant</h3>
                    <div class="flex items-center space-x-1">
                        <div class="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                        <p class="text-xs opacity-90">Online • Powered by AI</p>
                    </div>
                </div>
            </div>
            
            <div class="flex items-center space-x-2 relative z-10">
                <div class="flex items-center space-x-1">
                    <i class="fas fa-star text-yellow-300 text-xs"></i>
                    <span class="text-xs font-medium">4.9</span>
                </div>
                <button id="chat-close" class="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-200">
                    <i class="fas fa-times text-sm"></i>
                </button>
            </div>
        </div>
        
        <!-- Chat Messages -->
        <div id="chat-messages" class="flex-1 p-4 overflow-y-auto space-y-3 bg-gray-50">
            <!-- Welcome Message -->
            <div class="flex items-start space-x-3">
                <div class="w-8 h-8 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-robot text-white text-xs"></i>
                </div>
                <div class="bg-white rounded-2xl rounded-tl-sm p-3 max-w-xs shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-800 leading-relaxed">🙏 नमस्ते! मैं KMFSL का AI असिस्टेंट हूँ। मैं आपकी वित्तीय सेवाओं में सहायता कर सकता हूँ।</p>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div id="quick-actions" class="p-4 border-t border-gray-100 bg-white">
            <div class="mb-2">
                <p class="text-xs font-medium text-gray-600 mb-3">लोकप्रिय सेवाएं:</p>
            </div>
            <div class="grid grid-cols-2 gap-2 mb-3">
                <button class="quick-action-btn bg-gradient-to-r from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 text-blue-700 p-3 rounded-xl text-xs font-medium transition-all duration-200 border border-blue-200" data-action="iepf">
                    💰 IEPF Claim
                </button>
                <button class="quick-action-btn bg-gradient-to-r from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 text-green-700 p-3 rounded-xl text-xs font-medium transition-all duration-200 border border-green-200" data-action="shares">
                    📈 Share Services
                </button>
                <button class="quick-action-btn bg-gradient-to-r from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 text-purple-700 p-3 rounded-xl text-xs font-medium transition-all duration-200 border border-purple-200" data-action="nri">
                    🌍 NRI Services
                </button>
                <button class="quick-action-btn bg-gradient-to-r from-orange-50 to-orange-100 hover:from-orange-100 hover:to-orange-200 text-orange-700 p-3 rounded-xl text-xs font-medium transition-all duration-200 border border-orange-200" data-action="contact">
                    📞 Contact Us
                </button>
            </div>
        </div>
        
        <!-- Chat Input -->
        <div class="p-4 border-t border-gray-100 bg-white">
            <div class="flex space-x-3">
                <input type="text" id="chat-input" placeholder="अपना संदेश लिखें..." class="flex-1 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-50 transition-all duration-200">
                <button id="chat-send" class="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-4 py-3 rounded-xl transition-all duration-200 shadow-sm hover:shadow-md">
                    <i class="fas fa-paper-plane text-sm"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
#chatbot-container {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.font-inter {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.quick-action-btn {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.quick-action-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.quick-action-btn:active {
    transform: translateY(0);
}

#chat-messages {
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 #f8fafc;
}

#chat-messages::-webkit-scrollbar {
    width: 6px;
}

#chat-messages::-webkit-scrollbar-track {
    background: #f8fafc;
    border-radius: 3px;
}

#chat-messages::-webkit-scrollbar-thumb {
    background: linear-gradient(to bottom, #cbd5e1, #94a3b8);
    border-radius: 3px;
}

#chat-messages::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(to bottom, #94a3b8, #64748b);
}

#chat-window {
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

#chat-window:not(.hidden) {
    animation: slideUp 0.3s ease-out;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const chatToggle = document.getElementById('chat-toggle');
    const chatWindow = document.getElementById('chat-window');
    const chatClose = document.getElementById('chat-close');
    const chatInput = document.getElementById('chat-input');
    const chatSend = document.getElementById('chat-send');
    const chatMessages = document.getElementById('chat-messages');
    const quickActionBtns = document.querySelectorAll('.quick-action-btn');
    
    let isTyping = false;
    
    // Predefined responses
    const responses = {
        'iepf': {
            message: 'IEPF (Investor Education and Protection Fund) से आपके अदावी शेयर और लाभांश की वसूली में हमारी विशेषज्ञता है। हमारी सफलता दर 98% है।',
            actions: ['अधिक जानकारी', 'संपर्क करें']
        },
        'shares': {
            message: 'हम शेयर ट्रांसमिशन, डीमैट सेवाएं, और भौतिक शेयरों का डिजिटलीकरण करते हैं। आपको किस सेवा की आवश्यकता है?',
            actions: ['Share Transmission', 'Demat Services']
        },
        'nri': {
            message: 'NRI ग्राहकों के लिए हमारे पास विशेष सेवाएं हैं। हम आपकी भारतीय संपत्ति की वसूली में सहायता करते हैं।',
            actions: ['NRI Services', 'Property Recovery']
        },
        'contact': {
            message: 'आप हमसे संपर्क कर सकते हैं:\n📞 +91 7070972333\n📧 help@kmfsl.in\n🕒 सोमवार-शुक्रवार: 9:00 AM - 6:00 PM',
            actions: ['Call Now', 'Send Email']
        },
        'default': {
            message: 'मैं आपकी सहायता करने के लिए यहाँ हूँ। कृपया अपना प्रश्न पूछें या नीचे दिए गए विकल्पों में से चुनें।',
            actions: ['IEPF Claim', 'Share Services', 'Contact Us']
        }
    };
    
    let isOpen = false;
    
    // Toggle chat window
    function toggleChat() {
        isOpen = !isOpen;
        if (isOpen) {
            chatWindow.classList.remove('hidden');
            chatInput.focus();
            document.getElementById('chat-icon').innerHTML = '<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>';
            document.getElementById('chat-tooltip').style.display = 'none';
        } else {
            chatWindow.classList.add('hidden');
            document.getElementById('chat-icon').innerHTML = '<path d="M192 208c0-17.67-14.33-32-32-32h-16c-35.35 0-64 28.65-64 64v48c0 35.35 28.65 64 64 64h16c17.67 0 32-14.33 32-32V208zm176 144c35.35 0 64-28.65 64-64v-48c0-35.35-28.65-64-64-64h-16c-17.67 0-32 14.33-32 32v112c0 17.67 14.33 32 32 32h16zM256 0C113.18 0 4.58 118.83 0 256v16c0 8.84 7.16 16 16 16h16c8.84 0 16-7.16 16-16v-16c0-114.69 93.31-208 208-208s208 93.31 208 208h-.12c.08 2.43.12 165.72.12 165.72 0 23.35-18.93 42.28-42.28 42.28H320c0-26.51-21.49-48-48-48h-32c-26.51 0-48 21.49-48 48s21.49 48 48 48h181.72c49.86 0 90.28-40.42 90.28-90.28V256C507.42 118.83 398.82 0 256 0z"/>';
            document.getElementById('chat-tooltip').style.display = 'block';
        }
    }
    
    chatToggle.addEventListener('click', toggleChat);
    chatClose.addEventListener('click', toggleChat);
    
    // Quick action buttons
    quickActionBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.dataset.action;
            handleQuickAction(action);
        });
    });
    
    // Send message
    function sendMessage() {
        const message = chatInput.value.trim();
        if (message && !isTyping) {
            addUserMessage(message);
            chatInput.value = '';
            handleUserMessage(message);
        }
    }
    
    chatSend.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // Add user message
    function addUserMessage(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'flex items-start space-x-3 justify-end';
        messageDiv.innerHTML = `
            <div class="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-2xl rounded-tr-sm p-3 max-w-xs shadow-sm">
                <p class="text-sm leading-relaxed">${message}</p>
            </div>
            <div class="w-8 h-8 bg-gradient-to-r from-gray-400 to-gray-500 rounded-full flex items-center justify-center flex-shrink-0">
                <i class="fas fa-user text-white text-xs"></i>
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        scrollToBottom();
    }
    
    // Add bot message
    function addBotMessage(message, actions = []) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'flex items-start space-x-3';
        
        let actionsHtml = '';
        if (actions.length > 0) {
            actionsHtml = `
                <div class="mt-3 space-y-2">
                    ${actions.map(action => `
                        <button class="block w-full text-left text-xs bg-gradient-to-r from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 text-blue-700 p-2 rounded-lg border border-blue-200 transition-all duration-200 font-medium" onclick="handleActionClick('${action}')">
                            ${action}
                        </button>
                    `).join('')}
                </div>
            `;
        }
        
        messageDiv.innerHTML = `
            <div class="w-8 h-8 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <i class="fas fa-robot text-white text-xs"></i>
            </div>
            <div class="bg-white rounded-2xl rounded-tl-sm p-3 max-w-xs shadow-sm border border-gray-100">
                <p class="text-sm text-gray-800 leading-relaxed whitespace-pre-line">${message}</p>
                ${actionsHtml}
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        scrollToBottom();
    }
    
    // Handle quick actions
    function handleQuickAction(action) {
        const response = responses[action] || responses['default'];
        
        // Show typing indicator
        showTypingIndicator();
        
        setTimeout(() => {
            hideTypingIndicator();
            addBotMessage(response.message, response.actions);
        }, 1000);
    }
    
    // Handle user messages
    function handleUserMessage(message) {
        const lowerMessage = message.toLowerCase();
        let response = responses['default'];
        
        if (lowerMessage.includes('iepf') || lowerMessage.includes('claim') || lowerMessage.includes('अदावी')) {
            response = responses['iepf'];
        } else if (lowerMessage.includes('share') || lowerMessage.includes('शेयर') || lowerMessage.includes('transmission')) {
            response = responses['shares'];
        } else if (lowerMessage.includes('nri') || lowerMessage.includes('एनआरआई')) {
            response = responses['nri'];
        } else if (lowerMessage.includes('contact') || lowerMessage.includes('संपर्क') || lowerMessage.includes('phone') || lowerMessage.includes('फोन')) {
            response = responses['contact'];
        }
        
        // Show typing indicator
        showTypingIndicator();
        
        setTimeout(() => {
            hideTypingIndicator();
            addBotMessage(response.message, response.actions);
        }, 1500);
    }
    
    // Show typing indicator
    function showTypingIndicator() {
        if (isTyping) return;
        
        isTyping = true;
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typing-indicator';
        typingDiv.className = 'flex items-start space-x-3';
        typingDiv.innerHTML = `
            <div class="w-8 h-8 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <i class="fas fa-robot text-white text-xs"></i>
            </div>
            <div class="bg-white rounded-2xl rounded-tl-sm p-3 shadow-sm border border-gray-100">
                <div class="flex space-x-1">
                    <div class="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                    <div class="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style="animation-delay: 0.1s"></div>
                    <div class="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
                </div>
            </div>
        `;
        chatMessages.appendChild(typingDiv);
        scrollToBottom();
    }
    
    // Hide typing indicator
    function hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
        isTyping = false;
    }
    
    // Scroll to bottom
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Handle action clicks
    window.handleActionClick = function(action) {
        if (action === 'Call Now') {
            window.open('tel:+917070972333');
        } else if (action === 'Send Email') {
            window.open('mailto:help@kmfsl.in');
        } else if (action === 'अधिक जानकारी') {
            window.open('/services/iepf-claim.php', '_blank');
        } else if (action === 'संपर्क करें') {
            window.open('/contact.php', '_blank');
        } else {
            addUserMessage(action);
            handleUserMessage(action);
        }
    };
    
    // Auto-open chat after 5 seconds (optional)
    setTimeout(() => {
        if (chatWindow.classList.contains('hidden')) {
            // Show a subtle notification
            chatToggle.classList.add('animate-pulse');
            setTimeout(() => {
                chatToggle.classList.remove('animate-pulse');
            }, 3000);
        }
    }, 5000);
});
</script>