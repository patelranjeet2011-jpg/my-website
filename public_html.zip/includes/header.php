<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'KMFSL - Kaimur Financial Services'; ?></title>
    <meta name="description" content="<?php echo isset($page_description) ? $page_description : 'Professional financial services and asset recovery solutions'; ?>">
    <?php include 'styles.php'; ?>
</head>
<body>

<header class="fixed top-0 left-0 right-0 z-[100] transition-all duration-300 bg-white/95 shadow-lg backdrop-blur-custom" id="main-header">
    <div class="container-custom">
        <div class="flex items-center justify-between h-20 px-4">
            <!-- Logo -->
            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>index.php" class="flex items-center">
                <img 
                    src="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>kmfsl-logo.svg" 
                    alt="KMFSL - Kaimur Financial Services" 
                    class="h-16 w-auto"
                />
            </a>
            
            <!-- Desktop Navigation -->
            <nav class="hidden lg:flex items-center space-x-8">
                <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>index.php" class="text-secondary-700 hover:text-primary-600 font-medium transition-colors">
                    Home
                </a>
                <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>about.php" class="text-secondary-700 hover:text-primary-600 font-medium transition-colors">
                    About Us
                </a>
                
                <!-- Wealth Samadhan Main Menu -->
                <div class="relative group">
                    <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>services/wealth-samadhan.php" class="text-secondary-700 hover:text-primary-600 font-medium transition-colors flex items-center">
                        Wealth Samadhan
                        <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </a>
                    <div class="absolute top-full left-0 mt-0 w-80 bg-white rounded-lg shadow-xl border border-secondary-200 py-4 z-[9999] opacity-0 invisible transition-all duration-300">
                        <div class="grid grid-cols-1 gap-1">
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>nri-samadhan.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                NRI Samadhan
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>become-associate.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Become Associate
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Services Dropdown -->
                <div class="relative group">
                    <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>services.php" class="text-secondary-700 hover:text-primary-600 font-medium transition-colors flex items-center">
                        Services
                        <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </a>
                    <div class="absolute top-full left-0 mt-0 w-80 bg-white rounded-lg shadow-xl border border-secondary-200 py-4 z-[9999] opacity-0 invisible transition-all duration-300">
                        <div class="grid grid-cols-1 gap-1">
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>iepf-claim.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                IEPF Claim
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>transmission-shares.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Transmission of Shares
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>demat-physical-shares.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Demat of Physical Shares
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>unclaimed-dividends.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Unclaimed Dividends
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>conversion-shares.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Conversion of Shares/Debentures
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>property-claim.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Property Claim Samadhan
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>debtor-recovery.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Debtor Recovery
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>mutual-funds-recovery.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Recovery of Unclaimed Mutual Funds
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>bank-account-recovery.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Recovery of Inoperative Bank Accounts
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>provident-funds.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Provident Funds Claim
                            </a>
                            <a href="<?php echo (basename($_SERVER['PHP_SELF']) !== 'index.php' && strpos($_SERVER['REQUEST_URI'], '/services/') !== false) ? '' : 'services/'; ?>insurance-recovery.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors block">
                                Recovery of Unclaimed Matured Insurance
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Resources Dropdown -->
                <div class="relative group">
                    <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources.php" class="text-secondary-700 hover:text-primary-600 font-medium transition-colors flex items-center">
                        Resources
                        <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </a>
                    <div class="absolute top-full left-0 mt-0 w-72 bg-white rounded-lg shadow-xl border border-secondary-200 py-4 z-[9999] opacity-0 invisible transition-all duration-300">
                        <div class="grid grid-cols-1 gap-1">
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources/downloads.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                Downloads
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources/blog.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                Blog
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources/news-room.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                News Room
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources/testimonials.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                Testimonials
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources/faq.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                FAQ
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources/faq-kmfsl.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                FAQ KMFSL
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources/media-coverage.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                Media Coverage
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>resources/digital-talk-show.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                Digital Talk Show
                            </a>
                        </div>
                    </div>
                </div>

                <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false) ? '../' : ''; ?>contact.php" class="text-secondary-700 hover:text-primary-600 font-medium transition-colors">
                    Contact
                </a>
                
                <!-- Privacy Policy Dropdown -->
                <div class="relative group">
                    <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>privacy-policy.php" class="text-secondary-700 hover:text-primary-600 font-medium transition-colors flex items-center">
                        Privacy Policy
                        <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </a>
                    <div class="absolute top-full left-0 mt-0 w-64 bg-white rounded-lg shadow-xl border border-secondary-200 py-4 z-[9999] opacity-0 invisible transition-all duration-300">
                        <div class="grid grid-cols-1 gap-1">
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>terms-conditions.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                Terms & Conditions
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>disclaimer.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors">
                                Disclaimer
                            </a>
                        </div>
                    </div>
                </div>
            </nav>
            
            <!-- Auth Dropdown -->
            <div class="hidden lg:flex items-center">
                <div class="relative group">
                    <button class="flex items-center space-x-2 text-secondary-700 hover:text-primary-600 font-medium transition-colors">
                        <i class="fas fa-user w-4 h-4"></i>
                        <span>Login</span>
                        <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div class="absolute top-full right-0 mt-0 w-48 bg-white rounded-lg shadow-xl border border-secondary-200 py-2 z-[9999] opacity-0 invisible transition-all duration-300">
                        <div class="grid grid-cols-1 gap-1">
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>client/login.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors flex items-center">
                                <i class="fas fa-sign-in-alt mr-2 w-4 h-4"></i>
                                Login
                            </a>
                            <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>client/signup.php" class="px-4 py-2 text-sm text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors flex items-center">
                                <i class="fas fa-user-plus mr-2 w-4 h-4"></i>
                                Sign Up
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Mobile Menu Button -->
            <button class="lg:hidden p-2 text-secondary-700 hover:text-primary-600" onclick="toggleMobileMenu()">
                <i class="fas fa-bars w-6 h-6"></i>
            </button>
        </div>
        
        <!-- Enhanced Dropdown JavaScript -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dropdowns = document.querySelectorAll('.group');
            
            dropdowns.forEach(dropdown => {
                const menu = dropdown.querySelector('div[class*="absolute"]');
                if (!menu) return;
                
                let hideTimeout;
                
                // Show menu on hover
                dropdown.addEventListener('mouseenter', function() {
                    clearTimeout(hideTimeout);
                    menu.classList.remove('opacity-0', 'invisible');
                    menu.classList.add('opacity-100', 'visible');
                    menu.style.pointerEvents = 'auto';
                });
                
                // Hide menu with delay
                dropdown.addEventListener('mouseleave', function() {
                    hideTimeout = setTimeout(() => {
                        menu.classList.remove('opacity-100', 'visible');
                        menu.classList.add('opacity-0', 'invisible');
                        menu.style.pointerEvents = 'none';
                    }, 500); // 500ms delay
                });
                
                // Keep menu visible when hovering over it
                menu.addEventListener('mouseenter', function() {
                    clearTimeout(hideTimeout);
                });
                
                menu.addEventListener('mouseleave', function() {
                    hideTimeout = setTimeout(() => {
                        menu.classList.remove('opacity-100', 'visible');
                        menu.classList.add('opacity-0', 'invisible');
                        menu.style.pointerEvents = 'none';
                    }, 500);
                });
                
                // Make sure links are clickable
                const links = menu.querySelectorAll('a');
                links.forEach(link => {
                    link.addEventListener('click', function(e) {
                        // Allow normal link behavior
                        clearTimeout(hideTimeout);
                        menu.classList.remove('opacity-100', 'visible');
                        menu.classList.add('opacity-0', 'invisible');
                        menu.style.pointerEvents = 'none';
                    });
                });
                
                // Initialize pointer events as none
                menu.style.pointerEvents = 'none';
            });
        });
        </script>
        
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden lg:hidden bg-white border-t border-secondary-200">
            <div class="px-4 py-6 space-y-4">
                <a href="/index.php" class="block text-secondary-700 hover:text-primary-600 font-medium">
                    Home
                </a>
                <a href="/about.php" class="block text-secondary-700 hover:text-primary-600 font-medium">
                    About Us
                </a>
                <a href="#" class="block text-secondary-700 hover:text-primary-600 font-medium">
                    Services
                </a>
                <a href="#" class="block text-secondary-700 hover:text-primary-600 font-medium">
                    Resources
                </a>
                <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false) ? '../' : ''; ?>contact.php" class="block text-secondary-700 hover:text-primary-600 font-medium">
                    Contact
                </a>
                
                <div class="pt-4 border-t border-secondary-200">
                    <div class="space-y-4">
                        <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>client/login.php" class="btn-secondary w-full flex items-center justify-center space-x-2">
                            <i class="fas fa-sign-in-alt w-4 h-4"></i>
                            <span>Login</span>
                        </a>
                        <a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/services/') !== false || strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || strpos($_SERVER['REQUEST_URI'], '/client/') !== false || strpos($_SERVER['REQUEST_URI'], '/resources/') !== false) ? '../' : ''; ?>client/signup.php" class="btn-primary w-full flex items-center justify-center space-x-2">
                            <i class="fas fa-user-plus w-4 h-4"></i>
                            <span>Sign Up</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
// Mobile menu toggle function
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const menuButton = document.querySelector('button[onclick="toggleMobileMenu()"]');
    const icon = menuButton.querySelector('i');
    
    if (mobileMenu.classList.contains('hidden')) {
        mobileMenu.classList.remove('hidden');
        icon.classList.remove('fa-bars');
        icon.classList.add('fa-times');
    } else {
        mobileMenu.classList.add('hidden');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
    }
}

// Header scroll effect
window.addEventListener('scroll', function() {
    const header = document.getElementById('main-header');
    if (window.scrollY > 50) {
        header.classList.remove('bg-white/95');
        header.classList.add('bg-white', 'shadow-lg');
    } else {
        header.classList.remove('bg-white', 'shadow-lg');
        header.classList.add('bg-white/95');
    }
});
</script>