<?php
// सेशन शुरू करें और लॉगिन की जाँच करें
session_start();
if (!isset($_SESSION['admin_loggedin']) || $_SESSION['admin_loggedin'] !== true) {
    header('Location: login.php'); // अपने लॉगिन पेज पर भेजें
    exit;
}

// URL से क्लाइंट ID प्राप्त करें
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: Client ID is required.");
}
$clientId = htmlspecialchars($_GET['id']); // Sanitize for security
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Client Details</title>
    <style>
        /* आप यहाँ कुछ बेसिक स्टाइलिंग जोड़ सकते हैं */
        .details-section { margin-bottom: 2rem; }
        .details-section h3 { border-bottom: 1px solid #eee; padding-bottom: 10px; }
        .document-list, .message-list { list-style: none; padding: 0; }
        .document-list li, .message-list li { background: #f9f9f9; border: 1px solid #ddd; padding: 10px; margin-bottom: 5px; }
        .message-list .admin { text-align: right; background: #eef; }
    </style>
</head>
<body>

    <?php // include 'partials/header.php'; ?>
    <?php // include 'partials/sidebar.php'; ?>

    <div class="main-content">
        <h2>Client Profile</h2>
        <hr>

        <div id="client-info" class="details-section">
            <h3>Personal Information</h3>
            <p><strong>Name:</strong> <span id="client-name">Loading...</span></p>
            <p><strong>Email:</strong> <span id="client-email">Loading...</span></p>
            <p><strong>Phone:</strong> <span id="client-phone">Loading...</span></p>
            <p><strong>PAN Number:</strong> <span id="client-pan">Loading...</span></p>
            <p><strong>Date of Birth:</strong> <span id="client-dob">Loading...</span></p>
            <p><strong>Status:</strong> <span id="client-status">Loading...</span></p>
        </div>

        <div id="client-documents" class="details-section">
            <h3>Uploaded Documents</h3>
            <ul id="document-list" class="document-list">
                <li>Loading documents...</li>
            </ul>
        </div>
        
        <div id="client-messages" class="details-section">
            <h3>Conversation</h3>
            <ul id="message-list" class="message-list">
                <li>Loading messages...</li>
            </ul>
        </div>
        
        <br>
        <a href="clients.php">Back to Client List</a> </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const clientId = <?php echo json_encode($clientId); ?>;
        const apiUrl = `api/get_client_details.php?id=${clientId}`;

        // Selectors for different parts of the page
        const clientInfoDiv = document.getElementById('client-info');
        const docList = document.getElementById('document-list');
        const msgList = document.getElementById('message-list');

        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    // Handle API errors
                    clientInfoDiv.innerHTML = `<p>Error: ${data.error}</p>`;
                    docList.innerHTML = '';
                    msgList.innerHTML = '';
                    return;
                }

                // 1. Populate Client Details
                const client = data.client;
                document.getElementById('client-name').textContent = client.name;
                document.getElementById('client-email').textContent = client.email;
                document.getElementById('client-phone').textContent = client.phone;
                document.getElementById('client-pan').textContent = client.pan_number || 'N/A';
                document.getElementById('client-dob').textContent = client.dob || 'N/A';
                document.getElementById('client-status').textContent = client.status;

                // 2. Populate Documents
                docList.innerHTML = ''; // Clear "Loading..." message
                if (data.documents && data.documents.length > 0) {
                    data.documents.forEach(doc => {
                        const li = document.createElement('li');
                        // Creating a downloadable link
                        li.innerHTML = `<a href="../${doc.file_path}" target="_blank" download>${doc.document_name}</a> (Uploaded: ${new Date(doc.created_at).toLocaleDateString()})`;
                        docList.appendChild(li);
                    });
                } else {
                    docList.innerHTML = '<li>No documents found.</li>';
                }

                // 3. Populate Messages
                msgList.innerHTML = ''; // Clear "Loading..." message
                if (data.messages && data.messages.length > 0) {
                    data.messages.forEach(msg => {
                        const li = document.createElement('li');
                        // Add a class based on who sent the message
                        if (msg.sender_type === 'admin') {
                            li.classList.add('admin');
                        }
                        li.innerHTML = `<strong>${msg.sender_type.toUpperCase()}:</strong> ${msg.message} <br><small>${new Date(msg.created_at).toLocaleString()}</small>`;
                        msgList.appendChild(li);
                    });
                } else {
                    msgList.innerHTML = '<li>No messages found.</li>';
                }
            })
            .catch(error => {
                console.error('Error fetching client details:', error);
                clientInfoDiv.innerHTML = `<p>An error occurred while loading client details. Please check the console.</p>`;
            });
    });
    </script>

</body>
</html>