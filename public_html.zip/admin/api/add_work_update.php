<?php
session_start();
header('Content-Type: application/json');
include '../../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized Access']);
    exit();
}

$workId = filter_input(INPUT_POST, 'work_id', FILTER_VALIDATE_INT);
$updateNote = $_POST['update_note'] ?? ''; // TinyMCE से HTML कंटेंट आएगा

if (!$workId || empty($updateNote)) {
    echo json_encode(['success' => false, 'error' => 'Work ID and update note are required.']);
    exit();
}

try {
    $pdo->beginTransaction(); // Transaction शुरू करें

    // 1. पहले update note को work_updates टेबल में डालें
    // ध्यान दें: अब हम इसमें file_path नहीं डाल रहे हैं
    $sql = "INSERT INTO work_updates (work_id, update_note) VALUES (:work_id, :update_note)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':work_id' => $workId, ':update_note' => $updateNote]);
    
    // 2. अभी-अभी डाले गए अपडेट की ID प्राप्त करें
    $lastUpdateId = $pdo->lastInsertId();

    // 3. अगर फाइलें अपलोड हुई हैं, तो उन्हें प्रोसेस करें
    if (isset($_FILES['update_document'])) {
        $uploadDir = '../../uploads/work_documents/';
        if (!is_dir($uploadDir)) {
            if (!mkdir($uploadDir, 0775, true)) {
                throw new Exception('Failed to create upload directory.');
            }
        }
        
        $fileCount = count($_FILES['update_document']['name']);
        for ($i = 0; $i < $fileCount; $i++) {
            // हर फाइल के लिए एरर चेक करें
            if ($_FILES['update_document']['error'][$i] === UPLOAD_ERR_OK) {
                
                $originalName = basename($_FILES['update_document']['name'][$i]);
                $fileName = time() . '_' . uniqid() . '_' . $originalName; // और भी यूनिक नाम
                $targetFile = $uploadDir . $fileName;

                if (move_uploaded_file($_FILES['update_document']['tmp_name'][$i], $targetFile)) {
                    $filePath = 'uploads/work_documents/' . $fileName;
                    
                    // 4. हर फाइल को नई work_update_documents टेबल में डालें
                    $docSql = "INSERT INTO work_update_documents (work_update_id, file_path, original_name) VALUES (?, ?, ?)";
                    $docStmt = $pdo->prepare($docSql);
                    $docStmt->execute([$lastUpdateId, $filePath, $originalName]);
                }
            }
        }
    }
    
    $pdo->commit(); // Transaction सफल, बदलावों को सेव करें
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    $pdo->rollBack(); // अगर कोई एरर आए तो Transaction को वापस लें
    error_log("Add work update with files error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error. Could not add update.']);
}
?>