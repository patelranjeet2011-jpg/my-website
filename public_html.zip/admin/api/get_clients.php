<?php
session_start();
header('Content-Type: application/json');

// Admin session check — अगर आपके project में session key अलग है तो वही use कर लें
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// DB config path — अपनी project structure के हिसाब से path बदलें अगर ज़रूरी हो
require_once '../config/database.php';

try {
    // अगर आपकी table का नाम 'clients' नहीं है तो यहाँ बदल दें (e.g. users)
    $sql = "SELECT id, name, email, phone, pan_no, status, join_date 
            FROM clients 
            ORDER BY join_date DESC";
    $stmt = $pdo->query($sql);
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($clients);
} catch (PDOException $e) {
    error_log("Get clients error: " . $e->getMessage());
    echo json_encode(['error' => 'Database error. Could not fetch clients.']);
}
?>
