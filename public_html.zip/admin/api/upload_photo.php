<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit();
}
if (!isset($_FILES['profile_photo']) || $_FILES['profile_photo']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'error' => 'No file uploaded or an error occurred.']);
    exit();
}

// FIX: Corrected path to database config file
// It needs to go up two directories from admin/api/ to the root
include '../../config/database.php';

$clientId = filter_input(INPUT_POST, 'client_id', FILTER_VALIDATE_INT);
if (!$clientId) {
    echo json_encode(['success' => false, 'error' => 'Invalid client ID.']);
    exit();
}

$file = $_FILES['profile_photo'];
// FIX: Corrected path for file uploads directory
// It needs to go up two directories from admin/api/ to the root
$uploadDir = '../../uploads/profiles/' . $clientId . '/';
if (!is_dir($uploadDir)) {
    if (!mkdir($uploadDir, 0775, true)) {
        echo json_encode(['success' => false, 'error' => 'Failed to create directory. Check permissions.']);
        exit();
    }
}

$fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
$newFileName = 'profile.' . $fileExtension;
$filePath = $uploadDir . $newFileName;
// This path is correct as it's relative to the website root for the DB
$dbPath = 'uploads/profiles/' . $clientId . '/' . $newFileName;

// Allow certain file formats
$allowTypes = array('jpg','png','jpeg');
if(!in_array(strtolower($fileExtension), $allowTypes)){
    echo json_encode(['success' => false, 'error' => 'Only JPG, JPEG, & PNG files are allowed.']);
    exit();
}

if (move_uploaded_file($file['tmp_name'], $filePath)) {
    try {
        $sql = "UPDATE users SET profile_photo_path = :photo_path WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':photo_path' => $dbPath, ':id' => $clientId]);
        echo json_encode(['success' => true, 'path' => $dbPath]);
    } catch (PDOException $e) {
        unlink($filePath);
        error_log("Photo upload DB error: " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Database error.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file.']);
}
?>
