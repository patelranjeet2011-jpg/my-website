<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

include '../../config/database.php';

// यहाँ PHPMailer को शामिल करें
// PHPMailer को स्थापित करने के लिए: composer require phpmailer/phpmailer
// या इसे मैनुअली डाउनलोड करके शामिल करें
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../../vendor/autoload.php'; // सुनिश्चित करें कि यह पाथ सही है

$clientId = filter_input(INPUT_POST, 'client_id', FILTER_VALIDATE_INT);
if (!$clientId) {
    echo json_encode(['success' => false, 'error' => 'Invalid client ID.']);
    exit();
}

try {
    // 1. क्लाइंट की जानकारी प्राप्त करें
    $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
    $stmt->execute([$clientId]);
    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$client) {
        echo json_encode(['success' => false, 'error' => 'Client not found.']);
        exit();
    }
    
    // 2. एक नया पासवर्ड जेनरेट करें
    $newPassword = substr(md5(uniqid(rand(), true)), 0, 8);
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // 3. डेटाबेस में पासवर्ड अपडेट करें
    $updateStmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    $updateStmt->execute([$hashedPassword, $clientId]);

    // 4. क्लाइंट को ईमेल भेजें
    $mail = new PHPMailer(true);
    // SMTP सेटिंग्स
    $mail->isSMTP();
    $mail->Host = 'smtp.example.com'; // अपने SMTP सर्वर का पता
    $mail->SMTPAuth = true;
    $mail->Username = 'your_email@example.com'; // आपका ईमेल
    $mail->Password = 'your_email_password'; // आपका ईमेल पासवर्ड
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('no-reply@kmfsl.com', 'KMFSL');
    $mail->addAddress($client['email']);
    $mail->isHTML(true);
    $mail->Subject = 'Your Password Has Been Reset';
    $mail->Body    = 'Hello,<br><br>Your password for KMFSL has been reset. Your new password is: <strong>' . htmlspecialchars($newPassword) . '</strong><br><br>Please log in and change your password for security reasons.<br><br>Thank you.';
    $mail->send();

    echo json_encode(['success' => true]);

} catch (PDOException $e) {
    error_log("Password reset error (DB): " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error.']);
} catch (Exception $e) {
    error_log("Password reset error (Email): " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Email could not be sent.']);
}
?>