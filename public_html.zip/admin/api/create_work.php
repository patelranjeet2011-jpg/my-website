<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit();
}

// Data validation
$clientId = filter_input(INPUT_POST, 'client_id', FILTER_VALIDATE_INT);
$companyName = trim($_POST['company_name'] ?? '');

if (!$clientId || empty($companyName)) {
    echo json_encode(['success' => false, 'error' => 'Client ID and Company Name are required.']);
    exit();
}

try {
    $sql = "INSERT INTO work_list (client_id, company_name, folio_number, rta_contact_number, rta_email, service_type, task, status, created_at)
            VALUES (:client_id, :company_name, :folio_number, :rta_contact_number, :rta_email, :service_type, :task, 'Pending', NOW())";
    
    $stmt = $pdo->prepare($sql);
    
    $stmt->execute([
        ':client_id' => $clientId,
        ':company_name' => $companyName,
        ':folio_number' => $_POST['folio_number'] ?? null,
        ':rta_contact_number' => $_POST['rta_contact_number'] ?? null,
        ':rta_email' => $_POST['rta_email'] ?? null,
        ':service_type' => $_POST['service_type'] ?? null,
        ':task' => $_POST['initial_notes'] ?? null
    ]);

    echo json_encode(['success' => true]);

} catch (PDOException $e) {
    error_log("Work create error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error. Could not create work item.']);
}
?>