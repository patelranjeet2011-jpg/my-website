<?php
session_start();
header('Content-Type: application/json');
include '../../config/database.php';

if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

if (!isset($_GET['work_id']) || !isset($_GET['client_id'])) {
    echo json_encode(['error' => 'Invalid Request']);
    exit();
}

$workId = $_GET['work_id'];
$clientId = $_GET['client_id'];

try {
    // 1. मुख्य वर्क की जानकारी प्राप्त करें
    $workStmt = $pdo->prepare("SELECT * FROM work_list WHERE id = ? AND client_id = ?");
    $workStmt->execute([$workId, $clientId]);
    $work = $workStmt->fetch(PDO::FETCH_ASSOC);

    if (!$work) {
        echo json_encode(['error' => 'Work item not found.']);
        exit();
    }

    // 2. सभी अपडेट्स और उनसे जुड़े डॉक्यूमेंट्स प्राप्त करें
    // हम LEFT JOIN का उपयोग करेंगे ताकि जिन अपडेट्स के साथ डॉक्यूमेंट नहीं हैं, वे भी दिखें।
    // GROUP_CONCAT का उपयोग एक अपडेट से जुड़े कई डाक्यूमेंट्स को संभालने के लिए किया गया है।
    $updatesStmt = $pdo->prepare("
        SELECT 
            wu.id, 
            wu.update_note, 
            wu.created_at,
            GROUP_CONCAT(wud.file_path SEPARATOR '||') as file_paths,
            GROUP_CONCAT(wud.original_name SEPARATOR '||') as file_names
        FROM 
            work_updates wu
        LEFT JOIN 
            work_update_documents wud ON wu.id = wud.work_update_id
        WHERE 
            wu.work_id = ?
        GROUP BY
            wu.id
        ORDER BY 
            wu.created_at ASC
    ");
    $updatesStmt->execute([$workId]);
    $updatesData = $updatesStmt->fetchAll(PDO::FETCH_ASSOC);

    // PHP में डेटा को सही फॉर्मेट में व्यवस्थित करें
    $updates = [];
    foreach ($updatesData as $row) {
        $documentsList = [];
        if ($row['file_paths']) {
            $paths = explode('||', $row['file_paths']);
            $names = explode('||', $row['file_names']);
            for($i = 0; $i < count($paths); $i++) {
                $documentsList[] = [
                    'file_path' => $paths[$i],
                    'document_name' => $names[$i]
                ];
            }
        }
        $updates[] = [
            'id' => $row['id'],
            'update_note' => $row['update_note'],
            'created_at' => $row['created_at'],
            'documents' => $documentsList
        ];
    }


    // 3. इस वर्क से जुड़े सभी सामान्य डॉक्यूमेंट्स प्राप्त करें (जो किसी खास अपडेट से नहीं जुड़े हैं)
    $docsStmt = $pdo->prepare("SELECT document_name, file_path FROM work_documents WHERE work_id = ?");
    $docsStmt->execute([$workId]);
    $documents = $docsStmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. सारी जानकारी एक साथ JSON फॉर्मेट में भेजें
    echo json_encode([
        'work' => $work,
        'updates' => $updates,
        'documents' => $documents
    ]);

} catch (PDOException $e) {
    error_log("Get work details error: " . $e->getMessage());
    echo json_encode(['error' => 'Database query failed.']);
}
?>