<?php
session_start();
header('Content-Type: application/json');

// Session verification
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true || !isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

include '../../config/database.php';

$currentPassword = $_POST['current_password'] ?? '';
$newPassword = $_POST['new_password'] ?? '';

// Fetch the current admin's password from the database
try {
    $stmt = $pdo->prepare("SELECT password FROM admin_users WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        echo json_encode(['success' => false, 'error' => 'Admin not found.']);
        exit();
    }
    
    // Verify the current password
    if (!password_verify($currentPassword, $admin['password'])) {
        echo json_encode(['success' => false, 'error' => 'Incorrect current password.']);
        exit();
    }

    // Hash the new password and update it in the database
    $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $updateStmt = $pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
    $updateStmt->execute([$hashedNewPassword, $_SESSION['admin_id']]);
    
    echo json_encode(['success' => true]);

} catch (PDOException $e) {
    error_log("Password change error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error.']);
}
?>