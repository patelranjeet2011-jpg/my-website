<?php
session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}
include '../../config/database.php';
$firstName = trim($_POST['first_name'] ?? '');
$lastName = trim($_POST['last_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$password = trim($_POST['password'] ?? '');
if (empty($firstName) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'error' => 'All required fields must be filled.']);
    exit();
}
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin_users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'error' => 'Email already exists.']);
        exit();
    }
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO admin_users (first_name, last_name, email, phone, password, role) VALUES (?, ?, ?, ?, ?, 'admin')";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$firstName, $lastName, $email, $phone, $hashedPassword]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    error_log("Admin registration error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error.']);
}
?>