<?php
session_start();
header('Content-Type: application/json');
include '../../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized Access']);
    exit();
}

$clientId = filter_input(INPUT_POST, 'client_id', FILTER_VALIDATE_INT);
$docName = trim($_POST['document_name'] ?? '');

// Check if file was uploaded without errors
if (!isset($_FILES['document_file']['error']) || is_array($_FILES['document_file']['error'])) {
     echo json_encode(['success' => false, 'error' => 'Invalid file upload parameters.']);
     exit();
}

// Check for specific upload errors
if ($_FILES['document_file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'error' => 'File upload error code: ' . $_FILES['document_file']['error']]);
    exit();
}

if (!$clientId || empty($docName)) {
    echo json_encode(['success' => false, 'error' => 'Client ID and Document Name are required.']);
    exit();
}

$targetDir = "../../uploads/client_documents/";
if (!is_dir($targetDir)) {
    mkdir($targetDir, 0755, true);
}

// Create a unique file name to prevent overwriting
$fileName = $clientId . '_' . time() . '_' . basename($_FILES["document_file"]["name"]);
$targetFile = $targetDir . $fileName;
$dbPath = "uploads/client_documents/" . $fileName;

// Try to move the uploaded file
if (move_uploaded_file($_FILES["document_file"]["tmp_name"], $targetFile)) {
    try {
        $stmt = $pdo->prepare("INSERT INTO documents (client_id, document_name, file_path) VALUES (?, ?, ?)");
        $stmt->execute([$clientId, $docName, $dbPath]);
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        // If DB insert fails, delete the uploaded file
        unlink($targetFile);
        echo json_encode(['success' => false, 'error' => 'Database error.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file. Check permissions.']);
}
?>