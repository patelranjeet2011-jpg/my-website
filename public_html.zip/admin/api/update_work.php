<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo '<pre>';
print_r($_POST);
echo '</pre>';
die();
?>
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit();
}

$workId = filter_input(INPUT_POST, 'work_id', FILTER_VALIDATE_INT);
$clientId = filter_input(INPUT_POST, 'client_id', FILTER_VALIDATE_INT);
$companyName = trim($_POST['company_name'] ?? '');
$folioNumber = trim($_POST['folio_number'] ?? '');
$rtaContact = trim($_POST['rta_contact_number'] ?? '');
$rtaEmail = trim($_POST['rta_email'] ?? '');
$serviceType = trim($_POST['service_type'] ?? '');
$task = trim($_POST['initial_notes'] ?? '');

if (!$workId || !$clientId) {
    echo json_encode(['success' => false, 'error' => 'Work ID and Client ID are required.']);
    exit();
}

try {
    $sql = "UPDATE work_list SET
                company_name = :company_name,
                folio_number = :folio_number,
                rta_contact_number = :rta_contact_number,
                rta_email = :rta_email,
                service_type = :service_type,
                task = :task
            WHERE id = :work_id AND client_id = :client_id";
    
    $stmt = $pdo->prepare($sql);
    
    $stmt->execute([
        ':company_name' => $companyName,
        ':folio_number' => $folioNumber,
        ':rta_contact_number' => $rtaContact,
        ':rta_email' => $rtaEmail,
        ':service_type' => $serviceType,
        ':task' => $task,
        ':work_id' => $workId,
        ':client_id' => $clientId
    ]);

    echo json_encode(['success' => true]);

} catch (PDOException $e) {
    error_log("Work update error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error. Could not update work item.']);
}
?>