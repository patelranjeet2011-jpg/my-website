<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// The path to the database config file is two levels up from admin/api/
include '../../config/database.php';

$clientId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$clientId) {
    echo json_encode(['error' => 'Invalid client ID.']);
    exit();
}

try {
    // Fetch documents
    $stmt_docs = $pdo->prepare("SELECT document_name, file_path, created_at FROM documents WHERE client_id = ? ORDER BY id DESC");
    $stmt_docs->execute([$clientId]);
    $documents = $stmt_docs->fetchAll(PDO::FETCH_ASSOC);

    // Fetch messages
    $stmt_msgs = $pdo->prepare("SELECT message, sender_type, created_at FROM messages WHERE client_id = ? ORDER BY id ASC");
    $stmt_msgs->execute([$clientId]);
    $messages = $stmt_msgs->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'documents' => $documents,
        'messages' => $messages
    ]);

} catch (PDOException $e) {
    error_log("API Error (get_client_extra_details): " . $e->getMessage());
    echo json_encode(['error' => 'Database error.']);
}
?>

