<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// --- सबसे ज़रूरी: सुनिश्चित करें कि यह पाथ सही है ---
include '../../config/database.php';

$clientId = filter_input(INPUT_GET, 'client_id', FILTER_VALIDATE_INT);

if (!$clientId) {
    echo json_encode(['error' => 'Invalid Client ID']);
    exit();
}

try {
    // यह सुनिश्चित करें कि आपके टेबल और कॉलम के नाम सही हैं
    $sql = "SELECT id, client_id, company_name, service_type, status, created_at 
            FROM work_list 
            WHERE client_id = :client_id 
            ORDER BY created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':client_id' => $clientId]);
    $works = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($works);

} catch (PDOException $e) {
    // असली एरर को सर्वर पर लॉग करें, यूजर को न दिखाएं
    error_log("Get work list error: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Database error. Could not retrieve work list.']);
}
?>