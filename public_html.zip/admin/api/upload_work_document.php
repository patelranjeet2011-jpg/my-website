<?php
session_start();
header('Content-Type: application/json');
include '../../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$workId = filter_input(INPUT_POST, 'work_id', FILTER_VALIDATE_INT);
$docName = trim($_POST['document_name'] ?? 'Work Document');

if (!$workId || !isset($_FILES['work_document'])) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields.']);
    exit();
}

$targetDir = "../../uploads/work_documents/";
if (!is_dir($targetDir)) {
    mkdir($targetDir, 0755, true);
}
$fileName = time() . '_' . basename($_FILES["work_document"]["name"]);
$targetFile = $targetDir . $fileName;
$dbPath = "uploads/work_documents/" . $fileName;

if (move_uploaded_file($_FILES["work_document"]["tmp_name"], $targetFile)) {
    try {
        $stmt = $pdo->prepare("INSERT INTO work_documents (work_id, document_name, file_path) VALUES (?, ?, ?)");
        $stmt->execute([$workId, $docName, $dbPath]);
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to upload file.']);
}
?>