<?php
// api/send_message.php
session_start();
header('Content-Type: application/json');
include '../../config/database.php';

if (!isset($_SESSION['admin_logged_in']) || !isset($_SESSION['admin_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized Access']);
    exit();
}

$clientId = filter_input(INPUT_POST, 'client_id', FILTER_VALIDATE_INT);
$message = trim($_POST['message'] ?? '');
$adminId = 0; // Admin की ID 0 है

if (!$clientId || empty($message)) {
    echo json_encode(['success' => false, 'error' => 'Client ID and message are required.']);
    exit();
}

try {
    // THE FIX IS HERE: Ab yeh client ki tarah hi message save karega
    $sql = "INSERT INTO messages (sender_id, receiver_id, message, created_at) VALUES (?, ?, ?, NOW())";
    $stmt = $pdo->prepare($sql);
    
    // sender_id = 0 (admin), receiver_id = client ki ID
    $stmt->execute([$adminId, $clientId, $message]);
    
    echo json_encode(['success' => true]);

} catch (PDOException $e) {
    error_log("Message send error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error. Could not send message.']);
}
?>