<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true || !isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

include '../../config/database.php';

try {
    // यहाँ 'admin_users' टेबल से एडमिन की जानकारी ली जा रही है
    // सुनिश्चित करें कि आपकी टेबल का नाम यही है और इसमें admin_id है।
    $sql = "SELECT first_name, last_name, email, phone FROM admin_users WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin) {
        echo json_encode(['success' => true, 'profile' => $admin]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Admin profile not found.']);
    }
} catch (PDOException $e) {
    error_log("Admin profile fetch error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error.']);
}
?>