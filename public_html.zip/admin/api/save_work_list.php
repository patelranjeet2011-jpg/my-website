<?php
header('Content-Type: application/json');
include '../config/database.php';

$response = ['success' => false];

// Sanitize and retrieve POST data
$client_id = isset($_POST['client_id']) ? intval($_POST['client_id']) : 0;
$company_name = isset($_POST['company_name']) ? trim($_POST['company_name']) : '';
$folio_number = isset($_POST['folio_number']) ? trim($_POST['folio_number']) : '';
$rta_contact = isset($_POST['rta_contact']) ? trim($_POST['rta_contact']) : '';
$rta_email = isset($_POST['rta_email']) ? trim($_POST['rta_email']) : '';
$service_type = isset($_POST['service_type']) ? trim($_POST['service_type']) : '';
$initial_notes = isset($_POST['initial_notes']) ? trim($_POST['initial_notes']) : '';

if ($client_id > 0 && !empty($company_name) && !empty($service_type)) {
    
    $sql = "INSERT INTO work_lists (client_id, company_name, folio_number, rta_contact, rta_email, service_type, initial_notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issssss", $client_id, $company_name, $folio_number, $rta_contact, $rta_email, $service_type, $initial_notes);
    
    if ($stmt->execute()) {
        $response['success'] = true;
    } else {
        $response['error'] = 'Database error: ' . $stmt->error;
    }
    $stmt->close();
    
} else {
    $response['error'] = 'Required fields are missing.';
}

$conn->close();
echo json_encode($response);
?>