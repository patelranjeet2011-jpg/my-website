<?php
session_start();
header('Content-Type: application/json');

// जाँचें कि एडमिन लॉग इन है या नहीं
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // अगर लॉग इन नहीं है, तो अनधिकृत एरर भेजें
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

// डेटाबेस कनेक्शन शामिल करें
include '../../config/database.php';

try {
    // SQL क्वेरी बिना पासवर्ड के
    $sql = "SELECT id, CONCAT(first_name, ' ', last_name) AS name, email FROM users";
    
    // क्वेरी चलाएं और सभी क्लाइंट प्राप्त करें
    $stmt = $pdo->query($sql);
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // सफलता का संदेश और क्लाइंट की लिस्ट भेजें
    echo json_encode(['success' => true, 'clients' => $clients]);

} catch (PDOException $e) {
    // अगर कोई डेटाबेस एरर आता है, तो उसे लॉग करें और एक सामान्य एरर संदेश भेजें
    error_log("Client list fetch error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error.']);
}
?>