<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit();
}

// FIX: Corrected path to database config file
// It needs to go up two directories from admin/api/ to the root
include '../../config/database.php';

$clientId = filter_input(INPUT_POST, 'client_id', FILTER_VALIDATE_INT);
if (!$clientId) {
    echo json_encode(['success' => false, 'error' => 'Invalid client ID.']);
    exit();
}

try {
    $sql = "UPDATE users SET first_name = :first_name, last_name = :last_name, email = :email, phone = :phone, dob = :dob, pan_number = :pan_number WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => $clientId,
        ':first_name' => $_POST['first_name'] ?? null,
        ':last_name' => $_POST['last_name'] ?? null,
        ':email' => $_POST['email'] ?? null,
        ':phone' => $_POST['phone'] ?? null,
        ':dob' => !empty($_POST['dob']) ? $_POST['dob'] : null,
        ':pan_number' => $_POST['pan_number'] ?? null
    ]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    error_log("Profile update error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error. Could not update profile.']);
}
?>
