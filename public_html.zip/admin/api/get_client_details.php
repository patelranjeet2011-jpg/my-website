<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

$db_path = '../../config/database.php'; 
if (!file_exists($db_path)) {
    echo json_encode(['error' => "Server Error: Database config file not found."]);
    exit();
}
include $db_path;
if (!isset($pdo)) {
    echo json_encode(['error' => "Server Error: Database connection variable is not set."]);
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['error' => 'Client ID is missing.']);
    exit();
}

$clientId = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$adminId = 0; // Admin की ID 0 है

try {
    // 1. Fetch main client details
    $stmt = $pdo->prepare(
        "SELECT id, first_name, last_name, CONCAT(first_name, ' ', last_name) AS name, email, phone, dob, pan_number, created_at, status, profile_photo_path FROM users WHERE id = ?"
    );
    $stmt->execute([$clientId]);
    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$client) {
        echo json_encode(['error' => 'No client found with this ID.']);
        exit();
    }

    // 2. Fetch associated documents
    $docStmt = $pdo->prepare("SELECT document_name, file_path, created_at FROM documents WHERE client_id = ? ORDER BY id DESC");
    $docStmt->execute([$clientId]);
    $documents = $docStmt->fetchAll(PDO::FETCH_ASSOC);

    // 3. Fetch associated messages (THE FIX IS HERE)
    // अब यह क्लाइंट और एडमिन दोनों तरफ के मैसेज ढूंढेगा
    $msgStmt = $pdo->prepare(
        "SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC"
    );
    $msgStmt->execute([$clientId, $adminId, $adminId, $clientId]);
    $messages = $msgStmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Send all data back as a single JSON object
    echo json_encode([
        'client' => $client,
        'documents' => $documents,
        'messages' => $messages
    ]);

} catch (Exception $e) {
    echo json_encode(['error' => 'Database Query Failed: ' . $e->getMessage()]);
}
?>