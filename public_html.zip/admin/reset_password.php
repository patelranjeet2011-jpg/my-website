<?php
session_start();
include '../config/database.php';
$message = '';
$email = $_GET['email'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $otp = trim($_POST['otp'] ?? '');
    $newPassword = trim($_POST['new_password'] ?? '');
    try {
        $stmt = $pdo->prepare("SELECT id, otp FROM admin_users WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();
        if ($admin && $admin['otp'] == $otp) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $updateStmt = $pdo->prepare("UPDATE admin_users SET password = ?, otp = NULL WHERE id = ?");
            $updateStmt->execute([$hashedPassword, $admin['id']]);
            $message = 'Your password has been reset successfully.';
        } else {
            $message = 'Invalid OTP or email.';
        }
    } catch (PDOException $e) {
        $message = 'Database error. Please try again later.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="min-h-screen bg-gray-100 flex items-center justify-center">
    <div class="w-full max-w-sm p-8 space-y-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold text-center">Reset Password</h2>
        <?php if ($message): ?>
            <div class="p-3 text-sm text-center text-blue-700 bg-blue-100 rounded-lg">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <div class="space-y-4">
                <div>
                    <label for="otp" class="sr-only">OTP</label>
                    <input id="otp" name="otp" type="text" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter OTP">
                </div>
                <div>
                    <label for="new_password" class="sr-only">New Password</label>
                    <input id="new_password" name="new_password" type="password" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="New Password">
                </div>
            </div>
            <button type="submit" class="w-full mt-4 px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700">
                Reset Password
            </button>
        </form>
    </div>
</body>
</html>