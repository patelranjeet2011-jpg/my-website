<?php
session_start();

// Check if admin is already logged in
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: dashboard.php');
    exit();
}

$error_message = '';
$success_message = '';

// Handle login form submission
if ($_POST) {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $remember_me = isset($_POST['remember_me']);
    
    // Simple authentication (in production, use proper password hashing)
    if ($email === 'admin@kmfsl.com' && $password === 'admin123') {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_email'] = $email;
$_SESSION['admin_id'] = 1;
        
        // Set remember me cookie if checked
        if ($remember_me) {
            setcookie('admin_remember', base64_encode($email), time() + (30 * 24 * 60 * 60), '/');
        }
        
        header('Location: dashboard.php');
        exit();
    } else {
        $error_message = 'Invalid credentials. Please try again.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - KMFSL | Administrative Access</title>
    <meta name="description" content="Secure admin login for KMFSL administrative panel. Access client management, service tracking, and business analytics.">
    
    <!-- Common Styles -->
    <?php include '../includes/styles.php'; ?>
</head>
<body class="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
    <div class="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative z-10">
        <div class="max-w-md w-full space-y-8">
            <!-- Header -->
            <div class="text-center">
                <!-- Company Logo -->
                <div class="flex justify-center mb-6">
                    <div class="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-user-tie text-3xl text-white"></i>
                    </div>
                </div>
                <h2 class="text-3xl font-bold text-white mb-2">
                    Admin Login
                </h2>
                <p class="text-gray-400 mb-2">
                    KMFSL Administrative Panel
                </p>
                <div class="flex items-center justify-center text-blue-400 mb-6">
                    <i class="fas fa-shield-alt mr-2"></i>
                    <span class="text-sm">Secure Access Portal</span>
                </div>
            </div>
            
            <!-- Login Form -->
            <div class="bg-white bg-opacity-5 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700">
                <div class="px-8 py-10">
                    <!-- Error Message -->
                    <?php if ($error_message): ?>
                        <div class="bg-red-500 bg-opacity-20 border border-red-400 text-red-100 px-4 py-3 rounded-lg mb-6">
                            <div class="flex items-center">
                                <i class="fas fa-exclamation-triangle mr-2"></i>
                                <span><?php echo $error_message; ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="space-y-6">
                        <!-- Email Field -->
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-300 mb-2">
                                Email Address
                            </label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-user text-gray-400"></i>
                                </div>
                                <input 
                                    type="email" 
                                    id="email" 
                                    name="email" 
                                    required
                                    value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                    class="input-field w-full pl-10 pr-4 py-3 bg-gray-800 bg-opacity-50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white placeholder-gray-400"
                                    placeholder="admin@kmfsl.com"
                                >
                            </div>
                        </div>
                        
                        <!-- Password Field -->
                        <div>
                            <label for="password" class="block text-sm font-medium text-gray-300 mb-2">
                                Password
                            </label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-lock text-gray-400"></i>
                                </div>
                                <input 
                                    type="password" 
                                    id="password" 
                                    name="password" 
                                    required
                                    class="input-field w-full pl-10 pr-12 py-3 bg-gray-800 bg-opacity-50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-white placeholder-gray-400"
                                    placeholder="Enter your password"
                                >
                                <button type="button" class="absolute inset-y-0 right-0 pr-3 flex items-center" onclick="togglePassword()">
                                    <i id="password-icon" class="fas fa-eye text-gray-400 hover:text-gray-300"></i>
                                </button>
                            </div>
                        </div>
                        
                        <!-- Remember Me -->
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <input 
                                    id="remember_me" 
                                    name="remember_me" 
                                    type="checkbox" 
                                    class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-600 rounded bg-gray-800"
                                >
                                <label for="remember_me" class="ml-2 block text-sm text-gray-300">
                                    Remember me for 30 days
                                </label>
                            </div>
                        </div>
                        
                        <!-- Submit Button -->
                        <button 
                            type="submit" 
                            class="btn-primary w-full text-white py-3 px-4 rounded-lg font-semibold text-lg flex items-center justify-center"
                        >
                            <i class="fas fa-sign-in-alt mr-2"></i>
                            Sign In to Dashboard
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Security Notice -->
            <div class="bg-yellow-500 bg-opacity-20 border border-yellow-400 border-opacity-30 text-yellow-100 px-4 py-3 rounded-lg backdrop-blur-sm">
                <div class="flex items-center">
                    <i class="fas fa-shield-alt mr-3 text-yellow-300"></i>
                    <div>
                        <p class="text-sm font-medium">Secure Administrative Access</p>
                        <p class="text-xs text-yellow-200 mt-1">
                            This area is restricted to authorized personnel only. All access attempts are logged and monitored.
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Default Credentials Info (Remove in production) -->
            <div class="bg-blue-500 bg-opacity-20 border border-blue-400 border-opacity-30 text-blue-100 px-4 py-3 rounded-lg backdrop-blur-sm">
                <div class="flex items-center">
                    <i class="fas fa-info-circle mr-3 text-blue-300"></i>
                    <div>
                        <p class="text-sm font-medium">Development Access</p>
                        <p class="text-xs text-blue-200 mt-1">
                            Default credentials: <strong>admin@kmfsl.com</strong> / <strong>admin123</strong>
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Footer Links -->
            <div class="text-center text-gray-400 text-sm space-y-2">
                <p>
                    © 2024 Kaimur Financial Services Pvt. Ltd.
                </p>
                <div class="flex justify-center space-x-6">
                    <a href="../index.php" class="hover:text-blue-400 transition-colors flex items-center">
                        <i class="fas fa-home mr-1"></i>
                        Back to Website
                    </a>
                    <a href="../privacy-policy.php" class="hover:text-blue-400 transition-colors flex items-center">
                        <i class="fas fa-shield-alt mr-1"></i>
                        Privacy Policy
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Background Animation -->
    <div class="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div class="absolute -top-40 -right-40 w-80 h-80 bg-blue-500 bg-opacity-5 rounded-full animate-pulse"></div>
        <div class="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 bg-opacity-5 rounded-full animate-pulse" style="animation-delay: 2s;"></div>
        <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-500 bg-opacity-3 rounded-full animate-pulse" style="animation-delay: 4s;"></div>
    </div>
    
    <!-- JavaScript -->
    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const passwordIcon = document.getElementById('password-icon');
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.classList.remove('fa-eye');
                passwordIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordIcon.classList.remove('fa-eye-slash');
                passwordIcon.classList.add('fa-eye');
            }
        }
        
        // Auto-focus email field
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('email').focus();
            
            const form = document.querySelector('form');
            const inputs = form.querySelectorAll('input');
            
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('transform', 'scale-105');
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.classList.remove('transform', 'scale-105');
                });
            });
        });
        
        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            if (!email || !password) {
                e.preventDefault();
                alert('Please fill in all required fields.');
            }
        });
    </script>
</body>
</html>