<?php
// admin/work_details.php - Updated: wider Updates Log area (uses 12-col layout on large screens)
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Work Details - Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.tiny.cloud/1/jn3guezlo3pzgafi7ik0r6ivcxdtkzmukvehwt1tjc84gp4t/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
  <style>
    .update-thumb { width:140px; height:140px; object-fit:cover; border-radius:8px; border:1px solid #e5e7eb; }
    .file-badge { display:inline-block; padding:8px 12px; border-radius:10px; background:#f3f4f6; color:#1f2937; font-weight:600; text-decoration:none; }
    .update-card { background: #fff; border-radius:10px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); padding:18px; }
    .avatar-sm { width:46px; height:46px; border-radius:9999px; object-fit:cover; }
    /* make the updates column scroll nicely and use more of the page width */
    #updatesLog { max-height:calc(80vh - 260px); overflow-y:auto; padding-right:6px; }
    /* reduce container side padding on wide screens so updates can use more horizontal space */
    @media (min-width: 1024px) {
      .page-container { max-width: 1280px; } /* approx tailwind's 7xl -> a bit wider */
      .content-pad { padding-left: 8px; padding-right: 8px; }
    }
    /* make file-badges wrap nicely */
    .file-badge { white-space: normal; max-width: 100%; display:inline-block; }
  </style>
</head>
<body class="min-h-screen bg-gray-100">
  <?php include '../includes/header.php'; ?>

  <div class="page-container mx-auto px-4 sm:px-6 lg:px-2 py-8">
    <div id="pageContent" class="space-y-6 content-pad">
      <div class="flex items-center justify-between">
        <h1 id="pageTitle" class="text-2xl font-bold text-gray-800">Loading...</h1>
        <div><a href="dashboard.php" class="text-sm text-gray-600 hover:underline">← Back to Dashboard</a></div>
      </div>

      <!-- Use 12-column layout on large screens so updates area can be wider -->
      <div id="mainGrid" class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- LEFT: MAIN (span 8 columns on large screens - bigger area for updates) -->
        <div id="leftCol" class="lg:col-span-8 space-y-6">
          <div id="workDetailsCard" class="bg-white rounded-lg shadow p-6">
            <h2 class="text-lg font-semibold mb-4">Work Details</h2>
            <div id="workDetailsGrid" class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-700"></div>
          </div>

          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold mb-3">Add New Update</h3>
            <form id="addUpdateForm" enctype="multipart/form-data" class="space-y-3">
              <input type="hidden" name="work_id" id="form_work_id">
              <input type="hidden" name="client_id_for_refresh" id="form_client_id">
              <label class="block text-sm font-medium">Update Note</label>
              <textarea id="updateNoteEditor" name="update_note"></textarea>

              <label class="block text-sm font-medium">Attach Document(s) (Optional)</label>
              <input type="file" name="update_document[]" multiple class="block w-full text-sm">

              <div class="flex justify-end">
                <button id="addUpdateBtn" type="submit" class="bg-purple-600 text-white px-4 py-2 rounded-md font-semibold">Add Update</button>
              </div>
              <div id="addUpdateStatus" class="text-sm text-center mt-2"></div>
            </form>
          </div>

          <!-- BIGGER: Updates Log sits here in left (wider view) -->
          <div class="bg-white rounded-lg shadow p-5">
            <h3 class="font-semibold mb-3">Updates Log</h3>
            <div id="updatesLog" class="space-y-4 text-sm text-gray-700">
              <!-- updates will be injected here -->
            </div>
          </div>
        </div>

        <!-- RIGHT: Work Documents (narrower column) -->
        <div class="lg:col-span-4 space-y-6">
          <div class="bg-white rounded-lg shadow p-5">
            <h3 class="font-semibold mb-3">Work Documents</h3>
            <form id="uploadWorkDocForm" class="space-y-3" enctype="multipart/form-data">
              <input type="hidden" name="work_id" id="upload_work_id">
              <input type="text" name="document_name" placeholder="Document Name (e.g., PAN Card)" class="w-full p-2 border rounded text-sm" required>
              <input type="file" name="work_document" class="w-full text-sm" required>
              <button class="w-full bg-blue-600 text-white py-2 rounded-md font-semibold" type="submit">Upload Document</button>
            </form>
            <div id="workDocumentsList" class="mt-4 max-h-80 overflow-y-auto text-sm"></div>
          </div>
        </div>
      </div>
    </div>
  </div>

<script>
(function(){
  const params = new URLSearchParams(window.location.search);
  const workId = params.get('work_id') || '';
  const clientId = params.get('client_id') || '';

  if (!workId) {
    document.getElementById('pageContent').innerHTML = '<div class="bg-white p-6 rounded shadow">No work selected.</div>';
    return;
  }
  document.getElementById('pageTitle').innerText = 'Updating Work';

  tinymce.init({
    selector: '#updateNoteEditor',
    plugins: 'lists link image table code help wordcount',
    toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist outdent indent | link image',
    height: 220,
    menubar: false
  });

  function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, function(m){ return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]; }); }
  function isImagePath(path){ if(!path) return false; return /\.(jpe?g|png|gif|webp|bmp)$/i.test(path.split('?')[0]); }

  function renderUpdateItem(u){
    const authorName = u.author_name || u.sender_name || u.created_by || 'Admin';
    const avatarPath = u.author_avatar_path || u.avatar || '';
    let avatarHtml = '';
    if(avatarPath){
      avatarHtml = `<img src="../${escapeHtml(avatarPath)}" alt="${escapeHtml(authorName)}" class="avatar-sm">`;
    } else {
      const initials = (authorName.split(' ').filter(Boolean).slice(0,2).map(n=>n.charAt(0).toUpperCase()).join('')) || 'A';
      avatarHtml = `<div class="w-12 h-12 rounded-full bg-blue-500 text-white flex items-center justify-center font-semibold">${escapeHtml(initials)}</div>`;
    }

    let attachHtml = '';
    if (u.documents && u.documents.length > 0) {
      attachHtml = `<div class="mt-3 flex flex-wrap gap-3">` + u.documents.map(d => {
        const filePath = `../${d.file_path}`;
        if (isImagePath(d.file_path)) {
          return `<a href="${filePath}" target="_blank" class="block"><img src="${filePath}" alt="${escapeHtml(d.document_name)}" class="update-thumb"></a>`;
        } else {
          return `<a href="${filePath}" target="_blank" class="file-badge" title="${escapeHtml(d.document_name)}">${escapeHtml(d.document_name || 'File')}</a>`;
        }
      }).join('') + `</div>`;
    }

    const createdAt = u.created_at ? new Date(u.created_at).toLocaleString() : '';
    const title = u.title || u.update_subject || authorName;
    return `
      <div class="update-card">
        <div class="flex gap-4">
          <div>${avatarHtml}</div>
          <div class="flex-1">
            <div class="flex justify-between items-start">
              <div class="text-sm font-semibold text-gray-800">${escapeHtml(title)}</div>
              <div class="text-xs text-gray-500">${escapeHtml(createdAt)}</div>
            </div>
            <div class="mt-2 text-sm text-gray-700">${u.update_note || ''}</div>
            ${attachHtml}
          </div>
        </div>
      </div>
    `;
  }

  async function loadWork(){
    try {
      const url = `api/get_work_details.php?work_id=${encodeURIComponent(workId)}&client_id=${encodeURIComponent(clientId)}`;
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) { const text = await res.text(); throw new Error(`Invalid Request (status ${res.status}): ${text}`); }
      const data = await res.json();
      if (data.error) throw new Error(data.error || 'Error fetching work');

      const { work, updates = [], documents = [] } = data;
      const clientName = work.client_name || work.client || '';
      document.getElementById('pageTitle').innerText = `Updating Work for ${clientName || 'Client'}`;

      // Work details grid
      const rawPhone = work.rta_contact_number || '';
      const telNumber = rawPhone.replace(/\D/g,'');
      document.getElementById('workDetailsGrid').innerHTML = `
        <div><p class="text-xs text-gray-500">Company</p><p class="font-semibold">${escapeHtml(work.company_name || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">Service</p><p class="font-semibold">${escapeHtml(work.service_type || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">Folio Number</p><p class="font-semibold">${escapeHtml(work.folio_number || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">Status</p><p class="font-semibold">${escapeHtml(work.status || 'N/A')}</p></div>
        <div><p class="text-xs text-gray-500">RTA Contact</p><p class="font-semibold">${rawPhone ? `<a href="tel:${telNumber}" class="text-blue-600 hover:underline">${escapeHtml(rawPhone)}</a>` : 'N/A'}</p></div>
        <div><p class="text-xs text-gray-500">RTA Email</p><p class="font-semibold">${work.rta_email ? `<a href="mailto:${escapeHtml(work.rta_email)}" class="text-blue-600 hover:underline">${escapeHtml(work.rta_email)}</a>` : 'N/A'}</p></div>
        <div class="sm:col-span-2"><p class="text-xs text-gray-500">Initial Notes</p><p class="text-gray-700 whitespace-pre-wrap">${escapeHtml(work.initial_notes || 'N/A')}</p></div>
      `;

      document.getElementById('form_work_id').value = work.id;
      document.getElementById('form_client_id').value = work.client_id || clientId || '';
      document.getElementById('upload_work_id').value = work.id;

      // Updates log
      const updatesContainer = document.getElementById('updatesLog');
      updatesContainer.innerHTML = (updates && updates.length) ? updates.map(u => renderUpdateItem(u)).join('') : '<p class="text-sm text-gray-500">No updates yet.</p>';

      // Documents list (right column)
      const docsList = document.getElementById('workDocumentsList');
      docsList.innerHTML = (documents && documents.length) ? documents.map(d => `
        <div class="flex justify-between items-center p-3 border-b">
          <div class="text-sm font-medium">${escapeHtml(d.document_name)}</div>
          <div><a href="../${escapeHtml(d.file_path)}" target="_blank" class="file-badge">View</a></div>
        </div>
      `).join('') : '<p class="text-sm text-gray-500">No documents uploaded.</p>';

    } catch(err) {
      document.getElementById('pageContent').innerHTML = `<div class="bg-white p-6 rounded shadow text-red-600">Error: ${escapeHtml(err.message)}</div>`;
      console.error('loadWork error:', err);
    }
  }

  // Add update handler
  document.getElementById('addUpdateForm').addEventListener('submit', async function(e){
    e.preventDefault();
    const btn = document.getElementById('addUpdateBtn'); btn.disabled = true; btn.innerText = 'Saving...';
    const status = document.getElementById('addUpdateStatus');
    const editor = (typeof tinymce !== 'undefined') ? tinymce.get('updateNoteEditor') : null;
    const updateContent = (editor && editor.getContent) ? editor.getContent() : (document.querySelector('#updateNoteEditor')?.value || '');
    if (!updateContent.trim()) { alert('Please write an update note.'); btn.disabled=false; btn.innerText='Add Update'; return; }
    const form = new FormData(this); form.set('update_note', updateContent);
    try {
      const res = await fetch('api/add_work_update.php', { method: 'POST', body: form });
      if (!res.ok) { const txt = await res.text(); throw new Error(`Server error (status ${res.status}): ${txt}`); }
      const result = await res.json();
      if (result.success) {
        status.className = 'text-sm text-green-600 mt-2'; status.innerText = 'Update added.';
        if (editor && editor.setContent) editor.setContent('');
        this.reset(); await loadWork();
      } else throw new Error(result.error || 'Failed to add update');
    } catch(err) {
      status.className = 'text-sm text-red-600 mt-2'; status.innerText = 'Error: ' + err.message; console.error(err);
    } finally { btn.disabled = false; btn.innerText = 'Add Update'; }
  });

  // Upload work document handler
  document.getElementById('uploadWorkDocForm').addEventListener('submit', async function(e){
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]'); btn.disabled = true; btn.innerText = 'Uploading...';
    try {
      const res = await fetch('api/upload_work_document.php', { method: 'POST', body: new FormData(this) });
      if (!res.ok) { const txt = await res.text(); throw new Error(`Server error (status ${res.status}): ${txt}`); }
      const result = await res.json();
      if (result.success) { this.reset(); await loadWork(); } else throw new Error(result.error || 'Upload failed');
    } catch (err) { alert('Error uploading document: ' + err.message); console.error(err); } finally { btn.disabled = false; btn.innerText = 'Upload Document'; }
  });

  // initial load
  loadWork();
})();
</script>
</body>
</html>