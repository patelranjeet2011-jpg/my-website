<?php
session_start();
include '../config/database.php';
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    try {
        $stmt = $pdo->prepare("SELECT id FROM admin_users WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();
        if ($admin) {
            $otp = rand(100000, 999999);
            $updateStmt = $pdo->prepare("UPDATE admin_users SET otp = ? WHERE id = ?");
            $updateStmt->execute([$otp, $admin['id']]);
            $message = 'A password reset OTP has been sent to your email.';
            // यहाँ ईमेल भेजने का कोड आएगा
        } else {
            $message = 'Email not found.';
        }
    } catch (PDOException $e) {
        $message = 'Database error. Please try again later.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="min-h-screen bg-gray-100 flex items-center justify-center">
    <div class="w-full max-w-sm p-8 space-y-6 bg-white rounded-lg shadow-md">
        <h2 class="text-2xl font-bold text-center">Forgot Password</h2>
        <?php if ($message): ?>
            <div class="p-3 text-sm text-center text-blue-700 bg-blue-100 rounded-lg">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="">
            <div>
                <label for="email" class="sr-only">Email address</label>
                <input id="email" name="email" type="email" autocomplete="email" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Email address">
            </div>
            <button type="submit" class="w-full px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700">
                Send Reset Link
            </button>
        </form>
    </div>
</body>
</html>