<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}
include '../config/database.php';
// Services list as per your image
$services = [
    "IEPF Claim", "Transmission of Shares", "Demat of Physical Shares", "Unclaimed Dividends",
    "Conversion of Shares/Debentures", "Property Claim Samadhan", "Debtor Recovery",
    "Recovery of Unclaimed Mutual Funds", "Recovery of Inoperative Bank Accounts",
    "Provident Funds Claim", "Recovery of Unclaimed Matured Insurance"
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - KMFSL</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <style>
    .sidebar-item { display:block; width: 100%; text-align: left; padding:10px 12px; border-radius:6px; transition: background-color 0.2s, color 0.2s; }
    .sidebar-item:hover { background-color: #f3f4f6; }
    .sidebar-item.active { background:#eff6ff; color: #2563eb; font-weight: 600; }
    .tab-content { display: none; }
    .tab-content.active { display: block; }
    .modal { display: none; opacity: 0; transition: opacity 0.3s ease-in-out; }
    .modal.flex { display: flex; }
    .modal.visible { opacity: 1; }
    .chat-box::-webkit-scrollbar { width: 5px; }
    .chat-box::-webkit-scrollbar-track { background: #f1f1f1; }
    .chat-box::-webkit-scrollbar-thumb { background: #888; border-radius: 6px;}

    .modal-title {
        flex-grow: 1;
        flex-shrink: 1;
        min-width: 0;
        
    }
    .modal-close-btn {
        flex-shrink: 0;
    }
  </style>
 <script src="https://cdn.tiny.cloud/1/jn3guezlo3pzgafi7ik0r6ivcxdtkzmukvehwt1tjc84gp4t/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
</head>
<body class="min-h-screen bg-gray-100">
  <?php include '../includes/header.php'; ?>
  <div class="bg-white shadow-sm border-b mt-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex justify-end items-center py-3 space-x-4">
    <span class="text-sm text-gray-600">Admin User</span>
    <a href="logout.php" class="text-sm font-semibold text-red-600 hover:text-red-800 hover:underline">Logout</a>
</div></div>
  </div>

  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="flex flex-col lg:flex-row gap-8">
      <aside class="w-full lg:w-64 flex-shrink-0">
        <div class="bg-white rounded-lg shadow p-6">
          <nav class="space-y-2">
            <button onclick="showTab('overview')" class="sidebar-item" id="overview-tab">Overview</button>
            <button onclick="showTab('clients')" class="sidebar-item" id="clients-tab">Client Management</button>
            <button onclick="showTab('requests')" class="sidebar-item" id="requests-tab">Service Requests</button>
            <button onclick="showTab('documents')" class="sidebar-item" id="documents-tab">Document Review</button>
            <button onclick="showTab('reports')" class="sidebar-item" id="reports-tab">Reports & Analytics</button>
            <button onclick="showTab('settings')" class="sidebar-item" id="settings-tab">Settings</button>
          </nav>
        </div>
      </aside>
      
      <main class="flex-1">
        <div id="overview-content" class="tab-content"><div class="bg-white rounded-lg shadow p-6"><h2 class="text-2xl font-bold mb-4">Overview</h2><p>Welcome to the admin dashboard.</p></div></div>
        <div id="clients-content" class="tab-content"><div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold mb-4">Client Management</h2>
            <div class="overflow-x-auto"><table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50"><tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">#</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Join Date</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr></thead>
                <tbody class="bg-white divide-y divide-gray-200"><?php
                  try {
                    $stmt = $pdo->query("SELECT id, CONCAT(first_name, ' ', last_name) AS name, email, phone, created_at, status FROM users ORDER BY id DESC");
                    if ($stmt->rowCount() > 0) {
                        $sn = 1;
                        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                          echo '<tr class="hover:bg-gray-50">';
                          echo '<td class="py-3 px-4 whitespace-nowrap">'.$sn++.'</td>';
                          echo '<td class="py-3 px-4 whitespace-nowrap font-medium cursor-pointer text-blue-600 hover:underline" onclick="showClientDetails('.$row['id'].')">'.htmlspecialchars($row['name']).'</td>';
                          echo '<td class="py-3 px-4 whitespace-nowrap text-sm text-gray-500">'.htmlspecialchars($row['email']).'</td>';
                          echo '<td class="py-3 px-4 whitespace-nowrap text-sm text-gray-500">'.htmlspecialchars($row['phone']).'</td>';
                          echo '<td class="py-3 px-4 whitespace-nowrap text-sm text-gray-500">'.date('d M, Y', strtotime($row['created_at'])).'</td>';
                          echo '<td class="py-3 px-4 whitespace-nowrap text-sm font-semibold '.(htmlspecialchars(ucfirst($row['status'])) == 'Active' ? 'text-green-600' : 'text-red-500').'">'.htmlspecialchars(ucfirst($row['status'])).'</td>';
                          echo '<td class="py-3 px-4 whitespace-nowrap"><button onclick="showClientDetails('.$row['id'].')" class="text-blue-600 hover:underline text-sm font-semibold">View Details</button></td>';
                          echo '</tr>';
                        }
                    } else { echo '<tr><td colspan="7" class="text-center py-4 text-gray-500">No clients found.</td></tr>'; }
                  } catch (Exception $e) { echo '<tr><td colspan="7" class="text-center py-4 text-red-500">Error loading clients: ' . $e->getMessage() . '</td></tr>'; }
                  ?></tbody>
            </table></div>
        </div></div>
        <div id="requests-content" class="tab-content"><div class="bg-white rounded-lg shadow p-6"><h2 class="text-2xl font-bold">Service Requests</h2></div></div>
        <div id="documents-content" class="tab-content"><div class="bg-white rounded-lg shadow p-6"><h2 class="text-2xl font-bold">Document Review</h2></div></div>
        <div id="reports-content" class="tab-content"><div class="bg-white rounded-lg shadow p-6"><h2 class="text-2xl font-bold">Reports & Analytics</h2></div></div>

        <div id="settings-content" class="tab-content">
          <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold mb-4">Settings</h2>
            <div class="flex space-x-4 mb-4">
              <button id="admin-settings-tab" onclick="showSettingsSubTab('admin-settings')" class="px-4 py-2 text-sm font-semibold rounded-md border-b-2 border-transparent hover:border-blue-500 active-sub-tab">Admin</button>
              <button id="client-settings-tab" onclick="showSettingsSubTab('client-settings')" class="px-4 py-2 text-sm font-semibold rounded-md border-b-2 border-transparent hover:border-blue-500">Clients</button>
            </div>

            <div id="admin-settings-subtab" class="sub-tab-content">
              <h3 class="text-xl font-bold mb-4">Admin Profile Settings</h3>
              <div id="admin-profile-content" class="bg-gray-100 p-4 rounded-lg">
                <p>Loading admin profile...</p>
              </div>
              <div class="mt-8 bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-bold mb-4">Create New Admin User</h3>
                <form id="createAdminForm" onsubmit="createAdminUser(event)">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium">First Name</label>
                            <input type="text" name="first_name" class="mt-1 w-full border rounded-md p-2" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium">Last Name</label>
                            <input type="text" name="last_name" class="mt-1 w-full border rounded-md p-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium">Email (Login ID)</label>
                            <input type="email" name="email" class="mt-1 w-full border rounded-md p-2" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium">Phone</label>
                            <input type="text" name="phone" class="mt-1 w-full border rounded-md p-2">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium">Password</label>
                            <input type="password" name="password" class="mt-1 w-full border rounded-md p-2" required>
                        </div>
                    </div>
                    <div class="flex justify-end mt-4">
                        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md font-semibold">Create Admin</button>
                    </div>
                    <div id="createAdminStatus" class="mt-2 text-sm text-center"></div>
                </form>
              </div>
              </div>

            <div id="client-settings-subtab" class="sub-tab-content" style="display:none;">
              <h3 class="text-xl font-bold mb-4">Client List & Management</h3>
              <div id="client-list-content" class="bg-gray-100 p-4 rounded-lg">
                <p>Loading client list...</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>

  <div id="clientDetailsModal" class="modal fixed inset-0 bg-black bg-opacity-60 z-40 items-center justify-center p-4">
    <div class="bg-gray-50 w-full max-w-6xl rounded-lg shadow-xl max-h-[95vh] flex flex-col">
        <div class="sticky top-0 bg-white p-4 border-b flex justify-between items-center rounded-t-lg">
            <h2 class="text-xl font-bold text-gray-800 modal-title">Client Details</h2>
            <button onclick="closeModal('clientDetailsModal')" class="text-gray-500 hover:text-red-600 text-3xl modal-close-btn">&times;</button>
        </div>
        <div id="clientDetailsContent" class="p-6 overflow-y-auto"></div>
    </div>
  </div>

  <div id="workModal" class="modal fixed inset-0 bg-black bg-opacity-60 z-50 items-center justify-center p-4">
    <div class="bg-white w-full max-w-2xl rounded-lg shadow-xl">
      <div class="p-4 border-b flex justify-between items-center">
        <h2 id="workModalTitle" class="text-xl font-bold text-gray-800 modal-title">Create Work List</h2>
        <button onclick="closeModal('workModal')" class="text-gray-500 hover:text-red-600 text-3xl modal-close-btn">&times;</button>
      </div>
      <div class="p-6"><form id="workForm" onsubmit="handleWorkSubmit(event)">
          <input type="hidden" id="workClientId" name="client_id">
          <input type="hidden" id="workId" name="work_id">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><label class="block text-sm font-medium text-gray-700">Company Name</label><input type="text" name="company_name" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required></div>
            <div><label class="block text-sm font-medium text-gray-700">Folio Number</label><input type="text" name="folio_number" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></div>
            <div><label class="block text-sm font-medium text-gray-700">RTA Contact Number</label><input type="text" name="rta_contact_number" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></div>
            <div><label class="block text-sm font-medium text-gray-700">RTA Email</label><input type="email" name="rta_email" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></div>
            <div class="md:col-span-2"><label class="block text-sm font-medium text-gray-700">Service Type</label>
              <select name="service_type" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                <?php foreach ($services as $service): ?>
                  <option value="<?= htmlspecialchars($service) ?>"><?= htmlspecialchars($service) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="md:col-span-2"><label class="block text-sm font-medium text-gray-700">Initial Notes</label><textarea name="initial_notes" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></textarea></div>
          </div>
          <div class="flex justify-end gap-3 mt-6">
            <button type="button" onclick="closeModal('workModal')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-semibold">Cancel</button>
            <button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded-lg font-semibold" id="workSubmitButton">Create Work List</button>
          </div><div id="workStatus" class="mt-2 text-sm text-center"></div>
      </form></div>
    </div>
  </div>
  
  <div id="viewWorkListModal" class="modal fixed inset-0 bg-black bg-opacity-60 z-50 items-center justify-center p-4">
    <div class="bg-white w-full max-w-5xl rounded-lg shadow-xl max-h-[90vh] flex flex-col">
        <div class="p-4 border-b flex justify-between items-center">
          <h2 id="viewWorkListTitle" class="text-xl font-bold text-gray-800 modal-title">Work List</h2>
          <button onclick="closeModal('viewWorkListModal')" class="text-gray-500 hover:text-red-600 text-3xl modal-close-btn">&times;</button>
        </div>
        <div id="workListContent" class="p-6 overflow-y-auto"></div>
    </div>
  </div>

  <div id="workDetailsModal" class="modal fixed inset-0 bg-black bg-opacity-60 z-50 items-center justify-center p-4">
    <div class="bg-gray-100 w-full max-w-9xl rounded-lg shadow-xl max-h-[95vh] flex flex-col">
        <div class="p-4 border-b flex justify-between items-center bg-white rounded-t-lg">
            <h2 id="workDetailsTitle" class="text-xl font-bold text-gray-800 modal-title">Work Details</h2>
            <button onclick="closeModal('workDetailsModal')" class="text-gray-500 hover:text-red-600 text-3xl modal-close-btn">&times;</button>
        </div>
        <div id="workDetailsContent" class="p-6 overflow-y-auto">
            </div>
    </div>
  </div>
  <div id="editProfileModal" class="modal fixed inset-0 bg-black bg-opacity-60 z-50 items-center justify-center p-4">
    <div class="bg-white w-full max-w-2xl rounded-lg shadow-xl">
        <div class="p-4 border-b flex justify-between items-center">
          <h2 id="editProfileModalTitle" class="text-xl font-bold text-gray-800 modal-title">Edit Profile</h2>
          <button onclick="closeModal('editProfileModal')" class="text-gray-500 hover:text-red-600 text-3xl modal-close-btn">&times;</button>
        </div>
        <div class="p-6"><form id="editProfileForm" onsubmit="handleProfileUpdate(event)">
            <input type="hidden" id="editClientId" name="client_id">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><label class="block text-sm font-medium">First Name</label><input type="text" name="first_name" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" required></div>
              <div><label class="block text-sm font-medium">Last Name</label><input type="text" name="last_name" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm" required></div>
              <div><label class="block text-sm font-medium">Email</label><input type="email" name="email" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm" required></div>
              <div><label class="block text-sm font-medium">Phone</label><input type="text" name="phone" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm" required></div>
              <div><label class="block text-sm font-medium">Date of Birth</label><input type="date" name="dob" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm"></div>
              <div><label class="block text-sm font-medium">PAN Number</label><input type="text" name="pan_number" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm"></div>
            </div>
            <div class="flex justify-end gap-3 mt-6">
                <button type="button" onclick="closeModal('editProfileModal')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-300">Cancel</button>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-700">Save Changes</button>
            </div><div id="editProfileStatus" class="mt-2 text-sm text-center"></div>
        </form></div>
    </div>
  </div>

<script>
    
    tinymce.init({
        selector: '#updateNoteEditor', // हम यह ID अपने textarea को देंगे
        plugins: 'lists link image table code help wordcount',
        toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist outdent indent | link image',
        height: 200,
        menubar: false
    });
    // ========= HELPER FUNCTIONS =========
    function showTab(tabId) {
        document.querySelectorAll('.tab-content, .sidebar-item').forEach(el => el.classList.remove('active'));
        document.getElementById(tabId + '-content').classList.add('active');
        document.getElementById(tabId + '-tab').classList.add('active');
    }

    function openModal(modalId) {
        document.getElementById(modalId).classList.add('flex');
        setTimeout(() => document.getElementById(modalId).classList.add('visible'), 10);
    }
    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('visible');
            setTimeout(() => modal.classList.remove('flex'), 300);
        }
    }
    
    // ========= CLIENT RELATED FUNCTIONS =========
    async function showClientDetails(clientId) {
        const content = document.getElementById('clientDetailsContent');
        content.innerHTML = `<p class="text-center p-8">Loading client details...</p>`;
        openModal('clientDetailsModal');
        
        try {
            const response = await fetch(`api/get_client_details.php?id=${clientId}`);
            const data = await response.json();
            if (data.error) throw new Error(data.error);

            const { client, documents, messages } = data;
            const toTitleCase = (str) => str ? str.replace(/\w\S*/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()) : '';
            
            const nameTitle = toTitleCase(client.name || 'Client Name');
            const initials = (client.name || '').split(' ').filter(Boolean).slice(0, 2).map(n => n.charAt(0).toUpperCase()).join('');
            
            let profileImageHtml = `<div class="w-24 h-24 bg-blue-600 text-white flex items-center justify-center rounded-full text-4xl font-bold mb-2">${initials}</div>`;
            if (client.profile_photo_path) {
                profileImageHtml = `<img src="../${client.profile_photo_path}?t=${new Date().getTime()}" alt="Profile Photo" class="w-24 h-24 rounded-full mb-2 object-cover">`;
            }

            const phoneLink = client.phone ? `<a href="tel:${client.phone}" class="text-green-600 font-semibold hover:underline">${client.phone}</a>` : 'N/A';
            const emailLink = client.email ? `<a href="mailto:${client.email}" class="text-blue-600 font-semibold hover:underline">${client.email}</a>` : 'N/A';
            const panLink = client.pan_number ? `<a href="https://eportal.incometax.gov.in/iec/foservices/#/pre-login/link-aadhaar-status" target="_blank" class="font-semibold hover:underline">${client.pan_number}</a>` : 'N/A';

            let documentsHtml = '<p class="text-sm text-gray-500 px-3 py-2">No documents found.</p>';
            if (documents && documents.length > 0) {
                documentsHtml = documents.map(doc => `
                        <div class="flex justify-between items-center p-2.5 border-b last:border-b-0 hover:bg-gray-50">
                            <div><p class="text-sm font-medium text-gray-800">${doc.document_name}</p><p class="text-xs text-gray-500">Uploaded: ${new Date(doc.created_at).toLocaleDateString()}</p></div>
                            <a href="../${doc.file_path}" target="_blank" class="text-sm text-blue-600 hover:underline">View</a>
                        </div>`).join('');
            }
            
            let messagesHtml = '<p class="text-sm text-center text-gray-500 p-4">No messages yet.</p>';
            if (messages && messages.length > 0) {
                messagesHtml = messages.map(msg => {
                    const isAdmin = msg.sender_type === 'admin';
                    return `<div class="flex ${isAdmin ? 'justify-end' : 'justify-start'}"><div class="${isAdmin ? 'bg-blue-500 text-white' : 'bg-gray-200'} rounded-lg p-3 max-w-xs"><p class="text-sm">${msg.message}</p><p class="text-xs ${isAdmin ? 'text-blue-200' : 'text-gray-500'} text-right mt-1">${isAdmin ? 'Admin' : 'Client'} - ${new Date(msg.created_at).toLocaleString()}</p></div></div>`;
                }).join('');
            }

            content.innerHTML = `
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div class="lg:col-span-2 space-y-6">
                        <div class="bg-white rounded-lg shadow-md p-6 relative">
                            <h3 class="text-lg font-bold text-gray-800 mb-4">Personal Information</h3>
                            <div class="flex flex-col sm:flex-row items-center gap-6">
                                <div class="text-center flex-shrink-0">
                                    ${profileImageHtml}
                                    <input type="file" id="photoInput_${client.id}" onchange="handlePhotoUpload(${client.id})" class="hidden" accept="image/png, image/jpeg">
                                    <button onclick="document.getElementById('photoInput_${client.id}').click()" class="text-sm text-blue-600 font-semibold hover:underline">Upload Photo</button>
                                    <button onclick='openEditProfileModal(${JSON.stringify(client)})' class="mt-2 w-full bg-blue-50 text-blue-600 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-blue-100 flex items-center justify-center gap-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" /></svg>
                                        Edit Profile
                                    </button>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 flex-1 w-full">
                                    <div><p class="font-medium text-gray-500 text-sm">Full Name</p><p class="text-gray-800 font-semibold">${nameTitle}</p></div>
                                    <div><p class="font-medium text-gray-500 text-sm">Date of Birth</p><p class="font-semibold">${client.dob ? new Date(client.dob).toLocaleDateString() : 'N/A'}</p></div>
                                    <div><p class="font-medium text-gray-500 text-sm">Email ID</p>${emailLink}</div>
                                    <div><p class="font-medium text-gray-500 text-sm">Mobile Number</p>${phoneLink}</div>
                                    <div><p class="font-medium text-gray-500 text-sm">PAN Number</p>${panLink}</div>
                                    <div><p class="font-medium text-gray-500 text-sm">Join Date</p><p class="font-semibold">${client.created_at ? new Date(client.created_at).toLocaleDateString() : 'N/A'}</p></div>
                                    <div><p class="font-medium text-gray-500 text-sm">Status</p><span class="px-2 py-1 text-xs font-semibold rounded-full ${client.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">${toTitleCase(client.status || 'inactive')}</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white rounded-lg shadow-md p-6">
                            <div class="flex justify-between items-center mb-4"><h3 class="text-lg font-bold text-gray-800">Work Status</h3>
                                <div class="flex space-x-2">
                                    <button onclick="openWorkModalForCreate(${client.id}, '${nameTitle.replace(/'/g, "\\'")}')" class="bg-purple-600 text-white px-3 py-2 rounded-lg text-sm font-semibold hover:bg-purple-700 flex items-center gap-1">+ Create Work</button>
                                    <button onclick="openViewWorkListModal(${client.id}, '${nameTitle.replace(/'/g, "\\'")}')" class="bg-blue-600 text-white px-3 py-2 rounded-lg text-sm font-semibold hover:bg-blue-700">View Work List</button>
                                </div>
                            </div>
                            <div id="workStatusSummary"></div>
                        </div>
                        <div class="bg-white rounded-lg shadow-md p-6"><div class="flex justify-between items-center mb-4"><h3 class="font-bold text-lg">Documents (${documents.length || 0})</h3><button onclick="document.getElementById('uploadFormContainer').classList.toggle('hidden')" class="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-purple-700 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clip-rule="evenodd" /></svg>Upload Document</button></div><div id="uploadFormContainer" class="hidden my-4 p-4 bg-gray-50 rounded-lg border"><form id="uploadForm" onsubmit="uploadDocument(event)" enctype="multipart/form-data"><input type="hidden" name="client_id" value="${client.id}"><input type="text" name="document_name" placeholder="Document Name" required class="w-full p-2 border rounded-md mb-2 text-sm"><input type="file" name="document_file" required class="w-full text-sm p-1"><button type="submit" class="w-full mt-3 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Upload</button><div id="uploadStatus" class="mt-2 text-sm text-center"></div></form></div><div class="border rounded-md"><div id="documentsList" class="space-y-0 max-h-48 overflow-y-auto">${documentsHtml}</div></div></div>
                    </div>
                    <div class="lg:col-span-1 bg-white rounded-lg shadow-md flex flex-col h-[650px]">
                        <h3 class="font-bold text-lg p-4 border-b">Messages</h3>
                        <div id="messagesContainer" class="flex-1 p-4 space-y-4 overflow-y-auto chat-box">${messagesHtml}</div>
                        <div class="p-4 border-t bg-white rounded-b-lg"><form id="sendMessageForm" onsubmit="sendMessage(event)"><input type="hidden" name="client_id" value="${client.id}"><div class="flex items-center gap-2"><input type="text" name="message" placeholder="Type your message..." class="w-full p-2 border rounded-md text-sm focus:ring-blue-500 focus:border-blue-500" required><button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-blue-700">Send</button></div></form></div>
                    </div>
                </div>
            `;
            const chatBox = document.getElementById('messagesContainer');
            if(chatBox) chatBox.scrollTop = chatBox.scrollHeight;
        } catch (err) {
            content.innerHTML = `<p class="text-red-500 text-center p-8">Error: ${err.message}</p>`;
        }
    }
    
    function openEditProfileModal(client) {
        const form = document.getElementById('editProfileForm');
        form.reset();
        form.client_id.value = client.id;
        form.first_name.value = client.first_name;
        form.last_name.value = client.last_name;
        form.email.value = client.email;
        form.phone.value = client.phone;
        form.dob.value = client.dob;
        form.pan_number.value = client.pan_number;
        document.getElementById('editProfileStatus').innerText = '';
        openModal('editProfileModal');
    }

    async function handleProfileUpdate(event) {
        event.preventDefault();
        const form = event.target;
        const statusDiv = document.getElementById('editProfileStatus');
        const submitButton = form.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        statusDiv.className = 'mt-2 text-sm text-center text-blue-600';
        statusDiv.textContent = 'Saving...';
        
        try {
            const response = await fetch('api/update_profile.php', { method: 'POST', body: new FormData(form) });
            const result = await response.json();
            if (result.success) {
                statusDiv.className = 'mt-2 text-sm text-center text-green-600';
                statusDiv.textContent = 'Profile updated successfully!';
                setTimeout(() => {
                    closeModal('editProfileModal');
                    showClientDetails(form.client_id.value);
                }, 1500);
            } else { throw new Error(result.error || 'Failed to update profile.'); }
        } catch(error) {
            statusDiv.className = 'mt-2 text-sm text-center text-red-600';
            statusDiv.textContent = error.message;
        } finally {
            submitButton.disabled = false;
        }
    }

    async function handlePhotoUpload(clientId) {
        const fileInput = document.getElementById(`photoInput_${clientId}`);
        const file = fileInput.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('client_id', clientId);
        formData.append('profile_photo', file);

        try {
            const response = await fetch('api/upload_photo.php', { method: 'POST', body: formData });
            const result = await response.json();
            if (result.success) {
                alert('Photo uploaded successfully!');
                showClientDetails(clientId);
            } else { throw new Error(result.error || 'Failed to upload photo.'); }
        } catch (error) {
            alert(error.message);
        }
    }
    
    async function sendMessage(event) {
        event.preventDefault();
        const form = event.target;
        const input = form.querySelector('input[name="message"]');
        const clientId = form.querySelector('input[name="client_id"]').value;
        if (!input.value.trim()) return;
        try {
            const response = await fetch('api/send_message.php', { method: 'POST', body: new FormData(form) });
            const result = await response.json();
            if (result.success) {
                input.value = '';
                showClientDetails(clientId);
            } else { alert('Error: ' + result.error); }
        } catch (error) { console.error('Send message error:', error); }
    }

    async function uploadDocument(event) {
        event.preventDefault();
        const form = document.getElementById('uploadForm');
        const statusDiv = document.getElementById('uploadStatus');
        const fileInput = form.querySelector('input[type="file"]');
        const clientId = form.querySelector('input[name="client_id"]').value;
        if (!fileInput.files || fileInput.files.length === 0) {
            statusDiv.textContent = 'Please select a file to upload.';
            return;
        }
        statusDiv.textContent = 'Uploading...';
        try {
            const response = await fetch('api/upload_document.php', { method: 'POST', body: new FormData(form) });
            const result = await response.json();
            if (result.success) {
                statusDiv.textContent = 'Upload successful!';
                form.reset();
                showClientDetails(clientId);
            } else { statusDiv.textContent = 'Error: ' + result.error; }
        } catch(err) { statusDiv.textContent = 'Upload failed.'; }
    }
    

    // ========= WORK RELATED FUNCTIONS (UPDATED & NEW) =========
    
    function openWorkModalForCreate(clientId, clientName) {
        document.getElementById('workForm').reset();
        document.getElementById('workId').value = '';
        document.getElementById('workClientId').value = clientId;
        document.getElementById('workModalTitle').innerText = `Create Work List - ${clientName}`;
        document.getElementById('workSubmitButton').innerText = 'Create Work List';
        document.getElementById('workStatus').innerText = '';
        openModal('workModal');
    }

    async function openWorkModalForEdit(workId, clientId, clientName) {
        document.getElementById('workForm').reset();
        document.getElementById('workModalTitle').innerText = `Edit Work - ${clientName}`;
        document.getElementById('workSubmitButton').innerText = 'Save Changes';
        document.getElementById('workStatus').innerText = '';
        
        try {
            const response = await fetch(`api/get_work_details.php?work_id=${workId}&client_id=${clientId}`);
            const data = await response.json();
            if (data.error) throw new Error(data.error);
            
            const work = data.work; // Extract work object
            if (!work) throw new Error('Work data is missing in the API response.');

            document.getElementById('workId').value = work.id;
            document.getElementById('workClientId').value = clientId;
            const form = document.getElementById('workForm');
            form.company_name.value = work.company_name;
            form.folio_number.value = work.folio_number;
            form.rta_contact_number.value = work.rta_contact_number;
            form.rta_email.value = work.rta_email;
            form.service_type.value = work.service_type;
            form.initial_notes.value = work.initial_notes;
            openModal('workModal');
        } catch (error) {
            alert('Error fetching work details: ' + error.message);
        }
    }

    async function handleWorkSubmit(event) {
        event.preventDefault();
        const form = event.target;
        const statusDiv = document.getElementById('workStatus');
        const submitButton = form.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        statusDiv.textContent = 'Saving...';

        const workId = document.getElementById('workId').value;
        const apiEndpoint = workId ? 'api/update_work.php' : 'api/create_work.php';
        const formData = new FormData(form);

        if (workId) {
             formData.append('work_id', workId);
        }

        try {
            const response = await fetch(apiEndpoint, { method: 'POST', body: formData });
            const result = await response.json();
            if (result.success) {
                statusDiv.textContent = 'Work saved successfully!';
                setTimeout(() => {
                    closeModal('workModal');
                    const clientId = document.getElementById('workClientId').value;
                    showClientDetails(clientId);
                }, 1500);
            } else {
                throw new Error(result.error || 'Failed to save work.');
            }
        } catch (error) {
            statusDiv.textContent = error.message;
        } finally {
            submitButton.disabled = false;
        }
    }

    // NEW: openWorkDetailsPage replaces modal navigation — opens the new full page view in a NEW TAB
    function openWorkDetailsPage(workId, clientId) {
        const url = `work_details.php?work_id=${encodeURIComponent(workId)}&client_id=${encodeURIComponent(clientId||'')}`;
        // Open in new tab/window so admin sees full page (not modal)
        window.open(url, '_blank');
    }

    async function openViewWorkListModal(clientId, clientName) {
        const content = document.getElementById('workListContent');
        if (clientName) {
            document.getElementById('viewWorkListTitle').innerText = `Work List - ${clientName}`;
        }
        content.innerHTML = '<p class="text-center p-8">Loading work list...</p>';
        openModal('viewWorkListModal');

        try {
            const response = await fetch(`api/get_work_list.php?client_id=${clientId}`);
            const works = await response.json();
            if (works.error) throw new Error(works.error);

            if (works.length === 0) {
                content.innerHTML = '<p class="text-center p-8">No work items found.</p>';
                return;
            }

            let tableHtml = `<div class="overflow-x-auto"><table class="min-w-full divide-y divide-gray-200"><thead class="bg-gray-50"><tr>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Company</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Service</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">RTA Contact</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">RTA Email</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Actions</th></tr></thead><tbody>`;
            works.forEach(work => {
                const emailLink = work.rta_email ? `<a href="mailto:${work.rta_email}" class="text-blue-600 hover:underline">${work.rta_email}</a>` : 'N/A';
                tableHtml += `<tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 whitespace-nowrap font-medium">${work.company_name}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm">${work.service_type}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm">${work.rta_contact_number || 'N/A'}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm">${emailLink}</td>
                    <td class="px-4 py-3 whitespace-nowrap"><span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">${work.status}</span></td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm">
                        <button onclick="openWorkDetailsPage(${work.id}, ${clientId})" class="bg-green-100 text-green-700 px-3 py-1 rounded-md text-xs font-semibold hover:bg-green-200">View / Update</button>
                    </td></tr>`;
            });
            tableHtml += '</tbody></table></div>';
            content.innerHTML = tableHtml;
        } catch (error) { content.innerHTML = `<p class="text-center text-red-500 p-8">${error.message}</p>`; }
    }
    
    // ===== WORK DETAILS MODAL FUNCTIONS =====

// ===== यहाँ से कॉपी करना शुरू करें =====

async function openWorkDetailsModal(workId, clientId, clientName) {
    const content = document.getElementById('workDetailsContent');
    document.getElementById('workDetailsTitle').innerText = `Updating Work for ${clientName}`;
    content.innerHTML = '<p class="text-center p-8">Loading work details...</p>';
    openModal('workDetailsModal');
    if (document.getElementById('viewWorkListModal')) { closeModal('viewWorkListModal'); }

    try {
        const response = await fetch(`api/get_work_details.php?work_id=${workId}&client_id=${clientId}`);
        const data = await response.json();
        if (data.error) throw new Error(data.error);

        const { work, updates, documents } = data;
        if (!work) throw new Error('Work data could not be loaded from the server.');

        let updatesHtml = '<p class="text-sm text-gray-500 p-3">No updates yet.</p>';
        if(updates && updates.length > 0) {
            updatesHtml = updates.map(up => {
    let documentsHtml = '';
    // अब हम documents ऐरे पर लूप चलाएंगे
    if (up.documents && up.documents.length > 0) {
        documentsHtml = up.documents.map(doc => 
            `<a href="../${doc.file_path}" target="_blank" class="text-sm text-blue-600 hover:underline font-semibold ml-2">[${doc.document_name}]</a>`
        ).join('');
    }

    return `
    <div class="p-3 bg-gray-50 border-b">
        <p class="text-sm text-gray-800">${up.update_note}</p>
        <div class="flex justify-end items-center mt-1">
            <p class="text-xs text-gray-500">${new Date(up.created_at).toLocaleString()}</p>
            ${documentsHtml}
        </div>
    </div>`;
}).join('');
        }

        let documentsHtml = '<p class="text-sm text-gray-500 p-3">No documents for this work item.</p>';
        if(documents && documents.length > 0) {
            documentsHtml = documents.map(doc => `<div class="flex justify-between items-center p-3 border-b hover:bg-gray-50"><p class="text-sm font-medium">${doc.document_name}</p><a href="../${doc.file_path}" target="_blank" class="text-sm text-blue-600 hover:underline">View Document</a></div>`).join('');
        }

        content.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-6">
                    <div class="bg-white rounded-lg shadow p-5">
                        <div class="flex justify-between items-center mb-3"><h3 class="text-lg font-bold">Work Details</h3><button onclick="openWorkModalForEdit(${work.id}, ${work.client_id}, '${(clientName||'').replace(/'/g, "\\'")}')" class="text-sm bg-blue-100 text-blue-700 px-3 py-1 rounded-md font-semibold hover:bg-blue-200">Edit Details</button></div>
                        <div class="grid grid-cols-2 gap-4 text-sm">
                            <div><p class="font-medium text-gray-500">Company</p><p class="font-semibold">${work.company_name}</p></div>
                            <div><p class="font-medium text-gray-500">Service</p><p class="font-semibold">${work.service_type}</p></div>
                            <div><p class="font-medium text-gray-500">Folio Number</p><p class="font-semibold">${work.folio_number || 'N/A'}</p></div>
                            <div><p class="font-medium text-gray-500">Status</p><p class="font-semibold">${work.status}</p></div>
                            <div><p class="font-medium text-gray-500">RTA Contact</p><p class="font-semibold">${work.rta_contact_number || 'N/A'}</p></div>
                            <div><p class="font-medium text-gray-500">RTA Email</p><p class="font-semibold">${work.rta_email || 'N/A'}</p></div>
                            <div class="col-span-2"><p class="font-medium text-gray-500">Initial Notes</p><p class="text-gray-700 whitespace-pre-wrap">${work.initial_notes || 'N/A'}</p></div>
                        </div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-5">
                        <h3 class="text-lg font-bold mb-3">Add New Update</h3>
                        <form id="addWorkUpdateForm" onsubmit="handleAddWorkUpdate(event)" enctype="multipart/form-data">
                            <input type="hidden" name="work_id" value="${work.id}">
                            <input type="hidden" name="client_id_for_refresh" value="${work.client_id}">
                            <label class="block text-sm font-medium text-gray-700">Update Note</label>
                            
                            <textarea id="updateNoteEditor" name="update_note" rows="3" class="w-full p-2 border rounded-md mb-2" placeholder="Type update here..."></textarea>
                            
                            <label class="block text-sm font-medium text-gray-700">Attach Document(s) (Optional)</label>
                            <input type="file" name="update_document[]" class="w-full text-sm p-1 border rounded-md" multiple>
                            <button type="submit" class="w-full mt-3 bg-purple-600 text-white font-semibold py-2 rounded-md hover:bg-purple-700">Add Update</button>
                        </form>
                    </div>
                </div>
                <div class="space-y-6 mt-6">
                    <div class="bg-white rounded-lg shadow"><h3 class="text-lg font-bold p-5 border-b">Updates Log</h3><div class="max-h-60 overflow-y-auto">${updatesHtml}</div></div>
                    <div class="bg-white rounded-lg shadow p-5"><h3 class="text-lg font-bold mb-3">Work Documents</h3><form class="mb-4 p-4 bg-gray-50 border rounded-md" onsubmit="handleWorkDocumentUpload(event)"><input type="hidden" name="work_id" value="${work.id}"><input type="text" name="document_name" placeholder="Document Name (e.g., PAN Card)" required class="w-full p-2 border rounded-md mb-2"><input type="file" name="work_document" required class="w-full text-sm"><button type="submit" class="w-full mt-2 bg-blue-600 text-white font-semibold py-2 rounded-md hover:bg-blue-700">Upload Document</button></form><div class="border rounded-md max-h-48 overflow-y-auto">${documentsHtml}</div></div>
                </div>
            `;

        // TinyMCE को शुरू करने के लिए यह ज़रूरी है
        setTimeout(() => {
            try {
                tinymce.remove('#updateNoteEditor');
            } catch(e) {}
            tinymce.init({
                selector: '#updateNoteEditor',
                plugins: 'lists link image table code help wordcount',
                toolbar: 'undo redo | blocks | bold italic | alignleft aligncenter alignright | bullist numlist outdent indent | link image',
                height: 200,
                menubar: false
            });
        }, 100);

    } catch(err) {
        content.innerHTML = `<p class="text-red-500 text-center p-8">${err.message}</p>`;
    }
}

async function handleAddWorkUpdate(event) {
    event.preventDefault();
    const form = event.target;
    
    // एडिटर से कंटेंट इस तरह पाएं
    const updateNoteContent = tinymce.get('updateNoteEditor').getContent();
    if (!updateNoteContent) {
        alert('Please write an update note.');
        return;
    }
    
    const formData = new FormData(form);
    formData.set('update_note', updateNoteContent); // फॉर्म डेटा में एडिटर का कंटेंट डालें

    const workId = form.work_id.value;
    const clientId = form.client_id_for_refresh.value;
    const button = form.querySelector('button[type="submit"]');
    
    button.disabled = true;
    button.textContent = 'Saving...';
    
    try {
        const response = await fetch('api/add_work_update.php', { method: 'POST', body: formData });
        const result = await response.json();
        
        if (result.success) {
            tinymce.get('updateNoteEditor').setContent('');
            form.reset();
            const clientName = document.getElementById('workDetailsTitle').innerText.replace('Updating Work for ', '');
            openWorkDetailsModal(workId, clientId, clientName);
        } else {
            throw new Error(result.error || 'An unknown error occurred.');
        }
    } catch(err) {
        alert('Error adding update: ' + err.message);
    } finally {
        button.disabled = false;
        button.textContent = 'Add Update';
    }
}

    async function handleWorkDocumentUpload(event) {
        event.preventDefault();
        const form = event.target;
        const workId = form.work_id.value;
        const button = form.querySelector('button');
        button.disabled = true;
        button.textContent = 'Uploading...';
        
        try {
            const response = await fetch('api/upload_work_document.php', { method: 'POST', body: new FormData(form) });
            const result = await response.json();
            if (result.success) {
                form.reset();
                const clientName = document.getElementById('workDetailsTitle').innerText.replace('Updating Work for ', '');
                const clientId = document.querySelector('#addWorkUpdateForm input[name="client_id_for_refresh"]').value;
                openWorkDetailsModal(workId, clientId, clientName);

            } else {
                throw new Error(result.error);
            }
        } catch(err) {
            alert('Error uploading document: ' + err.message);
        } finally {
            button.disabled = false;
            button.textContent = 'Upload Document';
        }
    }

    // ========= NEW: SETTINGS-SPECIFIC FUNCTIONS =========
    function showSettingsSubTab(tabId) {
      document.querySelectorAll('.sub-tab-content').forEach(el => el.style.display = 'none');
      document.getElementById(tabId + '-subtab').style.display = 'block';
      document.querySelectorAll('.active-sub-tab').forEach(el => el.classList.remove('active-sub-tab'));
      document.getElementById(tabId + '-tab').classList.add('active-sub-tab');

      if (tabId === 'admin-settings') {
          loadAdminProfile();
      } else if (tabId === 'client-settings') {
          loadClientList();
      }
    }

    async function loadAdminProfile() {
      const content = document.getElementById('admin-profile-content');
      content.innerHTML = '<p>Loading admin profile...</p>';
      try {
          const response = await fetch('api/get_admin_profile.php');
          const data = await response.json();
          if (data.success) {
              const profile = data.profile;
              content.innerHTML = `
                  <form id="adminProfileForm" onsubmit="updateAdminProfile(event)">
                      <div class="space-y-4">
                          <div>
                              <label class="block text-sm font-medium">First Name</label>
                              <input type="text" name="first_name" value="${profile.first_name}" class="mt-1 w-full border rounded-md p-2">
                          </div>
                          <div>
                              <label class="block text-sm font-medium">Last Name</label>
                              <input type="text" name="last_name" value="${profile.last_name}" class="mt-1 w-full border rounded-md p-2">
                          </div>
                          <div>
                              <label class="block text-sm font-medium">Email</label>
                              <input type="email" name="email" value="${profile.email}" class="mt-1 w-full border rounded-md p-2">
                          </div>
                          <div>
                              <label class="block text-sm font-medium">Phone</label>
                              <input type="text" name="phone" value="${profile.phone}" class="mt-1 w-full border rounded-md p-2">
                          </div>
                          <div class="flex justify-between items-center bg-white p-3 rounded-lg border">
                              <p class="text-sm font-medium">Password</p>
                              <button type="button" onclick="openPasswordChangeModal()" class="text-sm text-blue-600 hover:underline font-semibold">Change Password</button>
                          </div>
                      </div>
                      <div class="flex justify-end gap-3 mt-4">
                          <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md font-semibold">Save Changes</button>
                      </div>
                      <div id="adminProfileStatus" class="mt-2 text-sm text-center"></div>
                  </form>
              `;
          } else {
              content.innerHTML = `<p class="text-red-500">${data.error}</p>`;
          }
      } catch (error) {
          content.innerHTML = `<p class="text-red-500">Error fetching profile.</p>`;
      }
    }

    async function updateAdminProfile(event) {
        event.preventDefault();
        const form = event.target;
        const statusDiv = document.getElementById('adminProfileStatus');
        const button = form.querySelector('button[type="submit"]');
        button.disabled = true;
        statusDiv.textContent = 'Saving...';
        try {
            const response = await fetch('api/update_admin_profile.php', { method: 'POST', body: new FormData(form) });
            const result = await response.json();
            if (result.success) {
                statusDiv.textContent = 'Profile updated successfully!';
                statusDiv.className = 'mt-2 text-sm text-center text-green-600';
            } else {
                throw new Error(result.error);
            }
        } catch (error) {
            statusDiv.textContent = 'Error: ' + error.message;
            statusDiv.className = 'mt-2 text-sm text-center text-red-600';
        } finally {
            button.disabled = false;
        }
    }

    async function loadClientList() {
      const content = document.getElementById('client-list-content');
      content.innerHTML = '<p>Loading client list...</p>';
      try {
        const response = await fetch('api/get_client_list.php');
        const data = await response.json();
        if (data.success) {
          if (data.clients.length === 0) {
            content.innerHTML = '<p>No clients found.</p>';
            return;
          }
          let tableHtml = `<div class="overflow-x-auto"><table class="min-w-full divide-y divide-gray-200"><thead class="bg-gray-50"><tr>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Password</th>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Actions</th></tr></thead><tbody>`;
          data.clients.forEach(client => {
            tableHtml += `<tr class="hover:bg-gray-50">
              <td class="px-4 py-3 whitespace-nowrap font-medium">${client.name}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm">${client.email}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm">${client.id}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm">${client.password}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm">
                <button onclick="resetClientPassword(${client.id})" class="bg-purple-100 text-purple-700 px-3 py-1 rounded-md text-xs font-semibold hover:bg-purple-200">Reset Password</button>
              </td></tr>`;
          });
          tableHtml += '</tbody></table></div>';
          content.innerHTML = tableHtml;
        } else {
          content.innerHTML = `<p class="text-red-500">${data.error}</p>`;
        }
      } catch (error) {
        content.innerHTML = `<p class="text-red-500">Error fetching client list.</p>`;
      }
    }

    async function resetClientPassword(clientId) {
      const confirmation = confirm('Are you sure you want to reset this client\'s password? A new password will be sent to their email.');
      if (!confirmation) {
          return;
      }
      try {
          const formData = new FormData();
          formData.append('client_id', clientId);
          const response = await fetch('api/reset_client_password.php', { method: 'POST', body: formData });
          const result = await response.json();
          if (result.success) {
              alert('Password reset successfully! A new password has been sent to the client.');
          } else {
              throw new Error(result.error);
          }
      } catch (error) {
          alert('Error resetting password: ' + error.message);
      }
    }

    function openPasswordChangeModal() {
        const modal = document.createElement('div');
        modal.id = 'passwordChangeModal';
        modal.classList.add('modal', 'flex', 'visible', 'z-50', 'fixed', 'inset-0', 'bg-black', 'bg-opacity-60', 'items-center', 'justify-center', 'p-4');
        modal.innerHTML = `
            <div class="bg-white w-full max-w-md rounded-lg shadow-xl">
                <div class="p-4 border-b flex justify-between items-center">
                    <h2 class="text-xl font-bold text-gray-800">Change Admin Password</h2>
                    <button onclick="closeModal('passwordChangeModal')" class="text-gray-500 hover:text-red-600 text-3xl">&times;</button>
                </div>
                <div class="p-6">
                    <form id="passwordChangeForm" onsubmit="handlePasswordChange(event)">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium">Current Password</label>
                                <input type="password" name="current_password" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium">New Password</label>
                                <input type="password" name="new_password" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium">Confirm New Password</label>
                                <input type="password" name="confirm_password" class="mt-1 w-full border-gray-300 rounded-md p-2 shadow-sm" required>
                            </div>
                        </div>
                        <div class="flex justify-end gap-3 mt-6">
                            <button type="button" onclick="closeModal('passwordChangeModal')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-300">Cancel</button>
                            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-700">Change Password</button>
                        </div>
                        <div id="passwordChangeStatus" class="mt-2 text-sm text-center"></div>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    async function handlePasswordChange(event) {
      event.preventDefault();
      const form = event.target;
      const statusDiv = document.getElementById('passwordChangeStatus');
      const button = form.querySelector('button[type="submit"]');
      button.disabled = true;
      statusDiv.textContent = 'Changing password...';

      const newPassword = form.new_password.value;
      const confirmPassword = form.confirm_password.value;

      if (newPassword !== confirmPassword) {
        statusDiv.textContent = 'New passwords do not match!';
        statusDiv.className = 'mt-2 text-sm text-center text-red-600';
        button.disabled = false;
        return;
      }

      try {
        const response = await fetch('api/change_admin_password.php', { method: 'POST', body: new FormData(form) });
        const result = await response.json();
        if (result.success) {
          statusDiv.textContent = 'Password changed successfully!';
          statusDiv.className = 'mt-2 text-sm text-center text-green-600';
          setTimeout(() => closeModal('passwordChangeModal'), 1500);
        } else {
          throw new Error(result.error);
        }
      } catch (error) {
        statusDiv.textContent = 'Error: ' + error.message;
        statusDiv.className = 'mt-2 text-sm text-center text-red-600';
      } finally {
        button.disabled = false;
      }
    }

    document.addEventListener('DOMContentLoaded', () => {
        showTab('clients');
    });

    async function createAdminUser(event) {
        event.preventDefault();
        const form = event.target;
        const statusDiv = document.getElementById('createAdminStatus');
        const button = form.querySelector('button');
        button.disabled = true;
        statusDiv.textContent = 'Creating user...';
        try {
            const response = await fetch('api/register_admin.php', {
                method: 'POST',
                body: new FormData(form)
            });
            const result = await response.json();
            if (result.success) {
                statusDiv.textContent = 'Admin user created successfully!';
                statusDiv.className = 'mt-2 text-sm text-center text-green-600';
                form.reset();
            } else {
                throw new Error(result.error);
            }
        } catch (error) {
            statusDiv.textContent = 'Error: ' + error.message;
            statusDiv.className = 'mt-2 text-sm text-center text-red-600';
        } finally {
            button.disabled = false;
        }
    }
</script>
</body>
</html>